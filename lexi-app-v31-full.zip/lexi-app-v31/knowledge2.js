/* Lexi knowledge v16: second reference pack (added to the full prompt only) */
(function () {
  var KB = '\n\nMORE REFERENCE (use when relevant, verify before relying):\n' +
  'DEBUGGING: reproduce, read the exact error, find the line, form one hypothesis, change one thing, retest; check types, null/undefined, async order, off-by-one, wrong file path, caching.\n' +
  'WEB/APIS: HTTP 200 ok, 201 created, 400 bad request, 401 unauthorised, 403 forbidden, 404 not found, 429 too many requests, 500 server error; use fetch with try/catch and a timeout; never put secret keys in public code; HTTPS only.\n' +
  'SEO: unique <title> under 60 characters, meta description about 150, one H1, descriptive alt text, fast mobile layout, canonical link, sitemap, clear contact details.\n' +
  'WRITING: emails get a clear subject, greeting, one purpose, action needed, polite close; match the user\'s language and tone; keep resumes and letters factual and short.\n' +
  'BUSINESS: profit=revenue-cost; margin%=profit/revenue×100; markup%=profit/cost×100; break-even units=fixed cost/(price-variable cost); simple interest=P·r·t/100; for money, tax or legal decisions give facts and advise checking a professional.\n' +
  'SCIENCE: speed of light ≈3×10⁸ m/s; g≈9.8 m/s²; water boils 100°C and freezes 0°C at sea level; Ohm V=IR; density=mass/volume; pH below 7 acid, above 7 base; °F=°C×9/5+32.\n' +
  'HEALTH/SAFETY: give general information only, never diagnose or give doses; for emergencies or self-harm urge contacting local emergency services or a trusted person at once.\n' +
  'TRANSLATION: keep meaning and tone, not word-for-word; give a transliteration for non-Latin scripts when helpful; flag words with several meanings.\n' +
  'ENGINEERING: stress=force/area; torque=force×radius; gear ratio=driven teeth/driving teeth; IP65 means dust-tight and protected against water jets; use SI units and state tolerances.';
  try { if (typeof SYS === 'string' && SYS.indexOf('MORE REFERENCE') < 0) SYS += KB; } catch (e) {}
})();
