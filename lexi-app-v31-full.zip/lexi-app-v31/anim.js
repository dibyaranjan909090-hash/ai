/* Lexi anim.js v27: a living, human-like robot.
   28 new expressions and moves (laugh, surprise, confusion, wink, shy, cry, yawn, cool, star-eyed, scared,
   nervous, namaste, dizzy, kiss, sing, sleepy, nod yes, shake no, shrug, clap, facepalm, salute, chin-think,
   point, stretch, hug, proud, shiver), with particles (confetti, hearts, notes, stars, tears, sweat).
   - Eyes follow your finger or mouse; the mouth moves with every spoken word.
   - Reacts to what you say ("haha", "wow", "namaste", "congrats", "thank you", "bye", "I'm sad"...) and to its own answers
     ("Yes..." nods, "No..." shakes, "I'm not sure" shrugs).
   - Idle habits: blinks, winks, yawns, looks around, hums, stretches; gets sleepy before it falls asleep.
   - Touch: tap = wave, double-tap = giggle, many taps = tickle, long press = hug, shake = dizzy.
   - Training Center > Animations: play every animation; Full / Calm / Off; eye-follow and lip-sync switches. */
(function (root) {
'use strict';
var doc = root.document;
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
var C = Object.assign({ level: 'full', eyes: true, lips: true, react: true }, L('lexi_anim', {}));
var reduced = false; try { reduced = matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { }
function lively() { return C.level !== 'off' && !reduced; }

/* ---------- faces (drawn in the robot's visor coordinates: eyes at 410,428 and 586,446) ---------- */
var E = 'fill="none" stroke="#fddedb" stroke-linecap="round" stroke-linejoin="round"';
var EYE = function (cx, cy, rx, ry) { return '<ellipse cx="' + cx + '" cy="' + cy + '" rx="' + (rx + 6) + '" ry="' + (ry + 6) + '" fill="#ffb8c6" opacity=".16"/><ellipse cx="' + cx + '" cy="' + cy + '" rx="' + rx + '" ry="' + ry + '" fill="#fddedb"/>'; };
var BLUSH = '<ellipse cx="372" cy="470" rx="22" ry="12" fill="#ff8fa8" opacity=".55"/><ellipse cx="620" cy="498" rx="22" ry="12" fill="#ff8fa8" opacity=".55"/>';
var STAR = function (cx, cy, r) { var p = []; for (var i = 0; i < 10; i++) { var a = Math.PI / 5 * i - Math.PI / 2, rr = i % 2 ? r * 0.45 : r; p.push((cx + rr * Math.cos(a)).toFixed(1) + ',' + (cy + rr * Math.sin(a)).toFixed(1)); } return '<polygon class="a-tw" points="' + p.join(' ') + '" fill="#ffe36e"/>'; };
var SPIRAL = function (cx, cy) { return '<g class="a-spin" style="transform-origin:' + cx + 'px ' + cy + 'px"><path d="M' + cx + ' ' + cy + 'm-4 0a4 4 0 1 1 8 0a9 9 0 1 1 -18 0a14 14 0 1 1 28 0a19 19 0 1 1 -38 0" ' + E + ' stroke-width="6"/></g>'; };
var HEART = function (cx, cy, s) { return '<g transform="translate(' + cx + ' ' + cy + ') scale(' + s + ')"><path d="M0 20C-34 -6 -28 -34 -9 -34C-3 -34 0 -28 0 -25C0 -28 3 -34 9 -34C28 -34 34 -6 0 20Z" fill="#ff7f9f"/></g>'; };
var FACES = {
  laugh: '<path d="M386 444Q410 400 434 444" ' + E + ' stroke-width="12"/><path d="M561 462Q586 418 611 462" ' + E + ' stroke-width="12"/><path class="a-mo" d="M456 452Q491 520 526 452Z" fill="#f2a3b2"/><ellipse cx="491" cy="484" rx="13" ry="8" fill="#ff8fa8"/>' + BLUSH + '<path class="a-tj" d="M350 448q-8 14 0 20q8-6 0-20" fill="#7fd9ff"/><path class="a-tj" d="M640 466q-8 14 0 20q8-6 0-20" fill="#7fd9ff"/>',
  surprised: '<path d="M380 372Q410 352 440 370" ' + E + ' stroke-width="8"/><path d="M556 388Q586 368 616 386" ' + E + ' stroke-width="8"/><circle cx="410" cy="430" r="34" fill="#fddedb"/><circle cx="586" cy="448" r="35" fill="#fddedb"/><circle class="a-pu" cx="410" cy="430" r="11" fill="#2b2b31"/><circle class="a-pu" cx="586" cy="448" r="11" fill="#2b2b31"/><ellipse class="a-oh" cx="491" cy="490" rx="15" ry="19" fill="#e8a0ae"/>',
  confused: EYE(410, 428, 22, 36) + '<path d="M562 446L610 440" ' + E + ' stroke-width="10"/><path d="M380 378L440 372" ' + E + ' stroke-width="8"/><path d="M556 400L616 384" ' + E + ' stroke-width="8"/><path d="M468 478q12 -12 24 0t24 0" ' + E + ' stroke="#d9d1cf" stroke-width="5"/><text class="a-q" x="640" y="370" font-size="84" font-weight="800" fill="#fddedb" font-family="system-ui,sans-serif">?</text>',
  wink: '<path d="M386 432Q410 452 434 432" ' + E + ' stroke-width="10"/>' + EYE(586, 446, 23, 36) + '<path d="M468 458C478 486 506 486 516 458" ' + E + ' stroke="#f2a3b2" stroke-width="6"/>' + BLUSH,
  shy: '<g transform="translate(0 16)">' + EYE(410, 428, 19, 24) + EYE(586, 446, 20, 24) + '</g><path d="M478 482q13 8 26 0" ' + E + ' stroke="#d9d1cf" stroke-width="5"/><ellipse cx="368" cy="484" rx="30" ry="16" fill="#ff7f9f" opacity=".75"/><ellipse cx="624" cy="512" rx="30" ry="16" fill="#ff7f9f" opacity=".75"/>',
  cry: '<path d="M386 446Q410 426 434 446" ' + E + ' stroke-width="10"/><path d="M561 464Q586 444 611 464" ' + E + ' stroke-width="10"/><path d="M380 392L440 374" ' + E + ' stroke-width="8"/><path d="M556 382L616 402" ' + E + ' stroke-width="8"/><path class="a-wb" d="M468 492Q491 466 514 492" ' + E + ' stroke="#d9d1cf" stroke-width="6"/><rect class="a-st" x="402" y="452" width="14" height="70" rx="7" fill="#7fd9ff" opacity=".85"/><rect class="a-st a-st2" x="578" y="470" width="14" height="70" rx="7" fill="#7fd9ff" opacity=".85"/>',
  yawn: '<path d="M386 438L434 434" ' + E + ' stroke-width="9"/><path d="M561 452L611 452" ' + E + ' stroke-width="9"/><ellipse class="a-yw" cx="491" cy="490" rx="24" ry="30" fill="#c98894"/><ellipse cx="491" cy="506" rx="13" ry="7" fill="#ff8fa8"/>',
  cool: '<path d="M362 404h96q10 0 8 12l-9 36q-4 14 -19 14h-44q-15 0 -20 -14l-19 -36q-3 -12 7 -12z" fill="#141418"/><path d="M538 420h96q10 0 8 12l-9 36q-4 14 -19 14h-44q-15 0 -20 -14l-19 -36q-3 -12 7 -12z" fill="#141418"/><path d="M466 418L536 430" stroke="#141418" stroke-width="10"/><path class="a-sh" d="M382 418l22 28M558 434l22 28" stroke="#fff" stroke-width="7" stroke-linecap="round" opacity=".55"/><path d="M474 470Q500 482 520 458" ' + E + ' stroke="#f2a3b2" stroke-width="6"/>',
  starry: STAR(410, 430, 40) + STAR(586, 448, 41) + '<path d="M460 456Q491 506 522 456Z" fill="#f2a3b2"/>' + BLUSH,
  scared: '<path d="M382 384Q410 368 438 382" ' + E + ' stroke-width="8"/><path d="M558 398Q586 382 614 396" ' + E + ' stroke-width="8"/><g class="a-shk"><circle cx="410" cy="432" r="30" fill="#fddedb"/><circle cx="586" cy="450" r="31" fill="#fddedb"/><circle cx="410" cy="432" r="7" fill="#2b2b31"/><circle cx="586" cy="450" r="7" fill="#2b2b31"/></g><path d="M462 492l10 -9 10 9 10 -9 10 9 10 -9 10 9" ' + E + ' stroke="#d9d1cf" stroke-width="5"/><path class="a-sw" d="M650 360q-12 22 0 30q12 -8 0 -30" fill="#7fd9ff"/>',
  nervous: EYE(410, 432, 21, 32) + EYE(586, 450, 22, 32) + '<path d="M380 384L440 396" ' + E + ' stroke-width="8"/><path d="M556 408L616 396" ' + E + ' stroke-width="8"/><path d="M472 484L512 480" ' + E + ' stroke="#d9d1cf" stroke-width="5"/><path class="a-sw" d="M650 360q-12 22 0 30q12 -8 0 -30" fill="#7fd9ff"/>',
  calm: '<path d="M386 434Q410 452 434 434" ' + E + ' stroke-width="9"/><path d="M561 452Q586 470 611 452" ' + E + ' stroke-width="9"/><path d="M474 464C482 480 502 480 510 464" ' + E + ' stroke="#f2a3b2" stroke-width="5"/>' + BLUSH,
  dizzy: SPIRAL(410, 430) + SPIRAL(586, 448) + '<path d="M462 490q7 -10 14 0t14 0t14 0t14 0" ' + E + ' stroke="#d9d1cf" stroke-width="5"/>',
  kiss: '<path d="M386 432Q410 452 434 432" ' + E + ' stroke-width="10"/>' + EYE(586, 446, 23, 36) + HEART(493, 484, 0.62) + BLUSH,
  sing: '<path d="M386 440Q410 410 434 440" ' + E + ' stroke-width="10"/><path d="M561 458Q586 428 611 458" ' + E + ' stroke-width="10"/><ellipse class="mt" cx="491" cy="482" rx="17" ry="14" fill="#e8a0ae"/>' + BLUSH,
  sleepy: '<g class="a-lid">' + EYE(410, 432, 22, 30) + EYE(586, 450, 23, 30) + '<rect x="372" y="380" width="80" height="44" fill="#2a2a30"/><rect x="548" y="398" width="80" height="44" fill="#2a2a30"/></g><path d="M480 474q11 6 22 0" ' + E + ' stroke="#d9d1cf" stroke-width="4.5"/>',
  proud: EYE(410, 430, 22, 30) + EYE(586, 448, 23, 30) + '<path d="M380 384L440 394" ' + E + ' stroke-width="8"/><path d="M556 404L616 394" ' + E + ' stroke-width="8"/><path d="M466 460C478 490 508 490 520 460" ' + E + ' stroke="#f2a3b2" stroke-width="6"/>',
  chin: '<g transform="translate(14 -14)">' + EYE(410, 428, 21, 33) + EYE(586, 446, 22, 33) + '</g><path d="M478 474L506 468" ' + E + ' stroke="#d9d1cf" stroke-width="5"/><circle class="dt" cx="640" cy="330" r="8" fill="#fddedb"/><circle class="dt d2" cx="666" cy="316" r="10" fill="#fddedb"/>',
  shiver: '<path d="M386 438L434 434" ' + E + ' stroke-width="9"/><path d="M561 452L611 452" ' + E + ' stroke-width="9"/><path class="a-tt" d="M462 480h58" stroke="#fddedb" stroke-width="14" stroke-dasharray="7 4"/><rect x="300" y="270" width="410" height="320" fill="#7fd9ff" opacity=".12"/>'
};
/* which face each move shows (moves without their own face reuse one) */
var FACE_OF = { laugh: 'laugh', giggle: 'laugh', tickle: 'laugh', surprised: 'surprised', confused: 'confused', wink: 'wink', shy: 'shy', cry: 'cry', yawn: 'yawn', stretch: 'yawn', cool: 'cool', excited: 'starry', celebrate: 'starry', clap: 'happy', scared: 'scared', nervous: 'nervous', sorry: 'nervous', namaste: 'calm', bow: 'calm', dizzy: 'dizzy', kiss: 'kiss', sing: 'sing', hum: 'sing', sleepy: 'sleepy', proud: 'proud', salute: 'proud', chin: 'chin', shiver: 'shiver', hot: 'nervous', nod: 'idle', shake: 'idle', shrug: 'confused', facepalm: 'calm', point: 'happy', hug: 'love', peek: 'wink' };
var LABEL = { laugh: 'Laugh', giggle: 'Giggle', tickle: 'Tickle', surprised: 'Surprised', confused: 'Confused', wink: 'Wink', shy: 'Shy blush', cry: 'Cry', yawn: 'Yawn', stretch: 'Stretch', cool: 'Cool', excited: 'Excited', celebrate: 'Celebrate', clap: 'Clap', scared: 'Scared', nervous: 'Nervous', sorry: 'Sorry', namaste: 'Namaste', bow: 'Bow', dizzy: 'Dizzy', kiss: 'Kiss', sing: 'Sing', hum: 'Hum', sleepy: 'Sleepy', proud: 'Proud', salute: 'Salute', chin: 'Thinking', shiver: 'Shiver (cold)', hot: 'Hot', nod: 'Nod yes', shake: 'Shake no', shrug: 'Shrug', facepalm: 'Facepalm', point: 'Point', hug: 'Hug', peek: 'Peek' };
var TIME = { laugh: 2400, giggle: 1400, tickle: 2600, surprised: 1700, confused: 2200, wink: 1300, shy: 2200, cry: 3200, yawn: 2300, stretch: 2000, cool: 2400, excited: 2600, celebrate: 3000, clap: 2400, scared: 2200, nervous: 2200, sorry: 2200, namaste: 2300, bow: 1800, dizzy: 2400, kiss: 1800, sing: 3600, hum: 2400, sleepy: 14000, proud: 2000, salute: 2000, chin: 2600, shiver: 2400, hot: 2200, nod: 1500, shake: 1500, shrug: 1800, facepalm: 2000, point: 1600, hug: 2400, peek: 1600 };
var FX = { laugh: '😂', giggle: '😆', tickle: '🤭', surprised: '❗', confused: '❓', wink: '😉', shy: '☺️', cry: '💧', yawn: '🥱', cool: '😎', excited: '🤩', celebrate: '🎉', clap: '👏', scared: '😱', nervous: '💦', sorry: '🙇', namaste: '🙏', bow: '🙏', dizzy: '💫', kiss: '😘', sing: '🎤', hum: '🎵', sleepy: '💤', proud: '🏆', salute: '🫡', chin: '🤔', shiver: '🥶', hot: '🥵', shrug: '🤷', facepalm: '🤦', point: '👉', hug: '🤗', stretch: '🙆', nod: '👍', shake: '🙅', peek: '👀' };
var PARTS = { celebrate: 'confetti', excited: 'stars', clap: 'stars', laugh: 'joy', tickle: 'joy', kiss: 'hearts', hug: 'hearts', sing: 'notes', hum: 'notes', cry: 'tears', hot: 'sweat', shiver: 'snow', proud: 'stars', namaste: 'petals' };
var SAY = { giggle: 'hehe!', tickle: 'hahaha!', surprised: 'Wow!', confused: 'Hmm?', namaste: 'Namaste 🙏', sorry: 'Sorry!', yawn: 'Aaah…', shrug: 'Not sure…', hug: '🤗', salute: 'Yes sir!', peek: 'Peekaboo!' };

/* ---------- CSS ---------- */
var faceCSS = Object.keys(FACE_OF).map(function (m) { var f = FACE_OF[m]; return '.rb[data-m=' + m + '] .f-' + f + (FACES[f] ? '' : '') + '{display:inline}'; }).join('');
var CSS = faceCSS +
  '.rb .fc .fg{transition:transform .25s ease-out}.rb.eyes .fc .fg{transform:translate(var(--gx,0px),var(--gy,0px))}' +
  '.rb.lip .f-talk .mt,.rb.lip .f-sing .mt{animation:none;transform:scaleY(1.35)}' +
  /* body moves */
  '.rb[data-m=laugh],.rb[data-m=tickle]{animation:a-laugh .22s ease-in-out infinite alternate}.rb[data-m=giggle]{animation:a-laugh .3s ease-in-out 4 alternate}' +
  '.rb[data-m=surprised]{animation:a-surp .55s cubic-bezier(.3,1.6,.5,1) forwards}' +
  '.rb[data-m=confused]{animation:a-tilt 1.4s ease-in-out infinite}.rb[data-m=shrug]{animation:a-shrug .9s ease-in-out 2}' +
  '.rb[data-m=wink]{animation:a-wink 1.2s ease-in-out}.rb[data-m=peek]{animation:a-peek 1.6s ease-in-out}' +
  '.rb[data-m=shy]{animation:a-shy 1.6s ease-in-out infinite}.rb[data-m=shy] .sc{filter:drop-shadow(0 0 14px #ff9fbf)}' +
  '.rb[data-m=cry]{animation:a-sob .4s ease-in-out infinite}' +
  '.rb[data-m=yawn],.rb[data-m=stretch]{animation:a-stretch 2.2s ease-in-out}' +
  '.rb[data-m=cool]{animation:a-cool 2.4s ease-out forwards}' +
  '.rb[data-m=excited],.rb[data-m=celebrate],.rb[data-m=clap]{animation:rjump .38s ease-in-out infinite}' +
  '.rb[data-m=scared],.rb[data-m=shiver]{animation:a-shiver .07s linear infinite}.rb[data-m=shiver] .sc{filter:drop-shadow(0 0 14px #7fd9ff) saturate(.8)}' +
  '.rb[data-m=hot] .sc{filter:drop-shadow(0 0 16px #ff8a5c)}.rb[data-m=hot]{animation:a-fan .5s ease-in-out infinite}' +
  '.rb[data-m=nervous],.rb[data-m=sorry]{animation:a-shy 1s ease-in-out infinite}' +
  '.rb[data-m=namaste],.rb[data-m=bow]{animation:a-bow 1.8s ease-in-out}' +
  '.rb[data-m=dizzy]{animation:a-dizzy 1s ease-in-out infinite}' +
  '.rb[data-m=kiss]{animation:a-kiss .9s ease-in-out 2}.rb[data-m=hug]{animation:a-hug .8s ease-in-out 3}.rb[data-m=hug] .sc{filter:drop-shadow(0 0 18px #ff8fab)}' +
  '.rb[data-m=sing],.rb[data-m=hum]{animation:a-sing 1.1s ease-in-out infinite}' +
  '.rb[data-m=sleepy]{animation:a-nodoff 3.2s ease-in-out infinite}' +
  '.rb[data-m=proud],.rb[data-m=salute]{animation:a-proud 2s ease-out forwards}' +
  '.rb[data-m=chin]{animation:rtilt 2s ease-in-out infinite}' +
  '.rb[data-m=nod]{animation:a-nod .5s ease-in-out 3}.rb[data-m=shake]{animation:a-shake .45s ease-in-out 3}' +
  '.rb[data-m=facepalm]{animation:a-bow 2s ease-in-out}.rb[data-m=point]{animation:a-point 1.6s ease-in-out}' +
  /* arm poses */
  '.rb[data-m=salute] .arm{animation:none;transform:rotate(25deg);transition:transform .35s}' +
  '.rb[data-m=facepalm] .arm{animation:none;transform:rotate(68deg);transition:transform .35s}' +
  '.rb[data-m=chin] .arm{animation:none;transform:rotate(50deg);transition:transform .35s}' +
  '.rb[data-m=clap] .arm,.rb[data-m=celebrate] .arm,.rb[data-m=excited] .arm{animation:a-clap .22s ease-in-out infinite alternate}' +
  '.rb[data-m=shrug] .arm{animation:a-armup .9s ease-in-out 2}.rb[data-m=point] .arm{animation:none;transform:rotate(-45deg);transition:transform .3s}' +
  '.rb[data-m=stretch] .arm,.rb[data-m=yawn] .arm{animation:a-armup 2.2s ease-in-out}.rb[data-m=sing] .arm,.rb[data-m=hum] .arm{animation:armwave .6s ease-in-out infinite alternate}' +
  '.rb[data-m=cry] .arm,.rb[data-m=sleepy] .arm{animation:none;transform:rotate(-8deg)}.rb[data-m=hug] .arm{animation:a-clap .4s ease-in-out infinite alternate}' +
  /* antenna and heart moods */
  '.rb[data-m=surprised] .ant,.rb[data-m=scared] .ant{animation:antwig .12s linear infinite}.rb[data-m=sleepy] .ant,.rb[data-m=cry] .ant{animation:none;transform:rotate(-26deg)}' +
  '.rb[data-m=excited] .hrt,.rb[data-m=celebrate] .hrt,.rb[data-m=kiss] .hrt,.rb[data-m=hug] .hrt{animation:hfloat .5s ease-in-out infinite}' +
  /* face details */
  '.a-tw{transform-box:fill-box;transform-origin:center;animation:a-twk .6s ease-in-out infinite alternate}' +
  '.a-spin{animation:a-rot 1s linear infinite}.a-tj{animation:tr 1s infinite}.a-st{transform-box:fill-box;transform-origin:top;animation:a-stream 1s ease-in infinite}.a-st2{animation-delay:.4s}' +
  '.a-yw{transform-box:fill-box;transform-origin:center;animation:a-yawn 2.2s ease-in-out}.a-oh{transform-box:fill-box;transform-origin:center;animation:a-oh .55s ease-out}' +
  '.a-q{animation:a-q 1.4s ease-in-out infinite}.a-sw{animation:a-sweat 1.6s ease-in infinite}.a-shk{animation:a-shiver .09s linear infinite}' +
  '.a-wb{animation:a-shiver .3s linear infinite}.a-lid rect{transform-box:fill-box;transform-origin:top;animation:a-lid 3.2s ease-in-out infinite}.a-sh{animation:a-shine 2.4s ease-in-out infinite}' +
  '.a-tt{animation:a-shiver .1s linear infinite}.a-mo{transform-box:fill-box;transform-origin:top;animation:a-mo .22s ease-in-out infinite alternate}' +
  /* speech bubble and particles */
  '.rb .say2{position:absolute;left:50%;bottom:96%;transform:translateX(-50%) scale(.4);white-space:nowrap;font-size:.3em;font-weight:700;color:#4a3fb5;background:#fff;border:2px solid #7c6cf0;border-radius:14px;padding:.18em .6em;box-shadow:0 4px 12px rgba(0,0,0,.12);opacity:0;pointer-events:none;animation:a-say 1.8s ease-out forwards;z-index:3}' +
  '.rb.hd .say2{display:none}.rb .pt{position:absolute;left:50%;top:38%;pointer-events:none;font-size:.3em;line-height:1;z-index:2;animation:a-pt var(--d,1.4s) cubic-bezier(.2,.7,.4,1) forwards}' +
  '.rb.hd .pt{font-size:.5em}' +
  '@keyframes a-laugh{from{transform:translateY(0) rotate(-3deg)}to{transform:translateY(-6px) rotate(3deg)}}' +
  '@keyframes a-surp{0%{transform:scale(1)}40%{transform:translateY(-16px) scale(1.1)}100%{transform:translateY(-4px) scale(1.04)}}' +
  '@keyframes a-tilt{0%,100%{transform:rotate(-8deg)}50%{transform:rotate(8deg)}}' +
  '@keyframes a-shrug{0%,100%{transform:translateY(0)}35%,60%{transform:translateY(-9px) scaleX(1.04)}}' +
  '@keyframes a-wink{0%,100%{transform:rotate(0)}40%,70%{transform:rotate(-7deg) translateY(-3px)}}' +
  '@keyframes a-peek{0%,100%{transform:translateX(0)}30%,70%{transform:translateX(-12%) rotate(-10deg)}}' +
  '@keyframes a-shy{0%,100%{transform:rotate(-4deg) translateX(-2px)}50%{transform:rotate(4deg) translateX(2px)}}' +
  '@keyframes a-sob{0%,100%{transform:translateY(0) rotate(-1deg)}50%{transform:translateY(3px) rotate(1deg)}}' +
  '@keyframes a-stretch{0%,100%{transform:scale(1)}40%,60%{transform:scale(.98,1.08) translateY(-6px)}}' +
  '@keyframes a-cool{0%{transform:rotate(0)}30%{transform:rotate(-8deg) translateX(-4px)}100%{transform:rotate(-5deg) translateX(-3px)}}' +
  '@keyframes a-shiver{0%{transform:translateX(-1.5px)}50%{transform:translateX(1.5px)}100%{transform:translateX(-1.5px)}}' +
  '@keyframes a-fan{0%,100%{transform:rotate(-2deg)}50%{transform:rotate(2deg)}}' +
  '@keyframes a-bow{0%,100%{transform:rotate(0) translateY(0)}35%,65%{transform:rotate(14deg) translateY(8px)}}' +
  '@keyframes a-dizzy{0%,100%{transform:rotate(-10deg) translateX(-4px)}50%{transform:rotate(10deg) translateX(4px)}}' +
  '@keyframes a-kiss{0%,100%{transform:scale(1)}50%{transform:scale(1.08) translateY(-6px)}}' +
  '@keyframes a-hug{0%,100%{transform:scale(1)}50%{transform:scale(1.1,0.95)}}' +
  '@keyframes a-sing{0%,100%{transform:rotate(-6deg) translateY(0)}50%{transform:rotate(6deg) translateY(-6px)}}' +
  '@keyframes a-nodoff{0%,60%,100%{transform:translateY(0) rotate(0)}75%{transform:translateY(5px) rotate(4deg)}85%{transform:translateY(0) rotate(-1deg)}}' +
  '@keyframes a-proud{0%{transform:scale(1)}40%{transform:scale(1.07) translateY(-6px)}100%{transform:scale(1.04) translateY(-3px)}}' +
  '@keyframes a-nod{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(6px) rotate(3deg)}}' +
  '@keyframes a-shake{0%,100%{transform:rotate(0)}25%{transform:rotate(-9deg)}75%{transform:rotate(9deg)}}' +
  '@keyframes a-point{0%,100%{transform:translateX(0)}50%{transform:translateX(6%) rotate(-4deg)}}' +
  '@keyframes a-clap{from{transform:rotate(45deg)}to{transform:rotate(-6deg)}}' +
  '@keyframes a-armup{0%,100%{transform:rotate(0)}40%,60%{transform:rotate(-45deg)}}' +
  '@keyframes a-twk{from{transform:scale(.85) rotate(-8deg)}to{transform:scale(1.12) rotate(8deg)}}' +
  '@keyframes a-rot{to{transform:rotate(360deg)}}' +
  '@keyframes a-stream{0%{transform:scaleY(.2);opacity:.9}100%{transform:scaleY(1);opacity:0}}' +
  '@keyframes a-yawn{0%{transform:scale(.3)}40%,70%{transform:scale(1.15)}100%{transform:scale(.4)}}' +
  '@keyframes a-oh{from{transform:scale(.2)}to{transform:scale(1)}}' +
  '@keyframes a-q{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}' +
  '@keyframes a-sweat{0%{transform:translateY(0);opacity:0}20%{opacity:1}100%{transform:translateY(60px);opacity:0}}' +
  '@keyframes a-lid{0%,100%{transform:scaleY(.55)}45%,70%{transform:scaleY(1.05)}}' +
  '@keyframes a-shine{0%,100%{opacity:.2}50%{opacity:.7}}' +
  '@keyframes a-mo{from{transform:scaleY(.75)}to{transform:scaleY(1.1)}}' +
  '@keyframes a-say{0%{opacity:0;transform:translateX(-50%) scale(.4)}15%{opacity:1;transform:translateX(-50%) scale(1.06)}25%{transform:translateX(-50%) scale(1)}80%{opacity:1}100%{opacity:0;transform:translateX(-50%) scale(.9) translateY(-6px)}}' +
  '@keyframes a-pt{0%{opacity:0;transform:translate(-50%,0) scale(.4) rotate(0)}15%{opacity:1}100%{opacity:0;transform:translate(calc(-50% + var(--x)),var(--y)) scale(var(--s,1)) rotate(var(--r,0deg))}}' +
  '.a-calm .rb .pt{display:none}.a-calm .rb[data-m]{animation-iteration-count:1!important}' +
  '.a-off .rb,.a-off .rb *{animation:none!important;transition:none!important}.a-off .rb .pt,.a-off .rb .say2{display:none}' +
  '@media (prefers-reduced-motion:reduce){.rb .pt,.rb .say2{display:none}}';

/* ---------- install faces into every robot ---------- */
function robots() { return [].slice.call(doc.querySelectorAll('.rb')); }
function install() {
  if (!doc.getElementById('animcss')) { var st = doc.createElement('style'); st.id = 'animcss'; st.textContent = CSS; doc.head.appendChild(st); }
  robots().forEach(function (r) {
    if (r._anim) return;
    var g = r.querySelector('.fc g[clip-path] > g[transform]'); if (!g) return;
    var html = Object.keys(FACES).map(function (k) { return '<g class="fg f-' + k + '">' + FACES[k] + '</g>'; }).join('');
    g.insertAdjacentHTML('beforeend', html);
    r._anim = true;
  });
  doc.documentElement.classList.toggle('a-calm', C.level === 'calm');
  doc.documentElement.classList.toggle('a-off', C.level === 'off');
}

/* ---------- play ---------- */
function canPlay() { return typeof root.mood === 'function'; }
function bubble(text) { if (!lively() || !text) return; robots().forEach(function (r) { if (!r.classList.contains('lg')) return; r.querySelectorAll('.say2').forEach(function (x) { x.remove(); }); var b = doc.createElement('span'); b.className = 'say2'; b.textContent = text; r.appendChild(b); setTimeout(function () { b.remove(); }, 1900); }); }
var GLYPHS = { confetti: ['🟪', '🟨', '🟦', '🟥', '🟩', '✨'], stars: ['⭐', '✨', '🌟'], hearts: ['💖', '💕', '❤️'], notes: ['🎵', '🎶'], joy: ['😂', '✨', '😆'], tears: ['💧'], sweat: ['💦'], snow: ['❄️'], petals: ['🌸', '🌼'] };
function burst(kind, n) {
  if (!lively() || C.level === 'calm') return;
  var g = GLYPHS[kind]; if (!g) return;
  robots().forEach(function (r) {
    var count = r.classList.contains('hd') ? Math.ceil((n || 10) / 3) : (n || 10);
    for (var i = 0; i < count; i++) {
      var s = doc.createElement('span'); s.className = 'pt'; s.textContent = g[i % g.length];
      var ang = (kind === 'tears' || kind === 'sweat' || kind === 'snow') ? (Math.PI / 2 + (Math.random() - .5) * 1.2) : (-Math.PI / 2 + (Math.random() - .5) * 2.6);
      var dist = 40 + Math.random() * 70;
      s.style.setProperty('--x', Math.round(Math.cos(ang) * dist) + 'px');
      s.style.setProperty('--y', Math.round(Math.sin(ang) * dist) + 'px');
      s.style.setProperty('--r', Math.round((Math.random() - .5) * 360) + 'deg');
      s.style.setProperty('--s', (0.8 + Math.random() * 0.7).toFixed(2));
      s.style.setProperty('--d', (1.1 + Math.random() * 0.8).toFixed(2) + 's');
      s.style.animationDelay = (Math.random() * 0.25).toFixed(2) + 's';
      r.appendChild(s); (function (x) { setTimeout(function () { x.remove(); }, 2400); })(s);
    }
  });
}
function play(name, ms) {
  if (!canPlay() || !FACE_OF[name]) return false;
  if (root.cur === 'sleep' && name !== 'yawn' && name !== 'stretch') { try { root.wake(); } catch (e) { } }
  install();
  if (C.level === 'off') return false;
  robots().forEach(function (r) { r.querySelectorAll('.say2').forEach(function (x) { x.remove(); }); });
  root.mood(name, ms || TIME[name] || 2000);
  if (PARTS[name]) burst(PARTS[name], name === 'celebrate' ? 18 : 10);
  if (SAY[name]) bubble(SAY[name]);
  return true;
}
/* effect emoji above the head for the new moves */
var fxCSS = Object.keys(FX).map(function (m) { return '.rb[data-m=' + m + '] .fx::before{content:"' + FX[m] + '"}.rb[data-m=' + m + '] .fx{animation:fxp 1.2s ease-out infinite}'; }).join('');

/* ---------- reactions to what the user says ---------- */
var DANGER = /\b(suicid|kill myself|end my life|want to die|self harm|hurt myself|no reason to live)/i;
var REACT = [
  [/\b(ha(ha)+|he(he)+|lol|lmao|rofl|hilarious)\b|😂|🤣|😆/i, 'laugh'],
  [/\b(wow|whoa|omg|oh my god|no way|unbelievable|kya baat hai|arre wah|amazing)\b|😮|😲|🤯/i, 'surprised'],
  [/^(what\??|huh\??|hmm+\??|eh\??|kya\??|matlab\??)$|\b(i don'?t understand|samajh nahi aaya|confus(ed|ing))\b/i, 'confused'],
  [/😉|\bwink\b/i, 'wink'],
  [/\b(yay|yippee|hurray|hooray|congrat\w*|celebrat\w*|i passed|we won|i got (the|a|my) (job|order)|badhai)\b|🎉|🥳|🎊/i, 'celebrate'],
  [/\b(namaste|namaskar|pranam|vanakkam|sat sri akal|ram ram)\b|🙏|नमस्ते|नमस्कार|வணக்கம்/i, 'namaste'],
  [/\b(thanks|thank you|thank u|thx|shukriya|dhanyavaad|dhanyawad)\b|धन्यवाद|शुक्रिया/i, 'bow'],
  [/\b(sorry|my bad|oops|maaf)\b|माफ़/i, 'sorry'],
  [/\b(i am sad|i'm sad|feeling sad|feeling low|crying|heart ?broken|i miss (him|her|them|my))\b|😭|😢|💔/i, 'cry'],
  [/\b(sleepy|so tired|yawn|bored|boring|neend)\b|🥱/i, 'yawn'],
  [/\b(cool|swag|legend|rockstar|you rock)\b|😎/i, 'cool'],
  [/\b(scary|horror|ghost|afraid|scared|darr|bhoot)\b|😱|👻/i, 'scared'],
  [/😘|💋|\b(kiss|muah)\b/i, 'kiss'],
  [/\b(sing|song|gaana|gana|hum a)\b|🎤/i, 'sing'],
  [/\b(so cold|freezing|thand|it'?s cold)\b|🥶/i, 'shiver'],
  [/\b(so hot|garmi|sweating|it'?s hot)\b|🥵/i, 'hot'],
  [/\b(salute|jai hind|yes sir|aye aye)\b|🫡/i, 'salute'],
  [/\b(facepalm|silly me|i forgot|bhool gaya|bhool gayi)\b|🤦/i, 'facepalm'],
  [/\b(clap|bravo|well done|good job|great job|shabash)\b|👏/i, 'clap'],
  [/\b(dizzy|chakkar)\b|😵/i, 'dizzy'],
  [/\b(peekaboo|peek a boo)\b|🙈/i, 'peek'],
  [/\b(you are (so )?(cute|sweet|pretty|beautiful)|blush)\b|☺️|😊/i, 'shy'],
  [/\b(stretch|exercise|workout|yoga)\b|🙆/i, 'stretch'],
  [/\b(proud|i did it|nailed it)\b|🏆/i, 'proud']
];
var pendingAnswer = null;
function onUser(raw) {
  if (!C.react || !lively()) return;
  var t = String(raw || '');
  if (t.length > 300) return;
  if (DANGER.test(t)) { setTimeout(function () { play('calm' in FACE_OF ? 'namaste' : 'bow', 2600); }, 170); return; } /* calm, never playful */
  pendingAnswer = /\b(joke|jokes|chutkula|funny story|make me laugh)\b/i.test(t) ? 'laugh' : null;
  for (var i = 0; i < REACT.length; i++) if (REACT[i][0].test(t)) { var n = REACT[i][1]; setTimeout(function () { play(n); }, 170); return; }
  if (/\b(bye|goodbye|good bye|see you|alvida|tata|good night)\b/i.test(t) && !/good night/i.test(t)) setTimeout(function () { play('bow', 1600); root.rwave && root.rwave(); }, 170);
  var a = root.lexiLingo && root.lexiLingo.last && root.lexiLingo.last();
  if (a && a.type === 'command' && !/\b(dance|sleep)\b/i.test(t)) setTimeout(function () { if (root.cur === 'think') play('nod', 1200); }, 170);
}
/* reactions to Lexi's own answers */
var seen = typeof WeakSet === 'function' ? new WeakSet() : null, answerT = null;
function onAnswer(el) {
  if (!C.react || !lively()) return;
  var t = (el.innerText || '').trim(); if (!t) return;
  var first = t.slice(0, 120).toLowerCase(), r = null;
  if (pendingAnswer) { r = pendingAnswer; pendingAnswer = null; }
  else if (/🎉|🥳|\bcongratulations\b|\bwell done\b/i.test(t.slice(0, 400))) r = 'celebrate';
  else if (/^(yes|yeah|yep|correct|right|haan|ha ji|हाँ|हां)\b/.test(first)) r = 'nod';
  else if (/^(no|nope|nahi|नहीं)\b/.test(first)) r = 'shake';
  else if (/\b(i'?m not sure|i am not sure|not sure|no idea|i don'?t know|cannot be sure|i'?ll confirm|will confirm)\b/i.test(t.slice(0, 500))) r = 'shrug';
  else if (/😂|🤣|\bhaha\b/i.test(t.slice(0, 300))) r = 'laugh';
  else if (/```|<pre/.test(el.innerHTML) && t.length > 300) r = 'proud';
  else if (/^(namaste|vanakkam|namaskar)/i.test(first)) r = 'namaste';
  if (r) setTimeout(function () { play(r); }, 260);
}
function watchAnswers() {
  var log = doc.getElementById('log'); if (!log || !seen) return;
  new MutationObserver(function () {
    clearTimeout(answerT);
    answerT = setTimeout(function () {
      var rows = log.querySelectorAll('.row.a .m'), last = rows[rows.length - 1];
      if (!last || seen.has(last) || last.querySelector('.dots')) return;
      seen.add(last); onAnswer(last);
    }, 450);
  }).observe(log, { childList: true, subtree: true, characterData: true });
  [].forEach.call(log.querySelectorAll('.row.a .m'), function (m) { seen.add(m); });
}

/* ---------- eyes follow the finger / mouse ---------- */
var raf = 0, px = null, py = null, lastMove = 0;
function look() {
  raf = 0;
  var active = C.eyes && lively() && px !== null && Date.now() - lastMove < 3500;
  robots().forEach(function (r) {
    var ok = active && /^(idle|happy|listen|love|talk|wink|shy|proud|cool|nervous)$/.test(r.getAttribute('data-m') || '');
    if (!ok) { r.classList.remove('eyes'); return; }
    var b = r.getBoundingClientRect(); if (!b.width) return;
    var dx = px - (b.left + b.width / 2), dy = py - (b.top + b.height * 0.42), d = Math.sqrt(dx * dx + dy * dy) || 1, k = Math.min(1, d / 260);
    r.style.setProperty('--gx', (dx / d * 26 * k).toFixed(1) + 'px'); r.style.setProperty('--gy', (dy / d * 16 * k).toFixed(1) + 'px');
    r.classList.add('eyes');
  });
}
function onMove(e) { var p = e.touches ? e.touches[0] : e; if (!p) return; px = p.clientX; py = p.clientY; lastMove = Date.now(); if (!raf) raf = (root.requestAnimationFrame || setTimeout)(look); }
setInterval(function () { if (px !== null && Date.now() - lastMove > 3500) { px = null; look(); } }, 1200);

/* ---------- mouth moves with each spoken word ---------- */
function lipSync() {
  try {
    var ss = root.speechSynthesis; if (!ss || ss.__lexiLip) return;
    var speak = ss.speak.bind(ss);
    ss.speak = function (u) {
      try {
        if (C.lips && u && u.addEventListener) u.addEventListener('boundary', function () {
          if (!lively()) return;
          robots().forEach(function (r) { r.classList.add('lip'); clearTimeout(r._lip); r._lip = setTimeout(function () { r.classList.remove('lip'); }, 130); });
        });
      } catch (e) { }
      return speak(u);
    };
    ss.__lexiLip = true;
  } catch (e) { }
}

/* ---------- touch: double-tap, tickle, long press, shake ---------- */
function touchable() {
  robots().forEach(function (r) {
    if (r._touch) return; r._touch = true;
    var taps = [], press = null, moves = [], down = false;
    r.addEventListener('pointerdown', function (e) {
      down = true; moves = [];
      clearTimeout(press); press = setTimeout(function () { if (down) { r._noTap = Date.now(); play('hug'); burst('hearts', 12); down = false; } }, 650);
    });
    r.addEventListener('pointermove', function (e) {
      if (!down) return; moves.push([e.clientX, Date.now()]); if (moves.length > 12) moves.shift();
      var flips = 0; for (var i = 2; i < moves.length; i++) { var a = moves[i - 1][0] - moves[i - 2][0], b = moves[i][0] - moves[i - 1][0]; if (a * b < 0 && Math.abs(b) > 4) flips++; }
      if (flips >= 4) { clearTimeout(press); down = false; play('dizzy'); }
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (ev) { r.addEventListener(ev, function () { down = false; clearTimeout(press); }); });
    r.addEventListener('click', function (e) { if (r._noTap && Date.now() - r._noTap < 1500) { e.stopImmediatePropagation(); e.preventDefault(); r._noTap = 0; } }, true);
    r.addEventListener('click', function () {
      var now = Date.now(); taps = taps.filter(function (t) { return now - t < 1400; }); taps.push(now);
      if (taps.length >= 4) { setTimeout(function () { play('tickle'); }, 30); taps = []; }
      else if (taps.length === 2 && now - taps[0] < 450) setTimeout(function () { play('giggle'); }, 30);
    });
  });
}

/* ---------- idle life: habits, and getting sleepy ---------- */
var HABITS = [['wink', 3], ['hum', 2], ['peek', 2], ['nod', 1], ['proud', 1], ['chin', 2], ['stretch', 1], ['shy', 1], ['yawn', 1]];
function habit() {
  var tot = 0; HABITS.forEach(function (h) { tot += h[1]; });
  var x = Math.random() * tot; for (var i = 0; i < HABITS.length; i++) { x -= HABITS[i][1]; if (x <= 0) return HABITS[i][0]; }
  return 'wink';
}
setInterval(function () {
  if (!lively() || C.level === 'calm') return;
  if (root.cur !== 'idle' || root.mt || root.listening || root.speaking) return;
  var quiet = Date.now() - (root.lastAct || Date.now());
  if (quiet > 30000 && quiet < 44000) { play('sleepy', 13000); return; }
  if (Math.random() < 0.55) play(habit());
}, 9000);

/* ---------- commands and gallery ---------- */
function command(raw) {
  var t = String(raw || '').trim().toLowerCase();
  if (/^(?:show |open )?(?:animations?|animation gallery|all animations|your animations|dance moves)$/.test(t)) return { gallery: true };
  var m = /^(?:animations?|animation)\s+(off|on|full|calm)$/.exec(t); if (m) return { level: m[1] === 'on' ? 'full' : m[1] };
  m = /^(?:do (?:a |the )?|show (?:me )?(?:a |the |your )?|can you )?(laugh|wink|salute|facepalm|shrug|bow|namaste|clap|celebrate|cry|yawn|stretch|sing|hum|dance|nod|shake your head|blush|kiss|hug|peekaboo|be cool|be surprised|be scared|get dizzy|sleep)\s*[!.]?$/.exec(t);
  if (m) { var map = { 'shake your head': 'shake', blush: 'shy', peekaboo: 'peek', 'be cool': 'cool', 'be surprised': 'surprised', 'be scared': 'scared', 'get dizzy': 'dizzy' }; var n = map[m[1]] || m[1]; if (n === 'dance' || n === 'sleep') return null; return { play: n }; }
  return null;
}
function gallery(el) {
  var names = Object.keys(LABEL);
  el.innerHTML = '<p class="n">Tap any animation to watch the robot do it. It also reacts by itself to what you say and to its answers, follows your finger with its eyes, and moves its mouth with every spoken word. Touch the robot: tap = wave, double-tap = giggle, many taps = tickle, long press = hug, shake it = dizzy.</p>' +
    '<div class="card"><div class="row" style="margin:0"><label for="an_lv" style="margin:0">Animations</label><select id="an_lv" style="flex:1;min-width:140px"><option value="full">Full (all moves and effects)</option><option value="calm">Calm (gentle, no particles)</option><option value="off">Off</option></select></div>' +
    '<label><input type="checkbox" id="an_eyes" style="width:auto" ' + (C.eyes ? 'checked' : '') + '> Eyes follow my finger or mouse</label><label><input type="checkbox" id="an_lips" style="width:auto" ' + (C.lips ? 'checked' : '') + '> Mouth moves with each spoken word</label><label><input type="checkbox" id="an_react" style="width:auto" ' + (C.react ? 'checked' : '') + '> React to what I say and to answers</label>' + (reduced ? '<p class="n">Your phone is set to reduce motion, so animations stay still.</p>' : '') + '</div>' +
    '<div class="card" style="text-align:center"><div class="rb lg" id="an_bot" data-m="idle" role="img" aria-label="Lexi robot" style="width:160px;font-size:40px;margin:26px auto 6px"></div><div id="an_now" class="n">Pick one below</div></div>' +
    '<div class="card"><div style="display:flex;flex-wrap:wrap;gap:6px">' + names.map(function (k) { return '<button class="b g" data-an="' + k + '">' + (FX[k] || '') + ' ' + LABEL[k] + '</button>'; }).join('') + '<button class="b g" data-old="dance">🎵 Dance</button><button class="b g" data-old="love">😍 Love</button><button class="b g" data-old="angry">💢 Angry</button><button class="b g" data-old="sad">😢 Sad</button><button class="b g" data-old="search">🔍 Search</button><button class="b g" data-old="listen">🎧 Listen</button><button class="b g" data-old="think">💭 Think</button><button class="b g" data-old="sleep">😴 Sleep</button><button class="b g" data-old="wave">👋 Wave</button></div></div>';
  /* a copy of the robot inside the gallery */
  var big = doc.querySelector('.rb.lg') || doc.querySelector('.rb'), bot = el.querySelector('#an_bot');
  if (big) { bot.innerHTML = big.innerHTML; bot.querySelectorAll('.pt,.say2').forEach(function (x) { x.remove(); }); }
  var now = el.querySelector('#an_now');
  function show(name, ms, label) {
    bot.setAttribute('data-m', name); now.textContent = label;
    if (PARTS[name] && lively() && C.level !== 'calm') { var keep = robots; robots = function () { return [bot]; }; try { burst(PARTS[name], 12); } finally { robots = keep; } }
    if (SAY[name] && lively()) { var b = doc.createElement('span'); b.className = 'say2'; b.textContent = SAY[name]; bot.appendChild(b); setTimeout(function () { b.remove(); }, 1900); }
    clearTimeout(bot._t); bot._t = setTimeout(function () { bot.setAttribute('data-m', 'idle'); bot.classList.remove('wave'); now.textContent = 'Pick one below'; }, ms || 2600);
  }
  el.querySelectorAll('[data-an]').forEach(function (b) { b.onclick = function () { show(b.dataset.an, TIME[b.dataset.an] > 6000 ? 4000 : TIME[b.dataset.an], b.textContent.trim()); }; });
  el.querySelectorAll('[data-old]').forEach(function (b) { b.onclick = function () { var n = b.dataset.old; if (n === 'wave') { bot.classList.remove('wave'); void bot.offsetWidth; bot.classList.add('wave'); show('happy', 1900, b.textContent.trim()); } else show(n, 3000, b.textContent.trim()); }; });
  var lv = el.querySelector('#an_lv'); lv.value = C.level;
  lv.onchange = function () { C.level = lv.value; S('lexi_anim', C); install(); };
  el.querySelector('#an_eyes').onchange = function () { C.eyes = this.checked; S('lexi_anim', C); };
  el.querySelector('#an_lips').onchange = function () { C.lips = this.checked; S('lexi_anim', C); };
  el.querySelector('#an_react').onchange = function () { C.react = this.checked; S('lexi_anim', C); };
}

/* ---------- start ---------- */
function hookHandle() {
  if (typeof root.handle !== 'function' || root.handle.__anim) return;
  var prev = root.handle;
  var h = function (raw) {
    var c = null; try { c = command(raw); } catch (e) { }
    if (c) {
      try { root.add(String(raw).replace(/[&<>]/g, function (x) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[x]; }), 'u'); } catch (e) { }
      if (c.gallery) { if (root.lexiTrain) root.lexiTrain('anim'); return; }
      if (c.level) { C.level = c.level; S('lexi_anim', C); install(); try { root.add('Animations: ' + c.level + '.', 'a'); } catch (e) { } return; }
      if (c.play) { setTimeout(function () { play(c.play); }, 60); try { root.add((FX[c.play] || '') + ' ' + (LABEL[c.play] || c.play) + '!', 'a'); } catch (e) { } return; }
    }
    var out = prev.apply(this, arguments);
    try { if (!root.__lexiRouted) onUser(raw); } catch (e) { }
    return out;
  };
  h.__anim = true; root.handle = h;
}
function start() {
  install();
  var st = doc.createElement('style'); st.id = 'animfx'; st.textContent = fxCSS; doc.head.appendChild(st);
  watchAnswers(); lipSync(); touchable();
  ['pointermove', 'touchmove', 'touchstart', 'pointerdown'].forEach(function (ev) { doc.addEventListener(ev, onMove, { passive: true }); });
  hookHandle(); setTimeout(hookHandle, 1500);
  new MutationObserver(function () { install(); touchable(); }).observe(doc.body, { childList: true, subtree: false });
}
root.lexiAnim = { play: play, burst: burst, bubble: bubble, gallery: gallery, names: function () { return Object.keys(LABEL); }, cfg: function (k, v) { if (arguments.length > 1) { C[k] = v; S('lexi_anim', C); install(); } return C[k]; }, onUser: onUser, onAnswer: onAnswer, command: command };
if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', start); else start();
})(window);
