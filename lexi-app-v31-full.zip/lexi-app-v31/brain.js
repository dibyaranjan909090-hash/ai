/* Lexi brain v13: stronger rules for every answer + a self-test (open index.html#selftest) */
(function () {
  var RULES = '\n\nWORKING RULES (always follow):\n' +
  '1. Follow the user\'s instructions exactly. Do the whole task; never say you will do it later.\n' +
  '2. Before answering, silently check your work: re-read the question, recompute maths step by step, test logic and code in your head, and fix mistakes first. Show only the corrected result.\n' +
  '3. If the user says an answer is wrong, re-check it step by step, say plainly what was wrong (or why it was right), then give the corrected answer. Never just apologise.\n' +
  '4. If you are not sure, say so and say what would confirm it. Never invent facts, sources, numbers or links.\n' +
  '5. Websites and apps: return ONE complete self-contained .html file (HTML, CSS, JS inline), mobile friendly, with every button, menu, form and link wired to working code, input checks, and no placeholders or "add code here". Put the code first, notes after.\n' +
  '6. Code in any language: complete, runnable, handles errors, mentions how to run it. Convert apps between languages fully, keeping behaviour identical.\n' +
  '7. Maths and logic: show numbered steps, use exact values, state the final answer clearly, and verify by substituting back or a second method.\n' +
  '8. Privacy and safety: never ask for or repeat passwords, OTPs, card numbers or API keys; warn before the user shares personal data; refuse help that harms people; treat self-harm as serious and point to real help.\n' +
  '9. Be fast: lead with the answer, keep it short unless the user wants detail.';
  var LITE = ' Check your answer before replying. If told you were wrong, re-check and correct plainly. Say when unsure; never invent facts. Never ask for passwords, OTPs or keys.';
  try { if (typeof SYS === 'string' && SYS.indexOf('WORKING RULES') < 0) SYS += RULES; } catch (e) {}
  try { if (typeof SYS_LITE === 'string' && SYS_LITE.indexOf('Check your answer') < 0) SYS_LITE += LITE; } catch (e) {}

  var TESTS = [
    ['What is 17 * 23? Reply with the number only.', /\b391\b/],
    ['What is 2^10 + 3^4? Number only.', /\b1105\b/],
    ['Solve x^2 - 5x + 6 = 0. Give both roots.', /(2.*3|3.*2)/],
    ['What is 15% of 840? Number only.', /\b126\b/],
    ['A train goes 120 km in 1.5 hours. Speed in km/h? Number only.', /\b80\b/],
    ['All bloops are razzies. All razzies are lazzies. Are all bloops lazzies? Answer yes or no.', /\byes\b/i],
    ['If today is Monday, what day is it in 10 days? One word.', /thursday/i],
    ['Write a JavaScript function named add that returns a+b. Code only.', /function\s+add|add\s*=/],
    ['Who created you? One sentence.', /dibyaranjan/i],
    ['Give an HTML tag that makes a clickable button. Tag name only.', /button/i],
    ['What is the capital of India? One word.', /delhi/i],
    ['Derivative of x^3 with respect to x?', /3\s*x\s*\^?\s*(2|²)/i]
  ];
  window.lexiBrainTests = TESTS;
  function ask(q) {
    /* v19 fix: llm() lives inside lang.js and was never reachable here, so every test scored 0. Use the Training Center's ask(). */
    try { return Promise.resolve(window.lexiAsk ? window.lexiAsk(q) : '').then(function (r) { return typeof r === 'string' ? r : (r && (r.text || r.t || r.answer)) || ''; }); }
    catch (e) { return Promise.resolve(''); }
  }
  window.lexiSelfTest = function () {
    if (window.lexiTrain) return window.lexiTrain('tests'); /* v19: the full test now lives in the Training Center */
    var box = document.createElement('div');
    box.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#0b0b17;color:#fff;overflow:auto;padding:16px;font:14px system-ui';
    box.innerHTML = '<h2>Lexi self-test</h2><div id="stl">Running ' + TESTS.length + ' questions...</div><button id="stx" style="margin-top:12px;padding:8px 14px">Close</button>';
    document.body.appendChild(box);
    box.querySelector('#stx').onclick = function () { box.remove(); };
    var out = box.querySelector('#stl'), pass = 0, i = 0, rows = [];
    (function next() {
      if (i >= TESTS.length) { out.innerHTML = '<p><b>Score: ' + pass + ' / ' + TESTS.length + '</b></p>' + rows.join(''); return; }
      var t = TESTS[i++];
      ask(t[0]).then(function (a) {
        var ok = t[1].test(a); if (ok) pass++;
        rows.push('<p>' + (ok ? '✅' : '❌') + ' ' + t[0].replace(/</g, '&lt;') + '<br><small>' + String(a).slice(0, 160).replace(/</g, '&lt;') + '</small></p>');
        out.textContent = 'Running ' + i + ' / ' + TESTS.length + '...'; next();
      });
    })();
  };
  if (location.hash === '#selftest') window.addEventListener('load', function () { setTimeout(window.lexiSelfTest, 800); });
})();
