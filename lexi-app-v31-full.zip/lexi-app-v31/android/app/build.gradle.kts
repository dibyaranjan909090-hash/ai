plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.purlinautomation.lexi"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.purlinautomation.lexi"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Your Lexi website address (https). It can also be changed inside the app.
        buildConfigField("String", "LEXI_URL", "\"https://YOUR-LEXI-SITE/index.html\"")
    }
    buildFeatures { buildConfig = true }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
