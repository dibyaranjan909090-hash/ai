package com.purlinautomation.lexi

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

/**
 * The floating robot. A small Lexi robot with a Mic ON/OFF button under it stays on top of every app.
 *  - Tap the robot: opens the Lexi panel (robot mode of your Lexi website) to talk/type; tap again to shrink.
 *  - Mic ON/OFF button: hands-free listening on/off, works even while the panel is closed.
 *  - Drag the robot anywhere. Answers are spoken and shown in a small speech bubble.
 * Speech uses the phone's own recogniser and voice (no AI server needed for the mic on Android).
 */
class FloatingService : Service() {

    companion object {
        @Volatile var running = false
        private const val PREFS = "lexi"
        private const val CH = "lexi_robot"
        private const val ACTION_MIC = "lexi.MIC"
        private const val ACTION_STOP = "lexi.STOP"
        fun lexiUrl(c: Context): String = c.getSharedPreferences(PREFS, MODE_PRIVATE).getString("url", BuildConfig.LEXI_URL) ?: BuildConfig.LEXI_URL
        fun saveUrl(c: Context, url: String) { c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("url", url).apply() }
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var bubble: LinearLayout
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var robotImg: ImageView
    private lateinit var micBtn: TextView
    private lateinit var sayView: TextView
    private lateinit var panel: LinearLayout
    private lateinit var panelLp: WindowManager.LayoutParams
    private lateinit var web: WebView
    private var panelOpen = false
    private var micOn = false
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val hideSay = Runnable { sayView.visibility = View.GONE }

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { s -> ttsReady = s == TextToSpeech.SUCCESS }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { js("tts-start", "") }
            override fun onDone(id: String?) { js("tts-end", "") }
            @Deprecated("old API") override fun onError(id: String?) { js("tts-end", "") }
        })
        buildPanel()
        buildBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_MIC -> setMicFromNative(!micOn)
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
        }
        return START_NOT_STICKY
    }

    // ---------- foreground notification (Android requires it while the mic can listen) ----------
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Lexi floating robot", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val mic = PendingIntent.getService(this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_MIC), flags)
        val stop = PendingIntent.getService(this, 2, Intent(this, FloatingService::class.java).setAction(ACTION_STOP), flags)
        val open = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java), flags)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Lexi robot is on your screen")
            .setContentText("Tap the robot to talk. Mic ON/OFF is under the robot.")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Mic on/off", mic).build())
            .addAction(Notification.Action.Builder(null, "Stop robot", stop).build())
            .setOngoing(true)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf() }   // Android refuses if started from the background: open the Lexi Robot app and press Start
    }

    private fun overlayType() = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    // ---------- the floating robot + mic button ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun buildBubble() {
        bubble = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        sayView = TextView(this).apply {
            setTextColor(Color.parseColor("#1A1A2E")); textSize = 13f; maxWidth = dp(220); maxLines = 5
            setPadding(dp(10), dp(7), dp(10), dp(7)); visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(14).toFloat() }
            elevation = dp(4).toFloat()
            setOnClickListener { openPanel() }
        }
        robotImg = ImageView(this).apply { setImageResource(R.drawable.robot); contentDescription = "Lexi robot. Tap to talk"; elevation = dp(6).toFloat() }
        micBtn = TextView(this).apply {
            textSize = 13f; gravity = Gravity.CENTER; setPadding(dp(12), dp(6), dp(12), dp(6)); elevation = dp(4).toFloat()
            setOnClickListener { setMicFromNative(!micOn) }
        }
        bubble.addView(sayView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(4) })
        bubble.addView(robotImg, LinearLayout.LayoutParams(dp(76), dp(76)))
        bubble.addView(micBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
        paintMic()

        val m = resources.displayMetrics
        bubbleLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val p = getSharedPreferences(PREFS, MODE_PRIVATE)
            x = p.getInt("bx", m.widthPixels - dp(110)); y = p.getInt("by", m.heightPixels / 2)
        }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        robotImg.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bubbleLp.x; oy = bubbleLp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (!moved && abs(dx) + abs(dy) > dp(8)) moved = true
                    if (moved) { bubbleLp.x = ox + dx.toInt(); bubbleLp.y = oy + dy.toInt(); wm.updateViewLayout(bubble, bubbleLp) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt("bx", bubbleLp.x).putInt("by", bubbleLp.y).apply()
                    else openPanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(bubble, bubbleLp)
    }

    private fun paintMic() {
        micBtn.text = if (micOn) "🎙 Mic ON" else "🎙 Mic OFF"
        micBtn.setTextColor(if (micOn) Color.WHITE else Color.parseColor("#374151"))
        micBtn.background = GradientDrawable().apply { setColor(Color.parseColor(if (micOn) "#16A34A" else "#E5E7EB")); cornerRadius = dp(20).toFloat() }
    }

    private fun setMicFromNative(on: Boolean) {
        micOn = on; paintMic()
        web.evaluateJavascript("window.lexiRobot&&lexiRobot.setMic($on,true)", null)
        say(if (on) "Mic is ON — just talk to me." else "Mic is OFF. Tap me to talk.", 2500)
    }

    private fun say(text: String, ms: Long) {
        if (panelOpen || text.isBlank()) return
        sayView.text = text; sayView.visibility = View.VISIBLE
        main.removeCallbacks(hideSay); main.postDelayed(hideSay, ms)
    }

    // ---------- the Lexi panel (your Lexi website in robot mode) ----------
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun buildPanel() {
        val m = resources.displayMetrics
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.parseColor("#0F1230")); cornerRadius = dp(18).toFloat() }
            clipToOutline = true; elevation = dp(10).toFloat()
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(6), dp(6)) }
        val title = TextView(this).apply { text = "⠿  Lexi"; setTextColor(Color.WHITE); textSize = 15f }
        fun barBtn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; setOnClickListener { f() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(barBtn("–") { closePanel() }, LinearLayout.LayoutParams(dp(40), dp(36)))
        bar.addView(barBtn("✕") { stopSelf() }, LinearLayout.LayoutParams(dp(40), dp(36)))

        web = WebView(this)
        web.setBackgroundColor(Color.TRANSPARENT)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false; loadWithOverviewMode = true; useWideViewPort = true
        }
        val home = Uri.parse(lexiUrl(this))
        web.addJavascriptInterface(Bridge(), "LexiAndroid")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                if (req.url.host == home.host) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, req.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                val ok = request.origin.host == home.host &&
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (ok && request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                else request.deny()
            }
        }
        val sep = if (home.query.isNullOrEmpty()) "?" else "&"
        web.loadUrl(home.toString().substringBefore('#') + sep + "mode=robot&embed=android")

        panel.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        panel.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val w = minOf(dp(320), m.widthPixels - dp(16)); val h = minOf(dp(500), (m.heightPixels * 0.7).toInt())
        panelLp = WindowManager.LayoutParams(
            w, h, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (m.widthPixels - w) / 2; y = (m.heightPixels - h) / 3
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        // drag the panel by its title bar
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y; true }
                MotionEvent.ACTION_MOVE -> { panelLp.x = ox + (e.rawX - sx).toInt(); panelLp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(panel, panelLp); true }
                else -> false
            }
        }
        wm.addView(panel, panelLp)
        // closed panel = window takes no space and no touches, but Lexi keeps running (hands-free mic)
        panelLp.width = 1; panelLp.height = 1; wm.updateViewLayout(panel, panelLp)
        panelLp.width = w; panelLp.height = h
    }

    private fun openPanel() {
        if (panelOpen) { closePanel(); return }
        panelOpen = true
        main.removeCallbacks(hideSay); sayView.visibility = View.GONE
        panel.visibility = View.VISIBLE
        panelLp.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL   // focusable: the keyboard can type into Lexi
        wm.updateViewLayout(panel, panelLp)
        bubble.visibility = View.GONE
    }

    private fun closePanel() {
        panelOpen = false
        panel.visibility = View.GONE
        val w = panelLp.width; val h = panelLp.height
        panelLp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        panelLp.width = 1; panelLp.height = 1; wm.updateViewLayout(panel, panelLp)
        panelLp.width = w; panelLp.height = h
        bubble.visibility = View.VISIBLE
    }

    // ---------- phone speech recognition + voice for the web page ----------
    private fun js(type: String, text: String) {
        val o = JSONObject().put("type", type).put("text", text).toString()
        main.post { web.evaluateJavascript("window.lexiRobot&&lexiRobot._native($o)", null) }
    }

    private fun startListening(lang: String) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { js("error", "permission"); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { js("error", "unavailable"); return }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                    override fun onPartialResults(r: Bundle?) {
                        r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { js("partial", it) }
                    }
                    override fun onResults(r: Bundle?) {
                        val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        js(if (t.isBlank()) "end" else "final", t)
                    }
                    override fun onError(e: Int) {
                        js(if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) "error" else "end",
                            if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) "permission" else "code $e")
                    }
                })
            }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { recognizer?.startListening(i) } catch (e: Exception) { js("end", "busy") }
    }

    /** What the Lexi web page can ask the phone to do (nothing else). */
    inner class Bridge {
        @JavascriptInterface fun hasSpeech(): Boolean = SpeechRecognizer.isRecognitionAvailable(this@FloatingService)
        @JavascriptInterface fun listen(lang: String) { main.post { startListening(lang) } }
        @JavascriptInterface fun stopListening() { main.post { try { recognizer?.stopListening() } catch (_: Exception) { } } }
        @JavascriptInterface fun speak(text: String, lang: String) {
            main.post {
                val t = tts ?: return@post
                if (!ttsReady) { js("tts-end", ""); return@post }
                try { t.setLanguage(Locale.forLanguageTag(lang)) } catch (_: Exception) { }
                t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lexi")
            }
        }
        @JavascriptInterface fun stopSpeaking() { main.post { tts?.stop(); js("tts-end", "") } }
        @JavascriptInterface fun micState(on: Boolean) { main.post { micOn = on; paintMic() } }
        @JavascriptInterface fun bubble(text: String) { main.post { say(text.take(240), (4000 + text.length * 50L).coerceAtMost(15000)) } }
        @JavascriptInterface fun minimize() { main.post { closePanel() } }
        @JavascriptInterface fun close() { main.post { stopSelf() } }
    }

    override fun onDestroy() {
        running = false
        try { recognizer?.destroy() } catch (_: Exception) { }
        try { tts?.shutdown() } catch (_: Exception) { }
        try { wm.removeView(bubble) } catch (_: Exception) { }
        try { wm.removeView(panel) } catch (_: Exception) { }
        try { web.destroy() } catch (_: Exception) { }
        super.onDestroy()
    }
}
