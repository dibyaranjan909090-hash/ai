package com.purlinautomation.lexi

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Set-up screen: allow "display over other apps" + microphone once, then start the floating robot.
 *  After that the robot lives on the screen; you never need to open this screen again. */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var urlBox: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding((24 * dp).toInt(), (32 * dp).toInt(), (24 * dp).toInt(), (24 * dp).toInt())
            setBackgroundColor(Color.parseColor("#0F1230"))
        }
        root.addView(ImageView(this).apply { setImageResource(R.drawable.robot) }, LinearLayout.LayoutParams((140 * dp).toInt(), (140 * dp).toInt()))
        root.addView(TextView(this).apply {
            text = "Lexi Floating Robot"; textSize = 24f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Lexi's robot floats on top of every app. Tap it to talk, use the Mic ON/OFF button under it for hands-free.\nPurlin Automation Pvt. Ltd."
            setTextColor(Color.parseColor("#C7CAF5")); gravity = Gravity.CENTER; setPadding(0, (8 * dp).toInt(), 0, (16 * dp).toInt())
        })
        urlBox = EditText(this).apply {
            hint = "Lexi website address (https://…)"
            setText(FloatingService.lexiUrl(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        root.addView(urlBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 16f
            setOnClickListener { onClick() }
        }.also { root.addView(it, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (54 * dp).toInt()).apply { topMargin = (10 * dp).toInt() }) }

        button("1. Allow \"Display over other apps\"") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("2. Allow microphone") { askPermissions() }
        button("3. ▶ Start floating robot") { start() }
        button("Stop floating robot") {
            stopService(Intent(this, FloatingService::class.java)); refresh()
        }
        status = TextView(this).apply { setTextColor(Color.parseColor("#A7F3D0")); setPadding(0, (16 * dp).toInt(), 0, 0); gravity = Gravity.CENTER }
        root.addView(status)
        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Color.parseColor("#0F1230")) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun askPermissions() {
        val want = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) want += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(want.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults); refresh()
    }

    private fun start() {
        val url = urlBox.text.toString().trim()
        if (!url.startsWith("https://") || url.contains("YOUR-LEXI-SITE")) {
            Toast.makeText(this, "Type your Lexi website address (https://…) first", Toast.LENGTH_LONG).show(); return
        }
        FloatingService.saveUrl(this, url)
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Step 1: allow \"Display over other apps\" for Lexi Robot", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Step 2: allow the microphone so Lexi can hear you", Toast.LENGTH_LONG).show()
            askPermissions(); return
        }
        startForegroundService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "Lexi robot is on your screen", Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        status.text = (if (overlay) "✓ Display over other apps" else "✗ Display over other apps") + "\n" +
            (if (mic) "✓ Microphone" else "✗ Microphone") + "\n" +
            (if (FloatingService.running) "● Floating robot is running" else "○ Floating robot is off")
    }
}
