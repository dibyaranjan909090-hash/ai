# Lexi Robot for Android — floating robot over every app

A small Lexi robot floats on top of all apps (like a chat head).
- **Tap the robot** → the Lexi panel opens (your Lexi website in robot mode): talk, type, see answers. Tap **–** to shrink back to the robot.
- **🎙 Mic ON / Mic OFF** under the robot → hands-free listening on/off. Works while the panel is closed; answers are spoken and shown in a small bubble.
- **Drag** the robot anywhere (it remembers the place). **✕** in the panel or the notification's **Stop robot** closes it.
- Voice commands: "mic off", "mic on", "open full Lexi".
- Uses the phone's own speech recognition and voice, so the mic works **without** the AI server.

## What you need
- Android Studio (Ladybug 2024.2 or newer) on a computer with internet.
- Your Lexi website published on **https** (Netlify, GitHub Pages, your hosting). The Android app shows that website.

## Build the APK (about 10 minutes)
1. Android Studio → **Open** → choose this `android` folder. Let it download Gradle and the Android SDK (first time only).
2. Optional: in `app/build.gradle.kts` change `https://YOUR-LEXI-SITE/index.html` to your Lexi address (it can also be typed inside the app).
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. The file is `app/build/outputs/apk/debug/app-debug.apk`.
   Or with a USB-connected phone: press ▶ Run.
4. Command line instead: `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).

## First start on the phone
1. Install the APK (allow "install unknown apps" for your file manager the first time).
2. Open **Lexi Robot** → type your Lexi website address.
3. **1. Allow "Display over other apps"** → switch on for Lexi Robot → come back.
4. **2. Allow microphone** → Allow.
5. **3. ▶ Start floating robot**. The robot appears; the setup screen goes to the background.

## Notes
- Android always shows a notification while the robot can use the mic — that is required by Android.
- Some phones (Xiaomi/MIUI, Oppo, Vivo, Realme) also need: App info → Other permissions → "Display pop-up windows" and
  battery → "No restrictions", or the robot may be closed in the background.
- For a Play Store release: Build → Generate Signed Bundle, and explain the overlay + microphone use in the store listing.
- Package name: `com.purlinautomation.lexi`. Minimum Android 8.0.
