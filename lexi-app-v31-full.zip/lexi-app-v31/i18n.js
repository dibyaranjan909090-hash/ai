/* Lexi i18n.js v22: install any language into Lexi.
   Installing a language (Training Center > Languages, or say "install Tamil"):
   - translates the whole interface once with AI (buttons, menus, tips, Training Center) and keeps it offline;
   - keeps learning: new text that appears later is translated in the background;
   - switches listening and speaking to that language when the phone supports it, and makes Lexi reply in it;
   - shows how to add the phone's voice and offline speech for that language, with test buttons.
   About 190 languages can be installed. "English (original)" switches back at any time. */
(function (root) {
'use strict';
var doc = root.document;
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
var K = 'lexi_i18n';
var ST = L(K, { cur: 'en', packs: {} }); if (!ST.packs) ST.packs = {};
function save() { if (!S(K, ST)) { /* storage full: keep only the current pack */ var p = {}; if (ST.packs[ST.cur]) p[ST.cur] = ST.packs[ST.cur]; ST.packs = p; S(K, ST); } }

/* ---------- every language that can be installed (ISO 639 codes) ---------- */
var CODES = ('af ak am ar as ay az ba be bg bho bm bn bo br bs ca ceb ckb co cs cy da de doi dv dz ee el en eo es et eu fa ff fi fil fj fo fr fy ga gd gl gn gom gu ha haw he hi hmn hr ht hu hy id ig ilo is it iu ja jv ka kk km kn ko kri ks ku ky la lb lg ln lo lt lus lv mai mg mi mk ml mn mni mr ms mt my ne new nl no nso ny oc om or os pa pam pl ps pt qu rn ro ru rw sa sat sd se sg si sk sl sm sn so sq sr ss st su sv sw ta te tg th ti tk tn to tr ts tt tw ty ug uk ur uz ve vi wo xh yi yo yue zh zh-TW zu ' +
  'tcy kok brx mwr hne gbm raj bgc awa mag sck kru gon bhb lmn wbr').split(' ');
var EXTRA = { tcy: ['Tulu', 'ತುಳು'], kok: ['Konkani', 'कोंकणी'], gom: ['Goan Konkani', 'कोंकणी'], brx: ['Bodo', 'बड़ो'], mwr: ['Marwari', 'मारवाड़ी'], hne: ['Chhattisgarhi', 'छत्तीसगढ़ी'], gbm: ['Garhwali', 'गढ़वळि'], raj: ['Rajasthani', 'राजस्थानी'], bgc: ['Haryanvi', 'हरियाणवी'], awa: ['Awadhi', 'अवधी'], mag: ['Magahi', 'मगही'], sck: ['Sadri', 'सादरी'], kru: ['Kurukh', 'कुड़ुख़'], gon: ['Gondi', 'गोंडी'], bhb: ['Bhili', 'भीली'], lmn: ['Lambadi', 'लम्बाडी'], wbr: ['Wagdi', 'वागड़ी'], sat: ['Santali', 'ᱥᱟᱱᱛᱟᱲᱤ'], mni: ['Manipuri (Meitei)', 'ꯃꯤꯇꯩꯂꯣꯟ'], doi: ['Dogri', 'डोगरी'], lus: ['Mizo', 'Mizo ṭawng'], new: ['Newari', 'नेपाल भाषा'], bho: ['Bhojpuri', 'भोजपुरी'], mai: ['Maithili', 'मैथिली'] };
var dnEn = null, dnSelf = {};
try { dnEn = new Intl.DisplayNames(['en'], { type: 'language' }); } catch (e) { }
function nameOf(c) { if (EXTRA[c]) return EXTRA[c][0]; try { var n = dnEn && dnEn.of(c); if (n && n !== c) return n; } catch (e) { } return c; }
function nativeOf(c) {
  if (EXTRA[c]) return EXTRA[c][1];
  try { dnSelf[c] = dnSelf[c] || new Intl.DisplayNames([c], { type: 'language' }); var n = dnSelf[c].of(c); if (n && n !== c) return n.charAt(0).toLocaleUpperCase(c) + n.slice(1); } catch (e) { }
  return nameOf(c);
}
function catalog() {
  var J = root.JTLANG, voice = {};
  if (J) J.LANGS.forEach(function (l) { voice[l.c] = l.s; });
  var seen = {};
  return CODES.filter(function (c, i, a) { return a.indexOf(c) === i; }).map(function (c) { return { c: c, name: nameOf(c), native: nativeOf(c), speech: voice[c] || '' }; })
    .filter(function (l) { if (seen[l.name]) return false; seen[l.name] = 1; return true; })
    .sort(function (a, b) { return a.name.localeCompare(b.name); });
}
function find(q) {
  q = String(q || '').toLowerCase().trim(); if (!q) return null;
  var al = { hindustani: 'hi', farsi: 'fa', mandarin: 'zh', cantonese: 'yue', bangla: 'bn', oriya: 'or', odiya: 'or', tagalog: 'fil', burmese: 'my', kannad: 'kn', panjabi: 'pa', 'brazilian portuguese': 'pt', 'traditional chinese': 'zh-TW', 'simplified chinese': 'zh', norwegian: 'no', 'meitei': 'mni' };
  if (al[q]) q = al[q];
  var cat = catalog();
  return cat.filter(function (l) { return l.c.toLowerCase() === q || l.name.toLowerCase() === q || l.native.toLowerCase() === q; })[0] ||
    cat.filter(function (l) { return l.name.toLowerCase().indexOf(q) === 0 || l.native.toLowerCase().indexOf(q) === 0; })[0] || null;
}

/* ---------- which text is interface text ---------- */
var KNOWN = ['Edit', 'Copy', 'Copied', '✏️ Edit', '📋 Copy', '🔊 Read', '🌐 Translate…', 'Save & send', 'Cancel', 'Read more ↗', 'Open YouTube ↗', 'Ask anything…', 'Type your question',
  'How can I help you today?', 'Ask anything, or tap the mic and speak.', 'Hands-free', 'Install', 'Clear chat', 'Speak replies', 'Settings', 'Send',
  'Photo, video, zip or file', 'Training Center', 'Teach Lexi', 'Self-test', 'AI VOICE ASSISTANT', 'Close', 'Remembered', 'Hello! I am Lexi, your assistant. How can I help you today?',
  '💡 Explain simply', '🇮🇳 Hindi meaning', '✍️ Use in sentences', 'Similar:', 'Opposite:', 'Did you mean', 'Word of the day', '📅 Word of the day',
  'Show meaning', '✅ I knew it', '🔁 Again', 'Run test', '▶ Run test', 'Stop', 'Save', 'Add', 'Remove', 'Download', 'Restore from file', 'Forget everything', 'Remember'];
var SKIP_SEL = 'script,style,code,pre,textarea,svg,[data-noi18n],#lang,.lxd-w,.lxd-ph';
var SKIP_ATTR = 'script,style,code,pre,svg,[data-noi18n],#lang'; /* text boxes keep what people type, but their hints are translated */
function inMessage(el) { var m = el.closest && el.closest('#log .row .m'); if (!m) return false; return !(el.closest('button,.lxd-pos,.lxd-b,.lxd-c,.jt-tools')); }
var BRAND = /^(?:Lexi|Purlin(?: Automation(?: Pvt\. Ltd\.)?)?|PAI-01-V1|WhatsApp|YouTube|Google|Gemini|Claude|ChatGPT|Groq|OpenRouter|Ollama|WordNet|Wiktionary|English)$/;
function isUiText(s) { s = String(s).trim(); return !BRAND.test(s) && s.length > 0 && s.length <= 400 && /[A-Za-z]{2}/.test(s) && !/^https?:\/\//.test(s) && !/^[\w.+-]+@[\w.-]+$/.test(s); }
/* numbers become {n} so "Remembered (5)" and "Remembered (12)" share one translation */
function keyOf(s) { return String(s).trim().replace(/\d+(?:[.,:]\d+)*/g, '{n}'); }
function fill(tpl, orig) { var nums = String(orig).match(/\d+(?:[.,:]\d+)*/g) || [], i = 0; return tpl.replace(/\{n\}/g, function () { return nums[i++] || ''; }); }

/* ---------- apply a language to the page ---------- */
var ORIG = new WeakMap(), ATTRS = ['placeholder', 'title', 'aria-label'];
var pending = {}, map = null;
function tr(s) { if (!map) return null; var k = keyOf(s), t = map[k]; return t ? fill(t, s) : null; }
function want(s) { var k = keyOf(s); if (map && !map[k] && isUiText(k)) pending[k] = 1; }
function doText(n) {
  var p = n.parentElement; if (!p || p.closest(SKIP_SEL) || inMessage(p)) return;
  var o = ORIG.get(n);
  var cur = n.nodeValue;
  if (o && cur !== o.t) o = null; /* the app changed this text itself */
  var src = o ? o.s : cur, s = src.trim(); if (!isUiText(s)) return;
  var t = tr(s);
  if (t) { var out = src.replace(s, t); if (cur !== out) { n.nodeValue = out; ORIG.set(n, { s: src, t: out }); } }
  else { if (o) { n.nodeValue = o.s; ORIG.delete(n); } want(s); }
}
function doAttrs(el) {
  if (el.closest(SKIP_ATTR + ',#log .row .m .src')) return;
  ATTRS.forEach(function (a) {
    if (!el.hasAttribute(a)) return;
    var keep = 'data-i18n-' + a, src = el.getAttribute(keep) || el.getAttribute(a), cur = el.getAttribute(a);
    if (el.getAttribute(keep) && cur !== el.getAttribute('data-i18n-t-' + a)) src = cur; /* changed by the app */
    if (!isUiText(src)) return;
    var t = tr(src);
    if (t) { el.setAttribute(keep, src); el.setAttribute('data-i18n-t-' + a, t); el.setAttribute(a, t); }
    else { if (el.getAttribute(keep)) { el.setAttribute(a, el.getAttribute(keep)); el.removeAttribute(keep); } want(src); }
  });
}
function walk(rootEl) {
  if (!rootEl) return;
  if (rootEl.nodeType === 3) return doText(rootEl);
  if (rootEl.nodeType !== 1) return;
  if (rootEl.matches && rootEl.matches(SKIP_SEL)) return;
  doAttrs(rootEl);
  var tw = doc.createTreeWalker(rootEl, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT), n;
  while ((n = tw.nextNode())) { if (n.nodeType === 3) doText(n); else doAttrs(n); }
}
function revert() {
  var tw = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT), n;
  while ((n = tw.nextNode())) {
    if (n.nodeType === 3) { var o = ORIG.get(n); if (o && n.nodeValue === o.t) n.nodeValue = o.s; ORIG.delete(n); }
    else ATTRS.forEach(function (a) { var k = 'data-i18n-' + a; if (n.getAttribute && n.getAttribute(k)) { n.setAttribute(a, n.getAttribute(k)); n.removeAttribute(k); n.removeAttribute('data-i18n-t-' + a); } });
  }
}
var queued = [], raf = 0, obs = null;
function schedule(nodes) { queued.push.apply(queued, nodes); if (!raf) raf = (root.requestAnimationFrame || setTimeout)(flush); }
function flush() { raf = 0; var q = queued; queued = []; if (!map) return; obs && obs.disconnect(); try { q.forEach(walk); } finally { observe(); } learnSoon(); }
function observe() {
  if (!obs) obs = new MutationObserver(function (ms) { var a = []; ms.forEach(function (m) { if (m.type === 'attributes') a.push(m.target); else m.addedNodes.forEach(function (x) { a.push(x); }); if (m.type === 'characterData') a.push(m.target); }); if (a.length) schedule(a); });
  obs.observe(doc.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
}
function tagline() {
  var b = doc.querySelector('header>b'); if (!b) return;
  var t = map && map[keyOf('AI VOICE ASSISTANT')];
  if (!doc.getElementById('i18ncss')) { var st = doc.createElement('style'); st.id = 'i18ncss'; st.textContent = 'header>b[data-tag]::after{content:attr(data-tag)!important}#log .row .m{unicode-bidi:plaintext}'; doc.head.appendChild(st); }
  if (t) b.setAttribute('data-tag', t.toLocaleUpperCase(ST.cur)); else b.removeAttribute('data-tag');
}
function use(code) {
  var pk = ST.packs[code];
  ST.cur = pk ? code : 'en'; save();
  revert();
  map = pk ? pk.map : null;
  doc.documentElement.lang = map ? code : 'en';
  tagline();
  if (map) { walk(doc.body); observe(); } else if (obs) obs.disconnect();
  /* listening/speaking language follows when the phone supports it */
  try { var sel = doc.getElementById('lang'), sp = pk && pk.speech; if (sel && sp && sel.value !== sp) { if (![].some.call(sel.options, function (o) { return o.value === sp; })) { var op = doc.createElement('option'); op.value = sp; op.textContent = pk.native; sel.appendChild(op); } sel.value = sp; sel.dispatchEvent(new Event('change', { bubbles: true })); } } catch (e) { }
  try { if (root.lexiTrainRebuild) root.lexiTrainRebuild(); } catch (e) { }
}

/* ---------- translation by AI (any provider; free AI without a key) ---------- */
function rawAI(system, user, ms) {
  var CFG = root.CFG || {}, H = { 'content-type': 'application/json' }, ctl = new AbortController();
  setTimeout(function () { try { ctl.abort(); } catch (e) { } }, ms || 45000);
  system = '[LEXI-TRAIN][/LEXI-TRAIN] ' + system; /* marker: no company knowledge is added to this request */
  var o = { method: 'POST', signal: ctl.signal, headers: H };
  function oai(u, key, model) { if (key) H.authorization = 'Bearer ' + key; o.body = JSON.stringify({ model: model, temperature: 0.2, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }); return root.fetch(u, o).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.choices[0].message.content; }); }
  var tries = [];
  if (CFG.gk) tries.push(function () { o.body = JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: [{ role: 'user', parts: [{ text: user }] }], generationConfig: { temperature: 0.2, responseMimeType: 'application/json' } }); return root.fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(CFG.gk), o).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.candidates[0].content.parts.map(function (p) { return p.text || ''; }).join(''); }); });
  if (CFG.ak) tries.push(function () { var h2 = Object.assign({}, H, { 'x-api-key': CFG.ak, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }); return root.fetch('https://api.anthropic.com/v1/messages', { method: 'POST', signal: ctl.signal, headers: h2, body: JSON.stringify({ model: 'claude-haiku-5-5', max_tokens: 8000, system: system, messages: [{ role: 'user', content: user }] }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.content[0].text; }); });
  if (CFG.ok) tries.push(function () { return oai('https://api.openai.com/v1/chat/completions', CFG.ok, 'gpt-4.1-mini'); });
  if (CFG.grk) tries.push(function () { return oai('https://api.groq.com/openai/v1/chat/completions', CFG.grk, 'llama-3.3-70b-versatile'); });
  if (CFG.ork) tries.push(function () { return oai('https://openrouter.ai/api/v1/chat/completions', CFG.ork, 'openrouter/auto'); });
  tries.push(function () { return oai('https://text.pollinations.ai/openai', '', 'openai'); });
  return tries.reduce(function (p, f) { return p.catch(f); }, Promise.reject());
}
function parseObj(t) { var s = String(t || ''), a = s.indexOf('{'), b = s.lastIndexOf('}'); if (a < 0 || b <= a) throw new Error('no JSON'); return JSON.parse(s.slice(a, b + 1)); }
function translateBatch(strings, lang) {
  var sys = 'You translate the user interface of a voice assistant app called Lexi into ' + lang.name + ' (' + lang.native + '). ' +
    'Translate every value naturally and briefly, the way a phone app in ' + lang.name + ' would say it. Use the native script of ' + lang.name + '. ' +
    'Keep emojis, symbols, "{n}" placeholders, line breaks, quotes and arrows exactly. Do not translate brand or product names (Lexi, Purlin, Purlin Automation, PAI-01-V1, WhatsApp, YouTube, Google, Gemini, Claude, ChatGPT, Groq, OpenRouter, Ollama, Colab, WordNet, Wiktionary, PDF, JSON, JSONL, API, URL, IP65). ' +
    'Commands the user can type (shown in quotes like “meaning of …”) may stay in English. ' +
    'Reply with ONLY a JSON object whose keys are the given numbers and whose values are the translations.';
  var obj = {}; strings.forEach(function (s, i) { obj[i + 1] = s; });
  return rawAI(sys, JSON.stringify(obj)).then(parseObj).then(function (o) {
    var out = {};
    strings.forEach(function (s, i) {
      var v = o[i + 1] || o[String(i + 1)]; if (typeof v !== 'string' || !v.trim()) return;
      v = v.trim();
      /* safety check: the translation must keep the same emojis/symbols and {n} slots, so a shifted answer never lands on the wrong button */
      var sym = function (x) { return (x.match(/[\p{Extended_Pictographic}✓✕✅❌↻→↳▶⬇★🔊]/gu) || []).sort().join(''); };
      var slots = function (x) { return (x.match(/\{n\}/g) || []).length; };
      if (sym(s) !== sym(v) || slots(s) !== slots(v)) return;
      out[s] = v;
    });
    return out;
  });
}
function translateAll(list, lang, onProgress) {
  var size = 35, batches = [], done = 0, out = {};
  for (var i = 0; i < list.length; i += size) batches.push(list.slice(i, i + size));
  var idx = 0;
  function worker() {
    if (idx >= batches.length) return Promise.resolve();
    var b = batches[idx++];
    return translateBatch(b, lang).catch(function () { return translateBatch(b, lang); }).catch(function () { return {}; })
      .then(function (m) { Object.assign(out, m); done += b.length; if (onProgress) onProgress(done, list.length); return worker(); });
  }
  return Promise.all([worker(), worker(), worker()]).then(function () { return out; });
}

/* ---------- gather all interface text (including every Training Center tab) ---------- */
function harvest() {
  var set = {};
  function add(s) { var k = keyOf(s); if (isUiText(k)) set[k] = 1; }
  KNOWN.forEach(add);
  function scan(el) {
    var tw = doc.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT), n;
    while ((n = tw.nextNode())) {
      if (n.nodeType === 3) { var p = n.parentElement; if (p && !p.closest(SKIP_SEL) && !inMessage(p)) add(n.nodeValue); }
      else ATTRS.forEach(function (a) { if (n.getAttribute && n.getAttribute(a) && !n.closest(SKIP_ATTR)) add(n.getAttribute(a)); });
    }
  }
  scan(doc.body);
  /* the + menu and the Training Center are built on demand: open them out of sight to read their text */
  try { var pb = doc.getElementById('plusb'); if (pb && !doc.getElementById('lxm')) { pb.click(); var mm = doc.getElementById('lxm'); if (mm) { scan(mm); mm.remove(); } } } catch (e) { }
  try {
    if (root.lexiTrain) {
      var had = doc.getElementById('ltc');
      if (!had) { root.lexiTrain('home'); var box = doc.getElementById('ltc'); box.style.visibility = 'hidden'; box.querySelectorAll('nav button').forEach(function (b) { b.click(); scan(box); }); box.remove(); }
      else { var on = had.querySelector('nav button.on'); had.querySelectorAll('nav button').forEach(function (b) { b.click(); scan(had); }); if (on) on.click(); }
    }
  } catch (e) { }
  Object.keys(pending).forEach(function (k) { set[k] = 1; });
  return Object.keys(set);
}

/* ---------- install / update / remove ---------- */
function voiceSpeech(c) { var J = root.JTLANG; if (!J) return ''; var l = J.langBy(c === 'fil' ? 'filipino' : c); return l ? l.s : ''; }
function install(code, onProgress) {
  var lang = find(code); if (!lang) return Promise.reject(new Error('Unknown language: ' + code));
  if (lang.c === 'en') { use('en'); return Promise.resolve({ lang: lang, count: 0 }); }
  var old = ST.packs[lang.c], strings = harvest();
  var todo = old ? strings.filter(function (s) { return !old.map[s]; }) : strings;
  if (onProgress) onProgress(0, todo.length);
  return translateAll(todo, lang, onProgress).then(function (m) {
    var got = Object.keys(m).length;
    if (!got && !old) throw new Error('No translation came back. Check the internet (or add an AI key) and try again.');
    var pk = old || { c: lang.c, name: lang.name, native: lang.native, map: {} };
    Object.assign(pk.map, m); pk.t = Date.now(); pk.count = Object.keys(pk.map).length; pk.speech = voiceSpeech(lang.c);
    ST.packs[lang.c] = pk; save(); use(lang.c);
    return { lang: lang, count: got, total: pk.count };
  });
}
function uninstall(code) { delete ST.packs[code]; if (ST.cur === code) use('en'); else save(); }
/* text that shows up later (new panels, messages' buttons) is translated in the background */
var learnT = null;
function learnSoon() {
  if (!map || learnT) return;
  learnT = setTimeout(function () {
    learnT = null; var ks = Object.keys(pending).slice(0, 60); if (!ks.length || !navigator.onLine) return;
    var pk = ST.packs[ST.cur], lang = find(ST.cur); if (!pk || !lang) return;
    ks.forEach(function (k) { delete pending[k]; });
    translateAll(ks, lang).then(function (m) { if (!Object.keys(m).length) return; Object.assign(pk.map, m); pk.count = Object.keys(pk.map).length; save(); if (ST.cur === pk.c) { map = pk.map; walk(doc.body); } });
  }, 2500);
}

/* ---------- phone voices and offline speech: what to do on this device ---------- */
function platform() { var u = navigator.userAgent; if (/Android/i.test(u)) return 'android'; if (/iPhone|iPad|iPod/i.test(u) || (/Mac/.test(u) && 'ontouchend' in doc)) return 'ios'; if (/Windows/i.test(u)) return 'windows'; if (/Mac/i.test(u)) return 'mac'; return 'other'; }
var GUIDE = {
  android: ['Read-aloud voice: Settings → System → Languages & input → Text-to-speech output → Speech Services by Google ⚙️ → Install voice data → choose the language → download.', 'Listening without internet: open the Google app → Settings → Voice → Offline speech recognition → All → download the language.', 'Then reopen Lexi.'],
  ios: ['Read-aloud voice: Settings → Accessibility → Spoken Content → Voices → choose the language → download a voice (Enhanced is clearer).', 'Listening: Settings → General → Keyboard → Keyboards → Add New Keyboard → add the language (turn on Dictation).', 'Then reopen Lexi in Safari or from the home screen.'],
  windows: ['Read-aloud voice: Settings → Time & language → Language & region → Add a language → choose it and tick Text-to-speech and Speech recognition.', 'Or: Settings → Time & language → Speech → Manage voices → Add voices.', 'Then restart Chrome or Edge.'],
  mac: ['Read-aloud voice: System Settings → Accessibility → Spoken Content → System voice → Manage Voices → tick a voice for the language.', 'Then restart the browser.'],
  other: ['Install a text-to-speech voice for the language in your system settings, then restart the browser.']
};
function hasVoice(c) { try { return speechSynthesis.getVoices().some(function (v) { return v.lang.replace('_', '-').toLowerCase().indexOf(c.toLowerCase()) === 0; }); } catch (e) { return false; } }
function testVoice(c, text) {
  try {
    speechSynthesis.cancel(); var u = new SpeechSynthesisUtterance(text);
    var v = speechSynthesis.getVoices().filter(function (x) { return x.lang.replace('_', '-').toLowerCase().indexOf(c.toLowerCase()) === 0; })[0];
    if (v) { u.voice = v; u.lang = v.lang; } else u.lang = c;
    speechSynthesis.speak(u); return !!v;
  } catch (e) { return false; }
}
function testListen(speechCode, cb) {
  var R = root.SpeechRecognition || root.webkitSpeechRecognition;
  if (!R) return cb('', 'This browser cannot listen. Use Chrome or Edge on Android or a computer, or Safari on iPhone.');
  try {
    var r = new R(); r.lang = speechCode; r.interimResults = false; r.maxAlternatives = 1;
    r.onresult = function (e) { cb(e.results[0][0].transcript, ''); };
    r.onerror = function (e) { cb('', e.error === 'language-not-supported' ? 'This phone cannot listen in this language yet.' : e.error === 'not-allowed' ? 'Allow the microphone for this site first.' : 'Did not hear anything (' + e.error + ').'); };
    r.start();
  } catch (e) { cb('', String(e.message || e)); }
}

/* ---------- chat commands: "install tamil", "switch app to hindi", "app ko marathi mein karo" ---------- */
var CMD = [
  /^(?:install|add|download|enable)\s+(?:the\s+)?(.{2,30}?)(?:\s+language)?(?:\s+(?:pack|in lexi|to lexi))?\s*[.!]?$/i,
  /^(?:switch|change|set|make)\s+(?:the\s+)?(?:app|lexi|interface|ui|app language|language of (?:the )?app)\s+(?:language\s+)?(?:to|into|in)\s+(.{2,30}?)\s*[.!]?$/i,
  /^(?:app|lexi|interface)\s+(?:ko|ki bhasha)\s+(.{2,30}?)\s+(?:mein|me|main)\s+(?:karo|kar do|badlo|chalao)\s*[.!]?$/i,
  /^(?:english|angrezi) (?:interface|app)$|^(?:switch|change) (?:the )?(?:app|interface) (?:back )?to english$/i
];
function command(raw) {
  var t = String(raw || '').trim(); if (t.length > 70) return null;
  for (var i = 0; i < CMD.length; i++) {
    var m = CMD[i].exec(t); if (!m) continue;
    var q = i === 3 ? 'en' : m[1].replace(/\b(language|bhasha|bhasa)\b/ig, '').trim();
    var lang = find(q); if (!lang) return null;  /* "install whatsapp" etc. are not languages */
    return { lang: lang };
  }
  return null;
}
function runCommand(c, say) {
  var lang = c.lang;
  if (lang.c === 'en') { use('en'); return say('The app is back in English.'); }
  if (ST.packs[lang.c]) { use(lang.c); return say('✅ ' + lang.native + ' (' + lang.name + ') is on.'); }
  say('⏳ Installing ' + lang.name + ' (' + lang.native + ')… translating the app. This takes about a minute and is needed only once.');
  install(lang.c).then(function (r) {
    var sp = r.lang && voiceSpeech(lang.c);
    say('✅ ' + lang.name + ' is installed: ' + r.total + ' interface texts translated. ' + (sp ? (hasVoice(lang.c) ? 'Speaking and listening are set to ' + lang.name + '.' : 'Listening is set to ' + lang.name + '. To hear replies aloud, add the ' + lang.name + ' voice: + → Training Center → Languages.') : lang.name + ' works for typing and replies; this phone cannot speak or listen in it yet.'));
  }).catch(function (e) { say('Could not install ' + lang.name + ': ' + (e && e.message || e)); });
}

root.lexiI18n = { catalog: catalog, find: find, install: install, uninstall: uninstall, use: use, packs: function () { return ST.packs; }, current: function () { return ST.cur; },
  currentLang: function () { return ST.cur === 'en' ? null : (ST.packs[ST.cur] || null); }, harvest: harvest, platform: platform, guide: function () { return GUIDE[platform()]; },
  rawAI: rawAI, hasVoice: hasVoice, testVoice: testVoice, testListen: testListen, command: command, runCommand: runCommand, t: function (s) { return tr(s) || s; }, _keyOf: keyOf, _fill: fill };

/* start in the installed language */
function start() { if (ST.cur !== 'en' && ST.packs[ST.cur]) setTimeout(function () { use(ST.cur); }, 300); else tagline(); }
if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', start); else start();
/* the voice-language box: picking a language that has a pack switches the app too */
setTimeout(function () {
  var sel = doc.getElementById('lang'); if (!sel) return;
  sel.addEventListener('change', function () { if (root.__lexiMicAuto) return; var c = (sel.value || '').slice(0, 2).toLowerCase(), cur = ST.cur.slice(0, 2); if (c === cur) return; if (ST.packs[c]) use(c); else if (c === 'en' && ST.cur !== 'en') use('en'); });
}, 1200);
})(window);
