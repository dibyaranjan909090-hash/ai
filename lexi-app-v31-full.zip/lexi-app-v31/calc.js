/* Lexi calc.js
   Offline calculation engine: expressions with exact big integers, equations,
   linear systems, polynomial calculus, statistics, finance, dates, number bases.
   Pure logic: works in the browser and in Node (window.JTCALC / globalThis.JTCALC). */
(function (root) {
'use strict';

var FN1 = { sin: 1, cos: 1, tan: 1, asin: 1, acos: 1, atan: 1, sinh: 1, cosh: 1, tanh: 1, sqrt: 1, cbrt: 1, ln: 1, log: 1, log2: 1, log10: 1, exp: 1, abs: 1, floor: 1, ceil: 1, round: 1, trunc: 1, sign: 1, fact: 1, rad: 1, deg: 1 };
var FNN = { max: 1, min: 1, sum: 1, avg: 1, mean: 1, median: 1, std: 1, var: 1, gcd: 1, lcm: 1, ncr: 1, npr: 1, pow: 1, hypot: 1, logb: 1, mod: 1, atan2: 1 };
var CONST = { pi: Math.PI, e: Math.E, tau: 2 * Math.PI, phi: (1 + Math.sqrt(5)) / 2 };
var TRIG = { sin: 1, cos: 1, tan: 1 }, ATRIG = { asin: 1, acos: 1, atan: 1 };

/* ---------- text -> canonical expression ---------- */
function canon(s) {
  s = ' ' + String(s).toLowerCase() + ' ';
  s = s.replace(/[×✕]/g, '*').replace(/[÷]/g, '/').replace(/[−–—]/g, '-').replace(/π/g, ' pi ').replace(/√\s*\(/g, ' sqrt(').replace(/√\s*([\d.]+)/g, ' sqrt($1)').replace(/∛\s*([\d.]+)/g, ' cbrt($1)').replace(/[?]/g, ' ').replace(/\s*=\s*$/, ' ');
  s = s.replace(/\b(?:please|calculate|calc|compute|evaluate|work out|solve|simplify|what(?:'s| is| are)?|whats|find|tell me|the value of|value of|answer(?: of)?|result of|how much is|how many is)\b/g, ' ');
  s = s.replace(/(\d)\s*,\s*(?=\d{3}\b)/g, '$1'); /* 1,000 -> 1000 */
  s = s.replace(/\b(\d+(?:\.\d+)?)\s*(?:%|percent|per cent)\s+of\b/g, '($1/100)*');
  s = s.replace(/\b(?:increase|raise|add)\s+(\d+(?:\.\d+)?)\s+by\s+(\d+(?:\.\d+)?)\s*(?:%|percent)/g, '$1*(1+$2/100)');
  s = s.replace(/\b(?:decrease|reduce|cut|subtract)\s+(\d+(?:\.\d+)?)\s+by\s+(\d+(?:\.\d+)?)\s*(?:%|percent)/g, '$1*(1-$2/100)');
  s = s.replace(/\blog\s*base\s*(\d+(?:\.\d+)?)\s*(?:of)?\s*(\d+(?:\.\d+)?)/g, 'logb($1,$2)');
  s = s.replace(/\bnatural\s+log(?:arithm)?(?:\s+of)?\b/g, 'ln ').replace(/\b(?:absolute value|modulus)(?:\s+of)?\b/g, 'abs ').replace(/\bsquare\s*root(?:\s+of)?\b/g, 'sqrt ').replace(/\bcube\s*root(?:\s+of)?\b/g, 'cbrt ');
  s = s.replace(/\bfactorial\s+of\s+(\d+)/g, 'fact($1)').replace(/\b(\d+)\s+factorial\b/g, 'fact($1)').replace(/\b(\d+)\s*!/g, 'fact($1)');
  s = s.replace(/\b(\d+)\s*(?:choose|c)\s*(\d+)\b/g, 'ncr($1,$2)').replace(/\b(\d+)\s*p\s*(\d+)\b/g, 'npr($1,$2)');
  s = s.replace(/\b(\d+(?:\.\d+)?)\s*(?:squared)\b/g, '($1)^2').replace(/\b(\d+(?:\.\d+)?)\s*(?:cubed)\b/g, '($1)^3');
  s = s.replace(/\bsquared\b/g, '^2').replace(/\bcubed\b/g, '^3');
  s = s.replace(/\b(?:to the power of|to the power|raised to the power of|raised to|power of|power)\b/g, '^');
  s = s.replace(/\b(?:multiplied by|multiply by|multiply|times|into)\b/g, '*').replace(/\b(?:divided by|divide by|divide|over)\b/g, '/').replace(/\bplus\b/g, '+').replace(/\bminus\b/g, '-').replace(/\b(?:modulo|mod|remainder)\b/g, '%');
  s = s.replace(/(\d)\s*x\s*(?=[\d(])/g, '$1*'); /* 3 x 4 */
  s = s.replace(/\b(sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|sqrt|cbrt|ln|log|log2|log10|exp|abs|fact)\s+of\s+/g, '$1 ');
  s = s.replace(/(\d)\s*°/g, '$1 deg ').replace(/\bdegrees?\b/g, ' deg ').replace(/\bradians?\b/g, ' rad ');
  s = s.replace(/\bhalf of\b/g, '0.5*').replace(/\bquarter of\b/g, '0.25*').replace(/\bthird of\b/g, '(1/3)*').replace(/\bdouble\b/g, '2*').replace(/\btriple\b/g, '3*');
  s = s.replace(/\bof\b/g, '*');
  return s.replace(/\s+/g, ' ').trim();
}
function hasRad(s) { return /\bpi\b|\btau\b|\brad\b|asin|acos|atan/.test(s); }

/* ---------- tokenizer + parser ---------- */
function tokenize(s) {
  var t = [], i = 0, m;
  while (i < s.length) {
    var c = s[i];
    if (c === ' ') { i++; continue; }
    if ((m = /^0x[0-9a-f]+/.exec(s.slice(i)))) { t.push({ t: 'num', v: parseInt(m[0], 16), big: BigInt(m[0]) }); i += m[0].length; continue; }
    if ((m = /^0b[01]+/.exec(s.slice(i)))) { t.push({ t: 'num', v: parseInt(m[0].slice(2), 2), big: BigInt(m[0]) }); i += m[0].length; continue; }
    if ((m = /^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/.exec(s.slice(i)))) { var big = /^\d+$/.test(m[0]) ? BigInt(m[0]) : null; t.push({ t: 'num', v: parseFloat(m[0]), big: big }); i += m[0].length; continue; }
    if ((m = /^[a-z_][a-z_0-9]*/.exec(s.slice(i)))) { t.push({ t: 'id', v: m[0] }); i += m[0].length; continue; }
    if ('+-*/%^(),!'.indexOf(c) >= 0) { t.push({ t: c }); i++; continue; }
    if (c === '=') { t.push({ t: '=' }); i++; continue; }
    throw new Error('bad char ' + c);
  }
  return t;
}
function parse(tokens) {
  var p = 0;
  function peek() { return tokens[p]; }
  function eat(t) { if (tokens[p] && tokens[p].t === t) return tokens[p++]; throw new Error('expected ' + t); }
  function startsOperand(x) { return x && (x.t === 'num' || x.t === 'id' || x.t === '('); }
  function expr() {
    var a = term();
    while (peek() && (peek().t === '+' || peek().t === '-')) { var op = tokens[p++].t; a = { n: 'bin', op: op, a: a, b: term() }; }
    return a;
  }
  function term() {
    var a = unary();
    for (;;) {
      var x = peek();
      if (x && (x.t === '*' || x.t === '/')) { p++; a = { n: 'bin', op: x.t, a: a, b: unary() }; }
      else if (x && x.t === '%' && startsOperand(tokens[p + 1])) { p++; a = { n: 'bin', op: '%', a: a, b: unary() }; }
      else if (x && (x.t === '(' || (x.t === 'id' && !(a.n === 'num' && false))) && a && implicitOK(a)) { a = { n: 'bin', op: '*', a: a, b: unary() }; }
      else if (x && x.t === 'num' && prevWasParen()) { a = { n: 'bin', op: '*', a: a, b: unary() }; }
      else break;
    }
    return a;
  }
  function implicitOK(a) { return a.n === 'num' || a.n === 'var' || a.n === 'fn' || a.n === 'bin' || a.n === 'pct' || a.n === 'fact' || a.n === 'neg'; }
  function prevWasParen() { return tokens[p - 1] && tokens[p - 1].t === ')'; }
  function unary() {
    if (peek() && peek().t === '-') { p++; return { n: 'neg', a: unary() }; }
    if (peek() && peek().t === '+') { p++; return unary(); }
    return power();
  }
  function power() {
    var a = postfix();
    if (peek() && peek().t === '^') { p++; var b = unaryPow(); a = { n: 'bin', op: '^', a: a, b: b }; }
    return a;
  }
  function unaryPow() { if (peek() && peek().t === '-') { p++; return { n: 'neg', a: unaryPow() }; } return power(); }
  function postfix() {
    var a = primary();
    for (;;) {
      var x = peek();
      if (x && x.t === '!') { p++; a = { n: 'fact', a: a }; }
      else if (x && x.t === '%' && !startsOperand(tokens[p + 1])) { p++; a = { n: 'pct', a: a }; }
      else break;
    }
    return a;
  }
  function primary() {
    var x = peek();
    if (!x) throw new Error('unexpected end');
    if (x.t === 'num') { p++; return { n: 'num', v: x.v, big: x.big }; }
    if (x.t === '(') { p++; var e = expr(); eat(')'); return e; }
    if (x.t === 'id') {
      p++;
      var name = x.v;
      if (name === 'deg' || name === 'rad') return { n: 'unit', name: name };
      if (FN1[name] || FNN[name]) {
        if (peek() && peek().t === '(') {
          p++; var args = [];
          if (peek() && peek().t !== ')') { args.push(expr()); while (peek() && peek().t === ',') { p++; args.push(expr()); } }
          eat(')');
          return { n: 'fn', name: name, args: args };
        }
        return { n: 'fn', name: name, args: [unaryPow()] };
      }
      if (CONST.hasOwnProperty(name)) return { n: 'num', v: CONST[name], big: null, c: name };
      return { n: 'var', name: name };
    }
    throw new Error('unexpected ' + x.t);
  }
  var tree = expr();
  /* degree / radian marker after a value: "30 deg" */
  if (p < tokens.length) throw new Error('trailing');
  return tree;
}
function parseExpr(s) { return parse(tokenize(canon(s))); }

/* ---------- evaluation ---------- */
function fact(n) { if (n < 0 || n !== Math.floor(n)) return NaN; if (n > 170) return Infinity; var r = 1; for (var i = 2; i <= n; i++) r *= i; return r; }
function gcd(a, b) { a = Math.abs(a); b = Math.abs(b); while (b) { var t = b; b = a % b; a = t; } return a; }
function stats(a) {
  var n = a.length, sum = a.reduce(function (x, y) { return x + y; }, 0), mean = sum / n, s = a.slice().sort(function (x, y) { return x - y; });
  var med = n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2, v = a.reduce(function (x, y) { return x + (y - mean) * (y - mean); }, 0) / n;
  return { n: n, sum: sum, mean: mean, median: med, varP: v, varS: n > 1 ? v * n / (n - 1) : NaN, min: s[0], max: s[n - 1] };
}
function evalNum(a, env, deg) {
  switch (a.n) {
    case 'num': return a.v;
    case 'var': if (env && env.hasOwnProperty(a.name)) return env[a.name]; throw new Error('unknown ' + a.name);
    case 'neg': return -evalNum(a.a, env, deg);
    case 'pct': return evalNum(a.a, env, deg) / 100;
    case 'fact': return fact(evalNum(a.a, env, deg));
    case 'unit': throw new Error('unit');
    case 'bin': {
      /* "30 deg" written as 30 * deg */
      var x = evalNum(a.a, env, deg), y;
      if (a.op === '*' && a.b.n === 'unit') return a.b.name === 'deg' ? x * Math.PI / 180 : x;
      y = evalNum(a.b, env, deg);
      switch (a.op) { case '+': return x + y; case '-': return x - y; case '*': return x * y; case '/': return x / y; case '%': return x - y * Math.floor(x / y); case '^': return Math.pow(x, y); }
      break;
    }
    case 'fn': {
      var args = a.args.map(function (z) { return z.n === 'bin' && z.op === '*' && z.b.n === 'unit' ? evalNum(z, env, deg) : evalNum(z, env, deg); }), v = args[0], nm = a.name;
      if (a.args[0] && a.args[0].n === 'bin' && a.args[0].op === '*' && a.args[0].b && a.args[0].b.n === 'unit') { /* explicit unit given: already radians */
        if (TRIG[nm]) return Math[nm](v);
      }
      if (TRIG[nm]) { var r = deg ? v * Math.PI / 180 : v; var q = Math[nm](r); if (Math.abs(q) < 1e-15) q = 0; if (nm === 'sin' && Math.abs(Math.abs(q) - 1) < 1e-15) q = Math.sign(q); if (nm === 'cos' && Math.abs(Math.abs(q) - 1) < 1e-15) q = Math.sign(q); if (nm === 'tan' && deg && Math.abs(v % 180) === 90) return Infinity; return round15(q); }
      if (ATRIG[nm]) { var o = Math[nm](v); return round15(deg ? o * 180 / Math.PI : o); }
      switch (nm) {
        case 'sinh': case 'cosh': case 'tanh': case 'sqrt': case 'cbrt': case 'exp': case 'abs': case 'floor': case 'ceil': case 'trunc': case 'sign': return Math[nm](v);
        case 'round': return args.length > 1 ? Math.round(v * Math.pow(10, args[1])) / Math.pow(10, args[1]) : Math.round(v);
        case 'ln': return Math.log(v);
        case 'log': return args.length > 1 ? Math.log(v) / Math.log(args[1]) : Math.log10(v);
        case 'log2': return Math.log2(v); case 'log10': return Math.log10(v);
        case 'logb': return Math.log(args[1]) / Math.log(args[0]);
        case 'fact': return fact(v);
        case 'rad': return v * Math.PI / 180; case 'deg': return v * 180 / Math.PI;
        case 'max': return Math.max.apply(null, args); case 'min': return Math.min.apply(null, args);
        case 'sum': return stats(args).sum; case 'avg': case 'mean': return stats(args).mean; case 'median': return stats(args).median;
        case 'std': return Math.sqrt(stats(args).varP); case 'var': return stats(args).varP;
        case 'gcd': return args.reduce(gcd); case 'lcm': return args.reduce(function (x, y) { return x * y / gcd(x, y); });
        case 'ncr': return Math.round(fact(v) / (fact(args[1]) * fact(v - args[1]))); case 'npr': return Math.round(fact(v) / fact(v - args[1]));
        case 'pow': return Math.pow(v, args[1]); case 'hypot': return Math.hypot.apply(null, args); case 'mod': return v - args[1] * Math.floor(v / args[1]); case 'atan2': return Math.atan2(v, args[1]);
      }
    }
  }
  throw new Error('eval');
}
function round15(x) { return Math.abs(x) < 1e-12 ? 0 : parseFloat(x.toPrecision(15)); }
/* exact integer arithmetic; throws if the expression is not purely integer */
function evalBig(a) {
  switch (a.n) {
    case 'num': if (a.big === null || a.big === undefined || a.c) throw new Error('nb'); return a.big;
    case 'neg': return -evalBig(a.a);
    case 'fact': { var n = evalBig(a.a); if (n < 0n || n > 5000n) throw new Error('big'); var r = 1n; for (var i = 2n; i <= n; i++) r *= i; return r; }
    case 'bin': {
      var x = evalBig(a.a), y = evalBig(a.b);
      switch (a.op) {
        case '+': return x + y; case '-': return x - y; case '*': return x * y;
        case '/': if (y === 0n || x % y !== 0n) throw new Error('nd'); return x / y;
        case '%': if (y === 0n) throw new Error('z'); return ((x % y) + y) % y;
        case '^': if (y < 0n || y > 20000n) throw new Error('exp'); if (x !== 0n && x !== 1n && x !== -1n && BigInt(x.toString().length) * y > 200000n) throw new Error('huge'); return x ** y;
      }
      break;
    }
    case 'fn': {
      var v = a.args.map(evalBig);
      if (a.name === 'gcd') return v.reduce(function (p, q) { p = p < 0n ? -p : p; q = q < 0n ? -q : q; while (q) { var t = q; q = p % q; p = t; } return p; });
      if (a.name === 'lcm') { var g = function (p, q) { while (q) { var t = q; q = p % q; p = t; } return p; }; return v.reduce(function (p, q) { return p * q / g(p < 0n ? -p : p, q < 0n ? -q : q); }); }
      if (a.name === 'abs') return v[0] < 0n ? -v[0] : v[0];
      if (a.name === 'fact') return evalBig({ n: 'fact', a: a.args[0] });
      if (a.name === 'ncr' || a.name === 'npr') { var nn = v[0], k = v[1]; if (k < 0n || k > nn || nn > 3000n) throw new Error('r'); var res = 1n, kk = a.name === 'ncr' ? (k > nn - k ? nn - k : k) : k; for (var j = 0n; j < kk; j++) { res = res * (nn - j); if (a.name === 'ncr') res = res / (j + 1n); } return res; }
      if (a.name === 'pow') { return evalBig({ n: 'bin', op: '^', a: a.args[0], b: a.args[1] }); }
      if (a.name === 'max') return v.reduce(function (p, q) { return q > p ? q : p; }); if (a.name === 'min') return v.reduce(function (p, q) { return q < p ? q : p; });
      if (a.name === 'sum') return v.reduce(function (p, q) { return p + q; });
    }
  }
  throw new Error('nb');
}
function groupBig(s) { var neg = s[0] === '-'; if (neg) s = s.slice(1); return (neg ? '-' : '') + s.replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function fmt(n) {
  if (!isFinite(n)) return isNaN(n) ? 'undefined' : (n > 0 ? '∞' : '-∞');
  if (Number.isInteger(n) && Math.abs(n) < 1e15) return String(n);
  var a = Math.abs(n);
  if (a !== 0 && (a < 1e-7 || a >= 1e21)) return n.toExponential(10).replace(/\.?0+e/, 'e');
  var s = parseFloat(n.toPrecision(12)).toString();
  return s;
}
function fmtGroup(n) { if (!isFinite(n) || Math.abs(n) >= 1e15) return ''; var s = fmt(n); if (/e/.test(s)) return ''; var p = s.split('.'); return p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + (p[1] ? '.' + p[1] : ''); }
function inWords(n) {
  n = Math.round(n); if (!isFinite(n) || Math.abs(n) >= 1e15 || n === 0) return n === 0 ? 'zero' : '';
  var ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'], tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
  function below(x) { var s = ''; if (x >= 100) { s += ones[Math.floor(x / 100)] + ' hundred'; x %= 100; if (x) s += ' '; } if (x >= 20) { s += tens[Math.floor(x / 10)]; if (x % 10) s += ' ' + ones[x % 10]; } else if (x) s += ones[x]; return s; }
  var neg = n < 0; n = Math.abs(n);
  var parts = [[1e7, 'crore'], [1e5, 'lakh'], [1e3, 'thousand']], out = [];
  parts.forEach(function (p) { if (n >= p[0]) { var q = Math.floor(n / p[0]); out.push(inWords(q) + ' ' + p[1]); n -= q * p[0]; } });
  if (n) out.push(below(n));
  return (neg ? 'minus ' : '') + out.join(' ');
}

/* ---------- solving ---------- */
function ratio(x) { /* decimal -> simple fraction text when it is clean */
  if (Number.isInteger(x)) return String(x);
  for (var d = 2; d <= 100; d++) { var nn = x * d; if (Math.abs(nn - Math.round(nn)) < 1e-9) return Math.round(nn) + '/' + d; }
  return fmt(x);
}
function varsOf(ast, set) {
  set = set || {};
  if (ast.n === 'var') set[ast.name] = 1;
  if (ast.a) varsOf(ast.a, set); if (ast.b) varsOf(ast.b, set); if (ast.args) ast.args.forEach(function (z) { varsOf(z, set); });
  return set;
}
function solveEquation(text) {
  var parts = canon(text).split('='), L, R;
  if (parts.length !== 2) return null;
  try { L = parse(tokenize(parts[0])); R = parse(tokenize(parts[1] || '0')); } catch (e) { return null; }
  var vs = Object.keys(Object.assign(varsOf(L), varsOf(R)));
  if (vs.length !== 1) return null;
  var v = vs[0], deg = !hasRad(text);
  function f(x) { var env = {}; env[v] = x; return evalNum(L, env, deg) - evalNum(R, env, deg); }
  var pts = [], i, ok = true; try { for (i = 0; i <= 6; i++) pts.push(f(i)); } catch (e) { return null; }
  /* polynomial degree by finite differences */
  var d = pts.slice(), degree = -1, tol = 1e-7 * (1 + Math.max.apply(null, pts.map(Math.abs)));
  for (var k = 0; k <= 5; k++) { if (d.some(function (z) { return Math.abs(z) > tol; })) degree = k; d = d.slice(1).map(function (z, j) { return z - d[j]; }); }
  var lines = [], sols = [];
  var polyOK = degree >= 0 && degree <= 2 && Math.abs(f(-1.5) - polyAt(pts, degree, -1.5)) < 1e-6 * (1 + Math.abs(f(-1.5)));
  if (degree === -1) return { answer: 'Every value of ' + v + ' satisfies it (identity).', lines: [] };
  if (polyOK && degree === 0) return { answer: 'No solution.', lines: ['The equation reduces to a false statement.'] };
  if (polyOK && degree === 1) {
    var b = pts[1] - pts[0], c = pts[0], x1 = -c / b;
    return { answer: v + ' = ' + ratio(x1) + (Number.isInteger(x1) || ratio(x1).indexOf('/') > 0 ? (Number.isInteger(x1) ? '' : '  (' + fmt(x1) + ')') : ''), lines: ['Linear: ' + polyStr([c, b], v) + ' = 0', v + ' = -(' + fmt(c) + ') / ' + fmt(b)] };
  }
  if (polyOK && degree === 2) {
    var fm = f(-1), a2 = (pts[1] + fm) / 2 - pts[0], b2 = (pts[1] - fm) / 2, c2 = pts[0], disc = b2 * b2 - 4 * a2 * c2;
    lines.push('Quadratic: ' + polyStr([c2, b2, a2], v) + ' = 0', 'a = ' + fmt(a2) + ', b = ' + fmt(b2) + ', c = ' + fmt(c2), 'Discriminant D = b² − 4ac = ' + fmt(disc));
    if (disc > 1e-12) { var r1 = (-b2 + Math.sqrt(disc)) / (2 * a2), r2 = (-b2 - Math.sqrt(disc)) / (2 * a2); lines.push(v + ' = (−b ± √D) / 2a'); return { answer: v + ' = ' + ratio(r1) + ' or ' + v + ' = ' + ratio(r2) + (Number.isInteger(r1) && Number.isInteger(r2) ? '' : '  (' + fmt(r1) + ', ' + fmt(r2) + ')'), lines: lines }; }
    if (Math.abs(disc) <= 1e-12) { var r0 = -b2 / (2 * a2); return { answer: v + ' = ' + ratio(r0) + ' (double root)', lines: lines }; }
    var re = -b2 / (2 * a2), im = Math.sqrt(-disc) / (2 * Math.abs(a2)); return { answer: v + ' = ' + fmt(re) + ' ± ' + fmt(im) + 'i  (no real roots)', lines: lines };
  }
  /* general numeric root search */
  var trig = /\b(?:sin|cos|tan)\b/.test(canon(text)), lim = trig ? (deg ? 360 : 2 * Math.PI * 2) : 1000, xs = [], step = trig && !deg ? 0.001 : 0.01, prev = null, px = -lim;
  for (var xx = -lim; xx <= lim; xx += step) {
    var fv; try { fv = f(xx); } catch (e) { prev = null; continue; }
    if (!isFinite(fv)) { prev = null; continue; }
    if (prev !== null && ((prev <= 0 && fv >= 0) || (prev >= 0 && fv <= 0)) && Math.abs(prev - fv) < 1e6) {
      var lo = px, hi = xx; for (var it = 0; it < 80; it++) { var mid = (lo + hi) / 2, fm2 = f(mid); if ((f(lo) <= 0) === (fm2 <= 0)) lo = mid; else hi = mid; }
      var root = (lo + hi) / 2; if (Math.abs(f(root)) < 1e-6 && !xs.some(function (z) { return Math.abs(z - root) < 1e-4; })) xs.push(root);
    }
    prev = fv; px = xx;
  }
  if (!xs.length) return { answer: 'I could not find a real solution between -1000 and 1000.', lines: [] };
  return { answer: v + ' ≈ ' + xs.slice(0, 8).map(function (z) { return fmt(parseFloat(z.toFixed(6))); }).join(', '), lines: ['Solved numerically (' + xs.length + ' real root' + (xs.length === 1 ? '' : 's') + ' in [' + fmt(-lim) + ', ' + fmt(lim) + ']).' + (trig && deg ? ' Angles in degrees; trig equations repeat every 360°.' : '')] };
}
function polyAt(pts, degree, x) { /* Newton forward differences through integer points 0..6 */
  var d = pts.slice(0, degree + 1), res = d[0], coef = 1, i, tbl = [pts.slice()];
  var t = pts.slice(), diffs = [t[0]];
  for (i = 1; i <= degree; i++) { t = t.slice(1).map(function (z, j) { return z - t[j]; }); diffs.push(t[0]); }
  res = 0; coef = 1; for (i = 0; i <= degree; i++) { res += diffs[i] * coef; coef *= (x - i) / (i + 1); }
  return res;
}
function solveSystem(text) {
  var eqs = String(text).toLowerCase().replace(/\band\b/g, ',').split(/[,;\n]+/).map(function (z) { return z.trim(); }).filter(Boolean);
  if (eqs.length < 2 || eqs.length > 4 || eqs.some(function (z) { return z.split('=').length !== 2; })) return null;
  var asts = [], vs = {};
  try { eqs.forEach(function (z) { var c = canon(z).split('='); var l = parse(tokenize(c[0])), r = parse(tokenize(c[1])); asts.push([l, r]); varsOf(l, vs); varsOf(r, vs); }); } catch (e) { return null; }
  var names = Object.keys(vs).sort();
  if (names.length !== eqs.length) return null;
  function fval(eq, env) { return evalNum(eq[0], env, true) - evalNum(eq[1], env, true); }
  var n = names.length, M = [], i, j;
  try {
    for (i = 0; i < n; i++) {
      var zero = {}; names.forEach(function (q) { zero[q] = 0; }); var f0 = fval(asts[i], zero), row = [];
      for (j = 0; j < n; j++) { var e = Object.assign({}, zero); e[names[j]] = 1; row.push(fval(asts[i], e) - f0); }
      var t2 = {}; names.forEach(function (q, k) { t2[q] = k + 2.5; }); var pred = f0; names.forEach(function (q, k) { pred += row[k] * t2[q]; });
      if (Math.abs(fval(asts[i], t2) - pred) > 1e-6 * (1 + Math.abs(pred))) return null; /* not linear */
      row.push(-f0); M.push(row);
    }
  } catch (e) { return null; }
  for (i = 0; i < n; i++) {
    var piv = i; for (j = i + 1; j < n; j++) if (Math.abs(M[j][i]) > Math.abs(M[piv][i])) piv = j;
    if (Math.abs(M[piv][i]) < 1e-12) return { answer: 'No unique solution (the equations are dependent or inconsistent).', lines: [] };
    var tmp = M[i]; M[i] = M[piv]; M[piv] = tmp;
    for (j = 0; j < n; j++) if (j !== i) { var fct = M[j][i] / M[i][i]; for (var k2 = i; k2 <= n; k2++) M[j][k2] -= fct * M[i][k2]; }
  }
  var out = names.map(function (q, k) { return q + ' = ' + ratio(M[k][n] / M[k][k]); });
  return { answer: out.join(', '), lines: ['Solved the ' + n + '×' + n + ' linear system by Gaussian elimination.'] };
}

/* polynomial coefficients by sampling (degree <= 8) */
function hasFn(a) { return !!a && (a.n === 'fn' || a.n === 'fact' || hasFn(a.a) || hasFn(a.b) || (a.args || []).some(hasFn)); }
function polyCoeffs(ast, v) {
  if (hasFn(ast)) return null;
  var N = 9, xs = [], ys = [], i, j;
  try { for (i = 0; i < N; i++) { var env = {}; env[v] = i; xs.push(i); ys.push(evalNum(ast, env, false)); } } catch (e) { return null; }
  var A = xs.map(function (x, r) { var row = []; for (j = 0; j < N; j++) row.push(Math.pow(x, j)); row.push(ys[r]); return row; });
  for (i = 0; i < N; i++) {
    var piv = i; for (j = i + 1; j < N; j++) if (Math.abs(A[j][i]) > Math.abs(A[piv][i])) piv = j;
    var t = A[i]; A[i] = A[piv]; A[piv] = t;
    for (j = 0; j < N; j++) if (j !== i) { var f = A[j][i] / A[i][i]; for (var k = i; k <= N; k++) A[j][k] -= f * A[i][k]; }
  }
  var c = A.map(function (r, k) { return r[N] / r[k]; }).map(function (z) { return Math.abs(z) < 1e-8 ? 0 : parseFloat(z.toFixed(8)); });
  var chk = [-1.5, 9.5, 11]; for (i = 0; i < chk.length; i++) { var env2 = {}; env2[v] = chk[i]; var tr; try { tr = evalNum(ast, env2, true); } catch (e) { return null; } var pr = 0; for (j = c.length - 1; j >= 0; j--) pr = pr * chk[i] + c[j]; if (Math.abs(tr - pr) > 1e-5 * (1 + Math.abs(tr))) return null; }
  while (c.length > 1 && c[c.length - 1] === 0) c.pop();
  return c;
}
function polyStr(c, v) {
  var out = [], i;
  for (i = c.length - 1; i >= 0; i--) { if (!c[i]) continue; var co = c[i], sg = co < 0 ? '-' : '+', a = Math.abs(co), cs = a === 1 && i > 0 ? '' : ratio(a); out.push((out.length ? ' ' + sg + ' ' : (sg === '-' ? '-' : '')) + cs + (i > 0 ? v + (i > 1 ? '^' + i : '') : '')); }
  return out.join('') || '0';
}
function simpson(f, a, b) { var n = 2000, h = (b - a) / n, s = f(a) + f(b), i; for (i = 1; i < n; i++) s += f(a + i * h) * (i % 2 ? 4 : 2); return s * h / 3; }

/* ---------- natural-language helpers ---------- */
function nums(s) { return (String(s).match(/-?\d+(?:\.\d+)?/g) || []).map(Number); }
function money(n) { return '₹' + n.toLocaleString('en-IN', { maximumFractionDigits: 2 }); }
var MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
function parseDate(s, now) {
  s = String(s).toLowerCase().trim(); now = now || new Date(); var m;
  var base = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (/^today$/.test(s)) return base; if (/^tomorrow$/.test(s)) { base.setDate(base.getDate() + 1); return base; } if (/^yesterday$/.test(s)) { base.setDate(base.getDate() - 1); return base; }
  if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/))) return new Date(+m[1], +m[2] - 1, +m[3]);
  if ((m = s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})$/))) return new Date(+m[3] < 100 ? 2000 + +m[3] : +m[3], +m[2] - 1, +m[1]);
  if ((m = s.match(/^(\d{1,2})(?:st|nd|rd|th)?\s+(?:of\s+)?([a-z]{3,9})(?:,?\s+(\d{4}))?$/)) && MONTHS.indexOf(m[2].slice(0, 3)) >= 0) { var d = new Date(m[3] ? +m[3] : now.getFullYear(), MONTHS.indexOf(m[2].slice(0, 3)), +m[1]); if (!m[3] && d < base) d.setFullYear(d.getFullYear() + 1); return d; }
  if ((m = s.match(/^([a-z]{3,9})\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s+(\d{4}))?$/)) && MONTHS.indexOf(m[1].slice(0, 3)) >= 0) { var d2 = new Date(m[3] ? +m[3] : now.getFullYear(), MONTHS.indexOf(m[1].slice(0, 3)), +m[2]); if (!m[3] && d2 < base) d2.setFullYear(d2.getFullYear() + 1); return d2; }
  return null;
}
function daysBetween(a, b) { return Math.round((Date.UTC(b.getFullYear(), b.getMonth(), b.getDate()) - Date.UTC(a.getFullYear(), a.getMonth(), a.getDate())) / 864e5); }
function ymd(a, b) { /* difference as years, months, days */
  var y = b.getFullYear() - a.getFullYear(), m = b.getMonth() - a.getMonth(), d = b.getDate() - a.getDate();
  if (d < 0) { m--; d += new Date(b.getFullYear(), b.getMonth(), 0).getDate(); } if (m < 0) { y--; m += 12; }
  return y + ' years, ' + m + ' months, ' + d + ' days';
}
function primeFactors(n) { var f = [], d = 2; while (n > 1 && d * d <= n) { while (n % d === 0) { f.push(d); n /= d; } d++; } if (n > 1) f.push(n); return f; }

/* ---------- the entry point: text -> {answer, lines} or null ---------- */
function answer(input, now) {
  var raw = String(input).trim(), lc = raw.toLowerCase().replace(/\?+$/g, '').replace(/([^\d)])!+$/g, '$1').replace(/\s+/g, ' ').trim(), m, r;
  if (!lc || lc.length > 400) return null;
  if (/^(?:call|dial|whatsapp|message|text|sms|alarm|remind|set |note|play|open|translate|read|say|send|show|delete|cancel|navigate|search|weather|news|spent|save|email|share|tell|switch)\b/.test(lc)) return null;

  /* number bases */
  if ((m = lc.match(/^(?:convert\s+)?(\d+)\s+(?:in|to|into)\s+(binary|hex|hexadecimal|octal)$/)) || (m = lc.match(/^(binary|hex|hexadecimal|octal)\s+(?:of|for)\s+(\d+)$/)) && ((m = [m[0], m[2], m[1]]))) {
    var base = /bin/.test(m[2]) ? 2 : /oct/.test(m[2]) ? 8 : 16, n = parseInt(m[1], 10); return { answer: m[1] + ' in ' + m[2] + ' = ' + n.toString(base).toUpperCase(), lines: [] };
  }
  if ((m = lc.match(/^(?:convert\s+)?([01]+|[0-7]+|[0-9a-f]+)\s+(binary|octal|hex|hexadecimal)\s+(?:to|in|into)\s+decimal$/)) || (m = lc.match(/^(?:decimal|value)\s+of\s+(binary|octal|hex|hexadecimal)\s+([0-9a-f]+)$/)) && ((m = [m[0], m[2], m[1]]))) {
    var b2 = /bin/.test(m[2]) ? 2 : /oct/.test(m[2]) ? 8 : 16, val = parseInt(m[1], b2); if (isNaN(val)) return null; return { answer: m[1] + ' (' + m[2] + ') = ' + val + ' in decimal', lines: [] };
  }
  if ((m = lc.match(/^(binary|octal|hex|hexadecimal)\s+([0-9a-f]+)\s+(?:to|in|into)\s+decimal$/))) { var b3 = /bin/.test(m[1]) ? 2 : /oct/.test(m[1]) ? 8 : 16, v3 = parseInt(m[2], b3); if (!isNaN(v3)) return { answer: m[2] + ' (' + m[1] + ') = ' + v3 + ' in decimal', lines: [] }; }
  /* primes, factors, gcd, lcm */
  if ((m = lc.match(/^is\s+(\d+)\s+(?:a\s+)?prime(?:\s+number)?$/))) { var p = +m[1], isP = p > 1 && primeFactors(p).length === 1; return { answer: p + (isP ? ' is a prime number.' : ' is not prime.'), lines: isP ? [] : ['Prime factors: ' + primeFactors(p).join(' × ')] }; }
  if ((m = lc.match(/^prime\s+factors?\s+of\s+(\d+)$/)) || (m = lc.match(/^(?:prime\s+)?factori[sz]e\s+(\d+)$/))) { var pf = primeFactors(+m[1]); var cnt = {}; pf.forEach(function (z) { cnt[z] = (cnt[z] || 0) + 1; }); return { answer: m[1] + ' = ' + Object.keys(cnt).map(function (z) { return cnt[z] > 1 ? z + '^' + cnt[z] : z; }).join(' × '), lines: [] }; }
  if ((m = lc.match(/^(?:all\s+)?factors?\s+of\s+(\d+)$/))) { var n2 = +m[1], fs = []; for (var q = 1; q <= n2; q++) if (n2 % q === 0) fs.push(q); return { answer: 'Factors of ' + n2 + ': ' + fs.join(', '), lines: [fs.length + ' factors'] }; }
  if ((m = lc.match(/^(gcd|hcf|lcm)\s+(?:of\s+)?([\d,\s]+?(?:\s+and\s+\d+)?)$/))) { var ns = nums(m[2].replace(/and/g, ' ')); if (ns.length >= 2) { var g = m[1] === 'lcm' ? ns.reduce(function (x, y) { return x * y / gcd(x, y); }) : ns.reduce(gcd); return { answer: m[1].toUpperCase() + ' of ' + ns.join(', ') + ' = ' + g, lines: [] }; } }

  /* statistics */
  if ((m = lc.match(/^(mean|average|avg|median|mode|sum|total|max|maximum|min|minimum|range|variance|std(?:\s?dev(?:iation)?)?|standard deviation|count)\s+(?:of\s+)?([-\d.,\s]+(?:and\s+[-\d.]+)?)$/))) {
    var a = nums(m[2].replace(/\band\b/g, ' ')); if (a.length >= 1) {
      var st = stats(a), k = m[1], res, lines = ['Numbers: ' + a.join(', ') + '  (n = ' + a.length + ')'];
      if (/mean|average|avg/.test(k)) res = 'Mean = ' + fmt(st.mean); else if (k === 'median') res = 'Median = ' + fmt(st.median);
      else if (k === 'mode') { var c = {}, best = 0, modes = []; a.forEach(function (z) { c[z] = (c[z] || 0) + 1; best = Math.max(best, c[z]); }); Object.keys(c).forEach(function (z) { if (c[z] === best) modes.push(z); }); res = best === 1 ? 'No repeated value (no mode)' : 'Mode = ' + modes.join(', '); }
      else if (/sum|total/.test(k)) res = 'Sum = ' + fmt(st.sum); else if (/max/.test(k)) res = 'Maximum = ' + fmt(st.max); else if (/min/.test(k)) res = 'Minimum = ' + fmt(st.min); else if (k === 'range') res = 'Range = ' + fmt(st.max - st.min); else if (k === 'count') res = 'Count = ' + a.length;
      else if (k === 'variance') { res = 'Variance = ' + fmt(st.varP) + ' (population)'; lines.push('Sample variance = ' + fmt(st.varS)); } else { res = 'Standard deviation = ' + fmt(Math.sqrt(st.varP)) + ' (population)'; lines.push('Sample standard deviation = ' + fmt(Math.sqrt(st.varS))); }
      if (/mean|average|avg/.test(k)) lines.push('Sum = ' + fmt(st.sum), 'Median = ' + fmt(st.median));
      return { answer: res, lines: lines };
    }
  }
  /* finance */
  if ((m = lc.match(/^emi\s+(?:for|of|on)?\s*(?:rs\.?|₹)?\s*([\d,.]+)\s*(?:lakh|lakhs)?\s*(?:at|@|with)?\s*([\d.]+)\s*%?\s*(?:interest|rate|p\.?a\.?)?\s*(?:for|over|per)?\s*(\d+(?:\.\d+)?)\s*(year|years|yr|yrs|month|months)$/))) {
    var P = parseFloat(m[1].replace(/,/g, '')) * (/lakh/.test(lc) ? 1e5 : 1), rr = parseFloat(m[2]) / 1200, nn = parseFloat(m[3]) * (/y/.test(m[4]) ? 12 : 1);
    var emi = rr === 0 ? P / nn : P * rr * Math.pow(1 + rr, nn) / (Math.pow(1 + rr, nn) - 1);
    return { answer: 'EMI = ' + money(emi) + ' per month', lines: ['Total payment: ' + money(emi * nn), 'Total interest: ' + money(emi * nn - P), 'Loan ' + money(P) + ' at ' + m[2] + '% for ' + nn + ' months'] };
  }
  if ((m = lc.match(/^(simple|compound)\s+interest\s+(?:on|of|for)?\s*(?:rs\.?|₹)?\s*([\d,.]+)\s*(?:at|@)\s*([\d.]+)\s*%?\s*(?:p\.?a\.?)?\s*(?:for|over)\s*(\d+(?:\.\d+)?)\s*(year|years|yr|yrs|month|months)$/))) {
    var Pp = parseFloat(m[2].replace(/,/g, '')), R = parseFloat(m[3]), T = parseFloat(m[4]) / (/month/.test(m[5]) ? 12 : 1);
    var amt = m[1] === 'simple' ? Pp * (1 + R * T / 100) : Pp * Math.pow(1 + R / 100, T);
    return { answer: (m[1] === 'simple' ? 'Simple' : 'Compound') + ' interest = ' + money(amt - Pp), lines: ['Total amount: ' + money(amt), 'Principal ' + money(Pp) + ', rate ' + R + '%, time ' + fmt(T) + ' years' + (m[1] === 'compound' ? ' (compounded yearly)' : '')] };
  }
  if ((m = lc.match(/^(?:add|apply|with|plus)\s+([\d.]+)\s*%?\s*(?:gst|vat|tax)\s+(?:to|on)\s+(?:rs\.?|₹)?\s*([\d,.]+)$/)) || (m = lc.match(/^(?:gst|vat|tax)\s+(?:on|of)\s+(?:rs\.?|₹)?\s*([\d,.]+)\s*(?:at|@)\s*([\d.]+)\s*%?$/)) && ((m = [m[0], m[2], m[1]]))) {
    var rt = parseFloat(m[1]), base0 = parseFloat(m[2].replace(/,/g, '')), tax = base0 * rt / 100; return { answer: 'Total = ' + money(base0 + tax), lines: ['Amount: ' + money(base0), rt + '% tax: ' + money(tax)] };
  }
  if ((m = lc.match(/^(?:what\s+is\s+)?(?:gst|vat|tax)?\s*@?\s*([\d.]+)\s*%\s*(?:gst|vat|tax)?\s+(?:on|of|for)\s+(?:rs\.?|₹)?\s*([\d,.]+)\s*(?:rs|rupees)?$/)) && /gst|vat|tax/.test(lc)) {
    var rt3 = parseFloat(m[1]), b3 = parseFloat(m[2].replace(/,/g, '')), tx3 = b3 * rt3 / 100; return { answer: 'Total = ' + money(b3 + tx3), lines: ['Amount: ' + money(b3), rt3 + '% tax: ' + money(tx3), /gst/.test(lc) ? 'CGST ' + money(tx3 / 2) + ' + SGST ' + money(tx3 / 2) : ''].filter(Boolean) };
  }
  if ((m = lc.match(/^(?:remove|exclude|without|extract)\s+([\d.]+)\s*%?\s*(?:gst|vat|tax)\s+(?:from)\s+(?:rs\.?|₹)?\s*([\d,.]+)$/))) {
    var rt2 = parseFloat(m[1]), tot = parseFloat(m[2].replace(/,/g, '')), bs = tot / (1 + rt2 / 100); return { answer: 'Price before tax = ' + money(bs), lines: ['Tax included: ' + money(tot - bs)] };
  }
  if ((m = lc.match(/^([\d.]+)\s*%\s*discount\s+(?:on|off|from)\s+(?:rs\.?|₹)?\s*([\d,.]+)$/)) || (m = lc.match(/^discount\s+([\d.]+)\s*%\s+(?:on|off|from)\s+(?:rs\.?|₹)?\s*([\d,.]+)$/))) {
    var dp = parseFloat(m[1]), pr = parseFloat(m[2].replace(/,/g, '')); return { answer: 'You pay ' + money(pr * (1 - dp / 100)), lines: ['Discount: ' + money(pr * dp / 100), 'Original price: ' + money(pr)] };
  }
  if ((m = lc.match(/^what\s+percent(?:age)?\s+is\s+([\d.,]+)\s+of\s+([\d.,]+)$/)) || (m = lc.match(/^([\d.,]+)\s+is\s+what\s+percent(?:age)?\s+of\s+([\d.,]+)$/))) {
    var x1 = parseFloat(m[1].replace(/,/g, '')), y1 = parseFloat(m[2].replace(/,/g, '')); return { answer: fmt(x1 / y1 * 100) + '%', lines: [fmt(x1) + ' is ' + fmt(x1 / y1 * 100) + '% of ' + fmt(y1)] };
  }
  if ((m = lc.match(/^(?:percent(?:age)?\s+)?(?:change|increase|decrease)\s+from\s+([\d.,]+)\s+to\s+([\d.,]+)$/))) {
    var o = parseFloat(m[1].replace(/,/g, '')), nw = parseFloat(m[2].replace(/,/g, '')), ch = (nw - o) / o * 100; return { answer: (ch >= 0 ? '+' : '') + fmt(ch) + '%', lines: [(ch >= 0 ? 'Increase' : 'Decrease') + ' of ' + fmt(Math.abs(nw - o))] };
  }
  if ((m = lc.match(/^bmi\b.*?(\d+(?:\.\d+)?)\s*kg.*?(\d+(?:\.\d+)?)\s*(cm|m|meter|metre|meters|metres)\b/)) || (m = lc.match(/^bmi\b.*?(\d+(?:\.\d+)?)\s*(cm|m)\b.*?(\d+(?:\.\d+)?)\s*kg/)) && ((m = [m[0], m[3], m[1], m[2]]))) {
    var kg = parseFloat(m[1]), h = parseFloat(m[2]) / (/^cm/.test(m[3]) ? 100 : 1), bmi = kg / (h * h); return { answer: 'BMI = ' + fmt(parseFloat(bmi.toFixed(1))), lines: [bmi < 18.5 ? 'Underweight' : bmi < 25 ? 'Normal weight' : bmi < 30 ? 'Overweight' : 'Obese range', 'General guide only, not medical advice.'] };
  }
  /* dates */
  if ((m = lc.match(/^(?:how many )?days?\s+(?:between|from)\s+(.+?)\s+(?:and|to)\s+(.+)$/))) {
    var d1 = parseDate(m[1], now), d2 = parseDate(m[2], now); if (d1 && d2) { var dd = daysBetween(d1, d2); return { answer: Math.abs(dd) + ' days', lines: [ymd(dd < 0 ? d2 : d1, dd < 0 ? d1 : d2), Math.floor(Math.abs(dd) / 7) + ' weeks and ' + Math.abs(dd) % 7 + ' days'] }; }
  }
  if ((m = lc.match(/^(?:how many )?days?\s+(?:until|till|left (?:for|until|till)|to)\s+(.+)$/))) { var d3 = parseDate(m[1], now); if (d3) { var nd = daysBetween(new Date(), d3); return { answer: nd + ' days', lines: [nd + ' days from today'] }; } }
  if ((m = lc.match(/^(?:my )?age\s+(?:if\s+)?(?:born|dob|date of birth)?\s*(?:on|is|:)?\s*(.+)$/)) || (m = lc.match(/^(?:calculate\s+)?age\s+from\s+(.+)$/))) { var bd = parseDate(m[1], now); if (bd && bd < (now || new Date())) return { answer: ymd(bd, now || new Date()), lines: ['Born ' + bd.toDateString(), 'Total days lived: ' + daysBetween(bd, now || new Date())] }; }

  /* calculus */
  if ((m = lc.match(/^(?:derivative|differentiate|differentiation)\s+(?:of\s+)?(.+?)(?:\s+(?:wrt|with respect to)\s+([a-z]))?$/))) {
    var dast; try { dast = parseExpr(m[1]); } catch (e) { dast = null; } if (dast) { var dv = m[2] || Object.keys(varsOf(dast))[0] || 'x'; var cf = polyCoeffs(dast, dv); if (cf) { var dc = cf.slice(1).map(function (z, i2) { return z * (i2 + 1); }); return { answer: "d/d" + dv + " = " + polyStr(dc.length ? dc : [0], dv), lines: ['f(' + dv + ') = ' + polyStr(cf, dv), 'Power rule applied term by term.'] }; } }
    return null;
  }
  if ((m = lc.match(/^(?:integrate|integral|integration)\s+(?:of\s+)?(.+?)(?:\s+from\s+(-?[\d.]+|-?pi)\s+to\s+(-?[\d.]+|-?pi))?(?:\s+(?:wrt|with respect to)\s+([a-z]))?$/))) {
    var iast; try { iast = parseExpr(m[1]); } catch (e) { iast = null; } if (iast) {
      var iv = m[4] || Object.keys(varsOf(iast))[0] || 'x', hasB = m[2] !== undefined, cf2 = polyCoeffs(iast, iv);
      var tonum = function (z) { return z === 'pi' ? Math.PI : z === '-pi' ? -Math.PI : parseFloat(z); };
      if (cf2) { var ic = [0].concat(cf2.map(function (z, i3) { return z / (i3 + 1); })); if (!hasB) return { answer: '∫ = ' + polyStr(ic, iv) + ' + C', lines: ['Power rule: ∫x^n dx = x^(n+1)/(n+1)'] }; var A = tonum(m[2]), B = tonum(m[3]), F = function (x) { var s = 0; for (var i4 = ic.length - 1; i4 >= 0; i4--) s = s * x + ic[i4]; return s; }; return { answer: fmt(parseFloat((F(B) - F(A)).toPrecision(12))), lines: ['Antiderivative: ' + polyStr(ic, iv), 'F(' + m[3] + ') − F(' + m[2] + ')'] }; }
      if (hasB) { var A2 = tonum(m[2]), B2 = tonum(m[3]), deg2 = false; try { var val2 = simpson(function (x) { var e = {}; e[iv] = x; return evalNum(iast, e, deg2); }, A2, B2); return { answer: '≈ ' + fmt(parseFloat(val2.toPrecision(10))), lines: ['Numerical integration (Simpson, 2000 steps).'] }; } catch (e) { return null; } }
    }
    return null;
  }

  /* systems and equations */
  if (lc.indexOf('=') > 0 && /[a-z]/.test(lc.replace(/\b(?:sin|cos|tan|sqrt|log|ln|and|solve|find)\b/g, ''))) {
    r = solveSystem(lc.replace(/^solve\s+/, '')); if (r) return r;
    r = solveEquation(lc.replace(/^solve\s+/, '')); if (r) return r;
    return null;
  }

  /* plain expression */
  var cn = canon(lc), tree, deg = !hasRad(cn);
  if (!/[\d]/.test(cn) && !/\bpi\b|\be\b/.test(cn)) return null;
  try { tree = parse(tokenize(cn)); } catch (e) { return null; }
  if (Object.keys(varsOf(tree)).length) return null;
  if (tree.n === 'num' && !tree.c) return null; /* just a number */
  var lines2 = [];
  try { var big = evalBig(tree); var bs2 = big.toString(); var res2 = Number(big);
    var out = { answer: bs2.length > 15 ? groupBig(bs2) : (bs2.length > 3 ? groupBig(bs2) + (Math.abs(res2) < 1e15 ? '' : '') : bs2), lines: [] };
    if (bs2.length > 15) { out.lines.push('Exact integer (' + bs2.length + ' digits)'); out.lines.push('≈ ' + res2.toExponential(6)); if (bs2.length <= 60) out.lines.push(bs2); } else if (Math.abs(res2) < 1e15) { var w = inWords(res2); if (w) out.lines.push(w); }
    out.copy = bs2; return out; } catch (e) { /* fall through to floating point */ }
  var val; try { val = evalNum(tree, {}, deg); } catch (e) { return null; }
  if (typeof val !== 'number') return null;
  var o2 = { answer: fmt(val), lines: lines2 };
  var gr = fmtGroup(val); if (gr && gr !== o2.answer && Math.abs(val) >= 1000) o2.lines.push(gr);
  if (/\b(sin|cos|tan)\b/.test(cn) && deg) o2.lines.push('Angles are in degrees (write pi or rad for radians).');
  if (Number.isInteger(val) && Math.abs(val) >= 1000 && Math.abs(val) < 1e15) { var w2 = inWords(val); if (w2) o2.lines.push(w2); }
  o2.copy = o2.answer;
  return o2;
}

root.JTCALC = { answer: answer, canon: canon, parseExpr: parseExpr, fmt: fmt, solveEquation: solveEquation, solveSystem: solveSystem, inWords: inWords, parseDate: parseDate };
})(typeof window !== 'undefined' ? window : globalThis);
