/* Lexi teach v19: your own rules + corrections, saved on this device and added to every AI request.
   v19: up to 25 rules; every correction is also found by meaning in train.js; API for the Training Center. */
(function () {
  var K = 'lexi_teach', D;
  try { D = JSON.parse(localStorage.getItem(K)) || {}; } catch (e) { D = {}; }
  D.rules = D.rules || []; D.fix = D.fix || [];
  function save() { try { localStorage.setItem(K, JSON.stringify(D)); } catch (e) {} apply(); try { if (window.lexiTrainRebuild) window.lexiTrainRebuild(); } catch (e) {} }
  function block() {
    var t = '';
    if (D.rules.length) t += '\nUser rules (always follow): ' + D.rules.slice(-25).join(' | ');
    if (D.fix.length) t += '\nPast corrections (use these answers when the same or similar question comes up): ' + D.fix.slice(-8).map(function (f) { return 'Q: ' + f.q + ' => A: ' + f.a; }).join(' | ');
    return t ? '\n[TEACH]' + t + '\n[/TEACH]' : '';
  }
  var RE = /\n\[TEACH\][\s\S]*?\[\/TEACH\]/;
  function apply() {
    var b = block();
    try { SYS = SYS.replace(RE, '') + b; } catch (e) {}
    try { SYS_LITE = SYS_LITE.replace(RE, '') + b; } catch (e) {}
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function panel() {
    var o = document.createElement('div');
    o.style.cssText = 'position:fixed;inset:0;z-index:99998;background:#0b0b17;color:#fff;overflow:auto;padding:16px;font:14px system-ui';
    function draw() {
      o.innerHTML = '<h2>🧠 Teach Lexi</h2><p>Rules and corrections are saved on this device only and added to every answer.</p>' +
        '<b>Add a rule</b><br><input id="tr" style="width:100%;padding:8px;margin:6px 0" placeholder="e.g. Always reply in Hinglish"><button id="tra">Add rule</button>' +
        '<br><br><b>Add a correction</b><br><input id="tq" style="width:100%;padding:8px;margin:6px 0" placeholder="Question Lexi got wrong"><input id="ta" style="width:100%;padding:8px;margin:6px 0" placeholder="The right answer"><button id="tfa">Add correction</button>' +
        '<h3>Rules</h3>' + (D.rules.map(function (r, i) { return '<p>' + esc(r) + ' <button data-r="' + i + '">✕</button></p>'; }).join('') || '<p>None yet</p>') +
        '<h3>Corrections</h3>' + (D.fix.map(function (f, i) { return '<p>' + esc(f.q) + ' → ' + esc(f.a) + ' <button data-f="' + i + '">✕</button></p>'; }).join('') || '<p>None yet</p>') +
        '<br><button id="tx" style="padding:8px 14px">Close</button>';
      o.querySelector('#tx').onclick = function () { o.remove(); };
      var tc = document.createElement('button'); tc.textContent = '🎓 Open Training Center'; tc.style.cssText = 'margin-left:8px;padding:8px 14px'; tc.onclick = function () { o.remove(); if (window.lexiTrain) window.lexiTrain('rules'); }; o.querySelector('#tx').after(tc);
      o.querySelector('#tra').onclick = function () { var v = o.querySelector('#tr').value.trim(); if (v) { D.rules.push(v.slice(0, 300)); save(); draw(); } };
      o.querySelector('#tfa').onclick = function () { var q = o.querySelector('#tq').value.trim(), a = o.querySelector('#ta').value.trim(); if (q && a) { D.fix.push({ q: q.slice(0, 500), a: a.slice(0, 1500) }); save(); draw(); } };
      [].forEach.call(o.querySelectorAll('button[data-r]'), function (b) { b.onclick = function () { D.rules.splice(+b.dataset.r, 1); save(); draw(); }; });
      [].forEach.call(o.querySelectorAll('button[data-f]'), function (b) { b.onclick = function () { D.fix.splice(+b.dataset.f, 1); save(); draw(); }; });
    }
    draw(); document.body.appendChild(o);
  }
  window.lexiTeach = panel;
  window.lexiTeachAPI = {
    get: function () { return D; },
    addRule: function (r) { r = String(r).trim().slice(0, 300); if (r && D.rules.indexOf(r) < 0) { D.rules.push(r); save(); } },
    delRule: function (i) { D.rules.splice(i, 1); save(); },
    addFix: function (q, a) { q = String(q).trim().slice(0, 500); a = String(a).trim().slice(0, 1500); if (!q || !a) return; D.fix = D.fix.filter(function (f) { return f.q !== q; }); D.fix.push({ q: q, a: a }); save(); },
    delFix: function (i) { D.fix.splice(i, 1); save(); }
  };
  var b = document.createElement('button');
  b.textContent = '🧠'; b.title = 'Teach Lexi';
  /* v19: sits above the message bar so it no longer covers the + button */
  b.style.cssText = 'position:fixed;left:12px;bottom:calc(96px + env(safe-area-inset-bottom,0px));z-index:9999;width:36px;height:36px;border-radius:50%;border:0;font-size:18px;background:#ff5fa2;color:#fff;opacity:.85;box-shadow:0 2px 8px rgba(0,0,0,.2)';
  b.setAttribute('aria-label', 'Teach Lexi');
  b.onclick = panel; document.body.appendChild(b);
  apply();
})();
