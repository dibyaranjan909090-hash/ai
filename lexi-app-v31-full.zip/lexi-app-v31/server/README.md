# Lexi AI server (free, about 10 minutes)

Why: the free keyless AI that Lexi used (Pollinations) now requires a key, so answers without a key became weak or failed.
This small server gives every Lexi user strong Google Gemini answers (good in Hindi, Odia, Malayalam, Kannada and 40+ languages)
without anyone entering a key. The key is stored as a secret on Cloudflare and never appears in the app.

## Set up
1. Gemini key: open https://aistudio.google.com/apikey, sign in with the company Google account, press **Create API key**, copy it.
2. Cloudflare: create a free account at https://dash.cloudflare.com/sign-up
3. **Workers & Pages → Create → Create Worker**, name it `lexi-ai`, press **Deploy**, then **Edit code**.
4. Delete the sample code, paste all of `lexi-ai-worker.js`, press **Deploy**.
5. Worker **Settings → Variables and Secrets → Add**:
   - `GEMINI_API_KEY` = your key, type **Secret**
   - `ALLOWED_ORIGINS` = your Lexi site, type **Text**, e.g. `https://lexi-purlin.netlify.app` (several: separate with commas; add `http://localhost:8000` for testing)
   - optional: `MODELS` (default `gemini-flash-latest,gemini-2.5-flash,gemini-2.5-flash-lite`), `PER_MINUTE` (default 20), `GROQ_API_KEY` (secret, backup)
   Deploy again.
6. Open `https://lexi-ai.<your-name>.workers.dev/health`: it should show `"ai":"gemini"`.
7. In Lexi: **+ → Training Center → AI server**, paste the address, **Save**, **Test**.
8. For all users: **Download lexi-config.json** there, put it in the Lexi folder (replace the old one), upload the folder again.

## Good to know
- Your own keys in Lexi's Settings are still used first on that device; the server is used when there is no key.
- Cloudflare's free plan allows 100,000 requests a day. Google sets free Gemini limits per project (AI Studio → Rate limits).
- On Google's free tier, content may be used to improve Google's products. For private business data or higher limits, turn on billing in AI Studio (the server code stays the same).
- Only sites listed in `ALLOWED_ORIGINS` can use the server, and each visitor is limited per minute, so others cannot spend your quota from their own sites.
- Photos sent to Lexi are answered too (Gemini reads images).
- **Voice for the floating robot (v28):** the server also turns speech into text (`POST /v1/transcribe`). The desktop robot app and the Android floating robot have no built-in speech recognition, so they send the short recording here. If you use them, add their addresses to `ALLOWED_ORIGINS` too: `lexi://app` for the desktop app (when it uses its built-in copy of Lexi) and your Lexi site for Android. Update the Worker code (paste the new `lexi-ai-worker.js`, Deploy) to get this.
