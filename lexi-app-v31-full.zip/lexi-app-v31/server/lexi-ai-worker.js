/* Lexi AI server: a Cloudflare Worker that gives every Lexi user strong AI answers without their own key.
   It speaks the OpenAI chat format (what Lexi already sends) and answers with Google Gemini, using the
   company's key stored as a secret on Cloudflare (never inside the app).

   Settings (Cloudflare dashboard > your Worker > Settings > Variables and Secrets):
     GEMINI_API_KEY   (secret, required)  key from https://aistudio.google.com/apikey
     ALLOWED_ORIGINS  (text, required)    your Lexi site(s), comma separated, e.g. https://lexi-purlin.netlify.app,http://localhost:8000
     MODELS           (text, optional)    models tried in order, default: gemini-flash-latest,gemini-2.5-flash,gemini-2.5-flash-lite
     PER_MINUTE       (text, optional)    requests per minute per visitor, default 20
     GROQ_API_KEY     (secret, optional)  backup when Gemini is busy (free key from https://console.groq.com/keys)

   Endpoints:
     GET  /health                         -> {"ok":true,...}
     POST /v1/chat/completions            -> OpenAI-style JSON, or a stream when "stream": true
     POST /v1/chat/completions?format=text -> plain text answer
     POST /v1/transcribe                  -> {"text":"..."}  speech to text for the floating robot's mic
                                             body: {"audio":"<base64>","mime":"audio/wav","lang":"en-IN"} (max ~3 MB) */

const DEFAULT_MODELS = 'gemini-flash-latest,gemini-2.5-flash,gemini-2.5-flash-lite';
const GEMINI = 'https://generativelanguage.googleapis.com/v1beta/models/';
const hits = new Map(); // best-effort rate limit per visitor (per Cloudflare location)

function cors(origin, env) {
  const allowed = (env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
  const ok = !!origin && allowed.includes(origin);
  return { ok, headers: { 'Access-Control-Allow-Origin': ok ? origin : 'null', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'content-type, authorization', 'Access-Control-Max-Age': '86400', 'Vary': 'Origin' } };
}
function json(obj, status, h) { return new Response(JSON.stringify(obj), { status: status || 200, headers: Object.assign({ 'content-type': 'application/json; charset=utf-8' }, h) }); }
function limited(ip, perMin) {
  const now = Date.now(), win = 60000, rec = hits.get(ip) || [];
  const recent = rec.filter(t => now - t < win); recent.push(now); hits.set(ip, recent);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > win) hits.delete(k);
  return recent.length > perMin;
}

/* OpenAI messages -> Gemini request */
function textOf(c) { return typeof c === 'string' ? c : Array.isArray(c) ? c.filter(p => p && (p.type === 'text' || typeof p.text === 'string')).map(p => p.text || '').join('\n') : ''; }
function partsOf(c) {
  if (typeof c === 'string') return c ? [{ text: c }] : [];
  if (!Array.isArray(c)) return [];
  const out = [];
  for (const p of c) {
    if (!p) continue;
    if (p.type === 'text' || typeof p.text === 'string') { if (p.text) out.push({ text: p.text }); continue; }
    const url = p.image_url && (p.image_url.url || p.image_url);
    const m = typeof url === 'string' && /^data:([\w/+.-]+);base64,(.+)$/s.exec(url);
    if (m) out.push({ inlineData: { mimeType: m[1], data: m[2] } });
    else if (typeof url === 'string') out.push({ text: '[image: ' + url + ']' });
  }
  return out;
}
function toGemini(body) {
  const msgs = Array.isArray(body.messages) ? body.messages.slice(-40) : [];
  const system = msgs.filter(m => m.role === 'system').map(m => textOf(m.content)).join('\n\n').slice(0, 60000);
  const contents = [];
  for (const m of msgs) {
    if (m.role === 'system') continue;
    const role = m.role === 'assistant' ? 'model' : 'user', parts = partsOf(m.content);
    if (!parts.length) continue;
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts.push(...parts); else contents.push({ role, parts }); // Gemini wants alternating turns
  }
  if (!contents.length) contents.push({ role: 'user', parts: [{ text: 'Hello' }] });
  if (contents[0].role !== 'user') contents.unshift({ role: 'user', parts: [{ text: '(continuing our conversation)' }] });
  const req = { contents, generationConfig: { maxOutputTokens: Math.min(Number(body.max_tokens) || 4096, 8192), temperature: typeof body.temperature === 'number' ? body.temperature : 0.6 } };
  if (system) req.systemInstruction = { parts: [{ text: system }] };
  return req;
}
function geminiText(j) {
  const c = j && j.candidates && j.candidates[0];
  return c && c.content && Array.isArray(c.content.parts) ? c.content.parts.map(p => p.text || '').join('') : '';
}

/* Google retires model names; if none of the listed models exist, ask Google which ones this key can use */
let discovered = null;
async function discover(env) {
  if (discovered && Date.now() - discovered.t < 6 * 3600e3) return discovered.ids;
  const r = await fetch(GEMINI.replace(/\/models\/$/, '/models') + '?pageSize=200', { headers: { 'x-goog-api-key': env.GEMINI_API_KEY } });
  if (!r.ok) return [];
  const j = await r.json();
  const num = id => { const m = /(\d+(?:\.\d+)?)/.exec(id); return m ? parseFloat(m[1]) : 0; };
  const ids = (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent')).map(m => String(m.name).replace(/^models\//, ''))
    .filter(id => /^gemini-/.test(id) && /flash/.test(id) && !/(image|tts|audio|live|embedding|thinking|robotics|native|computer)/.test(id))
    .sort((a, b) => (num(b) * 10 - (/lite/.test(b) ? 2 : 0) - (/(preview|exp)/.test(b) ? 1 : 0)) - (num(a) * 10 - (/lite/.test(a) ? 2 : 0) - (/(preview|exp)/.test(a) ? 1 : 0)));
  discovered = { t: Date.now(), ids: ids.slice(0, 3) };
  return discovered.ids;
}
/* one call to Gemini with model fallback; returns the Response from Google */
async function callGemini(env, req, stream) {
  let models = (env.MODELS || DEFAULT_MODELS).split(',').map(s => s.trim()).filter(Boolean);
  if (discovered && discovered.ids.length) models = discovered.ids.concat(models.filter(m => !discovered.ids.includes(m)));
  let last = null, missing = 0;
  for (const model of models) {
    const url = GEMINI + encodeURIComponent(model) + (stream ? ':streamGenerateContent?alt=sse' : ':generateContent');
    const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY }, body: JSON.stringify(req) });
    if (r.ok) return { r, model };
    last = { status: r.status, text: (await r.text()).slice(0, 300), model };
    if (r.status === 404 || r.status === 400 && /not (found|supported)|no longer available/i.test(last.text)) missing++;
    if (![400, 404, 429, 500, 503].includes(r.status)) break; // only try the next model when this one is missing or busy
  }
  if (missing && missing === models.length && !discovered) {      // every name was retired: find what exists now
    for (const model of await discover(env)) {
      const url = GEMINI + encodeURIComponent(model) + (stream ? ':streamGenerateContent?alt=sse' : ':generateContent');
      const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': env.GEMINI_API_KEY }, body: JSON.stringify(req) });
      if (r.ok) return { r, model };
      last = { status: r.status, text: (await r.text()).slice(0, 300), model };
    }
  }
  const e = new Error('gemini ' + (last ? last.status + ' ' + last.text : 'no model')); e.status = last ? last.status : 502; throw e;
}
async function callGroq(env, body) {
  const r = await fetch('https://api.groq.com/openai/v1/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + env.GROQ_API_KEY },
    body: JSON.stringify({ model: 'llama-3.3-70b-versatile', messages: (body.messages || []).map(m => ({ role: m.role, content: textOf(m.content) })), max_tokens: Math.min(Number(body.max_tokens) || 4096, 8192) }) });
  if (!r.ok) throw new Error('groq ' + r.status);
  const j = await r.json(); return j.choices[0].message.content || '';
}
function openaiJSON(text, model) {
  return { id: 'lexi-' + Date.now(), object: 'chat.completion', created: Math.floor(Date.now() / 1000), model, choices: [{ index: 0, message: { role: 'assistant', content: text }, finish_reason: 'stop' }] };
}
function chunk(text, model) { return 'data: ' + JSON.stringify({ id: 'lexi', object: 'chat.completion.chunk', model, choices: [{ index: 0, delta: { content: text } }] }) + '\n\n'; }
/* Gemini SSE stream -> OpenAI SSE stream */
function relay(geminiRes, model) {
  const dec = new TextDecoder(), enc = new TextEncoder();
  let buf = '';
  return geminiRes.body.pipeThrough(new TransformStream({
    transform(bytes, ctl) {
      buf += dec.decode(bytes, { stream: true });
      const lines = buf.split('\n'); buf = lines.pop();
      for (const l of lines) {
        const s = l.trim(); if (!s.startsWith('data:')) continue;
        try { const t = geminiText(JSON.parse(s.slice(5))); if (t) ctl.enqueue(enc.encode(chunk(t, model))); } catch (e) { }
      }
    },
    flush(ctl) {
      const s = buf.trim(); if (s.startsWith('data:')) { try { const t = geminiText(JSON.parse(s.slice(5))); if (t) ctl.enqueue(enc.encode(chunk(t, model))); } catch (e) { } }
      ctl.enqueue(enc.encode('data: [DONE]\n\n'));
    }
  }));
}

/* speech to text: Gemini listens to the recording; Groq Whisper is the backup */
const LANG_NAMES = { en: 'English', hi: 'Hindi', kn: 'Kannada', ta: 'Tamil', te: 'Telugu', ml: 'Malayalam', or: 'Odia', bn: 'Bengali', mr: 'Marathi', gu: 'Gujarati', pa: 'Punjabi', ur: 'Urdu', as: 'Assamese', ne: 'Nepali' };
async function transcribe(env, body) {
  const audio = String(body.audio || ''), mime = /^audio\/[\w.+-]+$/.test(body.mime || '') ? body.mime : 'audio/wav';
  const lang = String(body.lang || '').slice(0, 12), ln = LANG_NAMES[lang.split('-')[0]] || '';
  const prompt = 'Transcribe exactly what the speaker says in this recording, in the language and script they speak' + (ln ? ' (most likely ' + ln + ')' : '') +
    '. Write only the words, with no translation, labels, quotes or notes. If there is no clear speech, reply with nothing.';
  const req = { contents: [{ role: 'user', parts: [{ inlineData: { mimeType: mime, data: audio } }, { text: prompt }] }], generationConfig: { temperature: 0, maxOutputTokens: 2048 } };
  try {
    const { r } = await callGemini(env, req, false);
    return geminiText(await r.json()).trim().replace(/^["“]|["”]$/g, '');
  } catch (e) {
    if (!env.GROQ_API_KEY) throw e;
    const bin = Uint8Array.from(atob(audio), ch => ch.charCodeAt(0));
    const fd = new FormData(); fd.append('file', new Blob([bin], { type: mime }), 'speech.' + (mime.split('/')[1] || 'wav').replace(/[^a-z0-9].*$/, ''));
    fd.append('model', 'whisper-large-v3-turbo'); if (lang) fd.append('language', lang.split('-')[0]);
    const g = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', { method: 'POST', headers: { authorization: 'Bearer ' + env.GROQ_API_KEY }, body: fd });
    if (!g.ok) throw e;
    return String((await g.json()).text || '').trim();
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url), origin = request.headers.get('Origin') || '';
    const c = cors(origin, env);
    if (request.method === 'OPTIONS') return new Response(null, { status: c.ok ? 204 : 403, headers: c.headers });
    if (url.pathname === '/health') return json({ ok: true, ai: env.GEMINI_API_KEY ? 'gemini' : 'not set up', backup: !!env.GROQ_API_KEY, models: (env.MODELS || DEFAULT_MODELS) }, 200, c.headers);
    const isSTT = url.pathname === '/v1/transcribe';
    if ((url.pathname !== '/v1/chat/completions' && !isSTT) || request.method !== 'POST') return json({ error: 'not found' }, 404, c.headers);
    if (!c.ok) return json({ error: 'This site is not allowed to use this AI server. Add it to ALLOWED_ORIGINS.' }, 403, c.headers);
    if (!env.GEMINI_API_KEY) return json({ error: 'GEMINI_API_KEY is not set on the server.' }, 500, c.headers);
    const ip = request.headers.get('CF-Connecting-IP') || 'x';
    if (limited(ip, Number(env.PER_MINUTE) || 20)) return json({ error: 'Too many requests, please wait a minute.' }, 429, Object.assign({ 'Retry-After': '30' }, c.headers));
    let body;
    if (isSTT) {
      if (Number(request.headers.get('content-length') || 0) > 4e6) return json({ error: 'Recording too long.' }, 413, c.headers);
      try { body = await request.json(); } catch (e) { return json({ error: 'Bad JSON' }, 400, c.headers); }
      if (!body.audio || typeof body.audio !== 'string' || body.audio.length > 4e6) return json({ error: 'audio (base64) required, max about 3 MB' }, 400, c.headers);
      try { return json({ text: await transcribe(env, body) }, 200, c.headers); }
      catch (e) { return json({ error: 'Could not hear that: ' + String(e.message || e).slice(0, 200) }, e.status === 429 ? 429 : 502, c.headers); }
    }
    try { body = await request.json(); } catch (e) { return json({ error: 'Bad JSON' }, 400, c.headers); }
    if (!Array.isArray(body.messages) || !body.messages.length) return json({ error: 'messages required' }, 400, c.headers);
    const asText = url.searchParams.get('format') === 'text', stream = !!body.stream && !asText;
    const req = toGemini(body);
    try {
      const { r, model } = await callGemini(env, req, stream);
      if (stream) return new Response(relay(r, model), { headers: Object.assign({ 'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-cache' }, c.headers) });
      const j = await r.json(), text = geminiText(j);
      if (!text) { const why = (j.promptFeedback && j.promptFeedback.blockReason) || (j.candidates && j.candidates[0] && j.candidates[0].finishReason) || 'empty'; throw Object.assign(new Error('no text: ' + why), { status: 502 }); }
      return asText ? new Response(text, { headers: Object.assign({ 'content-type': 'text/plain; charset=utf-8' }, c.headers) }) : json(openaiJSON(text, model), 200, c.headers);
    } catch (e) {
      if (env.GROQ_API_KEY) {
        try {
          const text = await callGroq(env, body);
          if (stream) return new Response(chunk(text, 'groq') + 'data: [DONE]\n\n', { headers: Object.assign({ 'content-type': 'text/event-stream; charset=utf-8' }, c.headers) });
          return asText ? new Response(text, { headers: Object.assign({ 'content-type': 'text/plain; charset=utf-8' }, c.headers) }) : json(openaiJSON(text, 'groq'), 200, c.headers);
        } catch (e2) { }
      }
      return json({ error: 'AI is busy or unavailable: ' + String(e.message || e).slice(0, 200) }, e.status === 429 ? 429 : 502, c.headers);
    }
  }
};
