/* Lexi service worker: offline app shell + alarm notification taps */
var V = 'lexi-v33';
/* v20: the 1.4 MB TensorFlow files are no longer downloaded at install; they are cached the first time the photo detector needs them */
var FILES = ['./', 'index.html', 'aiserver.js', 'lexi-config.json', 'plus.js', 'tasks.js', 'lang.js', 'calc.js', 'smart.js', 'web.js', 'connect.js', 'vision.js', 'create.js', 'media.js', 'quick.js', 'brain.js', 'teach.js', 'knowledge.js', 'knowledge2.js', 'tools.js', 'models.js', 'memory.js', 'dict.js', 'sense.js', 'i18n.js', 'lingo.js', 'history.js', 'dict/index.json', 'train.js', 'anim.js', 'robot.js', 'company-profile.json', 'docs.json', 'training-examples.jsonl', 'robot-body.webp', 'robot-arm.webp', 'robot-ant.webp', 'robot-heart.webp', 'bubble.js', 'manifest.webmanifest', 'robot.png', 'icon-192.png', 'icon-512.png', 'icon-maskable-192.png', 'icon-maskable-512.png'];
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(V).then(function (c) { return c.addAll(FILES); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== V && k.indexOf('lexi-dict') !== 0; /* keep the downloaded dictionary */ }).map(function (k) { return caches.delete(k); })); }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin) return; /* API calls always go to the network */
  e.respondWith(caches.match(r, { ignoreSearch: true }).then(function (hit) {
    var net = fetch(r).then(function (res) {
      if (res && res.ok) { var copy = res.clone(); caches.open(/\/dict\//.test(u.pathname) ? 'lexi-dict-v1' : V).then(function (c) { c.put(r, copy); }); } /* dictionary parts live in their own cache */
      return res;
    }).catch(function () { return hit || caches.match('index.html'); });
    return hit || net;
  }));
});
self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (cs) {
    for (var i = 0; i < cs.length; i++) if ('focus' in cs[i]) return cs[i].focus();
    return self.clients.openWindow('./index.html');
  }));
});
