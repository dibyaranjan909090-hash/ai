/* Lexi knowledge v15: compact built-in reference added to the full (detailed) prompt */
(function () {
  var KB = '\n\nREFERENCE KNOWLEDGE (use when relevant, verify before relying):\n' +
  'MATHS: quadratic x=(-b±√(b²-4ac))/2a; compound interest A=P(1+r/n)^(nt); EMI=P·r(1+r)^n/((1+r)^n-1) with monthly r; GST: price×rate/100, CGST=SGST=half; % change=(new-old)/old×100; circle area πr², circumference 2πr; sphere volume 4/3πr³; d/dx xⁿ=n·xⁿ⁻¹; ∫xⁿdx=xⁿ⁺¹/(n+1)+C; speed=distance/time; force=mass×acceleration; power=voltage×current; work=force×distance.\n' +
  'LOGIC: write givens, list cases, eliminate contradictions, test the answer against every clue; for syllogisms draw sets; for probability count favourable/total and check the sum is 1.\n' +
  'WEBSITES: semantic HTML5, <meta viewport>, flex/grid layout, CSS variables, buttons use addEventListener, forms validate before submit, save data with localStorage inside try/catch, alt text on images, readable contrast, no external files unless asked.\n' +
  'CODE: handle empty input and errors, name things clearly, avoid global state, give one runnable example, mention the language version. Python: venv + pip; JavaScript: const/let, async/await, fetch with try/catch; SQL: parameterised queries; Java/C: check bounds and null.\n' +
  'CONVERTING APPS: list features first, map each to the target language/framework, keep data formats identical, then give the full converted code.\n' +
  'MECHANICAL: linear actuator travel time = stroke/speed; screw lead (mm/rev) × rpm/60 = speed (mm/s); power = force × speed; always state units and keep a safety margin of 20-30% on rated load.\n' +
  'STYLE: answer first, steps next, check last; reply in the user\'s language; say "not sure" rather than guess.';
  try { if (typeof SYS === 'string' && SYS.indexOf('REFERENCE KNOWLEDGE') < 0) SYS += KB; } catch (e) {}
})();
