/* Lexi web.js
   1) Website reader: give any link or domain (purlinautomation.in, https://...) and Lexi
      opens it live, shows a quick SEO / mobile / content check and answers your question
      about it with AI. No more "I cannot browse the internet".
   2) Website builder: "make a website for my bakery" builds a complete one-page site with
      a live preview, Download, Copy and Full screen. Then just say what to change
      ("change colour to blue", "add a pricing section") and it updates the same site.
      Works offline with a built-in template; with an AI key (or the free AI) the design and
      text are written for you.
   Loaded last, so it sees every message first. */
(function (root) {
'use strict';

/* ======================= PURE LOGIC ======================= */
var TLD = 'com|in|org|net|io|co|ai|app|dev|info|biz|me|xyz|site|online|store|shop|tech|edu|gov|us|uk|tv|cloud|live|blog|page|website|space|pro|club|world|news|today|digital|solutions|services|agency|design|studio|ac|res|ind';
var URL_RE = new RegExp('(?:https?:\\/\\/)?(?:www\\.)?[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*\\.(?:' + TLD + ')(?:\\.[a-z]{2})?(?::\\d+)?(?:\\/[^\\s"\'<>)]*)?', 'i');

function findURL(s) {
  s = String(s || '');
  var lines = s.split('\n').filter(function (l) { return l.trim(); });
  if ((/```/.test(s) || lines.length >= 3) && !/https?:\/\//i.test(s)) return null; /* pasted code: leave it to coding mode */
  var re = new RegExp(URL_RE.source, 'ig'), m;
  while ((m = re.exec(s))) {
    var before = s.charAt(m.index - 1);
    if (before === '@' || /[a-z0-9._%+-]/i.test(before) && s.slice(0, m.index).match(/[a-z0-9._%+-]+@$/i)) continue; /* e-mail */
    if (!/^https?:/i.test(m[0]) && /^\d+(\.\d+)+$/.test(m[0])) continue;
    var u = m[0].replace(/[.,;:!?]+$/, '');
    if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
    return u;
  }
  return null;
}

/* SEO / quality check from raw HTML (needs a DOMParser) */
function audit(html, url, Parser) {
  var doc = new Parser().parseFromString(html, 'text/html');
  function q(sel) { return doc.querySelector(sel); }
  function qa(sel) { return [].slice.call(doc.querySelectorAll(sel)); }
  function meta(n) { var e = q('meta[name="' + n + '" i]') || q('meta[property="' + n + '" i]'); return e ? (e.getAttribute('content') || '').trim() : ''; }
  var title = ((q('title') || {}).textContent || '').trim().replace(/\s+/g, ' ');
  var desc = meta('description');
  var h1 = qa('h1').map(function (e) { return e.textContent.trim().replace(/\s+/g, ' '); }).filter(Boolean);
  var h2 = qa('h2').map(function (e) { return e.textContent.trim().replace(/\s+/g, ' '); }).filter(Boolean);
  var imgs = qa('img'), noAlt = imgs.filter(function (i) { return !(i.getAttribute('alt') || '').trim(); }).length;
  var host = ''; try { host = new URL(url).hostname.replace(/^www\./, ''); } catch (e) { }
  var links = qa('a[href]').map(function (a) { return a.getAttribute('href') || ''; });
  var ext = links.filter(function (h) { return /^https?:/i.test(h) && host && h.indexOf(host) < 0; }).length;
  qa('script,style,noscript,svg,template').forEach(function (e) { e.remove(); });
  var text = ((doc.body || doc.documentElement).textContent || '').replace(/\s+/g, ' ').trim();
  var words = text ? text.split(' ').length : 0;
  var phones = (text.match(/(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}\b/g) || []).concat(links.filter(function (h) { return /^tel:/i.test(h); }).map(function (h) { return h.slice(4); }));
  var emails = (html.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/ig) || []).filter(function (e) { return !/\.(png|jpe?g|gif|webp|svg)$/i.test(e) && !/sentry|example|wixpress/i.test(e); });
  function uniq(a) { return a.filter(function (x, i) { return a.indexOf(x) === i; }); }
  var robots = meta('robots');
  var checks = [
    ['Secure (HTTPS)', /^https:/i.test(url), /^https:/i.test(url) ? 'Yes' : 'Site is not on https://'],
    ['Page title', title.length >= 20 && title.length <= 65, title ? '“' + title + '” (' + title.length + ' characters, best 30 to 60)' : 'Missing'],
    ['Meta description', desc.length >= 70 && desc.length <= 165, desc ? desc.length + ' characters (best 70 to 160)' : 'Missing: Google will pick random text'],
    ['One main heading (H1)', h1.length === 1, h1.length ? h1.length + ' found: “' + h1[0].slice(0, 70) + '”' : 'No H1 heading'],
    ['Section headings (H2)', h2.length >= 2, h2.length + ' found'],
    ['Mobile friendly (viewport)', !!q('meta[name="viewport" i]'), q('meta[name="viewport" i]') ? 'Yes' : 'Missing viewport tag'],
    ['Image alt text', imgs.length === 0 || noAlt === 0, imgs.length ? (imgs.length - noAlt) + ' of ' + imgs.length + ' images have alt text' : 'No images'],
    ['Enough content', words >= 300, words + ' words (300+ ranks better)'],
    ['Social preview (Open Graph)', !!(meta('og:title') && meta('og:image')), meta('og:image') ? 'Image set' : 'Add og:title and og:image for WhatsApp/Facebook previews'],
    ['Canonical link', !!q('link[rel="canonical" i]'), q('link[rel="canonical" i]') ? 'Yes' : 'Missing'],
    ['Language set', !!(doc.documentElement.getAttribute('lang')), doc.documentElement.getAttribute('lang') || 'Missing lang attribute'],
    ['Favicon', !!q('link[rel~="icon" i]'), q('link[rel~="icon" i]') ? 'Yes' : 'Missing'],
    ['Structured data', !!q('script[type="application/ld+json"]') || /application\/ld\+json/i.test(html), /application\/ld\+json/i.test(html) ? 'Yes' : 'Add LocalBusiness / Product schema'],
    ['Search engines allowed', !/noindex/i.test(robots), /noindex/i.test(robots) ? 'Page says noindex!' : 'Yes'],
    ['Contact details visible', phones.length > 0 || emails.length > 0, (uniq(phones).slice(0, 2).join(', ') || '') + (emails.length ? (phones.length ? ' · ' : '') + uniq(emails).slice(0, 2).join(', ') : '') || 'No phone or e-mail found'],
    ['Page size', html.length < 600000, Math.round(html.length / 1024) + ' KB of HTML']
  ];
  var pass = checks.filter(function (c) { return c[1]; }).length;
  return { title: title, desc: desc, h1: h1, h2: h2.slice(0, 12), words: words, text: text, checks: checks, score: Math.round(pass / checks.length * 100), links: links.length, ext: ext, images: imgs.length };
}

/* jina reader returns "Title: ...\nURL Source: ...\nMarkdown Content:\n..." */
function parseReader(t) {
  var title = (t.match(/^Title:\s*(.+)$/m) || [])[1] || '';
  var body = t.split(/^Markdown Content:\s*$/m)[1] || t;
  return { title: title.trim(), text: body.replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\n{3,}/g, '\n\n').trim() };
}

/* ---------- website builder ---------- */
var COLORS = { blue: '#2563eb', red: '#dc2626', green: '#16a34a', orange: '#ea580c', purple: '#7c3aed', violet: '#7c3aed', pink: '#db2777', teal: '#0d9488', cyan: '#0891b2', yellow: '#ca8a04', gold: '#b8860b', black: '#111827', grey: '#4b5563', gray: '#4b5563', navy: '#1e3a8a', maroon: '#7f1d1d', brown: '#92400e', indigo: '#4f46e5', saffron: '#f97316', 'sky blue': '#0ea5e9', 'dark blue': '#1e3a8a', 'light blue': '#38bdf8', 'dark green': '#166534' };
var BUILD_RE = /^(?:please\s+|can you\s+|pls\s+)?(?:make|create|build|generate|design|develop|code|write)\s+(?:me\s+)?(?:a\s+|an\s+|my\s+|our\s+|the\s+)?(?:(?:simple|modern|beautiful|professional|responsive|nice|good|new|small|single|one[- ]page|business|company|personal|portfolio|static|html)\s+)*(?:website|web\s?site|landing\s+page|web\s?page|home\s?page|site|portfolio)\b\s*(.*)$/i;
function isBuild(s) { return BUILD_RE.test(String(s || '').trim()); }
function titleCase(s) { return s.replace(/\b([a-z])/g, function (_, c) { return c.toUpperCase(); }); }
function parseBrief(s) {
  s = String(s || '').trim();
  var rest = (s.match(BUILD_RE) || [])[1] || s, o = { color: '#2563eb', dark: false, services: [] };
  var c; for (c in COLORS) if (new RegExp('\\b' + c + '\\b', 'i').test(rest)) { o.color = COLORS[c]; break; }
  if (/\bdark\b/i.test(rest)) o.dark = true;
  var ph = rest.match(/(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}\b/); if (ph) o.phone = ph[0].replace(/\s|-/g, '');
  var em = rest.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i); if (em) o.email = em[0];
  var sv = rest.match(/\b(?:services?|products?|offering|selling|sells|items?)\s*(?:are|like|:|-|such as|including)?\s+([^.]+)/i);
  if (sv) o.services = sv[1].split(/,|\band\b|\//).map(function (x) { return titleCase(x.replace(/\b(phone|email|colou?r)\b.*$/i, '').trim()); }).filter(function (x) { return x && x.length < 40; }).slice(0, 6);
  var nm = rest.match(/\b(?:for|called|named|of)\s+(?:my\s+|our\s+|a\s+|an\s+|the\s+)?(.+?)(?=\s+(?:with|that|which|in\s+\w+\s+colou?r|using|having|selling|sells|services?|products?|phone|email|and\s+(?:add|include|put))\b|[,.]|$)/i);
  o.name = nm ? titleCase(nm[1].trim()).slice(0, 48) : 'My Business';
  o.tagline = 'Quality you can trust. Service you can count on.';
  o.about = o.name + ' is dedicated to delivering excellent products and friendly service to every customer. Get in touch to find out how we can help you.';
  if (!o.services.length) o.services = ['Our Products', 'Custom Solutions', 'Support & Service'];
  return o;
}
function escA(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function siteHTML(o) {
  var bg = o.dark ? '#0f172a' : '#ffffff', fg = o.dark ? '#e2e8f0' : '#1f2937', card = o.dark ? '#1e293b' : '#f8fafc', mut = o.dark ? '#94a3b8' : '#6b7280';
  var wa = o.phone ? (o.phone.replace(/\D/g, '').length === 10 ? '91' : '') + o.phone.replace(/\D/g, '') : '';
  var icons = ['⚙️', '🛠️', '🤝', '🚚', '⭐', '📦'];
  return '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>' + escA(o.name) + '</title>\n<meta name="description" content="' + escA(o.name + ': ' + o.tagline) + '">\n<style>\n' +
    ':root{--c:' + o.color + ';--bg:' + bg + ';--fg:' + fg + ';--card:' + card + ';--mut:' + mut + '}\n*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--fg);line-height:1.6}\n' +
    'a{color:var(--c)}.w{max-width:1100px;margin:0 auto;padding:0 20px}\nnav{position:sticky;top:0;background:var(--bg);border-bottom:1px solid rgba(127,127,127,.15);z-index:9}nav .w{display:flex;align-items:center;justify-content:space-between;height:64px}\n.brand{font-weight:800;font-size:20px;color:var(--c);text-decoration:none}nav ul{display:flex;gap:22px;list-style:none;margin:0;padding:0}nav ul a{color:var(--fg);text-decoration:none;font-weight:500}\n' +
    '.hero{padding:90px 0;background:linear-gradient(135deg,var(--c),color-mix(in srgb,var(--c) 55%,#000));color:#fff;text-align:center}.hero h1{font-size:clamp(32px,6vw,56px);margin:0 0 12px;line-height:1.15}.hero p{font-size:20px;opacity:.92;margin:0 auto 28px;max-width:640px}\n' +
    '.btn{display:inline-block;background:#fff;color:var(--c);padding:13px 28px;border-radius:30px;font-weight:700;text-decoration:none;margin:4px}.btn.o{background:transparent;color:#fff;border:2px solid #fff}\nsection{padding:72px 0}h2{font-size:32px;text-align:center;margin:0 0 36px}\n' +
    '.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:22px}.card{background:var(--card);border-radius:16px;padding:28px;border:1px solid rgba(127,127,127,.15)}.card .i{font-size:34px}.card h3{margin:10px 0 6px}.card p{color:var(--mut);margin:0}\n' +
    '.about{max-width:760px;margin:0 auto;text-align:center;font-size:18px;color:var(--mut)}.alt{background:var(--card)}\n.contact{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px;text-align:center}\nfooter{padding:26px 0;text-align:center;color:var(--mut);font-size:14px;border-top:1px solid rgba(127,127,127,.15)}\n' +
    '.wa{position:fixed;right:18px;bottom:18px;background:#25d366;color:#fff;width:58px;height:58px;border-radius:50%;display:grid;place-items:center;font-size:28px;text-decoration:none;box-shadow:0 6px 18px rgba(0,0,0,.25)}\n@media(max-width:640px){nav ul{display:none}.hero{padding:64px 0}section{padding:52px 0}}\n</style>\n</head>\n<body>\n' +
    '<nav><div class="w"><a class="brand" href="#">' + escA(o.name) + '</a><ul><li><a href="#services">Services</a></li><li><a href="#about">About</a></li><li><a href="#contact">Contact</a></li></ul></div></nav>\n' +
    '<header class="hero"><div class="w"><h1>' + escA(o.name) + '</h1><p>' + escA(o.tagline) + '</p><a class="btn" href="#contact">Get in touch</a><a class="btn o" href="#services">Our services</a></div></header>\n' +
    '<section id="services"><div class="w"><h2>What we offer</h2><div class="grid">' + o.services.map(function (s, i) { return '<div class="card"><div class="i">' + icons[i % icons.length] + '</div><h3>' + escA(s) + '</h3><p>High quality ' + escA(s.toLowerCase()) + ' designed around your needs.</p></div>'; }).join('') + '</div></div></section>\n' +
    '<section id="about" class="alt"><div class="w"><h2>About us</h2><p class="about">' + escA(o.about) + '</p></div></section>\n' +
    '<section id="contact"><div class="w"><h2>Contact us</h2><div class="contact">' +
    (o.phone ? '<div class="card"><div class="i">📞</div><h3>Call</h3><p><a href="tel:' + escA(o.phone) + '">' + escA(o.phone) + '</a></p></div>' : '<div class="card"><div class="i">📞</div><h3>Call</h3><p>Add your phone number</p></div>') +
    (o.email ? '<div class="card"><div class="i">✉️</div><h3>E-mail</h3><p><a href="mailto:' + escA(o.email) + '">' + escA(o.email) + '</a></p></div>' : '<div class="card"><div class="i">✉️</div><h3>E-mail</h3><p>Add your e-mail</p></div>') +
    '<div class="card"><div class="i">📍</div><h3>Visit</h3><p>' + escA(o.address || 'Add your address') + '</p></div></div></div></section>\n' +
    '<footer>© ' + new Date().getFullYear() + ' ' + escA(o.name) + '. All rights reserved.</footer>\n' +
    (wa ? '<a class="wa" href="https://wa.me/' + wa + '" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">💬</a>\n' : '') + '</body>\n</html>\n';
}
/* simple edits the offline template understands */
function offlineEdit(o, s) {
  var lc = s.toLowerCase(), m, done = [];
  for (var c in COLORS) if (new RegExp('\\b' + c + '\\b').test(lc) && /colou?r|theme|make it|change|to\b/.test(lc)) { o.color = COLORS[c]; done.push('colour ' + c); break; }
  if ((m = s.match(/#[0-9a-f]{6}\b/i))) { o.color = m[0]; done.push('colour ' + m[0]); }
  if (/\bdark\b/.test(lc)) { o.dark = true; done.push('dark mode'); } else if (/\blight\b|\bwhite background\b/.test(lc)) { o.dark = false; done.push('light mode'); }
  if ((m = s.match(/\b(?:name|title|business name|company name)\s+(?:to|as|is|=|:)\s*["“]?([^"”\n]+?)["”]?\s*$/i))) { o.name = m[1].trim(); done.push('name'); }
  if ((m = s.match(/\btag ?line\s+(?:to|as|is|=|:)\s*["“]?([^"”\n]+?)["”]?\s*$/i))) { o.tagline = m[1].trim(); done.push('tagline'); }
  if ((m = s.match(/\babout(?: us| text| section)?\s+(?:to|as|is|=|:)\s*["“]?([^"”\n]+?)["”]?\s*$/i))) { o.about = m[1].trim(); done.push('about text'); }
  if ((m = s.match(/(?:\+?91[\s-]?)?[6-9]\d{4}[\s-]?\d{5}\b/))) { o.phone = m[0].replace(/\s|-/g, ''); done.push('phone + WhatsApp button'); }
  if ((m = s.match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i))) { o.email = m[0]; done.push('e-mail'); }
  if ((m = s.match(/\baddress\s+(?:to|as|is|=|:)?\s*(.+)$/i))) { o.address = m[1].trim(); done.push('address'); }
  if ((m = s.match(/\badd\s+(?:a\s+)?(?:service|product)s?\s+(.+)$/i))) { m[1].split(/,|\band\b/).forEach(function (x) { x = titleCase(x.trim()); if (x) o.services.push(x); }); done.push('services'); }
  if ((m = s.match(/\b(?:remove|delete)\s+(?:the\s+)?(?:service|product)\s+(.+)$/i))) { var k = m[1].trim().toLowerCase(); o.services = o.services.filter(function (x) { return x.toLowerCase() !== k; }); done.push('removed ' + k); }
  return done;
}
function extractHTML(t) {
  t = String(t || '');
  var m = t.match(/```(?:html)?[^\n]*\n([\s\S]*?)```/i) || t.match(/```(?:html)?[^\n]*\n([\s\S]*)$/i);
  var h = m ? m[1] : t;
  var i = h.search(/<!doctype html|<html[\s>]/i);
  if (i < 0) return null;
  h = h.slice(i);
  var e = h.search(/<\/html>/i);
  if (e >= 0) h = h.slice(0, e + 7);
  return /<body|<\/(?:div|section|header)>/i.test(h) ? h.trim() + '\n' : null;
}
function slug(s) { return String(s || 'website').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'website'; }

var EDIT_VERB = /\b(?:change|make|add|remove|delete|replace|update|edit|customi[sz]e|put|use|increase|decrease|move|set|insert|include|turn|rename|bigger|smaller|improve|redesign)\b/i;
var EDIT_NOUN = /\b(?:website|site|page|header|hero|section|footer|menu|nav|navbar|button|colou?rs?|theme|font|logo|image|photo|banner|form|contact|text|title|heading|tag ?line|background|dark|light|card|gallery|pricing|price|testimonials?|reviews?|map|whatsapp|phone|email|e-mail|address|about|services?|products?|faq|team|layout|animation|style)\b/i;
var NOT_EDIT = /^(?:add|save|new)\s+contact\s+\w+\s+[\d+]|^add\s+(?:a\s+)?(?:task|todo|note|event|alarm|reminder)\b|\bshopping\b|\b(?:alarm|remind|timer|spent|expense)\b|^(?:call|whatsapp|message|text|sms|email)\s+\w+/i;
function isEdit(s) { s = String(s || '').trim(); if (/^(?:website|site)\s*[:,-]/i.test(s)) return true; return s.split(/\s+/).length <= 40 && EDIT_VERB.test(s) && EDIT_NOUN.test(s) && !NOT_EDIT.test(s); }

var JW = { findURL: findURL, audit: audit, parseReader: parseReader, isBuild: isBuild, parseBrief: parseBrief, siteHTML: siteHTML, offlineEdit: offlineEdit, extractHTML: extractHTML, isEdit: isEdit, slug: slug };
root.JTWEB = JW;
if (typeof module !== 'undefined' && module.exports) module.exports = JW;
if (typeof document === 'undefined' || typeof window.handle !== 'function') return;

/* ======================= PAGE WIRING ======================= */
var style = document.createElement('style');
style.textContent = '.jw-sc{display:inline-block;padding:2px 10px;border-radius:12px;font-weight:700;color:#fff}' +
  '.jw-tb{width:100%;border-collapse:collapse;font-size:13.5px;margin:6px 0}.jw-tb td{padding:5px 6px;border-bottom:1px solid var(--bd);vertical-align:top}.jw-tb td:first-child{white-space:nowrap;width:1%}' +
  '.jw-pv{width:100%;height:420px;border:1px solid var(--bd);border-radius:12px;background:#fff;margin-top:8px}' +
  '.jw-row{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}.jw-b{border:1px solid var(--bd);background:var(--card);color:var(--fg);border-radius:16px;padding:6px 12px;font-size:13px;cursor:pointer}.jw-b.p{background:linear-gradient(135deg,var(--a),var(--b));color:#fff;border-color:transparent}' +
  '.jw-hint{font-size:12.5px;color:var(--mut);margin-top:6px}';
document.head.appendChild(style);
function el(t, a, kids) { var e = document.createElement(t); for (var k in a || {}) { if (k === 'text') e.textContent = a[k]; else if (k === 'html') e.innerHTML = a[k]; else e.setAttribute(k, a[k]); } (kids || []).forEach(function (c) { e.appendChild(c); }); return e; }
function bt(t, fn, primary) { var b = el('button', { type: 'button', 'class': 'jw-b' + (primary ? ' p' : ''), text: t }); b.onclick = fn; return b; }
function dots() { return add('<span class="dots"><i></i><i></i><i></i></span>', 'a'); }
function scroll() { log.scrollTop = log.scrollHeight; }
function mdh(t) { return (window.md || function (x) { return esc(x); })(t); }
function talk(t) { try { speak(String(t).replace(/```[\s\S]*?```/g, ' ').replace(/[#*`|>-]/g, ' ').slice(0, 400)); } catch (e) { } }
function feel(m, ms) { try { mood(m, ms); } catch (e) { } }
function footer(m, src, raw) {
  var f = el('div', { 'class': 'src' }); f.appendChild(document.createTextNode('Source: ' + src));
  var c = el('button', { 'class': 'cp', text: 'Copy' }); c.onclick = function () { try { navigator.clipboard.writeText(raw); c.textContent = 'Copied'; } catch (e) { } }; f.appendChild(c); m.appendChild(f);
}
function to(ms) { var c = new AbortController(); setTimeout(function () { c.abort(); }, ms); return c.signal; }
function getText(u, ms) { return fetch(u, { signal: to(ms || 15000) }).then(function (r) { if (!r.ok) throw r.status; return r.text(); }).then(function (t) { if (!t || t.length < 40) throw 0; return t; }); }
function firstOK(list) { return list.reduce(function (p, f) { return p.catch(f); }, Promise.reject()); }

/* AI with your key first, then the free service. msgs = [{role, content}] */
function gen(system, msgs, maxTok, ms) {
  ms = ms || 60000; maxTok = maxTok || 4096;
  var order = CFG.prov && CFG.prov !== 'auto' ? [CFG.prov, 'claude', 'chatgpt', 'gemini'] : ['claude', 'chatgpt', 'gemini'], tries = [];
  order.filter(function (x, i) { return order.indexOf(x) === i; }).forEach(function (p) {
    if (p === 'claude' && CFG.ak) ['claude-sonnet-5-5', 'claude-haiku-5-5'].forEach(function (mdl) {
      tries.push(function () { return fetch('https://api.anthropic.com/v1/messages', { method: 'POST', signal: to(ms), headers: { 'content-type': 'application/json', 'x-api-key': CFG.ak, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, body: new Blob([JSON.stringify({ model: mdl, max_tokens: maxTok, system: system, messages: msgs })], { type: 'application/json' }) }).then(function (r) { return r.json(); }).then(function (j) { if (!j.content) throw 0; return { t: j.content.map(function (x) { return x.text || ''; }).join(''), src: 'Claude' }; }); });
    });
    if (p === 'chatgpt' && CFG.ok) tries.push(function () { return fetch('https://api.openai.com/v1/chat/completions', { method: 'POST', signal: to(ms), headers: { 'content-type': 'application/json', authorization: 'Bearer ' + CFG.ok }, body: new Blob([JSON.stringify({ model: 'gpt-4.1-mini', max_tokens: maxTok, messages: [{ role: 'system', content: system }].concat(msgs) })], { type: 'application/json' }) }).then(function (r) { return r.json(); }).then(function (j) { return { t: j.choices[0].message.content, src: 'ChatGPT' }; }); });
    if (p === 'gemini' && CFG.gk) tries.push(function () { return fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(CFG.gk), { method: 'POST', signal: to(ms), headers: { 'content-type': 'application/json' }, body: new Blob([JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, generationConfig: { maxOutputTokens: maxTok }, contents: msgs.map(function (x) { return { role: x.role === 'assistant' ? 'model' : 'user', parts: [{ text: x.content }] }; }) })], { type: 'application/json' }) }).then(function (r) { return r.json(); }).then(function (j) { return { t: j.candidates[0].content.parts.map(function (p) { return p.text || ''; }).join(''), src: 'Gemini' }; }); });
  });
  [['groq', CFG.grk, 'https://api.groq.com/openai/v1/chat/completions', 'llama-3.3-70b-versatile', 'Groq'], ['openrouter', CFG.ork, 'https://openrouter.ai/api/v1/chat/completions', 'meta-llama/llama-3.3-70b-instruct:free', 'OpenRouter']].forEach(function (x) { if (!x[1]) return; tries.push(function () { var hd = { 'content-type': 'application/json', authorization: 'Bearer ' + x[1] }; if (x[0] === 'openrouter') { hd['HTTP-Referer'] = location.origin === 'null' ? 'https://jaan.app' : location.origin; hd['X-Title'] = 'Lexi'; } return fetch(x[2], { method: 'POST', signal: to(ms), headers: hd, body: new Blob([JSON.stringify({ model: x[3], max_tokens: maxTok, messages: [{ role: 'system', content: system }].concat(msgs) })], { type: 'application/json' }) }).then(function (r) { return r.json(); }).then(function (j) { return { t: j.choices[0].message.content, src: x[4] }; }); }); });
  tries.push(function () { return fetch('https://text.pollinations.ai/openai', { method: 'POST', signal: to(ms), headers: { 'content-type': 'application/json' }, body: new Blob([JSON.stringify({ model: 'openai', messages: [{ role: 'system', content: system }].concat(msgs) })], { type: 'application/json' }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return { t: j.choices[0].message.content, src: 'Free AI (no key)' }; }); });
  return tries.reduce(function (p, f) { return p.catch(function () { return f().then(function (r) { if (!r.t || !String(r.t).trim()) throw 0; return r; }); }); }, Promise.reject());
}
function history() { try { return (typeof ctx === 'function' ? ctx() : []).slice(-6); } catch (e) { return []; } }
function sysNow() { return (typeof SYS === 'string' ? SYS : '') + ' You can read websites: when WEBSITE CONTENT is included in the message it was fetched live for you just now, so use it and never say you cannot browse or cannot view websites.'; }

/* ---------- 1) website reader ---------- */
var PAGE = null; /* last website read: {url, title, text, a} */
function fetchSite(url) {
  var html = firstOK([
    function () { return getText('https://api.allorigins.win/raw?url=' + encodeURIComponent(url)); },
    function () { return getText('https://corsproxy.io/?url=' + encodeURIComponent(url)); },
    function () { return getText('https://api.codetabs.com/v1/proxy?quest=' + encodeURIComponent(url)); }
  ]).then(function (h) { if (!/<(?:html|body|head|div|title)/i.test(h)) throw 0; return h; });
  var reader = getText('https://r.jina.ai/' + url, 20000).then(parseReader);
  return Promise.all([html.catch(function () { return null; }), reader.catch(function () { return null; })]).then(function (r) {
    if (!r[0] && !r[1]) throw 0;
    var a = r[0] ? audit(r[0], url, DOMParser) : null;
    var text = (r[1] && r[1].text.length > 200 ? r[1].text : a ? a.text : (r[1] || {}).text || '').slice(0, 9000);
    return { url: url, title: (a && a.title) || (r[1] && r[1].title) || url, text: text, a: a };
  });
}
function auditCard(p) {
  var a = p.a, h = '<b>🌐 ' + esc(p.title) + '</b><br><a class="go" href="' + esc(p.url) + '" target="_blank" rel="noopener">' + esc(p.url) + ' ↗</a>';
  if (a) {
    var col = a.score >= 80 ? '#16a34a' : a.score >= 55 ? '#ca8a04' : '#dc2626';
    h += '<p style="margin:8px 0 4px">Website health score <span class="jw-sc" style="background:' + col + '">' + a.score + '/100</span></p><details' + (a.score < 80 ? ' open' : '') + '><summary>Show all ' + a.checks.length + ' checks</summary><table class="jw-tb">' +
      a.checks.map(function (c) { return '<tr><td>' + (c[1] ? '✅' : '⚠️') + ' ' + esc(c[0]) + '</td><td>' + esc(c[2]) + '</td></tr>'; }).join('') + '</table></details>';
  } else h += '<p class="jw-hint">Read the page text (detailed SEO check not available for this site).</p>';
  return h;
}
function readSite(url, question) {
  var m = dots(); feel('search');
  fetchSite(url).then(function (p) {
    PAGE = p; root.JW_page = p;
    m.innerHTML = auditCard(p);
    var row = el('div', { 'class': 'jw-row' });
    row.appendChild(bt('📝 Summarise', function () { ask(p, 'Summarise this website: what the business does, products/services, contact details.'); }));
    row.appendChild(bt('🔍 SEO & design tips', function () { ask(p, 'Give the 8 most important, specific improvements for this website (SEO, design, mobile, content, trust, conversion). Use the health check results.'); }));
    row.appendChild(bt('✨ Redesign this site', function () { add(esc('Redesign ' + p.url), 'u'); build('Redesign this website as a modern, fast, mobile-friendly one-page site. Keep the real business name, products, text and contact details from the content below.\n\nWEBSITE CONTENT:\n' + p.text.slice(0, 6000), null, p.title); }, true));
    m.appendChild(row); scroll();
    ask(p, question || 'What is this website about? Give a short summary and the top 5 specific improvements.', true);
  }).catch(function () {
    feel('sad', 2500);
    m.innerHTML = mdh('I could not open **' + url + '** just now. The site may be down, the address may be wrong, or it blocks readers. Check the link, or paste the page text / HTML here and I will review it.');
    var row = el('div', { 'class': 'jw-row' }); row.appendChild(bt('↗ Open the site', function () { window.open(url, '_blank'); })); m.appendChild(row);
    talk('I could not open that website just now.');
  });
}
function ask(p, question, silentUser) {
  if (!silentUser) add(esc(question), 'u');
  var m = dots();
  var a = p.a ? '\n\nHEALTH CHECK (' + p.a.score + '/100):\n' + p.a.checks.map(function (c) { return (c[1] ? 'OK ' : 'ISSUE ') + c[0] + ': ' + c[2]; }).join('\n') + '\nHeadings: ' + (p.a.h1.concat(p.a.h2)).join(' | ') : '';
  var user = question + '\n\nWEBSITE: ' + p.url + '\nTITLE: ' + p.title + a + '\n\nWEBSITE CONTENT (fetched live just now):\n' + p.text.slice(0, 7000);
  gen(sysNow(), history().concat([{ role: 'user', content: user }]), 2048, 45000).then(function (r) {
    m.innerHTML = mdh(r.t); footer(m, r.src + ' · read live from ' + p.url.replace(/^https?:\/\//, ''), r.t); scroll(); talk(r.t); feel('happy', 1800);
    try { remember(question + ' (' + p.url + ')', r.t); } catch (e) { }
  }).catch(function () {
    m.innerHTML = mdh('The AI is not reachable right now, but the health check above is complete. Add a Claude, ChatGPT or Gemini key in ⚙️ for written summaries and advice.'); feel('sad', 2000);
  });
}

/* ---------- 2) website builder ---------- */
var SITE = null; /* {html, name, opts (offline template), active} */
var BUILD_SYS = 'You are an expert web designer and front-end developer. Build complete, beautiful, modern, responsive, accessible websites. Rules: return ONE complete self-contained HTML file in a single ```html code block (<!DOCTYPE html> to </html>). Put all CSS in a <style> tag and any JavaScript in a <script> tag. Do not use external scripts, CSS frameworks or web fonts (use a system font stack). Images: use emoji, CSS gradients or inline SVG instead of external images. Include: sticky nav with smooth scrolling, hero with clear call-to-action, the requested sections, contact section with clickable tel:/mailto:/WhatsApp links when details are given, footer, mobile menu, good SEO tags (title, meta description, Open Graph, lang). Use real, specific, persuasive copy for the business (no lorem ipsum). After the code block write 2 or 3 short lines saying what you built and what the user can ask to change.';
function showSite(m, html, note, src) {
  SITE.html = html; SITE.active = true; root.JW_site = SITE;
  m.innerHTML = '<b>🌐 ' + esc(SITE.name) + '</b> <span class="jw-hint">(' + esc(src) + ')</span>' + (note ? mdh(note) : '');
  var fr = el('iframe', { 'class': 'jw-pv', sandbox: 'allow-scripts allow-forms allow-popups', title: 'Website preview' }); fr.srcdoc = html; m.appendChild(fr);
  var row = el('div', { 'class': 'jw-row' });
  row.appendChild(bt('⬇ Download .html', function () { var a = el('a', { href: URL.createObjectURL(new Blob([SITE.html], { type: 'text/html' })), download: slug(SITE.name) + '.html' }); document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 500); }, true));
  row.appendChild(bt('⛶ Full screen', function () { full(SITE.html); }));
  var cp = bt('📋 Copy code', function () { try { navigator.clipboard.writeText(SITE.html); cp.textContent = '✅ Copied'; } catch (e) { } }); row.appendChild(cp);
  row.appendChild(bt('</> View code', function () { var pre = m.querySelector('pre.jw-code'); if (pre) { pre.remove(); return; } pre = el('pre', { 'class': 'jt-code jw-code', 'data-lang': 'html' }, [el('code', { text: SITE.html })]); pre.style.cssText = 'max-height:320px;overflow:auto'; m.appendChild(pre); scroll(); }));
  row.appendChild(bt('✏️ Customise', function () { SITE.active = true; inp.value = 'website: '; inp.focus(); }));
  m.appendChild(row);
  var ch = el('div', { 'class': 'jw-row' });
  ['change colour to green', 'add a pricing section', 'add a contact form', 'add testimonials', 'make it dark mode', 'add WhatsApp button 9876543210'].forEach(function (t) { ch.appendChild(bt(t, function () { window.handle('website: ' + t); })); });
  m.appendChild(ch);
  m.appendChild(el('div', { 'class': 'jw-hint', text: 'Tell me any change in your own words (e.g. “change the name to Purlin Automation”, “add our address”, “make the buttons round”) and I will update this same website. Upload it free on Netlify Drop or GitHub Pages.' }));
  scroll(); feel('happy', 2000);
}
function full(html) {
  var d = el('dialog'); d.style.cssText = 'width:98vw;max-width:1400px;height:94vh;padding:8px;border:1px solid var(--bd);border-radius:14px;background:var(--card)';
  var fr = el('iframe', { sandbox: 'allow-scripts allow-forms allow-popups', title: 'Website full screen' }); fr.style.cssText = 'width:100%;height:calc(100% - 44px);border:0;border-radius:10px;background:#fff'; fr.srcdoc = html;
  var c = bt('✕ Close', function () { d.close(); d.remove(); }, true); d.appendChild(c); d.appendChild(fr); document.body.appendChild(d); d.showModal();
}
function build(brief, base, name) {
  var o = parseBrief(brief); if (name) o.name = String(name).slice(0, 48);
  SITE = { name: o.name, opts: o, html: '', active: true };
  var m = dots(); feel('think'); st.textContent = '🛠️ Building your website…';
  var msg = 'Build this website: ' + brief + (base ? '\n\nSTART FROM THIS HTML:\n' + base : '');
  gen(BUILD_SYS, [{ role: 'user', content: msg }], 8000, 120000).then(function (r) {
    st.textContent = '';
    var h = extractHTML(r.t); if (!h) throw 0;
    var t = (h.match(/<title>([^<]+)<\/title>/i) || [])[1]; if (t && !name) SITE.name = t.trim().slice(0, 48);
    SITE.opts = null;
    var note = r.t.replace(/```[\s\S]*?(```|$)/g, '').trim().slice(0, 600);
    showSite(m, h, note, r.src); talk('Your website is ready. Tap full screen to see it, or tell me what to change.');
  }).catch(function () {
    st.textContent = '';
    showSite(m, siteHTML(o), 'Built with the offline template (AI not reachable). Add your details by chatting, e.g. “phone 9876543210”, “email info@mysite.com”, “address Bhubaneswar, Odisha”, “add service Linear actuators”, “change colour to orange”. For a fully custom design, add an AI key in ⚙️.', 'offline template');
    talk('Your website is ready. Tell me what to change.');
  });
}
function editSite(req) {
  req = req.replace(/^(?:website|site)\s*[:,-]\s*/i, '');
  var m = dots(); feel('search');
  if (SITE.opts) { /* offline template: try quick local edits first */
    var o = JSON.parse(JSON.stringify(SITE.opts)), done = offlineEdit(o, req);
    if (done.length) { SITE.opts = o; SITE.name = o.name; showSite(m, siteHTML(o), '✅ Updated: ' + done.join(', ') + '.', 'offline template'); talk('Done. I updated the website.'); return; }
  }
  st.textContent = '🛠️ Updating your website…';
  gen(BUILD_SYS + ' You are editing an existing website: apply the requested change, keep everything else the same, and return the full updated file.', [{ role: 'user', content: 'CHANGE REQUEST: ' + req + '\n\nCURRENT WEBSITE HTML:\n```html\n' + SITE.html + '\n```' }], 8000, 120000).then(function (r) {
    st.textContent = ''; var h = extractHTML(r.t); if (!h) throw 0; SITE.opts = null;
    showSite(m, h, '✅ ' + (r.t.replace(/```[\s\S]*?(```|$)/g, '').trim().slice(0, 400) || 'Updated.'), r.src); talk('Done. I updated the website.');
  }).catch(function () {
    st.textContent = ''; feel('sad', 2000);
    m.innerHTML = mdh('I could not apply “' + req + '” right now: that change needs the AI and it is not reachable. Check your internet or add an AI key in ⚙️. Simple changes work offline: colour, dark mode, name, tagline, about text, phone, e-mail, address, add or remove a service.');
  });
}

/* ---------- front door ---------- */
var prevH = window.handle;
window.handle = function (raw) {
  var s = String(raw == null ? '' : raw).trim();
  if (!s || (window.JT_pending && window.JT_pending())) return prevH(raw);
  /* edit the website we just built */
  if (SITE && (/^(?:website|site)\s*[:,-]/i.test(s) || (SITE.active && isEdit(s) && !findURL(s)))) { add(esc(s), 'u'); return editSite(s); }
  /* build a website (a link inside means: redesign that site) */
  if (isBuild(s)) {
    var bu = findURL(s);
    if (bu) { add(esc(s), 'u'); var m0 = dots(); return fetchSite(bu).then(function (p) { m0.remove(); build(s + '\n\nWEBSITE CONTENT (fetched live from ' + bu + '):\n' + p.text.slice(0, 6000), null, p.title); }).catch(function () { m0.remove(); build(s); }); }
    add(esc(s), 'u'); return build(s);
  }
  if (SITE) SITE.active = false;
  /* open a link */
  var u = findURL(s);
  if (u && /^(?:open|launch|go to|goto|visit)\s+\S+$/i.test(s)) { add(esc(s), 'u'); return reply('Opening ' + esc(u.replace(/^https?:\/\//, '')) + '.', u); }
  /* any message with a website in it: read it live and answer */
  if (u) { add(esc(s), 'u'); var qn = s.replace(new RegExp(URL_RE.source, 'ig'), ' ').replace(/\s+/g, ' ').trim(); return readSite(u, qn.split(' ').length >= 3 ? s : ''); }
  /* follow-up questions about the website we just read */
  if (PAGE && /\b(?:this|that|the|my|our|your|same)\s+(?:web\s?site|site|page|web\s?page|home\s?page)\b|वेबसाइट|ವೆಬ್‌ಸೈಟ್|இணையதள|వెబ్‌సైట్/i.test(s)) { add(esc(s), 'u'); return ask(PAGE, s, true); }
  return prevH(raw);
};

/* ---------- help text ---------- */
(function () {
  var det = document.querySelectorAll('#panel details')[1];
  if (det) det.appendChild(el('div', { html: '<p><b>🌐 Websites:</b> type or say any link: <i>purlinautomation.in</i> · <i>check SEO of example.com</i> · <i>what does this site sell</i>. Lexi opens it live, scores it out of 100 and answers.</p><p><b>🛠️ Website builder:</b> make a website for my bakery with phone 9876543210 · then: change colour to green · add a pricing section · make it dark mode · website: add a photo gallery. Download the .html and upload it anywhere.</p>' }));
})();
})(typeof window !== 'undefined' ? window : globalThis);
