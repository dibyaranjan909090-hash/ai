/* Lexi lingo.js v23: automatic language for every message.
   - Detects the language of anything typed or spoken: 26 scripts (Hindi, Marathi, Nepali, Bengali, Assamese, Tamil, Telugu,
     Kannada, Malayalam, Gujarati, Punjabi, Odia, Urdu, Arabic, Persian, Pashto, Russian, Ukrainian, Chinese, Japanese, Korean...)
     plus Hinglish and 20 Latin-script languages (Spanish, French, German, Portuguese, Indonesian, Turkish, Swahili...).
   - Analyses each message: language, type (question / command / greeting / thanks / complaint / statement) and mood.
   - Automatically: tells the AI to reply in that language, switches the microphone to it, and after two messages in a row
     switches the whole app to it (installing the language pack if needed, with Undo).
   - Remembers which languages you use. Settings: Training Center > Languages > Automatic language. */
(function (root) {
'use strict';
var doc = root.document;
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
var CFG_K = 'lexi_lingo_cfg', ST_K = 'lexi_lingo';
var C = Object.assign({ reply: true, mic: true, app: true }, L(CFG_K, {}));
var ST = Object.assign({ recent: [], counts: {}, last: '' }, L(ST_K, {}));

/* ---------- detection ---------- */
/* common words per Latin-script language (each distinct word counts once) + tell-tale letters */
var LATIN = {
  es: 'el los las que y es por con para una del como pero muy está qué cómo dónde cuál cuánto gracias hola necesito quiero tengo la de en mi su al tienen tiene su sus usted nosotros garantía precio dirección también', esC: /[ñ¿¡]/g,
  fr: 'le les des est une du qui pas pour dans ce il elle vous nous je avec sur bonjour merci voudrais où la de et un mon quelle quel votre vos beaucoup suis êtes avez combien', frC: /[çœ]|[àâèêëîïôûù]/g,
  de: 'der die das und ist nicht ich du ein eine zu mit auf für dem von sie wir danke bitte brauche habe wo wie ihre ihr schön guten tag', deC: /[ßäöü]/g,
  pt: 'os não um uma com você eu muito obrigado obrigada olá também está são preciso quero o do da para meu seu sua qual endereço preço', ptC: /[ãõ]/g,
  it: 'il gli di che è non per della sono io tu grazie ciao anche questo vorrei ho dove qual vostro vostra indirizzo prezzo buongiorno',
  id: 'yang dan di ke dari ini itu dengan untuk tidak ada saya anda kami akan terima kasih apa bagaimana ingin membeli berapa harga alamat',
  ms: 'yang dan tidak saya anda kami akan terima kasih boleh sahaja kerana berapa harga',
  tr: 've bir bu için ile çok değil ben sen var teşekkür teşekkürler merhaba nasıl ne nedir nerede fiyat', trC: /[ğşı]/g,
  nl: 'het een en is van niet ik je dat die op zijn met dank graag wat waar',
  sw: 'na ya wa kwa ni katika hii yangu wewe mimi asante habari nini gani bei ngapi',
  pl: 'nie się na że jest do jak ale co dziękuję cześć czy ile', plC: /[ąęłżźść]/g,
  vi: 'và là của có không tôi bạn này cho với được', viC: /[ươđạảấầẩẫậắằẳẵặẹẻẽếềểễệịọỏốồổỗộớờởỡợụủứừửữự]/g,
  ro: 'și este nu pentru că sunt cu mulțumesc bună', roC: /[ăâîșț]/g,
  cs: 'je se na že to není jsem děkuji ahoj prosím', csC: /[ěřůč]/g,
  sv: 'och är det att inte jag du tack hej med', svC: /[åäö]/g,
  da: 'og er det at ikke jeg du tak hej med', daC: /[æøå]/g,
  fi: 'ja on ei se minä sinä kiitos hei että mitä',
  hu: 'és az egy nem hogy van köszönöm szia igen', huC: /[őű]/g,
  fil: 'ang ng sa mga ako ikaw salamat po hindi ano paano',
  en: 'the and is are was were you your to for of in on at it not with this that have has will what how why when where who which please thanks thank i my me can do does need want a an hello hi good morning ok okay yes no give tell show send call set price address'
};
/* one word is enough for these (greetings, thanks, very typical words) */
var STRONG = { gracias: 'es', hola: 'es', tienen: 'es', 'garantía': 'es', 'dirección': 'es', merci: 'fr', bonjour: 'fr', beaucoup: 'fr', votre: 'fr', quelle: 'fr', danke: 'de', 'schön': 'de', bitte: 'de', obrigado: 'pt', obrigada: 'pt', 'você': 'pt', 'endereço': 'pt', grazie: 'it', ciao: 'it', vostro: 'it', indirizzo: 'it', berapa: 'id', harga: 'id', terima: 'id', nedir: 'tr', 'teşekkürler': 'tr', merhaba: 'tr', asante: 'sw', habari: 'sw', 'dziękuję': 'pl', tack: 'sv', kiitos: 'fi', salamat: 'fil' };
var LATIN_CODES = Object.keys(LATIN).filter(function (k) { return typeof LATIN[k] === 'string'; });
var LSETS = {}; LATIN_CODES.forEach(function (k) { var o = {}; LATIN[k].split(' ').forEach(function (w) { o[w] = 1; }); LSETS[k] = o; });
function latinHits(code, uniq, s) { var n = 0, set = LSETS[code]; uniq.forEach(function (w) { if (set[w]) n++; }); var cr = LATIN[code + 'C']; if (cr) { cr.lastIndex = 0; n += Math.min(2, (s.match(cr) || []).length); } return n; }
/* Indian languages typed in English letters */
var ROMAN = {
  hi: /^(kal|subah|shaam|sham|raat|baje|jaldi|parso|kyaa|kya|kaise|kaisa|kaisi|kyun|kyon|kitna|kitne|kitni|kahan|kab|kaun|hai|hain|tha|thi|nahi|nahin|mujhe|mera|meri|mere|aap|aapka|aapki|tum|tumhara|karo|kardo|batao|bataiye|chahiye|accha|acha|theek|thik|haan|bhai|yaar|hoga|raha|rahi|wala|wali|abhi|aaj|bahut|bohot|samjhao|dikhao|lagao|bhejo|aayega|milega|kijiye|dijiye|ye|yeh|woh|matlab|kuch|sab|ho|ka|ki|ke|ko|se|mein|par|aur|lekin)$/,
  ta: /^(eppadi|epdi|irukeenga|irukinga|iruka|irukku|enna|ennada|illa|illai|sollunga|sollu|romba|nandri|vanakkam|venum|vendum|panna|pannunga|enakku|ungal|unga|seri|sari|theriyuma|theriyadhu)$/,
  te: /^(ela|unnaru|unnav|emiti|enti|cheppandi|cheppu|ledu|chala|bagunnara|bagunnava|naku|meeru|nenu|kavali|enduku|ekkada|evaru|cheyandi)$/,
  kn: /^(hegidira|hegiddiya|enu|yenu|illa|banni|gottilla|gottu|maadi|madi|nanna|ninna|nimma|beku|beda|yelli|yaaru|houdu|swalpa|sakkath)$/,
  bn: /^(kemon|acho|achen|ami|tumi|apni|kotha|bhalo|achi|korbo|korchi|kothay|kokhon|keno|chai|lagbe|dhonnobad|ki|na)$/,
  mr: /^(kasa|kasi|kase|aahe|ahe|kay|mala|tumhi|tumcha|majha|majhi|nahi|kuthe|kevha|sanga|kara|pahije|bara|dhanyavaad|ho)$/,
  ml: /^(sukhamano|sugamano|enthanu|enthaa|ningal|ningalude|alle|illa|venam|venda|evide|eppol|parayu|cheyyu|nanni|ente|enikku)$/,
  gu: /^(kem|cho|majama|majaama|shu|tame|tamaru|maru|hu|che|nathi|kya|kyare|joie|aavjo|aabhar)$/
};
var ROMAN_NAME = { hi: 'Hinglish', ta: 'Tanglish (Tamil in English letters)', te: 'Telugu in English letters', kn: 'Kannada in English letters', bn: 'Bengali in English letters', mr: 'Marathi in English letters', ml: 'Malayalam in English letters', gu: 'Gujarati in English letters' };
var MR = /(?:^|\s)(आहे|आहेत|नाही|काय|मला|तुम्ही|आणि|माझे|माझा|माझी|करा|होते|आम्ही|कसे|कुठे|सांगा|किंमत)(?=\s|$|[?।,.!])/g;
var NE = /तपाईं|तपाईँ|मलाई|छन्|हुन्छ|गर्नुहोस्|थियो|हुनुहुन्छ|छैन|(?:^|\s)छ(?=\s|$|[?।,.!])/g;
var UK = /(?:^|[\s,.!?])(яка|який|яке|ваша|ваш|що|це|дякую|привіт|адреса|будь ласка|скільки)(?=[\s,.!?]|$)/gi, RU = /(?:^|[\s,.!?])(какой|какая|какое|что|это|спасибо|привет|адрес|пожалуйста|сколько|вас|у)(?=[\s,.!?]|$)/gi;
function count(re, s) { re.lastIndex = 0; return (s.match(re) || []).length; }
var SCR = [['hi', /[ऀ-ॿ]/g], ['bn', /[ঀ-৿]/g], ['pa', /[਀-੿]/g], ['gu', /[઀-૿]/g], ['or', /[଀-୿]/g], ['ta', /[஀-௿]/g], ['te', /[ఀ-౿]/g], ['kn', /[ಀ-೿]/g], ['ml', /[ഀ-ൿ]/g], ['si', /[඀-෿]/g], ['th', /[฀-๿]/g], ['lo', /[຀-໿]/g], ['my', /[က-႟]/g], ['ka', /[Ⴀ-ჿ]/g], ['am', /[ሀ-፿]/g], ['km', /[ក-៿]/g], ['ar', /[؀-ۿݐ-ݿ]/g], ['he', /[֐-׿]/g], ['ru', /[Ѐ-ӿ]/g], ['el', /[Ͱ-Ͽ]/g], ['hy', /[԰-֏]/g], ['ja', /[぀-ヿ]/g], ['zh', /[一-鿿㐀-䶿]/g], ['ko', /[가-힯ᄀ-ᇿ]/g]];
/* the script used by most of the letters ("Translate नमस्ते to English" is English) */
function mainScript(s) {
  var latin = (s.match(/[A-Za-zÀ-ɏḀ-ỿ]/g) || []).length, best = '', bc = 0;
  SCR.forEach(function (x) { x[1].lastIndex = 0; var n = (s.match(x[1]) || []).length; if (n > bc) { bc = n; best = x[0]; } });
  if (best === 'zh' && /[぀-ヿ]/.test(s)) best = 'ja';
  if (!bc && !latin) return '';
  return bc > latin ? best : 'en';
}
function detect(text) {
  var s = String(text || '').replace(/```[\s\S]*?```/g, ' ').replace(/https?:\/\/\S+|www\.\S+/g, ' ').replace(/[\w.+-]+@[\w-]+\.[\w.]+/g, ' ').trim();
  var letters = (s.match(/\p{L}/gu) || []).length;
  if (letters < 2) return null;
  var sc = mainScript(s), code = sc, conf = 0.95, romanized = false;
  if (!sc) return null;
  if (sc === 'hi') { var mr = count(MR, s), ne = count(NE, s); if (mr > ne && mr > 0) code = 'mr'; else if (ne > 0) code = 'ne'; }
  else if (sc === 'bn') { if (/[ৰৱ]/.test(s)) code = 'as'; }
  else if (sc === 'ar') { if (/[ټډړښږ]/.test(s)) code = 'ps'; else if (/[ٹڈڑںےہ]/.test(s)) code = 'ur'; else if (/[پچژگیک]/.test(s)) code = 'fa'; }
  else if (sc === 'ru') { if (/[әғқңөұү]/i.test(s)) code = 'kk'; else if (/[іїєґ]/i.test(s) || count(UK, s) > count(RU, s)) code = 'uk'; else if (/[ђћџљњ]/i.test(s)) code = 'sr'; else if (/[ѓќѕ]/i.test(s)) code = 'mk'; else if (/ў/i.test(s)) code = 'be'; else if (/ъ/.test(s) && !/[ыэ]/.test(s)) code = 'bg'; }
  else if (sc === 'en') {
    var ws = (s.toLowerCase().match(/[\p{L}']+/gu) || []), uniq = ws.filter(function (w, i) { return ws.indexOf(w) === i; });
    var en = latinHits('en', uniq, s), best = 'en', bs = 0, strong = '';
    uniq.forEach(function (w) { if (STRONG[w] && !strong) strong = STRONG[w]; });
    LATIN_CODES.forEach(function (k) { if (k === 'en') return; var n = latinHits(k, uniq, s) + (strong === k ? 1 : 0); if (n > bs) { bs = n; best = k; } });
    var rbest = '', rn = 0;
    Object.keys(ROMAN).forEach(function (k) { var n = uniq.filter(function (w) { return ROMAN[k].test(w); }).length; if (n > rn) { rn = n; rbest = k; } });
    if (rn >= 2 && rn >= en) { code = rbest; romanized = true; conf = Math.min(0.95, 0.5 + rn * 0.12); }
    else if ((bs >= 2 && bs > en) || (strong && strong === best && en === 0)) { code = best; conf = Math.min(0.95, 0.45 + bs * 0.12); }
    else { code = 'en'; conf = en >= 2 ? 0.9 : en === 1 ? 0.7 : 0.5; }
  }
  return { code: code, romanized: romanized, conf: conf, name: nameOf(code, romanized), native: nativeOf(code), speech: speechOf(code) };
}
function nameOf(c, rom) { if (rom) return ROMAN_NAME[c] || c; try { var l = root.lexiI18n && root.lexiI18n.find(c); if (l) return l.name; } catch (e) { } try { var j = root.JTLANG.langBy(c); if (j) return j.name; } catch (e) { } return c; }
function nativeOf(c) { try { var l = root.lexiI18n && root.lexiI18n.find(c); if (l) return l.native; } catch (e) { } return nameOf(c); }
function speechOf(c) { try { var j = root.JTLANG.langBy(c === 'fil' ? 'filipino' : c); return j ? j.s : ''; } catch (e) { return ''; } }

/* ---------- analysis: what kind of message, which mood ---------- */
var Q_WORDS = /^(what|why|how|when|where|who|which|whose|can|could|would|should|is|are|do|does|did|will|kya|kyun|kaise|kab|kahan|kaun|kitna|क्या|क्यों|कैसे|कब|कहाँ|कौन|कितना|qué|cómo|por qué|dónde|quién|quoi|comment|pourquoi|où|qui|was|wie|warum|wo|wer)\b/i;
var CMD_WORDS = /^(?:please\s+)?(call|dial|send|set|open|play|show|remind|add|make|create|write|translate|install|switch|delete|cancel|start|stop|turn|search|find|tell|give|explain|calculate|convert)\b|\b(karo|kar do|kardo|lagao|bhejo|dikhao|chalao|batao|bataiye|लगाओ|भेजो|दिखाओ|चलाओ|करो|बताओ)\s*[.!]?$/i;
var GREET = /^(hi+|hello+|hey|namaste|namaskar|vanakkam|sat sri akal|salaam|assalam|hola|bonjour|hallo|ciao|olá|good (?:morning|afternoon|evening|night)|नमस्ते|नमस्कार|வணக்கம்|ನಮಸ್ಕಾರ|నమస్కారం|নমস্কার|السلام عليكم|こんにちは|你好|안녕하세요)\b/i;
var THANKS = /\b(thanks|thank you|thx|shukriya|dhanyavaad|dhanyawad|धन्यवाद|शुक्रिया|nandri|நன்றி|ಧನ್ಯವಾದ|ధన్యవాదాలు|ধন্যবাদ|gracias|merci|danke|obrigad[oa]|grazie|شكرا|ありがとう|谢谢|감사합니다)\b/i;
var POS = /\b(good|great|awesome|perfect|excellent|nice|love|happy|amazing|super|best|thanks|thank you|accha|acha|badhiya|mast|zabardast|shandaar|बढ़िया|अच्छा|शानदार|bueno|genial|excelente|bien|génial|super|toll|gut|ótimo|bom)\b|[👍😊😀😍❤️🙏🎉]/i;
var NEG = /\b(bad|wrong|worst|poor|angry|hate|problem|issue|error|broken|not working|doesn'?t work|failed|useless|slow|galat|bekar|bakwas|kharab|nahi chal|गलत|खराब|बेकार|समस्या|malo|mal|problema|mauvais|problème|schlecht|ruim)\b|[👎😡😠😞😢]/i;
function analyze(text) {
  var s = String(text || '').trim(), d = detect(s), type = 'statement';
  if (GREET.test(s)) type = 'greeting';
  else if (THANKS.test(s)) type = 'thanks';
  else if (/[?？؟]\s*$/.test(s) || Q_WORDS.test(s)) type = 'question';
  else if (CMD_WORDS.test(s)) type = 'command';
  if (NEG.test(s) && type !== 'thanks') type = type === 'question' ? 'question' : 'complaint';
  var p = POS.test(s), n = NEG.test(s), mood = p && !n ? 'positive' : n && !p ? 'negative' : 'neutral';
  return { lang: d, type: type, mood: mood, words: (s.match(/\p{L}+/gu) || []).length, t: Date.now() };
}

/* ---------- automatic actions ---------- */
function save() { S(ST_K, ST); }
function setMic(sp) {
  var sel = doc.getElementById('lang'); if (!sel || !sp || sel.value === sp) return;
  if (![].some.call(sel.options, function (o) { return o.value === sp; })) { var op = doc.createElement('option'); op.value = sp; op.textContent = nativeOf(sp.slice(0, 2)); sel.appendChild(op); }
  sel.value = sp; root.__lexiMicAuto = true; /* the app language is decided by autoApp, not by this mic change */
  try { sel.dispatchEvent(new Event('change', { bubbles: true })); } finally { root.__lexiMicAuto = false; }
}
var undoTo = null;
function toast(html, undo, label) {
  try {
    var d = doc.createElement('div'); d.setAttribute('role', 'status');
    d.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);top:12px;z-index:99999;background:#1d1a3a;color:#fff;padding:9px 14px;border-radius:999px;font:13px system-ui;box-shadow:0 4px 16px rgba(0,0,0,.3);max-width:92vw;display:flex;gap:10px;align-items:center';
    d.innerHTML = '<span></span>'; d.firstChild.textContent = html;
    if (undo) { var b = doc.createElement('button'); b.textContent = label || 'Undo'; b.style.cssText = 'border:0;background:#7c6cf0;color:#fff;border-radius:999px;padding:4px 10px;font:inherit;cursor:pointer'; b.onclick = function () { undo(); d.remove(); }; d.appendChild(b); }
    doc.body.appendChild(d); setTimeout(function () { d.remove(); }, 7000);
  } catch (e) { }
}
function autoApp(d) {
  var I = root.lexiI18n; if (!C.app || !I || !d) return;
  var cur = I.current(), r = ST.recent.slice(-3);
  var clear = function (x) { return x.split('|')[1] === '1'; };
  /* three clear messages in a row in another language (not romanized) */
  if (d.code !== 'en' && !d.romanized && r.length === 3 && r.every(function (x) { return x.split('|')[0] === d.code && clear(x); }) && cur !== d.code) {
    var from = cur, lang = I.find(d.code); if (!lang) return;
    if (I.packs()[d.code]) { I.use(d.code); toast('🌐 Lexi switched to ' + lang.native, function () { I.use(from); }); }
    else if (navigator.onLine && ST.asked !== d.code) {
      ST.asked = d.code; save();
      toast('🌐 Use Lexi in ' + lang.native + '?', function () { toast('⏳ Installing ' + lang.native + '…'); I.install(d.code).then(function () { toast('✅ Lexi is now in ' + lang.native); }).catch(function () { toast('Could not install ' + lang.name + ' now'); }); }, 'Install');
    }
    return;
  }
  /* three clear English messages in a row: back to English */
  if (d.code === 'en' && cur !== 'en' && r.length === 3 && r.every(function (x) { return x.split('|')[0] === 'en' && clear(x); })) {
    var was = cur; I.use('en'); toast('🌐 Lexi switched back to English', function () { I.use(was); });
  }
}
function remember(d) {
  ST.counts[d.name] = (ST.counts[d.name] || 0) + 1;
  var M = root.lexiMemory; if (!M) return;
  var tot = 0, top = null; Object.keys(ST.counts).forEach(function (k) { tot += ST.counts[k]; if (!top || ST.counts[k] > ST.counts[top]) top = k; });
  if (top && tot >= 5 && ST.counts[top] / tot >= 0.5) {
    var cur = M.get('lang_usual'); var txt = 'User usually writes in ' + top;
    if (cur !== txt) M.add(txt, 'lang_usual', 'chat');
  }
}
var lastA = null;
function onUser(raw) {
  var a = analyze(raw), d = a.lang; lastA = a;
  if (!d) return a;
  var words = (String(raw).match(/\p{L}+/gu) || []).length;
  ST.recent.push(d.code + (d.romanized ? '-Latn' : '') + '|' + (d.conf >= 0.85 && words >= 3 ? '1' : '0')); ST.recent = ST.recent.slice(-6); ST.last = d.code; save();
  if (d.conf >= 0.6) remember(d);
  if (C.mic && d.conf >= 0.85) { if (d.speech) setMic(d.speech); }
  try { autoApp(d); } catch (e) { }
  chip(raw, a);
  return a;
}
/* small note under the user's message: language, type, mood, and "Show in English" */
var TYPE = { question: '❓ question', command: '⚡ command', greeting: '👋 greeting', thanks: '🙏 thanks', complaint: '⚠️ complaint', statement: '💬 statement' };
var MOOD = { positive: '🙂', negative: '🙁', neutral: '' };
function chip(raw, a) {
  if (!a.lang) return;
  setTimeout(function () {
    try {
      var rows = doc.querySelectorAll('#log .row.u'), row = rows[rows.length - 1]; if (!row || row.querySelector('.lgc')) return;
      var m = row.querySelector('.m'); if (!m || m.textContent.trim().slice(0, 30) !== String(raw).trim().slice(0, 30)) return;
      var c = doc.createElement('div'); c.className = 'lgc';
      c.style.cssText = 'font-size:11.5px;opacity:.7;margin:3px 6px 0;text-align:right';
      var label = (a.lang.code === 'en' ? '' : '🌐 ' + a.lang.native + (a.lang.romanized ? ' (Roman script)' : '') + ' · ') + TYPE[a.type] + (MOOD[a.mood] ? ' ' + MOOD[a.mood] : '');
      c.appendChild(doc.createTextNode(label));
      if (a.lang.code !== 'en' || a.lang.romanized) {
        var b = doc.createElement('button'); b.textContent = 'Show in English'; b.style.cssText = 'margin-left:8px;border:0;background:none;color:inherit;text-decoration:underline;cursor:pointer;font:inherit';
        b.onclick = function () { b.disabled = true; b.textContent = '…'; translate(raw).then(function (t) { var sp = doc.createElement('span'); sp.setAttribute('data-noi18n', ''); sp.textContent = ' → “' + t + '”'; b.replaceWith(sp); }, function () { b.disabled = false; b.textContent = 'Show in English'; }); };
        c.appendChild(b);
      }
      row.appendChild(c);
    } catch (e) { }
  }, 60);
}
function translate(text) {
  var I = root.lexiI18n;
  if (I && I.rawAI) return I.rawAI('Translate the user\'s text into natural English. Reply with the translation only.', String(text).slice(0, 1500), 20000).then(function (t) { return String(t).trim().replace(/^["“]|["”]$/g, ''); });
  return Promise.reject();
}
/* instruction added to each AI request (by train.js) */
function instruction(q) {
  if (!C.reply) return '';
  var d = detect(String(q || '').slice(0, 600)); if (!d) return '';
  if (d.romanized) return d.code === 'hi' ? 'The user writes Hinglish (Hindi in Roman letters). Reply in natural Hinglish using Roman letters.' : 'The user writes ' + d.name + '. Reply the same way: ' + nameOf(d.code) + ' written in English (Roman) letters.';
  if (d.code === 'en') return d.conf >= 0.7 ? 'The user writes in English. Reply in English, even if other instructions mention another language.' : 'Reply in the same language as the user\'s message.';
  return 'The user writes in ' + d.name + ' (' + d.native + '). Reply only in ' + d.name + ' using its native script, even if other instructions mention another language. Use correct grammar and everyday words a native speaker would use; for technical terms with no common ' + d.name + ' word, keep the English term in brackets. Check the answer is accurate before writing it in ' + d.name + '.';
}

root.lexiLingo = { detect: detect, analyze: analyze, onUser: onUser, instruction: instruction, translate: translate, last: function () { return lastA; },
  stats: function () { return ST; }, cfg: function (k, v) { if (arguments.length > 1) { C[k] = v; S(CFG_K, C); } return C[k]; }, resetStats: function () { ST = { recent: [], counts: {}, last: '' }; save(); } };
/* read-aloud picks the right voice for more Latin-script languages too */
try { if (root.JTLANG) { var old = root.JTLANG.latinLang; root.JTLANG.latinLang = function (t) { var d = detect(t); return d && d.code !== 'en' && !d.romanized && d.conf >= 0.6 && /^[a-z]+$/.test(d.code) && scriptOf(t) === 'en' ? d.code : (old ? old(t) : 'en'); }; } } catch (e) { }
})(window);
