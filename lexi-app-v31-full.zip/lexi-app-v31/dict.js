/* Lexi dict.js v21: understands words and their meanings.
   - 147,478 English words and phrases offline (Princeton WordNet 3.1, dict/*.json, loaded only when needed).
   - Online: pronunciation and audio (Free Dictionary API) and words in thousands of languages (Wiktionary).
   - Understands word forms (ran -> run, children -> child, happier -> happy) and suggests spellings ("serendipty" -> serendipity).
   - Ask in English, Hinglish or Hindi: "meaning of serendipity", "define resilient", "what does ubiquitous mean",
     "serendipity ka matlab", "सपना का मतलब", "synonyms of happy", "opposite of strong", "pronounce quinoa",
     "spell necessary", "word of the day".
   - Every word you look up goes into "My words" with spaced-repetition practice (Training Center > Words). */
(function (root) {
'use strict';
var doc = root.document;
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
var of = root.fetch.bind(root);
var POSN = { n: 'noun', v: 'verb', a: 'adjective', r: 'adverb' };

/* ---------- word forms ---------- */
var IRR = {};
('went:go gone:go goes:go ran:run children:child mice:mouse men:man women:woman feet:foot teeth:tooth geese:goose people:person ' +
 'better:good best:good worse:bad worst:bad bought:buy brought:bring thought:think taught:teach caught:catch saw:see seen:see did:do done:do ' +
 'made:make took:take taken:take gave:give given:give ate:eat eaten:eat wrote:write written:write spoke:speak spoken:speak broke:break broken:break ' +
 'chose:choose chosen:choose drove:drive driven:drive flew:fly flown:fly knew:know known:know grew:grow grown:grow threw:throw thrown:throw ' +
 'began:begin begun:begin sang:sing sung:sing swam:swim drank:drink drunk:drink felt:feel kept:keep left:leave lost:lose meant:mean met:meet ' +
 'paid:pay said:say sold:sell sent:send sat:sit slept:sleep spent:spend stood:stand told:tell understood:understand won:win held:hold built:build ' +
 'found:find had:have has:have was:be were:be is:be are:be am:be been:be fell:fall fallen:fall forgot:forget forgotten:forget got:get gotten:get ' +
 'hid:hide hidden:hide led:lead rode:ride ridden:ride rose:rise risen:rise shook:shake shaken:shake stole:steal stolen:steal struck:strike wore:wear worn:wear ' +
 'woke:wake woken:wake lives:life knives:knife wives:wife leaves:leaf halves:half wolves:wolf shelves:shelf criteria:criterion phenomena:phenomenon ' +
 'analyses:analysis bases:basis crises:crisis theses:thesis indices:index matrices:matrix vertices:vertex oxen:ox lay:lie lain:lie bit:bite bitten:bite ' +
 'blew:blow blown:blow drew:draw drawn:draw fought:fight hung:hang heard:hear hurt:hurt laid:lay lent:lend let:let lit:light made:make ' +
 'read:read rang:ring rung:ring ran:run sought:seek shot:shoot shut:shut sang:sing sank:sink sunk:sink slid:slide spun:spin spread:spread ' +
 'sprang:spring sprung:spring stuck:stick stung:sting swept:sweep swore:swear sworn:swear tore:tear torn:tear wept:weep wound:wind withdrew:withdraw')
  .split(' ').forEach(function (p) { var x = p.split(':'); if (x[1]) IRR[x[0]] = x[1]; });
var RULES = [['ies', 'y'], ['ves', 'f'], ['sses', 'ss'], ['xes', 'x'], ['zes', 'z'], ['ches', 'ch'], ['shes', 'sh'], ['men', 'man'], ['es', 'e'], ['es', ''], ['s', ''],
  ['ied', 'y'], ['ed', 'e'], ['ed', ''], ['ying', 'ie'], ['ing', 'e'], ['ing', ''], ['ier', 'y'], ['iest', 'y'], ['er', 'e'], ['er', ''], ['est', 'e'], ['est', ''],
  ['ily', 'y'], ['ly', ''], ['ness', ''], ['iness', 'y']];
function forms(w) {
  var out = [w];
  if (IRR[w]) out.push(IRR[w]);
  RULES.forEach(function (r) { if (w.length > r[0].length + 1 && w.slice(-r[0].length) === r[0]) out.push(w.slice(0, -r[0].length) + r[1]); });
  /* doubled consonant: running -> run, stopped -> stop, bigger -> big */
  var m = /^(.*?)([bdgklmnprt])\2(?:ing|ed|er|est)$/.exec(w); if (m) out.push(m[1] + m[2]);
  return out.filter(function (x, i) { return x && out.indexOf(x) === i; });
}
function norm(w) { return String(w || '').toLowerCase().replace(/[“”"«»]/g, '').replace(/[‘’]/g, "'").replace(/^[\s'.,!?;:()-]+|[\s.,!?;:()]+$/g, '').replace(/\s+/g, ' ').trim(); }
function shardKey(w) { return (w + '_').slice(0, 2).replace(/[^a-z]/g, '_'); }

/* ---------- offline dictionary ---------- */
var SH = {}, SHQ = [];
function shard(k) {
  if (SH[k]) return SH[k];
  var p = of('dict/' + k + '.json').then(function (r) { if (!r.ok) throw r.status; return r.json(); }).catch(function () { delete SH[k]; return {}; });
  SH[k] = p; SHQ.push(k); if (SHQ.length > 40) delete SH[SHQ.shift()];
  return p;
}
function offline(word) {
  var w = norm(word), fs = forms(w);
  var keys = {}; fs.forEach(function (f) { keys[shardKey(f)] = 1; });
  return Promise.all(Object.keys(keys).map(shard)).then(function (arr) {
    var all = {}; arr.forEach(function (d) { for (var k in d) all[k] = d[k]; });
    for (var i = 0; i < fs.length; i++) {
      var f = fs[i], hit = all[f] || all[f.replace(/-/g, ' ')] || all[f.replace(/ /g, '-')];
      if (hit) return { word: w, base: f, senses: hit, src: 'WordNet (offline)' };
    }
    return null;
  });
}
/* edit distance with swaps (Damerau, optimal string alignment), stops early above max */
function edit(a, b, max) {
  if (Math.abs(a.length - b.length) > max) return max + 1;
  var d0 = null, d1 = [], i, j;
  for (j = 0; j <= b.length; j++) d1[j] = j;
  for (i = 1; i <= a.length; i++) {
    var d2 = [i], best = i;
    for (j = 1; j <= b.length; j++) {
      var v = Math.min(d1[j] + 1, d2[j - 1] + 1, d1[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (d0 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) v = Math.min(v, d0[j - 2] + 1);
      d2[j] = v; if (v < best) best = v;
    }
    if (best > max) return max + 1;
    d0 = d1; d1 = d2;
  }
  return d1[b.length];
}
function suggest(word) {
  var w = norm(word); if (w.length < 3) return Promise.resolve([]);
  var max = w.length > 7 ? 2 : 1, ks = {};
  ks[shardKey(w)] = 1; ks[shardKey(w[0] + (w[2] || ''))] = 1; ks[shardKey(w[1] + w[0] + w.slice(2))] = 1;   /* also catch a typo in the 2nd letter */
  return Promise.all(Object.keys(ks).map(shard)).then(function (arr) {
    var c = [];
    arr.forEach(function (d) { for (var k in d) { if (k.indexOf(' ') >= 0 && w.indexOf(' ') < 0) continue; var e = edit(w, k, max); if (e <= max) c.push([e, k]); } });
    c.sort(function (a, b) { return a[0] - b[0] || a[1].length - b[1].length; });
    return c.slice(0, 4).map(function (x) { return x[1]; }).filter(function (x, i, a) { return a.indexOf(x) === i; });
  });
}

/* ---------- online: pronunciation (English) and every language (Wiktionary) ---------- */
function timed(u, ms) { var c = new AbortController(); setTimeout(function () { try { c.abort(); } catch (e) { } }, ms || 6000); return of(u, { signal: c.signal }); }
function freeDict(w) {
  return timed('https://api.dictionaryapi.dev/api/v2/entries/en/' + encodeURIComponent(w)).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) {
    var e = j && j[0]; if (!e) throw 0;
    var ph = e.phonetic || ((e.phonetics || []).filter(function (p) { return p.text; })[0] || {}).text || '';
    var au = ((e.phonetics || []).filter(function (p) { return p.audio; })[0] || {}).audio || '';
    var senses = [];
    (e.meanings || []).forEach(function (m) {
      var pos = ({ noun: 'n', verb: 'v', adjective: 'a', adverb: 'r' })[m.partOfSpeech] || m.partOfSpeech;
      (m.definitions || []).slice(0, 3).forEach(function (d, i) { senses.push([pos, d.definition, d.example || '', (d.synonyms || []).concat(i ? [] : m.synonyms || []).slice(0, 6), (d.antonyms || []).concat(i ? [] : m.antonyms || []).slice(0, 4)]); });
    });
    return { word: e.word, base: e.word, senses: senses, phonetic: ph, audio: au, src: 'Free Dictionary (Wiktionary, CC BY-SA)' };
  });
}
function strip(h) { var d = doc.createElement('div'); d.innerHTML = String(h || ''); return (d.textContent || '').replace(/\s+/g, ' ').trim(); }
function wiktionary(w) {
  return timed('https://en.wiktionary.org/api/rest_v1/page/definition/' + encodeURIComponent(w.replace(/ /g, '_')), 7000).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) {
    var senses = [], langs = [];
    Object.keys(j || {}).forEach(function (code) {
      (j[code] || []).forEach(function (g) {
        if (langs.indexOf(g.language) < 0) langs.push(g.language);
        (g.definitions || []).slice(0, 3).forEach(function (d) {
          var def = strip(d.definition); if (!def) return;
          var ex = d.parsedExamples && d.parsedExamples[0] ? strip(d.parsedExamples[0].example) : (d.examples && d.examples[0] ? strip(d.examples[0]) : '');
          senses.push([String(g.partOfSpeech || '').toLowerCase(), def, ex, [], [], g.language]);
        });
      });
    });
    if (!senses.length) throw 0;
    return { word: w, base: w, senses: senses.slice(0, 10), langs: langs, src: 'Wiktionary (CC BY-SA)' };
  });
}
function lookup(word) {
  var w = norm(word);
  var latin = /^[a-z][a-z' .-]*$/.test(w);
  if (!latin) return w.indexOf(' ') < 0 ? wiktionary(w).catch(function () { return null; }) : Promise.resolve(null);
  return offline(w).then(function (r) {
    if (r || w.indexOf(' ') >= 0) return r;   /* a phrase that is not in the dictionary goes to the AI */
    return freeDict(w).catch(function () { return wiktionary(w); }).catch(function () { return null; });
  });
}

/* ---------- my words (spaced repetition) ---------- */
var KW = 'lexi_words', DAYS = [0, 1, 3, 7, 16, 35];
function words() { return L(KW, []); }
function saveWord(entry, quiet) {
  if (!entry || !entry.senses || !entry.senses.length) return;
  var ws = words(), w = entry.base || entry.word, x = ws.filter(function (y) { return y.w === w; })[0];
  var def = entry.senses[0][1];
  if (x) { if (!quiet) x.n = (x.n || 1) + 1; x.t = Date.now(); x.d = def; if (entry.senses[0][2]) x.ex = entry.senses[0][2]; }
  else ws.push({ w: w, d: def, p: entry.senses[0][0], ex: entry.senses[0][2] || '', t: Date.now(), n: 1, box: 0, due: Date.now() });
  S(KW, ws.slice(-1000));
}
function review(w, knew) {
  var ws = words(), x = ws.filter(function (y) { return y.w === w; })[0]; if (!x) return;
  x.box = knew ? Math.min(5, (x.box || 0) + 1) : 0; x.due = Date.now() + DAYS[x.box] * 864e5; S(KW, ws);
}
function removeWord(w) { S(KW, words().filter(function (y) { return y.w !== w; })); }
function due() { var now = Date.now(); return words().filter(function (y) { return (y.due || 0) <= now; }); }
var WOTD = 'resilient meticulous pragmatic tenacious candid diligent eloquent frugal gregarious ambiguous benevolent cogent concise diligence empathy feasible ' +
  'gratitude hypothesis impeccable innovate integrity leverage lucid mitigate negotiate nuance optimize paradigm persevere plausible precise prudent ' +
  'robust scalable serendipity sustainable synergy tangible transparent ubiquitous versatile viable vigilant warranty tolerance torque friction ' +
  'calibrate tolerance actuate durable efficient endurance inertia leverage momentum precision redundant reliable throughput velocity abundant ' +
  'accomplish adapt advocate allocate anticipate articulate assess authentic autonomy catalyst coherent collaborate commitment comprehensive ' +
  'consensus constructive credible curious decisive deliberate dependable discreet dynamic elaborate emphasize endeavor enhance essential ' +
  'evaluate evident exemplary facilitate flexible fluent foster genuine humble implement incentive inevitable initiative insight inspire ' +
  'intuitive keen meticulous modest motivate notable objective optimistic patience persuade proactive proficient prosper punctual rational ' +
  'reconcile refine relevant resourceful revenue rigorous spontaneous strategic streamline substantial thorough thrive versatile wholesome zeal';
function wordOfDay() { var a = WOTD.split(' ').filter(function (x, i, s) { return s.indexOf(x) === i; }), d = new Date(), n = d.getFullYear() * 400 + d.getMonth() * 31 + d.getDate(); return a[n % a.length]; }

/* ---------- understand the request ---------- */
var Q = '["\'“‘]?';
var QE = '["\'”’]?';
var PAT = [
  [new RegExp('^(?:what(?:\'s| is) the |tell me the |give me the )?(?:meaning|meanings|definition|defination|meaning and example) of (?:the )?(?:word )?' + Q + '(.+?)' + QE + '\\s*\\??$', 'i'), 'define'],
  [new RegExp('^(?:define|meaning|definition|dictionary|dict|meaning of)\\s*:?\\s+' + Q + '(.+?)' + QE + '\\s*\\??$', 'i'), 'define'],
  [new RegExp('^what does (?:the word )?' + Q + '(.+?)' + QE + ' mean\\s*\\??$', 'i'), 'define'],
  [new RegExp('^' + Q + '(.+?)' + QE + '\\s+(?:ka|ki|ke|ko)\\s+(?:matlab|mtlb|arth|meaning|definition)(?:\\s+(?:kya|kya hai|kya hota hai|hota hai|batao|bataiye|bata do|bolo|hai|hindi mein|hindi me|samjhao))*\\s*\\??$', 'i'), 'define', 'Hinglish'],
  [new RegExp('^' + Q + '(.+?)' + QE + '\\s+(?:का|की|के)\\s+(?:मतलब|अर्थ|मीनिंग)(?:\\s+(?:क्या|है|होता|बताओ|बताइए|बताइये|हिंदी|में))*\\s*[?।]?$'), 'define', 'Hindi'],
  [new RegExp('^(?:synonyms?|similar words?|other words?|another word|words? like) (?:of|for)?\\s*' + Q + '(.+?)' + QE + '\\s*\\??$', 'i'), 'syn'],
  [new RegExp('^(?:antonyms?|opposites?|opposite words?) (?:of|for)?\\s*' + Q + '(.+?)' + QE + '\\s*\\??$', 'i'), 'ant'],
  [new RegExp('^what is the opposite of ' + Q + '(.+?)' + QE + '\\s*\\??$', 'i'), 'ant'],
  [new RegExp('^(?:how (?:do (?:you|i)|to) )?(?:pronounce|pronunciation of)\\s+' + Q + '([a-z][a-z\' -]{0,40}?)' + QE + '\\s*\\??$', 'i'), 'pron'],
  [new RegExp('^(?:how (?:do (?:you|i)|to) )?spell\\s+' + Q + '(.+?)' + QE + '\\s*\\??$|^spelling of\\s+' + Q + '(.+?)' + QE + '\\s*\\??$', 'i'), 'spell'],
  [/^(?:word of the day|today'?s word|aaj ka word|new word|teach me a (?:new )?word)\s*[.!?]?$/i, 'wotd']
];
function parse(raw) {
  var t = String(raw || '').trim(); if (!t || t.length > 90 || /\n/.test(t)) return null;
  for (var i = 0; i < PAT.length; i++) {
    var m = PAT[i][0].exec(t); if (!m) continue;
    if (PAT[i][1] === 'wotd') return { mode: 'wotd', word: wordOfDay() };
    var orig = String(m[1] || m[2] || '').trim().replace(/^["'“‘]|["'”’]$/g, '');
    var w = norm(orig); if (!w || w.split(' ').length > 3 || w.length > 40) return null;
    /* PWM, SMPS, IP65, 24V, HTTP 404: abbreviations and codes are explained by the AI, not the dictionary */
    if (/\d/.test(w) || (/^[A-Z]{2,6}s?$/.test(orig) && PAT[i][1] !== 'spell')) return null;
    if (/^(this|that|it|the|my|your|our|these|those)\b/.test(w)) return null;   /* "what does this error mean" */
    if (/^(life|it|this|that|these|those|my name|your name|you|me|us|love)$/.test(w) && PAT[i][1] === 'define') return null; /* "meaning of life" is a question, not a word */
    return { mode: PAT[i][1], word: w, lang: PAT[i][2] || '' };
  }
  return null;
}

/* ---------- show the answer ---------- */
var CSS = '.lxd .lxd-h{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}.lxd .lxd-w{font-size:1.3em}.lxd .lxd-ph{opacity:.7}' +
  '.lxd .lxd-pos{margin:10px 0 2px;font-size:.8em;font-weight:700;letter-spacing:.06em;text-transform:uppercase;opacity:.65}' +
  '.lxd ol{margin:2px 0 6px 20px;padding:0}.lxd li{margin:3px 0}.lxd li i{display:block;opacity:.75;font-size:.92em}' +
  '.lxd .lxd-c{display:inline-block;margin:2px 4px 2px 0;padding:2px 9px;border-radius:999px;border:1px solid rgba(124,108,240,.45);background:transparent;color:inherit;font:inherit;font-size:.9em;cursor:pointer}' +
  '.lxd .lxd-b{margin:8px 6px 0 0;padding:5px 10px;border-radius:10px;border:1px solid rgba(124,108,240,.45);background:transparent;color:inherit;font:inherit;font-size:.9em;cursor:pointer}' +
  '.lxd .lxd-s{font-size:.8em;opacity:.6;margin-top:6px}.lxd .lxd-say{border:0;background:none;font-size:1.1em;cursor:pointer;padding:0 4px}';
function css() { if (!doc.getElementById('lxdcss')) { var s = doc.createElement('style'); s.id = 'lxdcss'; s.textContent = CSS; doc.head.appendChild(s); } }
function sayWord(w, audio) {
  if (audio) { try { var a = new Audio(audio); a.play().catch(function () { tts(w); }); return; } catch (e) { } }
  tts(w);
}
function tts(w) { try { speechSynthesis.cancel(); var u = new SpeechSynthesisUtterance(w); u.rate = 0.85; var v = speechSynthesis.getVoices().filter(function (x) { return /^en/i.test(x.lang); })[0]; if (v) u.voice = v; speechSynthesis.speak(u); } catch (e) { } }
function render(e, mode) {
  var groups = [], gi = {}, syn = [], ant = [];
  e.senses.forEach(function (s) {
    var key = (s[5] ? s[5] + ' · ' : '') + (POSN[s[0]] || s[0] || '');
    if (gi[key] == null) { gi[key] = groups.length; groups.push({ k: key, d: [] }); }
    if (groups[gi[key]].d.length < 4) groups[gi[key]].d.push(s);
    (s[3] || []).forEach(function (x) { if (syn.indexOf(x) < 0 && x !== e.base) syn.push(x); });
    (s[4] || []).forEach(function (x) { if (ant.indexOf(x) < 0) ant.push(x); });
  });
  (e.syn || []).forEach(function (x) { if (syn.indexOf(x) < 0 && x !== e.base) syn.push(x); });
  (e.ant || []).forEach(function (x) { if (ant.indexOf(x) < 0) ant.push(x); });
  var h = '<div class="lxd"><div class="lxd-h"><b class="lxd-w">' + esc(e.base || e.word) + '</b>' + (e.phonetic ? '<span class="lxd-ph">' + esc(e.phonetic) + '</span>' : '<span class="lxd-ph"></span>') +
    '<button class="lxd-say" aria-label="Pronounce ' + esc(e.base || e.word) + '">🔊</button></div>';
  if (e.base && e.word && e.base !== e.word) h += '<div class="lxd-s" style="margin:0">“' + esc(e.word) + '” is a form of “' + esc(e.base) + '”.</div>';
  if (mode === 'syn' || mode === 'ant') {
    var list = mode === 'syn' ? syn : ant;
    h += '<div class="lxd-pos">' + (mode === 'syn' ? 'Synonyms (similar words)' : 'Antonyms (opposite words)') + '</div>' + (list.length ? list.slice(0, 16).map(function (x) { return '<button class="lxd-c" data-w="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') : '<div>None listed in the dictionary. Tap “Explain simply” and the AI will suggest some.</div>');
    h += '<div class="lxd-pos">Meaning</div><div>' + esc(e.senses[0][1]) + '</div>';
  } else {
    groups.forEach(function (g) { h += '<div class="lxd-pos">' + esc(g.k) + '</div><ol>' + g.d.map(function (s) { return '<li>' + esc(s[1]) + (s[2] ? '<i>“' + esc(s[2]) + '”</i>' : '') + '</li>'; }).join('') + '</ol>'; });
    if (syn.length) h += '<div><b>Similar:</b> ' + syn.slice(0, 8).map(function (x) { return '<button class="lxd-c" data-w="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div>';
    if (ant.length) h += '<div><b>Opposite:</b> ' + ant.slice(0, 5).map(function (x) { return '<button class="lxd-c" data-w="' + esc(x) + '">' + esc(x) + '</button>'; }).join('') + '</div>';
  }
  h += '<div><button class="lxd-b" data-a="explain">💡 Explain simply</button><button class="lxd-b" data-a="hindi">🇮🇳 Hindi meaning</button><button class="lxd-b" data-a="sentence">✍️ Use in sentences</button></div>' +
    '<div class="lxd-s">Source: ' + esc(e.src) + ' · saved to My words</div></div>';
  return h;
}
function ai(prompt) {
  try { root.add(esc(prompt), 'u'); } catch (e) { }
  if (typeof root.smart === 'function') root.smart(prompt); else if (typeof root.handle === 'function') { root.__JT_skip = true; try { root.handle(prompt); } finally { root.__JT_skip = false; } }
}
function wire(el, e) {
  var w = e.base || e.word;
  var sb = el.querySelector('.lxd-say'); if (sb) sb.onclick = function () { sayWord(w, e.audio); };
  el.querySelectorAll('.lxd-c').forEach(function (b) { b.onclick = function () { ask('meaning of ' + b.dataset.w); }; });
  el.querySelectorAll('.lxd-b').forEach(function (b) {
    b.onclick = function () {
      var a = b.dataset.a;
      if (a === 'explain') ai('Explain the word "' + w + '" in very simple words, with two everyday examples.');
      if (a === 'hindi') ai('What is the meaning of the English word "' + w + '" in Hindi? Give the Hindi word(s), a simple Hindi explanation and one example sentence in Hindi and English.');
      if (a === 'sentence') ai('Write five short, natural example sentences using the word "' + w + '", each showing a different use.');
    };
  });
  /* add pronunciation and audio from the online dictionary without waiting for it */
  if (!e.phonetic && /^[a-z][a-z' -]*$/i.test(w)) freeDict(w).then(function (f) { var ph = el.querySelector('.lxd-ph'); if (ph && f.phonetic) ph.textContent = f.phonetic; e.audio = f.audio; }).catch(function () { });
}
function ask(text) { if (typeof root.handle === 'function') root.handle(text); }
function langLabel() { try { var J = root.JTLANG, c = (root.CFG && root.CFG.lang) || 'en-IN', l = J && J.langBy(c.slice(0, 2)); return l && l.c !== 'en' ? l.name : ''; } catch (e) { return ''; } }

/* answer a parsed request; fallback() hands it to the normal AI flow */
function answer(p, raw, fallback) {
  css();
  var wait = root.add('<span class="dots"><i></i><i></i><i></i></span>', 'a');
  function drop() { try { (wait.closest && wait.closest('.row') || wait).remove(); } catch (e) { } }
  function done(html, speech) { try { wait.innerHTML = html; } catch (e) { } try { root.log.scrollTop = root.log.scrollHeight; } catch (e) { } if (speech) try { root.speak(speech); } catch (e) { } }
  if (p.mode === 'spell') {
    return offline(p.word).then(function (r) {
      if (r && r.base === p.word) return done('<b>' + esc(p.word) + '</b> is spelled <b>' + esc(p.word.toUpperCase().split('').join(' - ')) + '</b>. ✅', p.word + ' is spelled ' + p.word.toUpperCase().split('').join(', '));
      return suggest(p.word).then(function (s) {
        if (!s.length) { drop(); return fallback(); }
        done('Did you mean <b>' + esc(s[0]) + '</b>? It is spelled <b>' + esc(s[0].toUpperCase().split('').join(' - ')) + '</b>.' + (s.length > 1 ? '<br><small>Other close words: ' + s.slice(1).map(esc).join(', ') + '</small>' : ''), s[0] + ' is spelled ' + s[0].toUpperCase().split('').join(', '));
      });
    });
  }
  return lookup(p.word).then(function (e) {
    if (!e) {
      return (/^[a-z]{5,}$/.test(p.word) ? suggest(p.word) : Promise.resolve([])).then(function (s) {
        if (s.length && /^[a-z]/.test(p.word)) {
          done('I could not find “' + esc(p.word) + '”. Did you mean: ' + s.map(function (x) { return '<button class="lxd-c" data-w="' + esc(x) + '">' + esc(x) + '</button>'; }).join(' ') + '<div class="lxd lxd-s">Or ask the AI: <button class="lxd-b" data-ai="1">💡 Explain “' + esc(p.word) + '”</button></div>');
          wait.querySelectorAll('.lxd-c').forEach(function (b) { b.onclick = function () { ask('meaning of ' + b.dataset.w); }; });
          var ab = wait.querySelector('[data-ai]'); if (ab) ab.onclick = function () { ai('What does "' + p.word + '" mean? Explain simply with an example.'); };
          return;
        }
        drop(); fallback();
      });
    }
    saveWord(e);
    if (p.mode === 'pron') { sayWord(e.base || e.word, e.audio); }
    var head = p.mode === 'wotd' ? '<div class="lxd lxd-s" style="margin:0 0 4px">📅 Word of the day</div>' : '';
    done(head + render(e, p.mode), p.mode === 'pron' ? '' : (e.base || e.word) + ': ' + e.senses[0][1]);
    wire(wait, e);
    if (/^WordNet/.test(e.src) && /^[a-z][a-z' -]*$/.test(e.base || e.word)) upgrade(wait, e, p.mode, head);
    var ll = p.lang || langLabel();
    if (ll && p.mode === 'define') ai('Explain the meaning of the word "' + (e.base || e.word) + '" in ' + ll + ' in two or three simple sentences, with one example.');
  });
}

/* merge the online dictionary (common senses first, real examples, pronunciation) with WordNet's similar/opposite words */
function upgrade(el, e, mode, head) {
  freeDict(e.base || e.word).then(function (f) {
    if (!f || !f.senses.length || !el.isConnected) return;
    var syn = [], ant = [];
    e.senses.forEach(function (s) { (s[3] || []).forEach(function (x) { if (syn.indexOf(x) < 0) syn.push(x); }); (s[4] || []).forEach(function (x) { if (ant.indexOf(x) < 0) ant.push(x); }); });
    var m = { word: e.word, base: e.base || e.word, senses: f.senses.slice(0, 8), phonetic: f.phonetic, audio: f.audio, src: 'Free Dictionary (Wiktionary) + WordNet', syn: syn, ant: ant };
    el.innerHTML = head + render(m, mode); wire(el, m);
    saveWord(m, true);
  }).catch(function () { });
}
root.lexiDict = { parse: parse, answer: answer, lookup: lookup, offline: offline, suggest: suggest, forms: forms, words: words, review: review, removeWord: removeWord, due: due, saveWord: saveWord, wordOfDay: wordOfDay, render: render, wire: wire, css: css, sayWord: sayWord, shardKey: shardKey, edit: edit };
})(window);
