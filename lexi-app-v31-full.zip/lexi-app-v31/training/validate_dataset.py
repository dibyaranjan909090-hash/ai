#!/usr/bin/env python3
"""Check (and optionally merge and split) Lexi training files.

Usage:
  python3 validate_dataset.py training-examples.jsonl
  python3 validate_dataset.py training-examples.jsonl lexi-training-2026-11-20.jsonl --out all.jsonl
  python3 validate_dataset.py all.jsonl --split 0.15        # writes lexi-train.jsonl + lexi-test.jsonl

Each line must be: {"messages": [{"role": "system"|"user"|"assistant", "content": "..."}, ...]}
with at least one user message and the assistant message last.
"""
import argparse, json, random, sys

def load(path):
    rows, errors = [], []
    with open(path, encoding='utf-8') as f:
        for n, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                errors.append(f'{path}:{n}: not valid JSON ({e.msg})')
                continue
            msgs = obj.get('messages') if isinstance(obj, dict) else None
            if not isinstance(msgs, list) or len(msgs) < 2:
                errors.append(f'{path}:{n}: needs a "messages" list with at least 2 messages')
                continue
            bad = [m for m in msgs if not isinstance(m, dict) or m.get('role') not in ('system', 'user', 'assistant')
                   or not isinstance(m.get('content'), str) or not m['content'].strip()]
            if bad:
                errors.append(f'{path}:{n}: every message needs role system/user/assistant and non-empty text')
                continue
            if msgs[-1]['role'] != 'assistant':
                errors.append(f'{path}:{n}: the last message must be the assistant answer')
                continue
            if not any(m['role'] == 'user' for m in msgs):
                errors.append(f'{path}:{n}: no user message')
                continue
            rows.append({'messages': msgs})
    return rows, errors

def key(row):
    return '\n'.join(m['content'].strip().lower() for m in row['messages'] if m['role'] == 'user')

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('files', nargs='+')
    ap.add_argument('--out', help='write the merged, de-duplicated examples here')
    ap.add_argument('--split', type=float, help='fraction kept aside as a test set, e.g. 0.15')
    ap.add_argument('--seed', type=int, default=7)
    a = ap.parse_args()

    rows, errors = [], []
    for p in a.files:
        r, e = load(p)
        rows += r
        errors += e
    seen, uniq, dups = set(), [], 0
    for r in rows:
        k = key(r)
        if k in seen:
            dups += 1
            continue
        seen.add(k)
        uniq.append(r)

    short = sum(1 for r in uniq if len(r['messages'][-1]['content']) < 15)
    words = sum(len(m['content'].split()) for r in uniq for m in r['messages'])
    print(f'Examples: {len(uniq)} valid, {dups} duplicates removed, {len(errors)} errors')
    print(f'Approx. words: {words}  (about {int(words * 1.4)} tokens)')
    if short:
        print(f'Warning: {short} assistant answers are very short; complete answers train better.')
    if len(uniq) < 100:
        print('Tip: aim for 100 to 300 good examples before fine-tuning.')
    for e in errors[:30]:
        print('  ' + e)
    if errors:
        print('Fix the errors above, then run again.')

    if a.out:
        with open(a.out, 'w', encoding='utf-8') as f:
            for r in uniq:
                f.write(json.dumps(r, ensure_ascii=False) + '\n')
        print(f'Wrote {a.out}')
    if a.split:
        random.Random(a.seed).shuffle(uniq)
        n = max(1, round(len(uniq) * a.split))
        for name, part in (('lexi-test.jsonl', uniq[:n]), ('lexi-train.jsonl', uniq[n:])):
            with open(name, 'w', encoding='utf-8') as f:
                for r in part:
                    f.write(json.dumps(r, ensure_ascii=False) + '\n')
            print(f'Wrote {name} ({len(part)} examples)')
    sys.exit(1 if errors else 0)

if __name__ == '__main__':
    main()
