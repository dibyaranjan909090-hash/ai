# Lexi fine-tuning on Google Colab (free T4 GPU) with Unsloth + LoRA.
#
# How to use:
#   1. Open https://colab.research.google.com, New notebook, Runtime > Change runtime type > T4 GPU.
#   2. Paste each "# %%" block below into its own cell, in order, and run it.
#   3. When asked, upload lexi-train.jsonl and lexi-test.jsonl
#      (Training Center > Dataset > "Download train + test split", or validate_dataset.py --split 0.15).
#   4. At the end, download lexi-model.zip: it holds the .gguf model and a Modelfile for Ollama.
#
# Model names and library options change over time. If a cell fails, check Unsloth's current
# notebooks (unsloth.ai/docs) for the latest model name and settings.

# %% 1. Install (takes 2-4 minutes)
# !pip install -q unsloth
# (In Colab, remove the "# " in front of the line above, or run: %pip install -q unsloth)

# %% 2. Settings
BASE_MODEL = "unsloth/Llama-3.2-3B-Instruct"   # small, fits the free GPU, understands Hindi. Try "unsloth/Llama-3.1-8B-Instruct" on a bigger GPU.
CHAT_TEMPLATE = "llama-3.1"                     # must match the base model family
MAX_LEN = 2048
EPOCHS = 3                                      # 2-3 for 100-300 examples; fewer for large sets
LEARNING_RATE = 2e-4
OUT_NAME = "lexi"

# %% 3. Upload the dataset files
import os
if not (os.path.exists("lexi-train.jsonl") and os.path.exists("lexi-test.jsonl")):
    try:
        from google.colab import files
        files.upload()   # choose lexi-train.jsonl and lexi-test.jsonl
    except ImportError:
        raise SystemExit("Put lexi-train.jsonl and lexi-test.jsonl next to this script.")

# %% 4. Load the base model in 4-bit and add LoRA adapters
from unsloth import FastLanguageModel
model, tokenizer = FastLanguageModel.from_pretrained(model_name=BASE_MODEL, max_seq_length=MAX_LEN, load_in_4bit=True)
model = FastLanguageModel.get_peft_model(
    model, r=16, lora_alpha=16, lora_dropout=0, bias="none",
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    use_gradient_checkpointing="unsloth", random_state=3407)

# %% 5. Turn each conversation into training text with the model's chat template
from unsloth.chat_templates import get_chat_template
from datasets import load_dataset
tokenizer = get_chat_template(tokenizer, chat_template=CHAT_TEMPLATE)
ds = load_dataset("json", data_files={"train": "lexi-train.jsonl", "test": "lexi-test.jsonl"})
def to_text(batch):
    return {"text": [tokenizer.apply_chat_template(m, tokenize=False, add_generation_prompt=False) for m in batch["messages"]]}
ds = ds.map(to_text, batched=True)
print(ds["train"][0]["text"][:600])

# %% 6. Train (only the assistant answers are learned)
import inspect
from trl import SFTTrainer, SFTConfig
cfg = dict(dataset_text_field="text", per_device_train_batch_size=2, gradient_accumulation_steps=4,
           warmup_steps=5, num_train_epochs=EPOCHS, learning_rate=LEARNING_RATE, logging_steps=5,
           optim="adamw_8bit", weight_decay=0.01, lr_scheduler_type="linear", seed=3407,
           output_dir="outputs", report_to="none")
params = inspect.signature(SFTConfig).parameters
cfg["max_seq_length" if "max_seq_length" in params else "max_length"] = MAX_LEN
args = SFTConfig(**cfg)
try:
    trainer = SFTTrainer(model=model, tokenizer=tokenizer, train_dataset=ds["train"], eval_dataset=ds["test"], args=args)
except TypeError:   # newer TRL renamed tokenizer -> processing_class
    trainer = SFTTrainer(model=model, processing_class=tokenizer, train_dataset=ds["train"], eval_dataset=ds["test"], args=args)
from unsloth.chat_templates import train_on_responses_only
trainer = train_on_responses_only(trainer,
    instruction_part="<|start_header_id|>user<|end_header_id|>\n\n",
    response_part="<|start_header_id|>assistant<|end_header_id|>\n\n")
stats = trainer.train()
print(stats)
print("Test loss:", trainer.evaluate().get("eval_loss"))

# %% 7. Try it on the held-back test questions
import json
FastLanguageModel.for_inference(model)
with open("lexi-test.jsonl", encoding="utf-8") as f:
    tests = [json.loads(l) for l in f if l.strip()][:8]
for t in tests:
    msgs = [m for m in t["messages"] if m["role"] != "assistant"]
    ids = tokenizer.apply_chat_template(msgs, add_generation_prompt=True, return_tensors="pt").to("cuda")
    out = model.generate(input_ids=ids, max_new_tokens=300, temperature=0.3, do_sample=True)
    print("Q:", msgs[-1]["content"])
    print("Lexi:", tokenizer.decode(out[0][ids.shape[1]:], skip_special_tokens=True).strip())
    print("Expected:", t["messages"][-1]["content"][:300], "\n" + "-" * 60)

# %% 8. Save: LoRA adapter + GGUF file + Modelfile for Ollama, then zip for download
model.save_pretrained(OUT_NAME + "_lora")
tokenizer.save_pretrained(OUT_NAME + "_lora")
model.save_pretrained_gguf(OUT_NAME + "_gguf", tokenizer, quantization_method="q4_k_m")   # takes 5-10 minutes
import glob, shutil
gguf = sorted(glob.glob(OUT_NAME + "_gguf*/*.gguf") + glob.glob("*.gguf"), key=os.path.getmtime)[-1]
os.makedirs("lexi-model", exist_ok=True)
shutil.copy(gguf, "lexi-model/lexi.gguf")
modelfile = getattr(tokenizer, "_ollama_modelfile", None)
if modelfile:
    modelfile = "\n".join(("FROM ./lexi.gguf" if l.startswith("FROM") else l) for l in modelfile.splitlines())
else:   # fallback: Llama 3 chat format
    modelfile = ('FROM ./lexi.gguf\n'
                 'TEMPLATE """{{ if .System }}<|start_header_id|>system<|end_header_id|>\n\n{{ .System }}<|eot_id|>{{ end }}'
                 '{{ range .Messages }}<|start_header_id|>{{ .Role }}<|end_header_id|>\n\n{{ .Content }}<|eot_id|>{{ end }}'
                 '<|start_header_id|>assistant<|end_header_id|>\n\n"""\n'
                 'PARAMETER stop "<|eot_id|>"\nPARAMETER temperature 0.4\n')
with open("lexi-model/Modelfile", "w") as f:
    f.write(modelfile)
shutil.make_archive("lexi-model", "zip", "lexi-model")
print("Ready: lexi-model.zip")
try:
    from google.colab import files
    files.download("lexi-model.zip")
except ImportError:
    pass

# %% 9. On your office computer (not in Colab)
#   unzip lexi-model.zip && cd lexi-model
#   ollama create lexi -f Modelfile
#   ollama run lexi "What does Purlin Automation make?"
# Then in Lexi: + > Training Center > My model > address http://localhost:11434/v1/chat/completions, model "lexi", Test connection.
