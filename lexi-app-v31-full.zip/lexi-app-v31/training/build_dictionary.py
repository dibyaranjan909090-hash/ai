#!/usr/bin/env python3
"""Build Lexi's offline English dictionary (dict/*.json) from Princeton WordNet 3.1.

Usage:
  npm pack wordnet-db && tar xzf wordnet-db-*.tgz      # gets package/dict/{index,data}.{noun,verb,adj,adv}
  python3 build_dictionary.py package/dict ../dict --senses 4

Output: one small JSON file per first two letters (ab.json, ac.json ... '_' for anything else), about 45 KB on average; dict/index.json lists them.
Each word maps to up to N senses, most common first: [part of speech, definition, example, synonyms, antonyms].
WordNet 3.1 is (c) Princeton University; see dict/WORDNET-LICENSE.txt.
"""
import argparse, json, os, re
from collections import defaultdict

POS = {'noun': 'n', 'verb': 'v', 'adj': 'a', 'adv': 'r'}
NAME = {'n': 'noun', 'v': 'verb', 'a': 'adjective', 's': 'adjective', 'r': 'adverb'}

def read_data(path):
    syn = {}
    with open(path, encoding='utf-8', errors='ignore') as f:
        for line in f:
            if line.startswith('  '):
                continue
            head, _, gloss = line.partition(' | ')
            p = head.split()
            off, sstype, wcnt = p[0], p[2], int(p[3], 16)
            words = [p[4 + 2 * i].replace('_', ' ') for i in range(wcnt)]
            words = [re.sub(r'\([a-z]+\)$', '', w) for w in words]   # "galore(ip)" -> "galore"
            i = 4 + 2 * wcnt
            pcnt = int(p[i]); i += 1
            ants = []
            for _ in range(pcnt):
                sym, toff, tpos, st = p[i], p[i + 1], p[i + 2], p[i + 3]
                i += 4
                if sym == '!':
                    ants.append((int(st[:2], 16), toff, tpos, int(st[2:], 16)))
            gloss = gloss.strip()
            parts = [g.strip() for g in gloss.split(';')]
            defs = [g for g in parts if not g.startswith('"')]
            exs = [g.strip('" ') for g in parts if g.startswith('"')]
            syn[off] = {'t': sstype, 'w': words, 'd': '; '.join(defs).strip(), 'e': exs[0] if exs else '', 'ants': ants}
    return syn

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('src'); ap.add_argument('out'); ap.add_argument('--senses', type=int, default=4)
    a = ap.parse_args()
    data = {}
    for pos, c in POS.items():
        data[c] = read_data(os.path.join(a.src, 'data.' + pos))
    words = defaultdict(list)
    order = defaultdict(list)
    for pos, c in POS.items():
        with open(os.path.join(a.src, 'index.' + pos), encoding='utf-8', errors='ignore') as f:
            for line in f:
                if line.startswith('  '):
                    continue
                p = line.split()
                lemma = p[0].replace('_', ' ')
                scnt, pcnt = int(p[2]), int(p[3])
                tagged = int(p[4 + pcnt + 1])          # how often this word was seen in this part of speech
                offs = p[4 + pcnt + 2:][:scnt]
                order[lemma].append((tagged, c))
                for off in offs[:a.senses]:
                    s = data[c].get(off)
                    if not s:
                        continue
                    synonyms = [w for w in s['w'] if w.lower() != lemma][:6]
                    ants = []
                    for src, toff, tpos, tw in s['ants']:
                        if src and s['w'][src - 1].lower() != lemma:
                            continue
                        t = data['a' if tpos == 's' else tpos].get(toff)
                        if t and tw:
                            ants.append(t['w'][tw - 1])
                    words[lemma].append([NAME[s['t']][0] if s['t'] != 's' else 'a', s['d'], s['e'], synonyms, ants[:4], c])
    shards = defaultdict(dict)
    for w, senses in words.items():
        # most used part of speech first (by WordNet's tagged-sense counts), then its senses in frequency order
        rank = {c: -t for t, c in order[w]}
        senses.sort(key=lambda x: rank.get(x[5], 0))
        k = ''.join(ch if 'a' <= ch <= 'z' else '_' for ch in (w + '_')[:2])
        shards[k][w] = [x[:5] for x in senses[:a.senses + 2]]
    os.makedirs(a.out, exist_ok=True)
    total = 0
    for k, d in sorted(shards.items()):
        path = os.path.join(a.out, k + '.json')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, separators=(',', ':'))
        total += os.path.getsize(path)
    with open(os.path.join(a.out, 'index.json'), 'w') as f:
        json.dump({'source': 'Princeton WordNet 3.1', 'words': len(words), 'files': sorted(shards)}, f)
    print(f'{len(words):,} words in {len(shards)} files, {total / 1e6:.1f} MB')

if __name__ == '__main__':
    main()
