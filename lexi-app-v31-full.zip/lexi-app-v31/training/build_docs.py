#!/usr/bin/env python3
"""Turn a folder of company documents into docs.json for Lexi (Level 5 knowledge for every user).

Usage:
  python3 build_docs.py my-docs/                  # writes docs.json here
  python3 build_docs.py my-docs/ --out ../docs.json --keep ../docs.json

Reads: .txt .md .csv .json .html .htm .docx .pptx and .pdf (PDF needs: pip install pypdf).
Put docs.json in the Lexi folder (next to index.html) and upload the folder again.
Everything in docs.json is public on your site: leave out private prices and customer data.
"""
import argparse, html, json, pathlib, re, sys, zipfile

def xml_text(xml, para_tag):
    xml = re.sub(r'</%s>' % re.escape(para_tag), '\n', xml)
    xml = re.sub(r'<w:tab/>', ' ', xml)
    return html.unescape(re.sub(r'<[^>]+>', '', xml))

def read_docx(p):
    with zipfile.ZipFile(p) as z:
        return xml_text(z.read('word/document.xml').decode('utf-8'), 'w:p')

def read_pptx(p):
    with zipfile.ZipFile(p) as z:
        names = sorted((n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)),
                       key=lambda n: int(re.sub(r'\D', '', n)))
        return '\n\n'.join(f'Slide {i}\n' + xml_text(z.read(n).decode('utf-8'), 'a:p') for i, n in enumerate(names, 1))

def read_pdf(p):
    try:
        from pypdf import PdfReader
    except ImportError:
        raise RuntimeError('install pypdf first: pip install pypdf')
    pages = [f'Page {i}\n' + (pg.extract_text() or '') for i, pg in enumerate(PdfReader(str(p)).pages, 1)]
    return '\n\n'.join(pages)

def read_html(p):
    t = p.read_text(encoding='utf-8', errors='ignore')
    t = re.sub(r'(?is)<(script|style|noscript|svg).*?</\1>', ' ', t)
    t = re.sub(r'(?i)<(br|/p|/div|/li|/h\d|/tr)[^>]*>', '\n', t)
    return html.unescape(re.sub(r'<[^>]+>', ' ', t))

READERS = {'.docx': read_docx, '.pptx': read_pptx, '.pdf': read_pdf, '.html': read_html, '.htm': read_html}
TEXT = {'.txt', '.md', '.csv', '.json', '.xml'}

def clean(t):
    t = t.replace('\r', '').replace('\x00', '')
    t = re.sub(r'[ \t]+', ' ', t)
    return re.sub(r'\n{3,}', '\n\n', t).strip()

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('folder')
    ap.add_argument('--out', default='docs.json')
    ap.add_argument('--keep', help='an existing docs.json whose documents should be kept')
    a = ap.parse_args()

    docs = []
    if a.keep and pathlib.Path(a.keep).exists():
        old = json.loads(pathlib.Path(a.keep).read_text(encoding='utf-8'))
        docs = old.get('docs', old) if isinstance(old, dict) else old
        print(f'Kept {len(docs)} documents from {a.keep}')
    names = {d['name'] for d in docs}

    folder = pathlib.Path(a.folder)
    if not folder.is_dir():
        sys.exit(f'{folder} is not a folder')
    added = 0
    for p in sorted(folder.rglob('*')):
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        try:
            if ext in READERS:
                text = READERS[ext](p)
            elif ext in TEXT:
                text = p.read_text(encoding='utf-8', errors='ignore')
            else:
                print(f'  skipped {p.name} (unsupported type; save as PDF, .docx or .txt)')
                continue
        except Exception as e:  # noqa: BLE001 - report and continue with the next file
            print(f'  skipped {p.name}: {e}')
            continue
        text = clean(text)
        if len(text) < 20:
            print(f'  skipped {p.name}: no readable text (scanned PDFs need OCR first)')
            continue
        name = str(p.relative_to(folder))
        docs = [d for d in docs if d['name'] != name]
        docs.append({'name': name, 'text': text})
        added += 1
        print(f'  added {name}: {len(text):,} characters')

    pathlib.Path(a.out).write_text(json.dumps({'version': 1, 'docs': docs}, ensure_ascii=False, indent=1), encoding='utf-8')
    print(f'Wrote {a.out}: {len(docs)} documents ({added} new or updated)')

if __name__ == '__main__':
    main()
