# Train Lexi, step by step

Lexi gets its answers from an AI model (Claude, ChatGPT, Gemini, Groq, OpenRouter, the free AI or your own model).
Training Lexi means giving that model your rules, your company facts and your documents, measuring the result,
and, at the end, optionally training a model of your own. Everything below runs from **+ → 🎓 Training Center** in the app.

Work through the levels in order. Change one thing, run the test, keep the change only if the score goes up or stays the same.

| Level | Where | What it does | Time |
|---|---|---|---|
| 1 Rules and corrections | Training Center → Rules | Rules apply to every answer. Corrections are found by the meaning of a question, so all of them are used. | 10 min |
| 2 Company profile | Training Center → Company | Address, website, phone, products, protection, warranty. Lexi answers company questions from these facts and says "the team will confirm" for anything missing. | 20 min |
| 3 Instant commands | Works in chat | Actuator calculator and company answers, offline, in under a second. | ready |
| 4 Tests | Training Center → Tests | 50 questions (maths, actuator, company, honesty, safety, code, Hindi/Hinglish, logic) plus your own. Score history is kept. | 5 min per run |
| 5 Knowledge base | Training Center → Knowledge | PDFs, Word, PowerPoint, text, web pages. Lexi searches them before every AI answer and sends only the best 3 to 5 passages. | 1 hour |
| 6 Dataset and own model | Training Center → Review answers, Dataset, My model | Collect good and corrected answers, export JSONL, fine-tune in Colab, run with Ollama. | 1 to 3 days |

## Level 1: rules and corrections
1. Open **Rules**. Add short, testable rules, one idea each, for example:
   - Give actuator answers in mm, N, mm/s, V and A.
   - Keep a 20 to 30% safety margin on load in every recommendation.
   - Reply in Hinglish when I write in Hinglish.
2. When Lexi answers wrongly, add a **correction**: the exact question and the right answer.
3. **Download rules + corrections** now and then as a backup (they live in this browser).

## Level 2: company profile
1. Open **Company** and fill every field you are sure about (phone, e-mail, hours, products and specs, warranty).
   Leave a field empty when unsure: Lexi then says the team will confirm.
2. Press **Save**. To give every phone the same facts, press **Download company-profile.json**,
   put it in the Lexi folder (replace the old file) and upload the folder again.

## Level 3: instant commands (no setup)
Type or say:
- `travel time 200 mm stroke at 10 mm/s`
- `speed lead 4 mm 3000 rpm`
- `power 6000 N at 5 mm/s efficiency 40%`
- `force torque 2 Nm lead 4 mm efficiency 35%`
- `duty cycle 30 s on 90 s off`
- `load 4000 N with 25% safety margin`
- `what is your company address`, `purlin website`, `your phone number`
- `open training center`

## Level 4: tests
1. Open **Tests**, choose the AI and **Full test**, press **Run test**. Write down the score (it is also saved in the history).
2. Add your own tests: a question plus words the right answer must contain (for example "IP65").
3. Re-run after every change. Tip: in **Review answers**, every fix can also become a test.

## Level 5: knowledge base
1. Open **Knowledge** and add your catalog, datasheets, manuals, FAQs, wiring guides and good past replies.
   Scanned PDFs have no text: use the original PDF or paste the text.
2. On **Overview**, type a question in "Try the training" to see which passages Lexi will send.
3. To give every user the same knowledge: **Download docs.json**, put it in the Lexi folder and upload the folder.
   Or build it on a computer: `python3 build_docs.py my-docs/ --out ../docs.json --keep ../docs.json`
4. Never put private prices, customer data, passwords or keys in shared files: everything in the folder is public.

## Level 6: dataset and your own model
1. **Review answers** shows recent chats. Press **✅ Good answer** for good ones and **✏️ Fix answer** for wrong ones.
2. **Dataset** shows the total (105 built-in examples plus yours). Aim for 100 to 300 high-quality examples.
   Press **Download train + test split** to get `lexi-train.jsonl` and `lexi-test.jsonl`.
3. Check the files: `python3 validate_dataset.py lexi-train.jsonl lexi-test.jsonl`
4. Train in Google Colab (free T4 GPU): follow `train_lexi_colab.py` cell by cell. Download `lexi-model.zip` at the end.
5. On an office computer: install Ollama, unzip, then `ollama create lexi -f Modelfile`.
   Allow the Lexi site to reach it, for example on Windows `setx OLLAMA_ORIGINS "https://your-lexi-site.netlify.app"`, then restart Ollama.
6. In Lexi: **My model** → address `http://localhost:11434/v1/chat/completions`, model `lexi` → **Test connection** → tick "Use my trained model first".
7. Run the full test on your model and on your usual AI. Keep your model only if it scores higher.

Notes:
- OpenAI's fine-tuning service is closed to new users (existing users until 6 January 2027). Google Vertex AI also offers paid Gemini tuning.
- A phone reaches the office model only on the same network; https sites may block plain http addresses, so use Lexi on that computer or an https tunnel.
- Fine-tuning teaches style and habits. Facts (specs, prices) belong in Levels 2 and 5, where they are easy to update.

## Installing languages (v22)
- Training Center → Languages → search → Install. It needs internet once (about a minute); after that the language works offline.
- Press ↻ next to an installed language after updating Lexi, so new texts get translated too.
- Run Tests → Languages after installing, to check how well your AI answers in that language.

## Memory and languages (v20)
- **Memory:** Training Center → Memory. Lexi saves facts you state (“my name is…”, “I live in…”, “remember that…”) and, with an AI, learns facts from any language in the background. Turn either off there. Download the list as a backup; never store secrets (they are blocked anyway).
- **Languages:** Training Center → Languages. Run the language test after changing AI provider: some free models are weaker in Odia, Malayalam or Kannada. Gemini and Claude are usually strongest across Indian languages.
- **Voice:** pick the language in the box at the top before speaking; the phone listens in one language at a time. Install missing read-aloud voices in the phone's Settings → Text-to-speech.
- **For fine-tuning:** add examples in the languages your customers use (Review answers → Good answer works in any language).

## Files in this folder
| File | Use |
|---|---|
| `validate_dataset.py` | Check, merge, de-duplicate and split JSONL training files |
| `build_docs.py` | Turn a folder of PDFs, Word, PowerPoint and text files into docs.json |
| `train_lexi_colab.py` | Fine-tune a small open model with Unsloth + LoRA in Colab and export it for Ollama |
