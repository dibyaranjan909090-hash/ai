/* Lexi create.js
   1) Image creator: "create an image of a red sports car" or "draw a cat astronaut".
      30 styles, 5 sizes, 1/2/4 variations at once, ✨ Improve prompt, "same idea in 6 styles",
      Download, ✏️ Edit the picture with words, 🔁 more like this.
      Free (Pollinations Flux / Turbo); with your Gemini or OpenAI key you can pick those models too.
   2) Accurate technical drawings (vector SVG, true proportions, dimensions):
      - "linear actuator drawing stroke 200 mm" → built-in parametric drawing, works offline.
      - "flange drawing OD 150 ID 60 PCD 110 6 holes 12 thick" → built-in parametric drawing.
      - anything else ("technical drawing of a shaft 200 long Ø30 with keyway") → AI writes the SVG drawing.
   3) Your photo, many looks: "show all styles" puts every on-device style side by side;
      "4 AI styles" redraws it four ways; free-form changes ("make his hoodie red") use
      Gemini / OpenAI image editing when a key is added.
   Loaded last. */
(function (root) {
'use strict';

/* ======================= PURE LOGIC ======================= */
var STYLES = [
  ['Auto', ''], ['Photo realistic', 'ultra realistic photograph, natural light, sharp focus, high detail, 50mm lens'], ['Cinematic', 'cinematic film still, dramatic lighting, shallow depth of field, color graded'],
  ['3D render', '3D render, Pixar style, soft global illumination, octane render'], ['Anime', 'anime illustration, clean line art, vibrant colours, detailed'], ['Ghibli', 'Studio Ghibli style, hand-painted, soft watercolour background, warm light'],
  ['Cartoon', 'cartoon illustration, bold outlines, flat bright colours'], ['Comic', 'comic book art, bold ink, halftone shading'], ['Oil painting', 'classical oil painting, visible brush strokes, rich colours'],
  ['Watercolour', 'delicate watercolour painting, soft edges, paper texture'], ['Pencil sketch', 'detailed graphite pencil sketch, cross hatching, white paper'], ['Digital art', 'digital painting, concept art, highly detailed, trending on artstation'],
  ['Pixel art', '16-bit pixel art, crisp pixels, limited palette'], ['Cyberpunk', 'cyberpunk, neon pink and teal lights, rainy night, futuristic'], ['Fantasy', 'epic fantasy art, magical lighting, highly detailed'],
  ['Minimal flat', 'minimalist flat vector illustration, simple shapes, pastel colours'], ['Logo', 'professional vector logo, simple, clean, centered, white background, no mockup'], ['App icon', 'app icon, rounded square, glossy, centered, simple'],
  ['Sticker', 'die-cut sticker, white border, vector, cute'], ['Poster', 'graphic poster design, bold typography area, striking composition'], ['Product photo', 'professional studio product photography, white seamless background, softbox lighting, high detail'],
  ['Engineering render', 'photorealistic industrial CAD render, accurate mechanical proportions, brushed aluminium and steel, studio lighting, white background'], ['Exploded view', 'technical exploded view illustration of the mechanism, every component separated along its axis, labelled-style layout, clean white background, isometric'],
  ['Cutaway', 'technical cutaway section view showing internal mechanism, gears, lead screw and motor, clean illustration'], ['Blueprint', 'technical blueprint drawing, white lines on blue grid paper, orthographic views, dimension lines'],
  ['Isometric', 'isometric 3D illustration, clean, soft shadows'], ['Line art', 'clean black line art, no shading, white background'], ['Low poly', 'low poly 3D art, faceted geometry'], ['Vintage photo', 'vintage 1970s film photo, grain, faded colours'], ['Neon', 'neon glow art on black background']
];
var SIZES = [['Square', 1024, 1024], ['Wide 16:9', 1344, 768], ['Tall 9:16', 768, 1344], ['4:3', 1152, 864], ['3:4', 864, 1152]];
var MECH = /\b(?:actuator|motor|gear(?:box)?|lead ?screw|ball ?screw|spindle|piston|cylinder|bearing|shaft|flange|bracket|bolt|nut|spring|pulley|coupling|valve|pump|engine|robot|robotic|machine|mechanism|cnc|turbine|chassis|clevis|housing|pcb|circuit board|enclosure)\b/i;
function pickStyle(text) { var s = String(text || '').toLowerCase(), i; for (i = 1; i < STYLES.length; i++) if (s.indexOf(STYLES[i][0].toLowerCase()) >= 0) return i; if (/\brealistic|photo\b/.test(s)) return 1; if (/\bexploded\b/.test(s)) return 22; if (/\bcutaway|cross.?section|inside\b/.test(s)) return 23; if (/\bblueprint\b/.test(s)) return 24; if (/\blogo\b/.test(s)) return 16; return MECH.test(s) ? 21 : 0; }
function pickSize(text) { var s = String(text || '').toLowerCase(); if (/\b(?:16:9|wide|landscape|banner|youtube|thumbnail|desktop wallpaper)\b/.test(s)) return 1; if (/\b(?:9:16|tall|portrait|story|reel|status|phone wallpaper|mobile wallpaper)\b/.test(s)) return 2; if (/\b4:3\b/.test(s)) return 3; if (/\b3:4\b/.test(s)) return 4; return 0; }
function pickCount(text) { var m = String(text || '').match(/\b([1-8]|two|three|four|five|six)\s+(?:images|pictures|photos|versions|variations|options|designs|logos|ideas)\b/i); if (!m) return 1; var n = { two: 2, three: 3, four: 4, five: 5, six: 6 }[m[1].toLowerCase()] || +m[1]; return Math.min(8, Math.max(1, n)); }
function cleanPrompt(text) { return String(text || '').replace(/^(?:please\s+|can you\s+)?(?:generate|create|make|draw|paint|design|render|imagine|visuali[sz]e|show)\s+(?:me\s+)?(?:an?\s+|the\s+)?(?:[1-8]|two|three|four|five|six)?\s*(?:ai\s+)?(?:images?|pictures?|photos?|illustrations?|drawings?|artworks?|wallpapers?|versions?|variations?|options?|designs?)?\s*(?:of|for|showing|about|:)?\s*/i, '').trim() || String(text || '').trim(); }

/* ---------- parametric drawings (pure SVG strings, real proportions) ---------- */
function num(s, re, d) { var m = String(s).match(re); return m ? parseFloat(m[1]) : d; }
function actuatorSpec(text) {
  var s = String(text || '').toLowerCase(), set = {};
  function g(re, d, k) { var v = num(s, re, null); if (v !== null) set[k] = 1; return v === null ? d : v; }
  var stroke = g(/stroke\s*(?:of|=|:|is)?\s*(\d+(?:\.\d+)?)/, null, 'stroke'); if (stroke === null) { stroke = num(s, /(\d+(?:\.\d+)?)\s*mm\s*stroke/, null); if (stroke !== null) set.stroke = 1; }
  if (stroke === null) stroke = 150;
  var inline = /\binline|in-line|straight\b/.test(s);
  var base = inline ? 210 : 140;
  var L = g(/(?:retract(?:ed)?|install(?:ation)?|closed|min(?:imum)?)\s*(?:length)?\s*(?:of|=|:|is)?\s*(\d+(?:\.\d+)?)/, stroke + base, 'L');
  if (L < stroke + 60) L = stroke + 60;
  return {
    stroke: stroke, L: L, ext: L + stroke, inline: inline,
    tube: g(/(?:tube|body|outer tube|housing)\s*(?:dia(?:meter)?|ø|od)?\s*(?:of|=|:|is)?\s*(\d+(?:\.\d+)?)/, 32, 'tube'),
    rod: g(/(?:rod|inner tube|piston rod)\s*(?:dia(?:meter)?|ø|od)?\s*(?:of|=|:|is)?\s*(\d+(?:\.\d+)?)/, 20, 'rod'),
    hole: g(/(?:hole|clevis|pin)\s*(?:dia(?:meter)?|ø|size)?\s*(?:of|=|:|is)?\s*(\d+(?:\.\d+)?)/, 8, 'hole'),
    force: g(/(\d+(?:\.\d+)?)\s*(?:n\b|newton)/, null, 'force'), kg: g(/(\d+(?:\.\d+)?)\s*kg/, null, 'kg'),
    speed: g(/(\d+(?:\.\d+)?)\s*mm\s*\/\s*s/, null, 'speed'), volt: g(/(\d+)\s*v(?:dc|olt)?\b/, null, 'volt'),
    ip: (s.match(/\bip\s?(\d{2})\b/) || [])[1] || null, model: (String(text).match(/\b(?:model|part(?: no\.?)?)\s*[:#]?\s*([A-Z0-9][\w-]{2,})/i) || [])[1] || (String(text).match(/\b([A-Z]{2,5}-\d{2}-[A-Z0-9]{1,4})\b/) || [])[1] || '',
    set: set
  };
}
function svgWrap(w, h, body, title) {
  return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h + '" font-family="Arial, Helvetica, sans-serif">' +
    '<defs><marker id="a" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#000"/></marker></defs>' +
    '<rect width="100%" height="100%" fill="#fff"/><rect x="8" y="8" width="' + (w - 16) + '" height="' + (h - 16) + '" fill="none" stroke="#000" stroke-width="2"/>' + body + '</svg>';
}
function dimH(x1, x2, y, label, yRef) { var t = ''; if (yRef !== undefined) t += '<line x1="' + x1 + '" y1="' + yRef + '" x2="' + x1 + '" y2="' + (y + 6) + '" stroke="#000" stroke-width=".8"/><line x1="' + x2 + '" y1="' + yRef + '" x2="' + x2 + '" y2="' + (y + 6) + '" stroke="#000" stroke-width=".8"/>'; return t + '<line x1="' + x1 + '" y1="' + y + '" x2="' + x2 + '" y2="' + y + '" stroke="#000" stroke-width="1" marker-start="url(#a)" marker-end="url(#a)"/><rect x="' + ((x1 + x2) / 2 - label.length * 4.2 - 4) + '" y="' + (y - 17) + '" width="' + (label.length * 8.4 + 8) + '" height="15" fill="#fff"/><text x="' + ((x1 + x2) / 2) + '" y="' + (y - 5) + '" font-size="14" text-anchor="middle">' + label + '</text>'; }
function titleBlock(w, h, rows) {
  var bw = 360, bh = rows.length * 20 + 10, x = w - bw - 8, y = h - bh - 8, t = '<rect x="' + x + '" y="' + y + '" width="' + bw + '" height="' + bh + '" fill="#fff" stroke="#000" stroke-width="1.5"/>';
  rows.forEach(function (r, i) { var yy = y + 20 + i * 20; t += '<text x="' + (x + 8) + '" y="' + yy + '" font-size="' + (i === 0 ? '14" font-weight="bold' : '12.5') + '">' + r + '</text>'; if (i) t += '<line x1="' + x + '" y1="' + (yy - 15) + '" x2="' + (x + bw) + '" y2="' + (yy - 15) + '" stroke="#000" stroke-width=".5"/>'; });
  return t;
}
function escX(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function actuatorSVG(p) {
  var W = 1200, H = 760, margin = 70, sc = (W - 2 * margin - 40) / (p.ext + p.hole * 3), g = '';
  function act(x0, yc, len, label) {
    var e = p.hole * 1.6, tubeLen = p.L - p.hole * 2.2 - 6, rodVis = len - tubeLen - p.hole * 2.2, T = p.tube * sc, R = p.rod * sc, o = '';
    var rx = x0, tx = x0 + e * sc, tEnd = tx + tubeLen * sc, rEnd = x0 + len * sc;
    o += '<circle cx="' + rx + '" cy="' + yc + '" r="' + (p.hole * 1.6 * sc) + '" fill="#e5e7eb" stroke="#000" stroke-width="1.6"/><circle cx="' + rx + '" cy="' + yc + '" r="' + (p.hole / 2 * sc) + '" fill="#fff" stroke="#000" stroke-width="1.2"/>';
    o += '<rect x="' + tx + '" y="' + (yc - T / 2) + '" width="' + (tEnd - tx) + '" height="' + T + '" fill="#d1d5db" stroke="#000" stroke-width="1.8" rx="3"/>';
    if (!p.inline) { var mL = Math.min(tubeLen * 0.55, 130) * sc, mH = T * 1.05; o += '<rect x="' + (tx + 4 * sc) + '" y="' + (yc + T / 2) + '" width="' + mL + '" height="' + (mH) + '" fill="#9ca3af" stroke="#000" stroke-width="1.6" rx="' + (mH / 3) + '"/><text x="' + (tx + 4 * sc + mL / 2) + '" y="' + (yc + T / 2 + mH / 2 + 4) + '" font-size="11" text-anchor="middle">MOTOR</text>'; }
    else { var iL = Math.min(110, tubeLen * 0.4) * sc; o += '<rect x="' + tx + '" y="' + (yc - T / 2) + '" width="' + iL + '" height="' + T + '" fill="#9ca3af" stroke="#000" stroke-width="1.8" rx="3"/><line x1="' + (tx + iL) + '" y1="' + (yc - T / 2) + '" x2="' + (tx + iL) + '" y2="' + (yc + T / 2) + '" stroke="#000" stroke-width="1.2"/><text x="' + (tx + iL / 2) + '" y="' + (yc - T / 2 - 6) + '" font-size="11" text-anchor="middle">MOTOR + GEARBOX</text>'; }
    o += '<rect x="' + tEnd + '" y="' + (yc - R / 2) + '" width="' + Math.max(2, rEnd - p.hole * 1.6 * sc - tEnd) + '" height="' + R + '" fill="#f3f4f6" stroke="#000" stroke-width="1.6"/>';
    o += '<circle cx="' + rEnd + '" cy="' + yc + '" r="' + (p.hole * 1.6 * sc) + '" fill="#e5e7eb" stroke="#000" stroke-width="1.6"/><circle cx="' + rEnd + '" cy="' + yc + '" r="' + (p.hole / 2 * sc) + '" fill="#fff" stroke="#000" stroke-width="1.2"/>';
    o += '<line x1="' + (rx - 20) + '" y1="' + yc + '" x2="' + (rEnd + 20) + '" y2="' + yc + '" stroke="#000" stroke-width=".7" stroke-dasharray="14 4 3 4"/>';
    o += '<text x="' + (rx - p.hole * 1.6 * sc) + '" y="' + (yc + T / 2 + (p.inline ? 30 : T * 1.05 + 26)) + '" font-size="15" font-weight="bold">' + label + '</text>';
    return { o: o, rx: rx, rEnd: rEnd, top: yc - T / 2, tEnd: tEnd };
  }
  var x0 = margin + 20, a1 = act(x0, 170, p.L, 'RETRACTED'), a2 = act(x0, 430, p.ext, 'EXTENDED');
  g += a1.o + a2.o;
  g += dimH(a1.rx, a1.rEnd, 100, 'L = ' + p.L + ' (hole to hole)', a1.top - 4);
  g += dimH(a2.rx, a2.rEnd, 360, 'L + S = ' + p.ext, a2.top - 4);
  g += dimH(a1.rEnd, a2.rEnd, 545, 'STROKE S = ' + p.stroke, 470);
  g += '<line x1="' + a1.rEnd + '" y1="200" x2="' + a1.rEnd + '" y2="551" stroke="#000" stroke-width=".6" stroke-dasharray="5 4"/>';
  var hx = a2.rEnd + 6; g += '<text x="' + (a1.rEnd + p.hole * 2 * sc) + '" y="' + (170 + 5) + '" font-size="12">Ø' + p.hole + ' hole</text><text x="' + ((a2.tEnd + a2.rEnd) / 2) + '" y="' + (430 - p.rod * sc / 2 - 8) + '" font-size="12" text-anchor="middle">rod Ø' + p.rod + '</text><text x="' + (x0 + 160 * sc) + '" y="' + (430 - p.tube * sc / 2 - 8) + '" font-size="12">tube Ø' + p.tube + '</text>';
  var D = function (k, v) { return v + (p.set[k] ? '' : '*'); };
  var spec = ['Stroke: ' + D('stroke', p.stroke) + ' mm', 'Retracted length: ' + D('L', p.L) + ' mm', 'Extended length: ' + p.ext + ' mm', 'Hole: Ø' + D('hole', p.hole) + ' mm', 'Tube Ø' + D('tube', p.tube) + ' · Rod Ø' + D('rod', p.rod) + ' mm', 'Motor: ' + (p.inline ? 'inline' : 'parallel (side mounted)')];
  if (p.force || p.kg) spec.push('Load: ' + (p.force ? p.force + ' N' : '') + (p.kg ? (p.force ? ' / ' : '') + p.kg + ' kg' : ''));
  if (p.speed) spec.push('Speed: ' + p.speed + ' mm/s'); if (p.volt) spec.push('Voltage: ' + p.volt + ' V DC'); if (p.ip) spec.push('Protection: IP' + p.ip);
  var sy = 600; g += '<text x="' + margin + '" y="' + (sy - 8) + '" font-size="14" font-weight="bold">SPECIFICATION</text>';
  spec.forEach(function (t, i) { g += '<text x="' + (margin + (i % 2) * 300) + '" y="' + (sy + 14 + Math.floor(i / 2) * 20) + '" font-size="13">' + escX(t) + '</text>'; });
  g += '<text x="' + margin + '" y="' + (H - 22) + '" font-size="11" fill="#444">* default value, not given. All dimensions in mm. Proportional drawing from the given values.</text>';
  g += titleBlock(W, H, ['LINEAR ACTUATOR' + (p.model ? ' ' + escX(p.model) : ''), 'Stroke ' + p.stroke + ' mm · L ' + p.L + ' mm', 'Units: mm · Scale: fit (proportional)', 'Drawn by Lexi · ' + new Date().toISOString().slice(0, 10)]);
  return svgWrap(W, H, g);
}
function flangeSpec(text) {
  var s = String(text || '').toLowerCase();
  var od = num(s, /(?:od|outer\s*(?:dia(?:meter)?)?|outside\s*dia(?:meter)?)\s*(?:=|:|of)?\s*(\d+(?:\.\d+)?)/, 150), id = num(s, /(?:id|inner\s*(?:dia(?:meter)?)?|bore|inside\s*dia(?:meter)?)\s*(?:=|:|of)?\s*(\d+(?:\.\d+)?)/, Math.round(od * 0.4));
  var pcd = num(s, /(?:pcd|bolt\s*circle|pitch\s*circle)\s*(?:dia(?:meter)?)?\s*(?:=|:|of)?\s*(\d+(?:\.\d+)?)/, Math.round((od + id) / 2));
  var n = num(s, /(\d+)\s*(?:x\s*)?(?:bolt\s*)?holes?/, 4), hd = num(s, /holes?\s*(?:of\s*)?(?:dia(?:meter)?|ø)?\s*(?:=|:|of)?\s*ø?\s*(\d+(?:\.\d+)?)\s*mm/, Math.max(6, Math.round(od / 14))), t = num(s, /\b(?:thick(?:ness)?|thk)\s*(?:=|:|of|is)?\s*(\d+(?:\.\d+)?)/, num(s, /(\d+(?:\.\d+)?)\s*(?:mm\s*)?(?:thick|thk)\b/, 12));
  return { od: od, id: Math.min(id, od - 10), pcd: Math.min(Math.max(pcd, id + hd + 4), od - hd - 4), n: Math.max(2, Math.min(36, Math.round(n))), hd: hd, t: t };
}
function flangeSVG(p) {
  var W = 1100, H = 680, sc = 420 / p.od, cx = 300, cy = 330, R = p.od / 2 * sc, r = p.id / 2 * sc, P = p.pcd / 2 * sc, h = p.hd / 2 * sc, g = '';
  g += '<circle cx="' + cx + '" cy="' + cy + '" r="' + R + '" fill="#e5e7eb" stroke="#000" stroke-width="2"/><circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="#fff" stroke="#000" stroke-width="2"/>';
  g += '<circle cx="' + cx + '" cy="' + cy + '" r="' + P + '" fill="none" stroke="#000" stroke-width=".7" stroke-dasharray="14 4 3 4"/>';
  for (var i = 0; i < p.n; i++) { var a = -Math.PI / 2 + i * 2 * Math.PI / p.n; g += '<circle cx="' + (cx + P * Math.cos(a)) + '" cy="' + (cy + P * Math.sin(a)) + '" r="' + h + '" fill="#fff" stroke="#000" stroke-width="1.6"/>'; }
  g += '<line x1="' + (cx - R - 20) + '" y1="' + cy + '" x2="' + (cx + R + 20) + '" y2="' + cy + '" stroke="#000" stroke-width=".7" stroke-dasharray="14 4 3 4"/><line x1="' + cx + '" y1="' + (cy - R - 20) + '" x2="' + cx + '" y2="' + (cy + R + 20) + '" stroke="#000" stroke-width=".7" stroke-dasharray="14 4 3 4"/>';
  g += dimH(cx - R, cx + R, cy + R + 50, 'Ø' + p.od + ' OD', cy);
  g += '<text x="' + (cx + 8) + '" y="' + (cy - 6) + '" font-size="14">Ø' + p.id + ' bore</text><text x="' + (cx + P * 0.72 + 10) + '" y="' + (cy - P * 0.72 - 10) + '" font-size="14">' + p.n + ' × Ø' + p.hd + ' on PCD Ø' + p.pcd + '</text>';
  g += '<text x="' + (cx - R) + '" y="' + (cy - R - 30) + '" font-size="15" font-weight="bold">FRONT VIEW</text>';
  var sx = 700, T = p.t * sc, sTop = cy - R;
  g += '<text x="' + sx + '" y="' + (cy - R - 30) + '" font-size="15" font-weight="bold">SECTION A-A</text>';
  g += '<rect x="' + sx + '" y="' + sTop + '" width="' + T + '" height="' + (R - r) + '" fill="url(#hatch)" stroke="#000" stroke-width="2"/><rect x="' + sx + '" y="' + (cy + r) + '" width="' + T + '" height="' + (R - r) + '" fill="url(#hatch)" stroke="#000" stroke-width="2"/>';
  g += '<line x1="' + (sx - 20) + '" y1="' + cy + '" x2="' + (sx + T + 20) + '" y2="' + cy + '" stroke="#000" stroke-width=".7" stroke-dasharray="14 4 3 4"/>';
  [cy - P, cy + P].forEach(function (y) { g += '<rect x="' + sx + '" y="' + (y - h) + '" width="' + T + '" height="' + (2 * h) + '" fill="#fff" stroke="#000" stroke-width="1"/>'; });
  g += dimH(sx, sx + T, cy + R + 50, p.t + ' thk', cy + R);
  g = '<defs><pattern id="hatch" width="8" height="8" patternTransform="rotate(45)" patternUnits="userSpaceOnUse"><rect width="8" height="8" fill="#f3f4f6"/><line x1="0" y1="0" x2="0" y2="8" stroke="#000" stroke-width="1"/></pattern></defs>' + g;
  g += titleBlock(W, H, ['FLANGE Ø' + p.od + ' × ' + p.t, 'Bore Ø' + p.id + ' · ' + p.n + ' holes Ø' + p.hd + ' on PCD ' + p.pcd, 'Units: mm · Scale: fit (proportional)', 'Drawn by Lexi · ' + new Date().toISOString().slice(0, 10)]);
  return svgWrap(W, H, g);
}
var DRAW_RE = /\b(?:technical|engineering|mechanical|cad|2d|dimensioned|orthographic|blueprint|workshop|fabrication|part|assembly|ga)\s+(?:drawing|diagram|sketch|views?|print|layout)\b|\b(?:drawing|diagram)\s+(?:of|for)\s+(?:an?\s+|the\s+)?(?:linear actuator|actuator|flange|shaft|bracket|plate|gear|part|pulley|bush|coupling|housing|clevis)\b|\b(?:linear actuator|actuator|flange)\s+(?:drawing|diagram|dimensions?|drawing with dimensions)\b|^draw\s+(?:an?\s+|the\s+)?(?:linear actuator|actuator|flange)\b/i;
function sanitizeSVG(t) {
  var m = String(t || '').match(/<svg[\s\S]*<\/svg>/i); if (!m) return null;
  var s = m[0].replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi, '').replace(/\son\w+\s*=\s*(["']).*?\1/gi, '').replace(/(?:xlink:)?href\s*=\s*(["'])\s*(?:javascript|data|https?):[^"']*\1/gi, '');
  if (!/xmlns=/.test(s)) s = s.replace(/<svg/i, '<svg xmlns="http://www.w3.org/2000/svg"');
  return s;
}
var JG = { STYLES: STYLES, SIZES: SIZES, pickStyle: pickStyle, pickSize: pickSize, pickCount: pickCount, cleanPrompt: cleanPrompt, actuatorSpec: actuatorSpec, actuatorSVG: actuatorSVG, flangeSpec: flangeSpec, flangeSVG: flangeSVG, DRAW_RE: DRAW_RE, sanitizeSVG: sanitizeSVG };
root.JTCREATE = JG;
if (typeof module !== 'undefined' && module.exports) module.exports = JG;
if (typeof document === 'undefined' || typeof window.handle !== 'function') return;

/* ======================= PAGE WIRING ======================= */
var style = document.createElement('style');
style.textContent = '.jg-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;margin:8px 0}.jg-t{position:relative;border-radius:12px;overflow:hidden;background:var(--card);border:1px solid var(--bd);cursor:pointer;aspect-ratio:1}.jg-t img{width:100%;height:100%;object-fit:cover;display:block}.jg-t span{position:absolute;left:0;right:0;bottom:0;background:linear-gradient(transparent,rgba(0,0,0,.75));color:#fff;font-size:12px;padding:14px 6px 5px}' +
  '.jg-t.ld::after{content:"⏳";position:absolute;inset:0;display:grid;place-items:center;font-size:26px;background:var(--card)}.jg-t.er::after{content:"⚠️ retry";position:absolute;inset:0;display:grid;place-items:center;font-size:14px;background:var(--card)}' +
  '.jg-p{width:100%;min-height:58px;border:1px solid var(--bd);border-radius:12px;background:var(--bg);color:var(--fg);font:inherit;font-size:14.5px;padding:8px}.jg-chips{display:flex;flex-wrap:wrap;gap:5px;margin:6px 0}.jg-c{border:1px solid var(--bd);background:var(--card);color:var(--fg);border-radius:14px;padding:4px 10px;font-size:12.5px;cursor:pointer}.jg-c.on{background:linear-gradient(135deg,var(--a),var(--b));color:#fff;border-color:transparent}' +
  '.jg-l{font-size:12.5px;color:var(--mut);margin-top:6px}.jg-big{width:100%;border-radius:12px;display:block;margin:8px 0;background:#fff}.jg-row{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}';
document.head.appendChild(style);
function el(t, a, kids) { var e = document.createElement(t); for (var k in a || {}) { if (k === 'text') e.textContent = a[k]; else if (k === 'html') e.innerHTML = a[k]; else e.setAttribute(k, a[k]); } (kids || []).forEach(function (c) { if (c) e.appendChild(c); }); return e; }
function bt(t, fn, cls) { var b = el('button', { type: 'button', 'class': cls || 'jv-b', text: t }); b.onclick = fn; return b; }
function to(ms) { var c = new AbortController(); setTimeout(function () { c.abort(); }, ms); return c.signal; }
function feel(m, ms) { try { mood(m, ms); } catch (e) { } }
function talk(t) { try { speak(t); } catch (e) { } }
function scroll() { log.scrollTop = log.scrollHeight; }
function dl(url, name) { var a = el('a', { href: url, download: name }); document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 400); }
function toData(url) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { try { var c = document.createElement('canvas'); c.width = i.naturalWidth; c.height = i.naturalHeight; c.getContext('2d').drawImage(i, 0, 0); res(c.toDataURL('image/png')); } catch (e) { rej(e); } }; i.onerror = rej; i.src = url; }); }
function saveImg(url, name) { if (/^data:/.test(url)) return dl(url, name); toData(url).then(function (d) { dl(d, name); }, function () { window.open(url, '_blank'); }); }

/* small text AI: your keys (via the app), then the free services */
function txt(system, user, ms) {
  ms = ms || 40000;
  var T = [];
  ['gemini', 'claude', 'chatgpt', 'groq', 'openrouter'].forEach(function (p) { T.push(function () { return ai(p, system + '\n\n' + user); }); });
  function oai(u, key, model) { return function () { return fetch(u, { method: 'POST', signal: to(ms), headers: Object.assign({ 'content-type': 'application/json' }, key ? { authorization: 'Bearer ' + key } : {}), body: new Blob([JSON.stringify({ model: model, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] })], { type: 'application/json' }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.choices[0].message.content; }); }; }
  if (CFG.pk) T.push(oai('https://gen.pollinations.ai/v1/chat/completions', CFG.pk, 'openai'));
  T.push(oai('https://text.pollinations.ai/openai', '', 'openai'));
  T.push(oai('https://gen.pollinations.ai/v1/chat/completions', '', 'openai'));
  return T.reduce(function (p, f) { return p.catch(function () { return Promise.resolve().then(f).then(function (t) { if (!t || !String(t).trim()) throw 0; return String(t); }); }); }, Promise.reject());
}

/* ---------- image URLs / models ---------- */
var MODELS = [['flux', 'Free · Flux (best)'], ['turbo', 'Free · Turbo (fast)'], ['gemini', 'Gemini (your key)'], ['openai', 'OpenAI (your key)']];
function freeURLs(prompt, w, h, seed, model) {
  var q = encodeURIComponent(prompt.slice(0, 1500)), pr = 'width=' + w + '&height=' + h + '&seed=' + seed + '&nologo=true&model=' + model;
  var a = [];
  if (CFG.pk) a.push('https://gen.pollinations.ai/image/' + q + '?' + pr + '&key=' + encodeURIComponent(CFG.pk));
  a.push('https://image.pollinations.ai/prompt/' + q + '?' + pr);
  a.push('https://gen.pollinations.ai/image/' + q + '?' + pr);
  return a;
}
function keyImage(model, prompt, w, h, srcData) {
  if (model === 'gemini') {
    if (!CFG.gk) return Promise.reject('Add a Gemini key in 🔌 to use Gemini pictures.');
    var parts = [{ text: prompt + (srcData ? '' : (w > h ? ' (wide 16:9 image)' : h > w ? ' (tall 9:16 image)' : ' (square image)')) }];
    if (srcData) parts.unshift({ inlineData: { mimeType: 'image/png', data: srcData.split(',')[1] } });
    return tryM(['gemini-2.5-flash-image', 'gemini-2.5-flash-image-preview', 'gemini-2.0-flash-preview-image-generation'], function (m) {
      return fetch('https://generativelanguage.googleapis.com/v1beta/models/' + m + ':generateContent?key=' + encodeURIComponent(CFG.gk), { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: parts }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'] } }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (r) { var q = r.candidates[0].content.parts.filter(function (x) { return x.inlineData; })[0]; if (!q) throw 0; return 'data:' + q.inlineData.mimeType + ';base64,' + q.inlineData.data; });
    });
  }
  if (model === 'openai') {
    if (!CFG.ok) return Promise.reject('Add an OpenAI key in 🔌 to use OpenAI pictures.');
    var size = w > h ? '1536x1024' : h > w ? '1024x1536' : '1024x1024';
    if (srcData) return fetch(srcData).then(function (r) { return r.blob(); }).then(function (b) { var f = new FormData(); f.append('model', 'gpt-image-1'); f.append('prompt', prompt); f.append('size', size); f.append('image', new File([b], 'image.png', { type: 'image/png' })); return fetch('https://api.openai.com/v1/images/edits', { method: 'POST', headers: { authorization: 'Bearer ' + CFG.ok }, body: f }); }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (r) { return 'data:image/png;base64,' + r.data[0].b64_json; });
    return fetch('https://api.openai.com/v1/images/generations', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + CFG.ok }, body: JSON.stringify({ model: 'gpt-image-1', prompt: prompt, size: size }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (r) { return 'data:image/png;base64,' + r.data[0].b64_json; });
  }
  return Promise.reject();
}
function tile(grid, label, makeSrc, onPick) {
  var t = el('div', { 'class': 'jg-t ld', title: label, role: 'button', tabindex: '0' }), im = el('img', { alt: label }), sp = el('span', { text: label });
  t.appendChild(im); t.appendChild(sp); grid.appendChild(t);
  var srcs = null, k = 0;
  function tryNext() { if (!srcs || k >= srcs.length) { t.className = 'jg-t er'; return; } im.src = srcs[k++]; }
  im.onload = function () { t.className = 'jg-t'; scroll(); };
  im.onerror = tryNext;
  Promise.resolve(makeSrc()).then(function (s) { srcs = [].concat(s); tryNext(); }, function (e) { t.className = 'jg-t er'; t.title = String(e || 'failed'); });
  t.onclick = function () { if (/er/.test(t.className)) { k = 0; t.className = 'jg-t ld'; return Promise.resolve(makeSrc()).then(function (s) { srcs = [].concat(s); tryNext(); }); } if (!/ld/.test(t.className)) onPick(im.currentSrc || im.src, label); };
  return t;
}

/* ---------- 1) image creator ---------- */
var LAST = null;
function generate(raw, forced) {
  var o = forced || { prompt: cleanPrompt(raw), style: pickStyle(raw), size: pickSize(raw), n: Math.max(pickCount(raw), 2), model: 'flux' };
  if (/^(?:a|an|the)?\s*$/.test(o.prompt)) o.prompt = 'a beautiful landscape';
  LAST = o;
  var m = add('', 'a');
  m.appendChild(el('b', { text: '🖼️ Image creator' }));
  var ta = el('textarea', { 'class': 'jg-p', 'aria-label': 'Picture description' }); ta.value = o.prompt; m.appendChild(ta);
  function chipRow(list, cur, onSel, lbl) { var r = el('div', { 'class': 'jg-chips' }); r.appendChild(el('span', { 'class': 'jg-l', text: lbl, style: 'margin:4px 4px 0 0' })); list.forEach(function (x, i) { var c = bt(x, function () { [].forEach.call(r.querySelectorAll('.jg-c'), function (z) { z.classList.remove('on'); }); c.classList.add('on'); onSel(i); }, 'jg-c' + (i === cur ? ' on' : '')); r.appendChild(c); }); m.appendChild(r); return r; }
  chipRow(STYLES.map(function (s) { return s[0]; }), o.style, function (i) { o.style = i; }, '🎨 Style');
  chipRow(SIZES.map(function (s) { return s[0]; }), o.size, function (i) { o.size = i; }, '📐 Size');
  chipRow(['1', '2', '4', '6'], [1, 2, 4, 6].indexOf(o.n) < 0 ? 1 : [1, 2, 4, 6].indexOf(o.n), function (i) { o.n = [1, 2, 4, 6][i]; }, '🔢 How many');
  chipRow(MODELS.map(function (x) { return x[1]; }), MODELS.map(function (x) { return x[0]; }).indexOf(o.model), function (i) { o.model = MODELS[i][0]; }, '🧠 Model');
  var grid = el('div', { 'class': 'jg-grid' }), row = el('div', { 'class': 'jg-row' });
  row.appendChild(bt('🎲 Create', function () { o.prompt = ta.value.trim() || o.prompt; run(); }, 'jv-b p'));
  row.appendChild(bt('✨ Improve prompt', function () {
    var b = this; b.textContent = '✨ Improving…';
    var isMech = MECH.test(ta.value);
    txt('You write prompts for an AI image generator. Rewrite the idea as ONE detailed, accurate image prompt (max 90 words): subject, key parts and their real proportions, materials, colours, setting, lighting, camera/view. ' + (isMech ? 'It is a mechanical / engineering subject: describe the real components correctly (e.g. for an electric linear actuator: aluminium outer tube, chrome inner rod, DC motor housing mounted parallel or inline, gearbox, rear and front clevis mounting holes, cable). ' : '') + 'Return only the prompt text, no quotes, no intro.', ta.value).then(function (t) { ta.value = t.replace(/^["'\s]+|["'\s]+$/g, ''); b.textContent = '✨ Improved'; }, function () { b.textContent = '✨ AI busy: try again'; });
  }));
  row.appendChild(bt('🌈 Same idea in 6 styles', function () { o.prompt = ta.value.trim() || o.prompt; run(true); }));
  m.appendChild(row); m.appendChild(grid);
  m.appendChild(el('div', { 'class': 'jg-l', text: 'Tap a picture to open it: download, edit it with words, make more like it. Free pictures come from Pollinations (no key); for very exact pictures choose Gemini or OpenAI after adding a key in 🔌. For dimensioned engineering drawings say “technical drawing of …”.' }));
  function run(styles6) {
    grid.innerHTML = ''; var sz = SIZES[o.size], list = [];
    if (styles6) { var pick = MECH.test(o.prompt) ? [21, 22, 23, 24, 1, 25] : [1, 3, 4, 8, 9, 13]; pick.forEach(function (i) { list.push({ st: i, seed: Math.floor(Math.random() * 1e6) }); }); }
    else for (var i = 0; i < o.n; i++) list.push({ st: o.style, seed: Math.floor(Math.random() * 1e6) });
    list.forEach(function (it) {
      var full = o.prompt + (STYLES[it.st][1] ? ', ' + STYLES[it.st][1] : '') + (MECH.test(o.prompt) ? ', correct engineering proportions, realistic mechanical detail' : '');
      tile(grid, STYLES[it.st][0] === 'Auto' ? 'Option' : STYLES[it.st][0], function () { return o.model === 'gemini' || o.model === 'openai' ? keyImage(o.model, full, sz[1], sz[2]) : freeURLs(full, sz[1], sz[2], it.seed, o.model); }, function (src, label) { open(src, full, label); });
    });
    feel('think'); talk('Creating your pictures.'); setTimeout(function () { feel('happy', 1500); }, 3000); scroll();
  }
  run();
}
function open(src, prompt, label) {
  var m = add('', 'a');
  m.appendChild(el('b', { text: '🖼️ ' + label }));
  var im = el('img', { 'class': 'jg-big', src: src, alt: prompt }); m.appendChild(im);
  var row = el('div', { 'class': 'jg-row' });
  row.appendChild(bt('⬇ Download', function () { saveImg(src, 'lexi-image.png'); }, 'jv-b p'));
  row.appendChild(bt('✏️ Edit with words', function () { toData(src).then(function (d) { root.JV.set(d); reply('✏️ Ready. Tell me what to change, e.g. “remove background”, “add text SALE at the top”, “make it black and white”, “make the sky orange”.'); inp.focus(); }, function () { reply('This picture host does not allow editing in the browser. Download it, then send it with ➕ to edit.'); }); }));
  row.appendChild(bt('🔁 4 more like this', function () { generate('', Object.assign({}, LAST || {}, { prompt: prompt, n: 4, style: 0 })); }));
  row.appendChild(bt('📋 Copy prompt', function () { try { navigator.clipboard.writeText(prompt); } catch (e) { } }));
  m.appendChild(row); m.appendChild(el('div', { 'class': 'jg-l', text: prompt.slice(0, 300) })); scroll();
}

/* ---------- 2) technical drawings ---------- */
function showSVG(svg, title, note, src) {
  var m = add('', 'a'), url = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  m.appendChild(el('b', { text: '📐 ' + title }));
  if (note) m.appendChild(el('div', { 'class': 'jg-l', html: note }));
  m.appendChild(el('img', { 'class': 'jg-big', src: url, alt: title }));
  var row = el('div', { 'class': 'jg-row' });
  row.appendChild(bt('⬇ SVG (CAD / print)', function () { dl(url, title.replace(/[^\w]+/g, '-').toLowerCase() + '.svg'); }, 'jv-b p'));
  row.appendChild(bt('⬇ PNG', function () { var i = new Image(); i.onload = function () { var c = document.createElement('canvas'); c.width = i.naturalWidth * 2; c.height = i.naturalHeight * 2; var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(i, 0, 0, c.width, c.height); dl(c.toDataURL('image/png'), title.replace(/[^\w]+/g, '-').toLowerCase() + '.png'); }; i.src = url; }));
  row.appendChild(bt('🖨 Print / PDF', function () { var d = el('dialog'); d.style.cssText = 'width:96vw;max-width:1300px;padding:8px'; var f = el('iframe', { sandbox: 'allow-modals' }); f.style.cssText = 'width:100%;height:80vh;border:0'; f.srcdoc = '<!doctype html><style>@page{size:landscape;margin:8mm}body{margin:0}img{width:100%}</style><img src="' + url + '"><script>onload=function(){print()}<\/script>'; f.setAttribute('sandbox', 'allow-scripts allow-modals'); d.appendChild(bt('✕ Close', function () { d.close(); d.remove(); })); d.appendChild(f); document.body.appendChild(d); d.showModal(); }));
  row.appendChild(bt('🖼️ Realistic render', function () { generate('', { prompt: title + ', ' + (note || '').replace(/<[^>]+>/g, ' ').slice(0, 200), style: 21, size: 1, n: 2, model: 'flux' }); }));
  m.appendChild(row);
  if (src) m.appendChild(el('div', { 'class': 'jg-l', text: src }));
  scroll(); feel('happy', 1600);
}
function drawing(text) {
  var lc = text.toLowerCase();
  if (/\bactuator\b/.test(lc)) {
    var p = actuatorSpec(text);
    talk('Here is the linear actuator drawing.');
    return showSVG(actuatorSVG(p), 'Linear actuator ' + p.stroke + ' mm stroke', 'Accurate proportional drawing from your values (unmarked values use defaults, shown with *). Change any value by asking again, e.g. “linear actuator drawing stroke 300 retracted 450 rod 25 tube 40 hole 10 inline 24V 6000N IP65 model PAI-01-V1”.', 'Built-in drawing: works offline.');
  }
  if (/\bflange\b/.test(lc)) {
    var f = flangeSpec(text);
    return showSVG(flangeSVG(f), 'Flange Ø' + f.od, 'Accurate drawing from your values. Example: “flange drawing OD 200 ID 80 PCD 160 8 holes 14 mm thickness 20”.', 'Built-in drawing: works offline.');
  }
  var m = add('<span class="dots"><i></i><i></i><i></i></span>', 'a'); feel('think'); st.textContent = '📐 Drawing…';
  txt('You are a senior mechanical design engineer and CAD draftsman. Output ONLY one SVG element (no markdown, no explanation): a clean 2D engineering drawing on white, viewBox="0 0 1200 800", font-family Arial. Requirements: correct proportions to scale from the given dimensions (state the scale), the needed orthographic views (front / top / side or section) laid out in third-angle projection, visible lines black 2px, hidden lines dashed, centre lines dash-dot, dimension lines with arrowheads (use a <marker>) and values in mm, diameters with Ø, a title block bottom-right with part name, material (if known), units mm, scale and date. If a dimension is missing choose a sensible standard value and mark it with *. No scripts, no external links, no images.', text, 90000).then(function (t) {
    st.textContent = ''; var svg = sanitizeSVG(t); if (!svg) throw 0; m.parentNode.remove();
    showSVG(svg, cleanPrompt(text).replace(/^(?:a\s+)?(?:technical|engineering|mechanical|cad|2d)\s+(?:drawing|diagram)\s+(?:of\s+)?/i, '').slice(0, 60) || 'Technical drawing', 'Drawn by AI as a vector drawing: check every dimension before manufacturing. Values marked * were assumed.', 'AI-generated SVG');
  }).catch(function () {
    st.textContent = ''; feel('sad', 2000);
    m.innerHTML = (window.md || esc)('I could not reach the AI to draw that right now. These drawings work offline: **linear actuator drawing stroke 200 mm** and **flange drawing OD 150 ID 60 PCD 110 6 holes 12 thick**. For other parts add a free Gemini or Groq key in 🔌 and try again.');
  });
}

/* ---------- 3) many looks for your photo ---------- */
function gallery() {
  var C = root.JV && root.JV.cur(); if (!C) return reply('Send a photo first with ➕, then say “show all styles”.');
  var m = add('', 'a'); m.appendChild(el('b', { text: '🎨 Your photo in every style' })); m.appendChild(el('div', { 'class': 'jg-l', text: 'Tap one to apply it (then keep editing with words). These run on your device.' }));
  var grid = el('div', { 'class': 'jg-grid' }); m.appendChild(grid);
  var P = root.JT_PRESETS || {};
  root.JV.loadImg(C.url).then(function (img) {
    Object.keys(P).forEach(function (k) {
      if (k === 'original') return;
      tile(grid, String(P[k].name || k).replace(/^\W+\s*/, ''), function () { var c = root.JV.canvasOf(img, 320), x = c.getContext('2d', { willReadFrequently: true }), id = x.getImageData(0, 0, c.width, c.height); P[k].fn(id.data, c.width, c.height); x.putImageData(id, 0, 0); return c.toDataURL('image/jpeg', 0.85); }, function () { root.JV.edit([{ op: 'preset', v: k }]); });
    });
    var row = el('div', { 'class': 'jg-row' }); row.appendChild(bt('✨ 4 AI styles (anime, 3D, Ghibli, oil)', function () { aiLooks(); }, 'jv-b p')); m.appendChild(row); scroll();
  });
}
function aiLooks() {
  var C = root.JV.cur(); if (!C) return;
  var m = add('<span class="dots"><i></i><i></i><i></i></span>', 'a'); st.textContent = '🔍 Studying your photo…';
  root.JV.vision('Describe this picture in one detailed sentence for an artist to redraw it: main subject, face/hair, clothing and colours, pose, background. No intro, max 70 words.', [C.url], 45000).then(function (r) {
    st.textContent = ''; m.innerHTML = '<b>✨ AI looks of your photo</b><div class="jg-l">Free AI redraws your photo from its description, so details can differ. With a Gemini or OpenAI key, use “AI edit: …” for exact edits of your own photo.</div>';
    var grid = el('div', { 'class': 'jg-grid' }); m.appendChild(grid); var d = r.t.replace(/\s+/g, ' ').slice(0, 500);
    [4, 5, 3, 8, 7, 13].forEach(function (i) { var full = STYLES[i][1] + ', ' + d; tile(grid, STYLES[i][0], function () { return freeURLs(full, 1024, 1024, Math.floor(Math.random() * 1e6), 'flux'); }, function (src, label) { open(src, full, label); }); });
    scroll();
  }).catch(function () { st.textContent = ''; m.innerHTML = 'I could not study the photo online right now. The on-device styles above still work.'; });
}
function aiEdit(instr) {
  var C = root.JV && root.JV.cur(); if (!C) return reply('Send a photo first with ➕.');
  var m = add('<span class="dots"><i></i><i></i><i></i></span>', 'a'); st.textContent = '✨ Editing with AI…'; feel('think');
  var prompt = 'Edit this image: ' + instr + '. Keep everything else exactly the same (same person, pose, framing and style).';
  var model = CFG.gk ? 'gemini' : CFG.ok ? 'openai' : null;
  var p = model ? root.JV.loadImg(C.url).then(function (i) { return root.JV.canvasOf(i, 1024).toDataURL('image/png'); }).then(function (d) { return keyImage(model, prompt, 1024, 1024, d); }) : Promise.reject('nokey');
  p.then(function (d) { st.textContent = ''; root.JV.set(d); root.JV.show(m, d, '✨ AI edit (' + (model === 'gemini' ? 'Gemini' : 'OpenAI') + '): ' + esc(instr), 'ai'); feel('happy', 1600); talk('Done.'); })
    .catch(function (e) {
      if (e !== 'nokey') { st.textContent = ''; m.innerHTML = 'The AI edit did not work (' + esc(String(e)) + '). Check your key in 🔌 or try a simpler change.'; feel('sad', 2000); return; }
      root.JV.vision('Describe this picture in one detailed sentence for an artist to redraw it: main subject, face/hair, clothing and colours, pose, background. No intro, max 70 words.', [C.url], 45000).then(function (r) {
        st.textContent = ''; m.innerHTML = '<b>✨ Redrawn with your change</b><div class="jg-l">Free mode: the AI redraws the photo with your change, so details can differ. For exact edits of your own photo add a free Gemini key in 🔌.</div>';
        var grid = el('div', { 'class': 'jg-grid' }); m.appendChild(grid); var full = r.t.replace(/\s+/g, ' ').slice(0, 450) + '. Change: ' + instr + '. Photo realistic, same composition.';
        for (var i = 0; i < 2; i++) tile(grid, 'Option ' + (i + 1), function () { return freeURLs(full, 1024, 1024, Math.floor(Math.random() * 1e6), 'flux'); }, function (src, label) { open(src, full, label); });
        scroll();
      }).catch(function () { st.textContent = ''; m.innerHTML = 'I need the internet for that change. On-device edits still work: remove background, colours, text, crop, styles.'; });
    });
}
root.JG = { generate: generate, drawing: drawing, gallery: gallery, aiEdit: aiEdit };

/* ---------- front door ---------- */
var prevH = root.handle;
var GEN_RE = /^(?:please\s+|can you\s+)?(?:generate|create|make|draw|paint|design|render|imagine|visuali[sz]e|show me)\s+(?:me\s+)?(?:an?\s+|the\s+|some\s+)?(?:[1-8]|two|three|four|five|six)?\s*(?:ai\s+)?(?:images?|pictures?|photos?|illustrations?|artworks?|wallpapers?|logos?|icons?|posters?|renders?|stickers?|thumbnails?|art)\b/i;
root.handle = function (raw) {
  var s = String(raw == null ? '' : raw).trim(), lc = s.toLowerCase();
  if (!s || (window.JT_pending && window.JT_pending())) return prevH(raw);
  if (DRAW_RE.test(s)) { add(esc(s), 'u'); return drawing(s); }
  if (GEN_RE.test(s) || /^(?:draw|paint|imagine|render|visuali[sz]e)\s+(?:an?|the|me)\s+\w+/i.test(s) && !/\b(?:conclusion|line|graph|chart)\b/i.test(s)) { add(esc(s), 'u'); return generate(s); }
  var C = root.JV && root.JV.cur();
  if (C) {
    if (/^(?:show|try|apply)?\s*(?:all|every|more|other)\s+(?:the\s+)?(?:styles?|filters?|effects?|looks?)\b|^style (?:options|gallery)$|^(?:more|all) options$/i.test(lc)) { add(esc(s), 'u'); return gallery(); }
    if (/^(?:4|four)?\s*ai (?:styles?|looks?)$/i.test(lc)) { add(esc(s), 'u'); return aiLooks(); }
    if (/^ai\s*edit\s*[:,-]?\s*/i.test(s)) { add(esc(s), 'u'); return aiEdit(s.replace(/^ai\s*edit\s*[:,-]?\s*/i, '')); }
    var fresh = Date.now() - (C.t || 0) < 30 * 60000, vis = root.JTVISION && root.JTVISION.intent(s, true);
    if (fresh && !vis && !(root.JW_site && root.JW_site.active) && /^(?:make|turn|change|replace|put|give|add|remove|swap|convert)\b/i.test(lc) && /\b(?:him|her|them|his|hers|their|it|photo|picture|image|pic|shirt|hoodie|dress|hair|sky|background|eyes|face|car|wall|clothes|hat|glasses|colou?r)\b/.test(lc)) { add(esc(s), 'u'); return aiEdit(s); }
  }
  return prevH(raw);
};
var det = document.querySelectorAll('#panel details')[1];
if (det) det.appendChild(el('div', { html: '<p><b>🖼️ Create pictures:</b> create an image of a red sports car · 4 logos for Purlin Automation · draw a cat astronaut in anime style · wallpaper of mountains 9:16. Pick from 30 styles, 5 sizes, 1–6 at once, ✨ Improve prompt, 🌈 Same idea in 6 styles.</p><p><b>📐 Technical drawings (accurate):</b> linear actuator drawing stroke 200 mm retracted 340 hole 8 · flange drawing OD 150 ID 60 PCD 110 6 holes 12 thick · technical drawing of a shaft 200 long Ø30 with keyway. Download SVG / PNG / PDF.</p><p><b>🎨 Your photo:</b> show all styles · 4 AI styles · make his hoodie red · AI edit: add sunglasses.</p>' }));
})(typeof window !== 'undefined' ? window : globalThis);
