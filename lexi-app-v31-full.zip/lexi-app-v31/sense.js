/* Lexi sense.js v26: understands sentences and paragraphs in any language.
   Ask in chat (English, Hinglish, Hindi):
     "explain: <text>", "meaning of this sentence: <text>", "what does "<sentence>" mean",
     "summarize: <paragraph>", "simplify: <text>", "correct grammar: <text>", "word by word: <text>",
     "is line ka matlab batao: <text>", "<sentence> ka matlab kya hai", "इस वाक्य का मतलब: <text>"
   Answer:
     at once, offline: language, sentences, words, reading time, reading level, hard words from the dictionary;
     then with AI: meaning in plain English and in your language, translation, summary, simple version,
     key points, idioms, word-by-word meaning, grammar corrections, tone.
   Every text you ask about is saved in "My sentences" with practice cards (Training Center > Sentences). */
(function (root) {
'use strict';
var doc = root.document;
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
var MAXLEN = 8000;

/* ---------- understand the request ---------- */
var SEP = '\\s*[:：\\-–—]\\s*';
var KIND = '(?:sentence|line|paragraph|para|text|phrase|passage|quote|quotation|proverb|idiom|saying|message|lines|sentences|verse|statement)';
var PAT = [
  [new RegExp('^(?:what(?:\'s| is) the |tell me the |give me the )?(?:meaning|explanation|interpretation) of (?:this|the following|these|the|my)?\\s*' + KIND + SEP + '([\\s\\S]+)$', 'i'), 'explain'],
  [new RegExp('^(?:please\\s+)?(?:explain|understand|analy[sz]e|interpret|decode|break\\s?down|meaning)(?: (?:this|the|my|the following))?(?: ' + KIND + ')?' + SEP + '([\\s\\S]+)$', 'i'), 'explain'],
  [/^what does\s+["“'‘]([^"”'’]{12,})["”'’]\s+mean\s*\??$/i, 'explain'],
  [/^what (?:does|do)\s+(?!this\b|that\b|it\b)((?:\S+\s+){4,}\S+?)\s+mean\s*\??$/i, 'explain'],   /* unquoted sentence of 5+ words */
  [new RegExp('^(?:please\\s+)?(?:summari[sz]e|summary(?: of)?|tl;?dr|give (?:me )?(?:a |the )?summary(?: of)?)(?: (?:this|the|my|the following))?(?: ' + KIND + ')?' + SEP + '([\\s\\S]+)$', 'i'), 'summary'],
  [new RegExp('^(?:please\\s+)?(?:simplify|make (?:it|this) simple(?:r)?|explain simply|in simple words)(?: (?:this|the|my))?(?: ' + KIND + ')?' + SEP + '([\\s\\S]+)$', 'i'), 'simple'],
  [new RegExp('^(?:please\\s+)?(?:correct|fix|check|improve)(?: the| my| this)? (?:grammar|spelling|sentence|english|writing|text)(?: of| in)?' + SEP + '([\\s\\S]+)$', 'i'), 'grammar'],
  [new RegExp('^(?:translate and explain|word[- ]by[- ]word(?: meaning)?|meaning of each word(?: in)?)' + SEP + '([\\s\\S]+)$', 'i'), 'words'],
  /* Hinglish */
  [new RegExp('^(?:is|iss|ye|yeh|is wali|iss wali) (?:line|sentence|vakya|vaakya|paragraph|para|baat|message) (?:ka|ki|ke) (?:matlab|mtlb|arth|meaning)(?: (?:kya hai|batao|bataiye|samjhao|samjhaiye|bata do))*' + SEP + '([\\s\\S]+)$', 'i'), 'explain', 'Hinglish'],
  [/^([\s\S]{12,}?)\s+(?:ka|is line ka|iska) (?:matlab|mtlb|arth|meaning)(?: (?:kya hai|kya hota hai|batao|bataiye|samjhao|bata do))*\s*\??$/i, 'explain', 'Hinglish'],
  /* Hindi */
  [new RegExp('^(?:इस|इन|यह|ये) (?:वाक्य|वाक्यों|पंक्ति|पंक्तियों|पैराग्राफ|अनुच्छेद|लाइन|बात|संदेश) (?:का|के|की) (?:मतलब|अर्थ)(?: (?:क्या है|बताइए|बताओ|बताइये|समझाइए|समझाओ))*' + SEP + '([\\s\\S]+)$'), 'explain', 'Hindi'],
  [/^([\s\S]{12,}?)\s+(?:का|के) (?:मतलब|अर्थ)(?: (?:क्या है|बताइए|बताओ|समझाइए))*\s*[?।]?$/, 'explain', 'Hindi']
];
function words(t) { return (String(t).match(/[\p{L}\p{M}\p{N}'’-]+/gu) || []); }
function parse(raw) {
  var t = String(raw || '').trim(); if (!t) return null;
  for (var i = 0; i < PAT.length; i++) {
    var m = PAT[i][0].exec(t); if (!m) continue;
    var text = m[1].trim().replace(/^["“'‘]|["”'’]$/g, '').trim();
    var wc = words(text).length;
    if (wc < 3 && !/[぀-ヿ㐀-鿿가-힯]/.test(text)) return null;   /* one or two words: the dictionary handles those */
    return { mode: PAT[i][1], text: text.slice(0, MAXLEN), cut: text.length > MAXLEN, lang: PAT[i][2] || '' };
  }
  /* "summarize the history of India" is a question; a pasted paragraph after "summarize" is a text */
  var m2 = /^(?:summari[sz]e|simplify|explain)\s+([\s\S]+)$/i.exec(t);
  if (m2 && words(m2[1]).length >= 30) return { mode: /^summ/i.test(t) ? 'summary' : /^simp/i.test(t) ? 'simple' : 'explain', text: m2[1].trim().slice(0, MAXLEN), cut: m2[1].length > MAXLEN, lang: '' };
  return null;
}

/* ---------- offline analysis ---------- */
function sentences(t) { return String(t).split(/(?<=[.!?।॥。！？])\s+|\n+/).map(function (s) { return s.trim(); }).filter(function (s) { return /\p{L}/u.test(s); }); }
function syllables(w) { w = w.toLowerCase().replace(/[^a-z]/g, ''); if (w.length <= 3) return 1; w = w.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '').replace(/^y/, ''); var m = w.match(/[aeiouy]{1,2}/g); return m ? m.length : 1; }
var COMMON = {}; ('the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were been has had did said very more much many such').split(' ').forEach(function (w) { COMMON[w] = 1; });
function offline(text) {
  var d = root.lexiLingo ? root.lexiLingo.detect(text) : null;
  var ws = words(text), ss = sentences(text);
  var out = { lang: d, sentences: ss.length || 1, words: ws.length, minutes: Math.max(1, Math.round(ws.length / 200)) };
  if (d && d.code === 'en' && ws.length >= 5) {
    var syl = ws.reduce(function (n, w) { return n + syllables(w); }, 0);
    var fre = 206.835 - 1.015 * (ws.length / (ss.length || 1)) - 84.6 * (syl / ws.length);
    out.ease = Math.round(Math.max(0, Math.min(100, fre)));
    out.level = fre >= 80 ? 'very easy' : fre >= 60 ? 'easy' : fre >= 50 ? 'fairly hard' : fre >= 30 ? 'hard' : 'very hard (academic)';
  }
  return out;
}
/* everyday long words that are not "hard" */
var EASY = {};
('yesterday tomorrow question questions answer answers assistant business important different something everything anything nothing somebody everybody language languages children ' +
 'beautiful happened happening together actually probably remember possible interest interested interesting computer software hardware internet website telephone mobile ' +
 'customer customers company companies products quantity delivery shipping quotation discount address national international government education hospital mountain ' +
 'yourself himself herself ourselves themselves birthday weekend everyone sometimes whatever whenever wherever although continue continued complete completed problem ' +
 'problems solution solutions question information understand understood friendly favourite favorite morning evening afternoon midnight thousand hundred million ' +
 'february december november september thirteen fourteen eighteen nineteen seventeen practice practise exercise distance direction directions building buildings ' +
 'standard material materials electric electrical machine machines starting finished pleasure personal training learning teaching speaking reading writing working ' +
 'shopping cooking traveling travelling yourself necessary decision decisions question opinion position activity activities everyday increase increased decrease remember remembers progress interesting machines').split(' ').forEach(function (w) { EASY[w] = 1; });
/* meanings of the hardest English words, from the offline dictionary */
function hardWords(text, n) {
  var LD = root.lexiDict; if (!LD) return Promise.resolve([]);
  var seen = {}, cand = words(text).map(function (w) { return w.toLowerCase().replace(/['’]s$/, ''); })
    .filter(function (w) { if (seen[w] || COMMON[w] || EASY[w] || !/^[a-z-]{8,}$/.test(w)) return false; seen[w] = 1; return true; })
    .sort(function (a, b) { return b.length - a.length; }).slice(0, n || 6);
  return Promise.all(cand.map(function (w) { return LD.offline(w).then(function (e) { return e && !EASY[e.base] && !COMMON[e.base] ? { w: e.base, p: e.senses[0][0], d: e.senses[0][1] } : null; }).catch(function () { return null; }); }))
    .then(function (a) { return a.filter(Boolean); });
}

/* ---------- AI analysis ---------- */
function userLang(hint) {
  if (hint) return hint;
  try { var il = root.lexiI18n && root.lexiI18n.currentLang(); if (il) return il.name; } catch (e) { }
  try { var J = root.JTLANG, c = (root.CFG && root.CFG.lang) || 'en-IN', l = J && J.langBy(c.slice(0, 2)); if (l && l.c !== 'en') return l.name; } catch (e) { }
  return '';
}
var FOCUS = { explain: 'Focus on the meaning.', summary: 'Focus on a clear summary and key points.', simple: 'Focus on a very simple version a 12-year-old understands.', grammar: 'Focus on grammar and spelling corrections; keep the writer\'s meaning and tone.', words: 'Focus on the word-by-word meaning and the translation.' };
function prompt(text, mode, ul) {
  var sys = 'You are an expert linguist and teacher who understands every language, dialect, script, idiom, proverb, slang and writing style in the world. ' +
    'Analyse the user\'s text accurately. Never invent meanings: if a part is unclear or ambiguous, say so in "notes". ' + (FOCUS[mode] || FOCUS.explain) + ' ' +
    'Reply with ONLY one JSON object, no markdown, with these keys: ' +
    '"language" (name of the text\'s language, and dialect if clear), "meaning" (what the text means, in plain English, 1-4 sentences), ' +
    (ul && ul !== 'English' ? '"meaning_user" (the same meaning written in ' + ul + ', native script' + (/Hinglish/.test(ul) ? ', Roman letters' : '') + '), ' : '') +
    '"translation" (natural English translation, or "" if the text is already English), "simple" (the text rewritten in very simple words, same language as the text), ' +
    '"summary" (1-2 sentences, only if the text has 3 or more sentences, else ""), "key_points" (array of up to 6 short points, only for longer texts), ' +
    '"idioms" (array of {"phrase","meaning"} for idioms, proverbs, slang or figurative language; [] if none), ' +
    '"word_by_word" (array of {"word","meaning"} in English for each important word, max 20, only if the text has 25 words or fewer; [] otherwise), ' +
    '"grammar" ({"ok": true/false, "corrected": corrected text in the same language or "", "notes": array of short explanations}), ' +
    '"tone" (e.g. formal, friendly, angry, poetic, sarcastic, business), "notes" (anything ambiguous or cultural to know, or "").';
  return { sys: sys, user: 'TEXT:\n' + text };
}
function parseJSON(t) { var s = String(t || ''), a = s.indexOf('{'), b = s.lastIndexOf('}'); if (a < 0 || b <= a) throw new Error('no JSON'); return JSON.parse(s.slice(a, b + 1)); }
function analyseAI(text, mode, ul) {
  var I = root.lexiI18n; if (!I || !I.rawAI) return Promise.reject(new Error('AI not available'));
  var p = prompt(text, mode, ul);
  return I.rawAI(p.sys, p.user, 60000).then(parseJSON);
}

/* ---------- my sentences ---------- */
var KS = 'lexi_sentences', DAYS = [0, 1, 3, 7, 16, 35];
function list() { return L(KS, []); }
function save(text, a, lang) {
  var all = list().filter(function (x) { return x.text !== text; });
  all.push({ text: text.slice(0, 2000), lang: lang || '', meaning: a.meaning || '', mu: a.meaning_user || '', tr: a.translation || '', summary: a.summary || '', t: Date.now(), box: 0, due: Date.now() });
  S(KS, all.slice(-500));
}
function review(text, knew) { var all = list(), x = all.filter(function (y) { return y.text === text; })[0]; if (!x) return; x.box = knew ? Math.min(5, (x.box || 0) + 1) : 0; x.due = Date.now() + DAYS[x.box] * 864e5; S(KS, all); }
function remove(text) { S(KS, list().filter(function (y) { return y.text !== text; })); }
function due() { var now = Date.now(); return list().filter(function (y) { return (y.due || 0) <= now; }); }
function search(q) { q = String(q || '').toLowerCase(); return list().filter(function (x) { return (x.text + ' ' + x.meaning + ' ' + x.tr + ' ' + x.mu).toLowerCase().indexOf(q) >= 0; }); }

/* ---------- show the answer ---------- */
var CSS = '.lxs .lxs-h{font-size:.8em;font-weight:700;letter-spacing:.06em;text-transform:uppercase;opacity:.65;margin:12px 0 3px}.lxs .lxs-q{border-left:3px solid rgba(124,108,240,.6);padding:4px 10px;margin:4px 0 8px;opacity:.9;white-space:pre-wrap;max-height:220px;overflow:auto}' +
  '.lxs .lxs-chips{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0}.lxs .lxs-chip{font-size:.82em;padding:2px 9px;border-radius:999px;border:1px solid rgba(124,108,240,.4)}' +
  '.lxs table{border-collapse:collapse;width:100%;font-size:.92em}.lxs td{padding:3px 6px;border-bottom:1px solid rgba(127,127,127,.2);vertical-align:top}.lxs td:first-child{font-weight:600;white-space:nowrap}' +
  '.lxs ul{margin:2px 0 4px 18px;padding:0}.lxs .lxs-s{font-size:.8em;opacity:.6;margin-top:8px}.lxs .lxs-b{margin:8px 6px 0 0;padding:5px 10px;border-radius:10px;border:1px solid rgba(124,108,240,.45);background:transparent;color:inherit;font:inherit;font-size:.9em;cursor:pointer}';
function css() { if (!doc.getElementById('lxscss')) { var s = doc.createElement('style'); s.id = 'lxscss'; s.textContent = CSS; doc.head.appendChild(s); } }
var TITLE = { explain: 'Meaning', summary: 'Summary', simple: 'In simple words', grammar: 'Grammar check', words: 'Word by word' };
function head(o, text) {
  var chips = [];
  if (o.lang) chips.push('🌐 ' + (o.lang.romanized ? o.lang.name : o.lang.native + (o.lang.native !== o.lang.name ? ' · ' + o.lang.name : '')));
  chips.push(o.sentences + (o.sentences === 1 ? ' sentence' : ' sentences'), o.words + ' words', '⏱ ' + o.minutes + ' min read');
  if (o.level) chips.push('📖 ' + o.level + ' (' + o.ease + '/100)');
  return '<div class="lxs-q" data-noi18n>' + esc(text.length > 900 ? text.slice(0, 900) + '…' : text) + '</div><div class="lxs-chips">' + chips.map(function (c) { return '<span class="lxs-chip">' + esc(c) + '</span>'; }).join('') + '</div>';
}
function hardHTML(h) { return h.length ? '<div class="lxs-h">Hard words</div><table>' + h.map(function (x) { return '<tr><td data-noi18n>' + esc(x.w) + '</td><td data-noi18n>' + esc(x.d) + '</td></tr>'; }).join('') + '</table>' : ''; }
function aiHTML(a, mode, ul) {
  var h = '', sec = function (t, body) { if (body) h += '<div class="lxs-h">' + esc(t) + '</div>' + body; };
  var p = function (s) { return s ? '<div data-noi18n>' + esc(s) + '</div>' : ''; };
  var order = mode === 'grammar' ? ['grammar', 'meaning'] : mode === 'summary' ? ['summary', 'key', 'meaning'] : mode === 'simple' ? ['simple', 'meaning'] : mode === 'words' ? ['translation', 'words', 'meaning'] : ['meaning', 'translation', 'summary', 'key', 'simple'];
  ['meaning', 'translation', 'summary', 'key', 'simple', 'words', 'grammar'].forEach(function (k) { if (order.indexOf(k) < 0) order.push(k); });
  order.forEach(function (k) {
    if (k === 'meaning') { sec('Meaning', p(a.meaning)); if (a.meaning_user && ul) sec('Meaning in ' + ul, p(a.meaning_user)); }
    if (k === 'translation' && a.translation && a.translation !== a.meaning) sec('English translation', p(a.translation));
    if (k === 'summary') sec('Summary', p(a.summary));
    if (k === 'key' && a.key_points && a.key_points.length) sec('Key points', '<ul data-noi18n>' + a.key_points.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>');
    if (k === 'simple' && a.simple && a.simple !== a.meaning) sec('In simple words', p(a.simple));
    if (k === 'words' && a.word_by_word && a.word_by_word.length) sec('Word by word', '<table data-noi18n>' + a.word_by_word.map(function (x) { return '<tr><td>' + esc(x.word) + '</td><td>' + esc(x.meaning) + '</td></tr>'; }).join('') + '</table>');
    if (k === 'grammar' && a.grammar) {
      var g = a.grammar;
      if (g.ok === false || (g.notes && g.notes.length)) sec('Grammar', (g.ok === false && g.corrected ? '<div data-noi18n><b>Corrected:</b> ' + esc(g.corrected) + '</div>' : '') + (g.notes && g.notes.length ? '<ul data-noi18n>' + g.notes.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul>' : ''));
      else if (mode === 'grammar') sec('Grammar', '<div>✅ No mistakes found.</div>');
    }
  });
  if (a.idioms && a.idioms.length) sec('Idioms and expressions', '<table data-noi18n>' + a.idioms.map(function (x) { return '<tr><td>' + esc(x.phrase) + '</td><td>' + esc(x.meaning) + '</td></tr>'; }).join('') + '</table>');
  if (a.tone) sec('Tone', p(a.tone));
  if (a.notes) sec('Good to know', p(a.notes));
  return h;
}
function answer(pq, raw, fallback) {
  css();
  var o = offline(pq.text), ul = userLang(pq.lang);
  if (o.lang && o.lang.code !== 'en' && !ul) ul = '';
  var el = root.add('<div class="lxs"><div class="lxs-h">' + esc(TITLE[pq.mode] || 'Meaning') + '</div>' + head(o, pq.text) + '<div class="lxs-hard"></div><div class="lxs-ai"><span class="dots"><i></i><i></i><i></i></span> <small>Understanding the full meaning…</small></div>' + (pq.cut ? '<div class="lxs-s">Only the first 8,000 characters were analysed.</div>' : '') + '</div>', 'a');
  var box = el.querySelector('.lxs') || el;
  var isEn = !o.lang || o.lang.code === 'en';
  if (isEn) hardWords(pq.text, 6).then(function (h) { var x = box.querySelector('.lxs-hard'); if (x) x.innerHTML = hardHTML(h); });
  analyseAI(pq.text, pq.mode, ul).then(function (a) {
    var x = box.querySelector('.lxs-ai'); if (!x) return;
    x.innerHTML = aiHTML(a, pq.mode, ul) + '<div><button class="lxs-b" data-a="read">🔊 Read meaning</button><button class="lxs-b" data-a="more">💬 Ask more</button></div><div class="lxs-s">Saved to My sentences · ' + esc(a.language || (o.lang && o.lang.name) || '') + '</div>';
    save(pq.text, a, a.language || (o.lang && o.lang.name));
    try { root.remember(raw.slice(0, 1500), (a.meaning || '') + (a.translation ? '\nTranslation: ' + a.translation : '') + (a.summary ? '\nSummary: ' + a.summary : '')); } catch (e) { }
    x.querySelector('[data-a=read]').onclick = function () { try { root.speak(a.meaning_user || a.meaning || ''); } catch (e) { } };
    x.querySelector('[data-a=more]').onclick = function () { var t = doc.getElementById('t'); if (t) { t.value = 'About the text "' + pq.text.slice(0, 120) + (pq.text.length > 120 ? '…' : '') + '": '; t.focus(); } };
    try { root.speak(a.meaning_user || a.meaning || ''); } catch (e) { }
    try { root.log.scrollTop = root.log.scrollHeight; } catch (e) { }
  }).catch(function () {
    var x = box.querySelector('.lxs-ai'); if (!x) return;
    x.innerHTML = '<div class="lxs-s" style="opacity:.85">The full meaning needs the AI, which could not be reached. ' + (root.lexiAIServer && root.lexiAIServer.on() ? 'Try again in a moment.' : 'Set up the free company AI server (+ → Training Center → AI server) or add a key in Settings.') + '</div><button class="lxs-b" data-a="retry">↻ Try again</button>';
    x.querySelector('[data-a=retry]').onclick = function () { var r = el.closest('.row') || el; r.remove(); answer(pq, raw, fallback); };
  });
}

root.lexiSense = { parse: parse, answer: answer, offline: offline, hardWords: hardWords, analyse: analyseAI, list: list, save: save, review: review, remove: remove, due: due, search: search, aiHTML: aiHTML, head: head, css: css, sentences: sentences };
})(window);
