/* Lexi robot.js v30: the floating robot (v30: cropped WIDGET window = robot + Mic/keyboard/menu buttons + type box only; v29: Mini/Small/Normal/Large sizes in the desktop app).
   Widget: index.html?mode=widget or #widget, or ⋯ > Widget window / Widget on top, or say "open widget".
   Robot mode shows only Lexi's robot, with a mic ON/OFF button under it. Tap the robot to talk once,
   turn the mic ON for hands-free (Lexi keeps listening), and answers appear in a speech bubble.
   Open it with: + menu > Floating robot, the app shortcut "Floating robot", index.html#robot, ?mode=robot,
   or say "robot mode". Say "open full Lexi" or use the ⋯ menu to go back.
   Floating over other windows: ⋯ > Float on screen (Chrome/Edge on a computer), the Lexi desktop app
   (desktop/ folder) or the Android floating robot (android/ folder).
   Cloud mic: where the browser has no speech recognition (desktop app, Android app, Firefox), Lexi records
   the question and the company AI server (or your Gemini key) turns it into text. */
(function (root) {
'use strict';
var doc = root.document, KEY = 'lexi_robot';
function L(d) { try { var v = JSON.parse(localStorage.getItem(KEY)); return v && typeof v === 'object' ? Object.assign({}, d, v) : d; } catch (e) { return d; } }
function S() { try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) { } }
var P = L({ mic: false, start: false, x: null, y: null, cloud: false });
var Q = new URLSearchParams(location.search);
var DESK = !!root.lexiDesktop || Q.get('desktop') === '1';
var DROID = !!root.LexiAndroid || Q.get('embed') === 'android';
var ELECTRON = /Electron\//.test(navigator.userAgent);
var on = false, pip = null, el = null, bot = null, bub = null, micB = null, box = null, menu = null, hideT = 0;
function $(id) { return doc.getElementById(id); }
function hf() { return $('hf'); }
function g(n) { return root[n]; }

/* ================= cloud mic (speech to text through the AI server) ================= */
var cm = { stream: null, ctx: null, proc: null, src: null, active: false, stop: null };
function sttTarget() {
  var srv = root.lexiAIServer && root.lexiAIServer.on && root.lexiAIServer.on() ? root.lexiAIServer.url() : '';
  if (srv) return { kind: 'server', url: srv + '/v1/transcribe' };
  var C = root.CFG || {};
  if (C.gk) return { kind: 'gemini', key: C.gk };
  return null;
}
function needCloud() { return !g('SR') || ELECTRON || DROID || P.cloud; }
function wav16(chunks, rate) {
  var n = 0, i, j; for (i = 0; i < chunks.length; i++) n += chunks[i].length;
  var ratio = rate / 16000, outLen = Math.floor(n / ratio), pcm = new Int16Array(outLen), all = new Float32Array(n), o = 0;
  for (i = 0; i < chunks.length; i++) { all.set(chunks[i], o); o += chunks[i].length; }
  for (i = 0; i < outLen; i++) {   /* average the samples that fall into each 16 kHz step */
    var a = Math.floor(i * ratio), b = Math.min(n, Math.floor((i + 1) * ratio)), s = 0;
    for (j = a; j < b; j++) s += all[j];
    var v = b > a ? s / (b - a) : all[a] || 0; v = Math.max(-1, Math.min(1, v * 1.4));
    pcm[i] = v < 0 ? v * 0x8000 : v * 0x7fff;
  }
  var buf = new ArrayBuffer(44 + pcm.length * 2), d = new DataView(buf);
  function w(off, str) { for (var k = 0; k < str.length; k++) d.setUint8(off + k, str.charCodeAt(k)); }
  w(0, 'RIFF'); d.setUint32(4, 36 + pcm.length * 2, true); w(8, 'WAVE'); w(12, 'fmt '); d.setUint32(16, 16, true); d.setUint16(20, 1, true); d.setUint16(22, 1, true);
  d.setUint32(24, 16000, true); d.setUint32(28, 32000, true); d.setUint16(32, 2, true); d.setUint16(34, 16, true); w(36, 'data'); d.setUint32(40, pcm.length * 2, true);
  new Int16Array(buf, 44).set(pcm);
  return new Uint8Array(buf);
}
function b64(u8) { var s = '', i, step = 0x8000; for (i = 0; i < u8.length; i += step) s += String.fromCharCode.apply(null, u8.subarray(i, i + step)); return btoa(s); }
function transcribe(u8) {
  var t = sttTarget(), lang = (root.CFG && root.CFG.lang) || 'en-IN', audio = b64(u8);
  if (!t) return Promise.reject(new Error('nostt'));
  if (t.kind === 'server') return fetch(t.url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ audio: audio, mime: 'audio/wav', lang: lang }) })
    .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); }).then(function (j) { return String(j.text || '').trim(); });
  return fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(t.key), { method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ contents: [{ role: 'user', parts: [{ inlineData: { mimeType: 'audio/wav', data: audio } }, { text: 'Transcribe exactly what the speaker says (language code ' + lang + '), in the language and script they speak. Write only the words. If there is no clear speech, reply with nothing.' }] }], generationConfig: { temperature: 0, maxOutputTokens: 2048 } }) })
    .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    .then(function (j) { var c = j.candidates && j.candidates[0]; return c && c.content ? c.content.parts.map(function (p) { return p.text || ''; }).join('').trim() : ''; });
}
function releaseMic() {
  try { cm.proc && cm.proc.disconnect(); cm.src && cm.src.disconnect(); } catch (e) { }
  if (cm.stream) cm.stream.getTracks().forEach(function (t) { t.stop(); });
  if (cm.ctx) try { cm.ctx.close(); } catch (e) { }
  cm.stream = cm.ctx = cm.proc = cm.src = null;
}
function openMic() {
  if (cm.stream && cm.ctx && cm.ctx.state !== 'closed') return Promise.resolve();
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return Promise.reject(Object.assign(new Error('nomic'), { name: 'NoMic' }));
  return navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } }).then(function (s) {
    cm.stream = s; var AC = root.AudioContext || root.webkitAudioContext; cm.ctx = new AC();
    cm.src = cm.ctx.createMediaStreamSource(s);
  });
}
/* record one question: waits for speech, stops after a short silence */
function recordOnce() {
  return openMic().then(function () {
    return new Promise(function (resolve) {
      var ctx = cm.ctx, proc = ctx.createScriptProcessor(4096, 1, 1), chunks = [], pre = [], floor = null, cal = 0, started = false, loud = 0, quiet = 0, t0 = Date.now(), done = false;
      var per = 4096 / ctx.sampleRate, endQuiet = Math.ceil(1.1 / per), maxLen = Math.ceil(15 / per);
      if (ctx.state === 'suspended') ctx.resume();
      function finish(stoppedByUser) {
        if (done) return; done = true; cm.active = false; cm.stop = null;
        try { proc.disconnect(); cm.src.disconnect(proc); } catch (e) { }
        resolve(started || (stoppedByUser && chunks.length > 3) ? wav16(pre.concat(chunks), ctx.sampleRate) : null);
      }
      cm.active = true; cm.stop = function () { finish(true); };
      proc.onaudioprocess = function (e) {
        if (done) return;
        var x = new Float32Array(e.inputBuffer.getChannelData(0)), s = 0, i;
        for (i = 0; i < x.length; i += 4) s += x[i] * x[i];
        var rms = Math.sqrt(s / (x.length / 4));
        if (cal < 4) { floor = floor === null ? rms : Math.min(floor, rms); cal++; }
        var th = Math.max(0.012, (floor || 0) * 2.6);
        if (!started) {
          pre.push(x); if (pre.length > 4) pre.shift();
          loud = rms > th ? loud + 1 : 0;
          if (loud >= 2) { started = true; root.lexiRobot && root.lexiRobot._heard && root.lexiRobot._heard(); }
          else if (Date.now() - t0 > 7000) finish(false);
          return;
        }
        chunks.push(x);
        quiet = rms > th * 0.8 ? 0 : quiet + 1;
        if (quiet >= endQuiet || chunks.length >= maxLen) finish(false);
      };
      cm.src.connect(proc); proc.connect(ctx.destination);
    });
  });
}
function cloudListen() {
  var st = g('st'), orb = g('orb'), hfe = hf();
  if (cm.active) { cm.stop && cm.stop(); return; }
  if (g('listening')) return;
  if (!sttTarget()) {
    if (hfe) hfe.checked = false; setMicUI();
    if (st) st.textContent = 'Voice needs the AI server';
    var msg = 'To hear you here, Lexi needs the company AI server (+ → Training Center → AI server) or a Gemini key in ⚙️ Settings. You can type for now.';
    try { g('reply') ? g('reply')(g('esc')(msg), null, msg) : g('add')(msg, 'a'); } catch (e) { }
    return;
  }
  try { speechSynthesis.cancel(); } catch (e) { }
  root.listening = true; if (orb) orb.className = 'on'; if (st) st.textContent = 'Listening…';
  try { root.mood && root.mood('listen'); } catch (e) { }
  recordOnce().then(function (wav) {
    root.listening = false; if (orb && orb.className === 'on') orb.className = '';
    if (!wav) { if (st && st.textContent === 'Listening…') st.textContent = 'Tap the mic and speak'; try { root.mood(root.base()); } catch (e) { } if (!(hfe && hfe.checked)) releaseMic(); setTimeout(root.loop, 500); return; }
    if (!(hfe && hfe.checked)) releaseMic();
    if (st) st.textContent = 'Understanding…';
    try { root.mood('think'); } catch (e) { }
    return transcribe(wav).then(function (text) {
      if (text && !/^\(?(no (clear )?speech|silence|inaudible)\)?\.?$/i.test(text)) { if (st) st.textContent = text; root.handle(text); }
      else { if (st) st.textContent = 'I did not catch that'; try { root.mood(root.base()); } catch (e) { } setTimeout(root.loop, 600); }
    });
  }).catch(function (e) {
    root.listening = false; if (orb && orb.className === 'on') orb.className = '';
    try { root.mood(root.base()); } catch (x) { }
    var denied = e && (e.name === 'NotAllowedError' || e.name === 'SecurityError' || e.name === 'NoMic');
    if (denied) { if (hfe) hfe.checked = false; releaseMic(); setMicUI(); if (st) st.textContent = 'Please allow microphone access'; return; }
    if (st) st.textContent = 'Voice service busy, try again';
    if (hfe && hfe.checked) setTimeout(root.loop, 3000);
  });
}
/* Android app: the phone's own speech recognition and voice (no server needed) */
var AND = root.LexiAndroid, nat = { on: false };
function hasNative(f) { try { return !!(AND && AND[f] && (f !== 'hasSpeech' || AND.hasSpeech())); } catch (e) { return false; } }
function nativeListen() {
  var st = g('st'), orb = g('orb');
  if (nat.on) { try { AND.stopListening(); } catch (e) { } return; }
  if (root.listening) return;
  try { AND.stopSpeaking && AND.stopSpeaking(); } catch (e) { }
  nat.on = true; root.listening = true; if (orb) orb.className = 'on'; if (st) st.textContent = 'Listening…';
  try { root.mood && root.mood('listen'); } catch (e) { }
  try { AND.listen((root.CFG && root.CFG.lang) || 'en-IN'); } catch (e) { nat.on = false; root.listening = false; cloudListen(); }
}
function onNative(ev) {
  var st = g('st'), orb = g('orb'), h = hf();
  if (typeof ev === 'string') try { ev = JSON.parse(ev); } catch (e) { return; }
  if (!ev) return;
  if (ev.type === 'partial') { if (st && ev.text) st.textContent = ev.text; if (root.lexiRobot) root.lexiRobot._heard(); return; }
  if (ev.type === 'final' || ev.type === 'error' || ev.type === 'end') {
    if (!nat.on) return;
    nat.on = false; root.listening = false; if (orb && orb.className === 'on') orb.className = '';
    if (ev.type === 'final' && ev.text) { if (st) st.textContent = ev.text; root.handle(ev.text); return; }
    try { root.mood(root.base()); } catch (e) { }
    if (ev.type === 'error' && /permission/i.test(ev.text || '')) { if (h) h.checked = false; setMicUI(); if (st) st.textContent = 'Please allow microphone access'; return; }
    if (st && st.textContent === 'Listening…') st.textContent = '';
    setTimeout(root.loop, h && h.checked ? 300 : 600);
    return;
  }
  if (ev.type === 'tts-start') { root.speaking = true; if (orb) orb.className = 'talk'; try { root.mood('talk'); } catch (e) { } }
  if (ev.type === 'tts-end') { root.speaking = false; if (orb) orb.className = ''; if (st) st.textContent = ''; try { root.mood(root.base()); } catch (e) { } setTimeout(root.loop, 400); }
  syncState();
}
function installAndroid() {
  if (!AND || root.__lexiNative) return;
  root.__lexiNative = true;
  if (hasNative('speak')) root.speakB = function (t) {
    if (!root.SPK) return;
    t = String(t).replace(/<[^>]+>/g, ' ').replace(/[*`#_]/g, '').replace(/\s+/g, ' ').trim();
    if (t.length > 350) { t = t.slice(0, 350); t = t.slice(0, Math.max(t.lastIndexOf('. ') + 1, 200)); }
    try { AND.speak(t, (root.CFG && root.CFG.lang) || 'en-IN'); } catch (e) { }
  };
  if (hasNative('hasSpeech')) {
    root.__lexiCloudMic = true;
    root.listen = nativeListen;
    root.loop = function () { var h = hf(); if (h && h.checked && !root.listening && !root.speaking) nativeListen(); };
    var h = hf(); if (h) h.onchange = function () { if (h.checked) root.loop(); else if (nat.on) try { AND.stopListening(); } catch (e) { } setMicUI(); };
  }
}

function installCloud() {
  installAndroid();
  if (!needCloud() || root.__lexiCloudMic) return;
  root.__lexiCloudMic = true;
  root.listen = cloudListen;
  root.loop = function () { var h = hf(); if (h && h.checked && !root.listening && !root.speaking) cloudListen(); };
  var h = hf(); if (h) h.onchange = function () { if (h.checked) root.loop(); else { if (cm.active && cm.stop) cm.stop(); releaseMic(); } setMicUI(); };
}
root.lexiCloudMic = { listen: cloudListen, wav16: wav16, transcribe: transcribe, available: function () { return !!sttTarget(); }, active: function () { return cm.active; }, release: releaseMic };

/* ================= robot mode ================= */
var CSS = '' +
'html.robot-mode,html.robot-mode body{overflow:hidden!important;overscroll-behavior:none}' +
'html.robot-mode body>*:not(#robo):not(script):not(style):not(link):not(.robot-keep){display:none!important}' +
'html.robot-mode body{background:radial-gradient(circle at 50% 70%,#2b2f6b,#0f1230 70%)!important;min-height:100vh;margin:0}' +
'html.robot-mode.robot-clear,html.robot-mode.robot-clear body{background:transparent!important}' +
'#robo>*{flex:none}#robo{position:fixed;z-index:2147483000;display:flex;flex-direction:column;align-items:center;gap:6px;touch-action:none;font:14px/1.35 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#1a1a2e;-webkit-user-select:none;user-select:none}' +
'#robo .rb.rbx{width:128px;font-size:34px;cursor:grab;filter:drop-shadow(0 10px 18px rgba(0,0,0,.35))}' +
'#robo.drag .rb.rbx{cursor:grabbing}' +
'#robo .rbx .say,#robo .rbx .say2{display:none!important}' +
'#robo .ring{position:absolute;left:50%;width:118px;height:22px;margin-left:-59px;border-radius:50%;background:radial-gradient(ellipse,rgba(0,0,0,.28),transparent 70%);pointer-events:none}' +
'#robo.mic .ring{background:radial-gradient(ellipse,rgba(34,197,94,.75),transparent 70%);animation:robring 1.6s ease-in-out infinite}' +
'#robo.hear .ring{background:radial-gradient(ellipse,rgba(59,130,246,.85),transparent 70%)}' +
'@keyframes robring{50%{transform:scale(1.18);opacity:.6}}' +
'#robo .bub{max-width:min(270px,calc(100vw - 24px));max-height:150px;overflow:auto;background:#fff;border-radius:16px;padding:9px 12px;box-shadow:0 8px 26px rgba(0,0,0,.28);position:relative;font-size:13.5px;-webkit-user-select:text;user-select:text;display:none}' +
'#robo .bub.show{display:block;animation:robpop .25s ease-out}' +
'#robo .bub::after{content:"";position:absolute;left:50%;bottom:-7px;margin-left:-7px;border:7px solid transparent;border-bottom:0;border-top-color:#fff}' +
'#robo .bub .who{font-size:11.5px;color:#6b7090;margin-bottom:3px}#robo .bub p{margin:.2em 0}#robo .bub img,#robo .bub video,#robo .bub iframe{max-width:100%;max-height:90px}' +
'#robo .bub a{color:#4f46e5}#robo .bub pre{white-space:pre-wrap;font-size:12px}' +
'@keyframes robpop{from{opacity:0;transform:translateY(6px) scale(.96)}}' +
'#robo .ctl{display:flex;gap:6px;align-items:center}' +
'#robo .ctl button{border:0;cursor:pointer;font:600 13px system-ui,sans-serif;border-radius:999px;height:36px;padding:0 12px;background:#fff;color:#1a1a2e;box-shadow:0 4px 14px rgba(0,0,0,.25)}' +
'#robo .ctl .mic{min-width:96px;background:#e5e7eb;color:#374151;white-space:nowrap}' +
'#robo .ctl .mic.on{background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff}' +
'#robo .ctl .sm{width:36px;padding:0;font-size:16px}' +
'#robo .type{display:none;gap:4px}#robo .type.show{display:flex}' +
'#robo .type input{width:190px;border:0;border-radius:999px;padding:9px 12px;font:14px system-ui,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.25);outline:none}' +
'#robo .type button{border:0;border-radius:50%;width:36px;height:36px;background:#4f46e5;color:#fff;cursor:pointer}' +
'#robo .menu{position:absolute;bottom:44px;right:0;background:#fff;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.3);padding:5px;min-width:200px;display:none;z-index:2}' +
'#robo .menu.show{display:block}#robo .menu button{display:flex;gap:8px;width:100%;border:0;background:none;padding:9px 10px;border-radius:9px;font:14px system-ui,sans-serif;text-align:left;cursor:pointer;color:#1a1a2e}#robo .menu button:hover{background:#eef0ff}' +
'#robo .st{font-size:11.5px;color:#e5e7ff;text-shadow:0 1px 3px rgba(0,0,0,.6);min-height:15px;max-width:240px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
'html.robot-clear #robo .st{color:#1a1a2e;text-shadow:0 0 4px #fff,0 0 8px #fff}' +
'@media (prefers-reduced-motion:reduce){#robo .ring{animation:none!important}}' +
/* v29 sizes (desktop robot): Mini shows only the robot; its buttons appear when you point at it */
'#robo.sz-mini .rb.rbx{width:72px;font-size:19px}#robo.sz-mini .ring{width:66px;margin-left:-33px;height:14px}#robo.sz-mini .bub{max-height:118px;font-size:12.5px}' +
'#robo.sz-mini .st,#robo.sz-mini .ctl{display:none}#robo.sz-mini:hover .ctl,#robo.sz-mini.keep .ctl{display:flex}#robo.sz-mini .ctl .mic{min-width:0;padding:0 10px}' +
'#robo.sz-small .rb.rbx{width:96px;font-size:26px}#robo.sz-small .ring{width:88px;margin-left:-44px;height:18px}#robo.sz-small .bub{max-height:118px}#robo.sz-small .ctl .mic{min-width:84px}' +
'#robo.sz-large .rb.rbx{width:170px;font-size:45px}#robo.sz-large .ring{width:156px;margin-left:-78px;height:26px}#robo.sz-large .bub{max-height:190px;font-size:14.5px}' +
/* v30 widget: only the cropped area is shown - robot, status line, Mic/keyboard/menu buttons and the type box, always visible */
'html.widget-mode,html.widget-mode body{width:100%;height:100%;margin:0}' +
'html.widget-mode body{background:radial-gradient(circle at 50% 62%,#2d3275,#14173d 55%,#0b0d26 100%)!important}' +
'html.widget-mode #robo{left:50%!important;right:auto!important;top:auto!important;bottom:14px!important;transform:translateX(-50%)!important;width:calc(100% - 20px);max-width:380px;gap:7px}' +
'html.widget-mode #robo .bub{max-width:100%;width:max-content}' +
'html.widget-mode #robo .type{display:flex;width:100%;justify-content:center}html.widget-mode #robo .type input{flex:1;min-width:0;width:auto;max-width:280px}' +
'html.widget-mode #robo .st{color:#e5e7ff}' +
'html.widget-mode #robo .menu{bottom:92px;top:auto;right:auto;left:50%;transform:translateX(-50%);width:max-content;max-width:calc(100vw - 24px);max-height:calc(100vh - 140px);overflow:auto}' +
'#robo .ctl .menu button{height:auto;border-radius:9px;box-shadow:none;background:none;font:14px system-ui,sans-serif;white-space:nowrap;padding:8px 10px}#robo .ctl .menu button:hover{background:#eef0ff}';

function css(d) { if (d.getElementById('robocss')) return; var s = d.createElement('style'); s.id = 'robocss'; s.textContent = CSS; d.head.appendChild(s); }
function src() { return doc.querySelector('.rb.hd') || doc.querySelector('.rb.lg'); }
function build() {
  if (el) return el;
  css(doc);
  el = doc.createElement('div'); el.id = 'robo'; el.setAttribute('role', 'region'); el.setAttribute('aria-label', 'Lexi floating robot');
  el.innerHTML = '<div class="bub" aria-live="polite"></div><div class="rb lg rbx" role="button" tabindex="0" aria-label="Tap to talk to Lexi"></div><div class="ring"></div>' +
    '<div class="st"></div><div class="ctl"><button class="mic" aria-pressed="false" title="Mic on/off (hands-free listening)">🎙️ Mic OFF</button>' +
    '<button class="sm kb" title="Type to Lexi" aria-label="Type">⌨️</button><button class="sm more" title="More" aria-label="More options">⋯</button><div class="menu" role="menu"></div></div>' +
    '<div class="type"><input type="text" placeholder="Type to Lexi…" aria-label="Type to Lexi" enterkeyhint="send"><button aria-label="Send">➤</button></div>';
  bot = el.querySelector('.rbx'); bub = el.querySelector('.bub'); micB = el.querySelector('.mic'); box = el.querySelector('.type'); menu = el.querySelector('.menu');
  var s = src();
  if (s) {
    bot.innerHTML = s.innerHTML; bot.querySelectorAll('.pt,.say2').forEach(function (x) { x.remove(); });
    bot._anim = !!s._anim; bot.setAttribute('data-m', s.getAttribute('data-m') || 'idle');
    new MutationObserver(function () { bot.setAttribute('data-m', s.getAttribute('data-m') || 'idle'); ['wave', 'wake'].forEach(function (c) { bot.classList.toggle(c, s.classList.contains(c)); }); syncState(); })
      .observe(s, { attributes: true, attributeFilter: ['data-m', 'class'] });
  } else bot.innerHTML = '<img src="robot.png" alt="" style="width:100%">';
  /* the ring sits just under the robot's feet */
  el.querySelector('.ring').style.top = '0px';
  wire();
  return el;
}
function placeRing() { var r = el && el.querySelector('.ring'); if (r && bot) r.style.top = (bot.offsetTop + bot.offsetHeight - 14) + 'px'; }

/* ---------- speech bubble ---------- */
function showBubble(html, who, ms) {
  if (!bub) return;
  bub.innerHTML = (who ? '<div class="who"></div>' : '') + '<div class="tx"></div>';
  if (who) bub.firstChild.textContent = who;
  var tx = bub.lastChild; if (typeof html === 'string') tx.textContent = html; else tx.appendChild(html);
  bub.classList.add('show'); bub.scrollTop = 0; placeRing(); keepInView();
  clearTimeout(hideT); if (ms) hideT = setTimeout(function () { bub.classList.remove('show'); placeRing(); keepInView(); }, ms);
}
function answerNode(m) {
  var c = m.cloneNode(true);
  c.querySelectorAll('script,style,audio,select,.dots,.src,.jt-tools,button,input,textarea').forEach(function (x) { x.remove(); });
  c.querySelectorAll('[id]').forEach(function (x) { x.removeAttribute('id'); });
  c.querySelectorAll('a').forEach(function (a) { a.target = '_blank'; a.rel = 'noopener'; });
  return c;
}
var lastAns = null;
function watchLog() {
  var log = $('log'); if (!log) return;
  var t = 0;
  new MutationObserver(function () {
    clearTimeout(t); t = setTimeout(function () {
      if (!on) return;
      var rows = log.querySelectorAll('.row.a .m'), m = rows[rows.length - 1];
      if (!m) return;
      if (m.querySelector('.dots') || !m.textContent.trim()) { showBubble('Thinking…', '', 0); return; }
      var txt = m.textContent.trim(), ms = Math.min(45000, 9000 + txt.length * 60);
      if (m !== lastAns || bub.dataset.len !== String(txt.length)) {
        lastAns = m; bub.dataset.len = txt.length; var node = answerNode(m); showBubble(node, 'Lexi', ms);
        if (AND && AND.bubble) { clearTimeout(watchLog._a); watchLog._a = setTimeout(function () { try { AND.bubble(node.textContent.replace(/\s+/g, ' ').trim()); } catch (e) { } }, 900); }
      }
    }, 120);
  }).observe(log, { childList: true, subtree: true, characterData: true });
}
function watchStatus() {
  var st = $('st'); if (!st) return;
  new MutationObserver(function () { syncState(); }).observe(st, { childList: true, subtree: true, characterData: true });
}
function syncState() {
  if (!el) return;
  var st = $('st'), s = st ? st.textContent.trim() : '', lis = !!root.listening, h = hf();
  el.classList.toggle('mic', !!(h && h.checked)); el.classList.toggle('hear', lis);
  var line = el.querySelector('.st');
  if (lis) line.textContent = s && s !== 'Listening…' ? '🎙️ ' + s : '🎙️ Listening…';
  else if (root.speaking) line.textContent = '🔊 Speaking… (tap me to stop)';
  else if (/Understanding|Thinking/.test(s)) line.textContent = s;
  else if (h && h.checked) line.textContent = 'Mic on — just talk';
  else line.textContent = s && s.length < 60 && !/^Tap the mic/.test(s) ? s : 'Tap me to talk';
  setMicUI();
}
function setMicUI() {
  if (!micB) return;
  var h = hf(), onn = !!(h && h.checked);
  micB.classList.toggle('on', onn); micB.setAttribute('aria-pressed', String(onn)); micB.textContent = onn ? '🎙️ Mic ON' : '🎙️ Mic OFF';
  el.classList.toggle('mic', onn);
}

/* ---------- mic ---------- */
function setMic(v, quiet) {
  var h = hf(); if (!h) return;
  v = !!v;
  if (h.checked !== v) { h.checked = v; try { h.onchange && h.onchange(); } catch (e) { } }
  if (!v) { try { root.rec && root.rec.stop(); if (nat.on) AND.stopListening(); } catch (e) { } if (cm.active && cm.stop) cm.stop(); releaseMic(); }
  P.mic = v; S(); setMicUI(); syncState();
  if (!quiet) showBubble(v ? 'Mic is ON. I am listening — just talk to me.' : 'Mic is OFF. Tap me when you want to talk.', '', 3500);
  if (root.lexiDesktop && root.lexiDesktop.micState) try { root.lexiDesktop.micState(v); } catch (e) { }
  if (root.LexiAndroid && root.LexiAndroid.micState) try { root.LexiAndroid.micState(v); } catch (e) { }
}
function talkOnce() {
  if (root.speaking) { try { if (root.NA) root.NA.pause(); speechSynthesis.cancel(); if (AND && AND.stopSpeaking) AND.stopSpeaking(); } catch (e) { } root.speaking = false; var o = g('orb'); if (o) o.className = ''; syncState(); return; }
  try { root.wake && root.wake(); } catch (e) { }
  try { root.listen(); } catch (e) { }
}

/* ---------- drag (inside the page, or the whole window in the desktop app) ---------- */
function keepInView() {
  if (!el || pip || DESK || DROID || el.dataset.center) return;
  var r = el.getBoundingClientRect(), W = innerWidth, H = innerHeight;
  var x = Math.min(Math.max(4, r.left), Math.max(4, W - r.width - 4)), y = Math.min(Math.max(4, r.top), Math.max(4, H - r.height - 4));
  el.style.left = x + 'px'; el.style.top = y + 'px'; el.style.right = el.style.bottom = 'auto';
}
function position() {
  if (!el) return;
  var small = innerWidth < 420 || pip || DESK || DROID;
  el.style.left = el.style.top = el.style.right = el.style.bottom = '';
  if (small) { el.dataset.center = '1'; el.style.left = '50%'; el.style.bottom = '10px'; el.style.transform = 'translateX(-50%)'; return; }
  delete el.dataset.center; el.style.transform = '';
  if (P.x !== null && P.y !== null) { el.style.left = P.x + 'px'; el.style.top = P.y + 'px'; requestAnimationFrame(keepInView); }
  else { el.style.right = '24px'; el.style.bottom = '20px'; }
}
function wire() {
  var sx = 0, sy = 0, ox = 0, oy = 0, moved = false, down = false, lastX = 0, lastY = 0, longT = 0, longDone = false;
  bot.addEventListener('pointerdown', function (e) {
    if (e.button > 0) return;
    down = true; moved = false; longDone = false; sx = lastX = e.screenX; sy = lastY = e.screenY;
    var r = el.getBoundingClientRect(); ox = r.left; oy = r.top;
    try { bot.setPointerCapture(e.pointerId); } catch (x) { }
    clearTimeout(longT); longT = setTimeout(function () { if (!moved) { longDone = true; toggleMenu(true); } }, 650);
  });
  bot.addEventListener('pointermove', function (e) {
    if (!down) return;
    var dx = e.screenX - sx, dy = e.screenY - sy;
    if (!moved && Math.abs(dx) + Math.abs(dy) < 6) return;
    if (!moved) { moved = true; clearTimeout(longT); el.classList.add('drag'); }
    if (root.lexiDesktop && root.lexiDesktop.moveBy) { root.lexiDesktop.moveBy(e.screenX - lastX, e.screenY - lastY); lastX = e.screenX; lastY = e.screenY; return; }
    if (pip || DROID) return;
    delete el.dataset.center; el.style.transform = ''; el.style.right = el.style.bottom = 'auto';
    el.style.left = (ox + dx) + 'px'; el.style.top = (oy + dy) + 'px';
  });
  function up() {
    if (!down) return; down = false; clearTimeout(longT); el.classList.remove('drag');
    if (moved) { if (!el.dataset.center && !DESK) { keepInView(); var r = el.getBoundingClientRect(); P.x = Math.round(r.left); P.y = Math.round(r.top); S(); } if (root.lexiDesktop && root.lexiDesktop.moved) root.lexiDesktop.moved(); return; }
    if (longDone) return;
    talkOnce();
  }
  bot.addEventListener('pointerup', up); bot.addEventListener('pointercancel', function () { down = false; clearTimeout(longT); el.classList.remove('drag'); });
  bot.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); talkOnce(); } });
  bot.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  micB.onclick = function () { var h = hf(); setMic(!(h && h.checked)); };
  el.querySelector('.kb').onclick = function () { box.classList.toggle('show'); el.classList.toggle('keep', box.classList.contains('show')); if (box.classList.contains('show')) box.querySelector('input').focus(); placeRing(); keepInView(); };
  el.querySelector('.more').onclick = function (e) { e.stopPropagation(); toggleMenu(); };
  var inp = box.querySelector('input');
  function sendTyped() { var v = inp.value.trim(); if (!v) return; inp.value = ''; root.handle(v); }
  inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); sendTyped(); } if (e.key === 'Escape') box.classList.remove('show'); });
  box.querySelector('button').onclick = sendTyped;
  bub.addEventListener('click', function () { clearTimeout(hideT); });
  el.ownerDocument.addEventListener('click', function (e) { if (menu && !menu.contains(e.target) && !e.target.closest('.more')) { menu.classList.remove('show'); el.classList.toggle('keep', box.classList.contains('show')); } });
}
function toggleMenu(force) {
  var show = force === true ? true : !menu.classList.contains('show');
  menu.innerHTML = '';
  function item(icon, label, fn) { var b = el.ownerDocument.createElement('button'); b.setAttribute('role', 'menuitem'); b.innerHTML = '<span></span><span></span>'; b.firstChild.textContent = icon; b.lastChild.textContent = label; b.onclick = function (e) { e.stopPropagation(); menu.classList.remove('show'); fn(); }; menu.appendChild(b); }
  var h = hf();
  item('🎙️', h && h.checked ? 'Mic OFF' : 'Mic ON (hands-free)', function () { setMic(!(h && h.checked)); });
  item('🗣️', 'Talk once', talkOnce);
  var vol = $('vol'); if (vol) item('🔊', 'Spoken replies on/off', function () { vol.click(); showBubble(String(vol.textContent).indexOf('🔇') >= 0 ? 'Spoken replies OFF' : 'Spoken replies ON', '', 2500); });
  if (root.lexiDesktop) {
    item('🗔', 'Open full Lexi', function () { root.lexiDesktop.openFull(); });
    if (root.lexiDesktop.setSize) [['mini', 'Mini'], ['small', 'Small'], ['normal', 'Normal'], ['large', 'Large']].forEach(function (z) {
      item(curSize === z[0] ? '🔘' : '⚪', 'Size: ' + z[1], function () { root.lexiDesktop.setSize(z[0]); });
    });
    item('🙈', 'Hide robot (Ctrl+Shift+L)', function () { root.lexiDesktop.hide(); });
    /* Quit is only in the tray menu (near the clock), so the robot is never closed by a mis-tap */
  } else if (root.LexiAndroid) {
    item('🗔', 'Open full Lexi here', exit);
    item('➖', 'Minimise to bubble', function () { root.LexiAndroid.minimize(); });
    item('✖', 'Close floating robot', function () { root.LexiAndroid.close(); });
  } else {
    if (pip) item('↩️', 'Back into the browser tab', function () { try { pip.close(); } catch (e) { } });
    else {
      item('📌', 'Widget on top of all windows', function () { floatOnScreen(true); });
      item('🪟', 'Widget in its own window', openWidgetWindow);
      item('📍', 'Float robot only (on top)', function () { floatOnScreen(); });
    }
    if (isWidgetPage() && !pip) { item('🗔', 'Open full Lexi in a tab', function () { try { root.open(location.pathname.split('/').pop() || 'index.html', '_blank'); } catch (e) { } try { root.close(); } catch (e) { } }); item('✖', 'Close this widget', function () { try { root.close(); } catch (e) { } showBubble('Close this window with its ✕ button.', '', 4000); }); }
    else item('🗔', 'Open full Lexi', exit);
    item(P.start ? '☑️' : '⬜', 'Always start in robot mode', function () { P.start = !P.start; S(); showBubble(P.start ? 'Lexi will open as the floating robot.' : 'Lexi will open normally.', '', 2500); });
  }
  menu.classList.toggle('show', show);
  el.classList.toggle('keep', show || box.classList.contains('show'));
}

/* ---------- Document Picture-in-Picture: the robot floats above every window ---------- */
function floatOnScreen(asWidget) {
  asWidget = asWidget === true;
  if (!root.documentPictureInPicture) {
    showBubble('Floating above other windows works in Chrome or Edge on a computer. On a phone, use the Lexi Android floating robot; on Windows/Mac/Linux you can also install the Lexi desktop robot.', '', 12000);
    return;
  }
  if (pip) return;
  root.documentPictureInPicture.requestWindow(asWidget ? { width: WIDGET_W, height: WIDGET_H } : { width: 290, height: 400 }).then(function (w) {
    pip = w;
    [].forEach.call(doc.querySelectorAll('style,link[rel=stylesheet]'), function (s) { w.document.head.appendChild(s.cloneNode(true)); });
    w.document.documentElement.className = 'robot-mode' + (asWidget ? ' widget-mode' : '');
    w.document.title = 'Lexi';
    if (asWidget) { box.classList.add('show'); el.classList.add('keep'); }
    w.document.body.appendChild(el);
    el.ownerDocument.addEventListener('click', function (e) { if (menu && !menu.contains(e.target) && !e.target.closest('.more')) menu.classList.remove('show'); });
    position();
    showBubble('I float on top now. Tap me to talk, type below, or turn the mic ON.', '', 5000); setTimeout(placeRing, 150);
    w.addEventListener('pagehide', function () { pip = null; doc.body.appendChild(el); if (asWidget && !isWidgetPage()) { box.classList.remove('show'); el.classList.remove('keep'); } position(); placeRing(); });
  }).catch(function () { showBubble('Could not open the floating window. Click the ⋯ button again.', '', 5000); });
}

/* ---------- v30 widget: the cropped window (robot + Mic OFF / keyboard / menu buttons + type box) ---------- */
var WIDGET_W = 400, WIDGET_H = 470;
function isWidgetPage() { return Q.get('mode') === 'widget' || location.hash === '#widget'; }
function widgetStyle(on_) { doc.documentElement.classList.toggle('widget-mode', !!on_); if (box) { box.classList.toggle('show', !!on_ || box.classList.contains('show')); el.classList.toggle('keep', !!on_); } placeRing(); }
function openWidgetWindow() {
  var w = null, left = Math.max(0, (screen.availWidth || 1200) - WIDGET_W - 40), top = Math.max(0, (screen.availHeight || 800) - WIDGET_H - 80);
  try { w = root.open((location.href.split('#')[0].split('?')[0]) + '?mode=widget', 'lexi_widget', 'popup=yes,width=' + WIDGET_W + ',height=' + WIDGET_H + ',left=' + left + ',top=' + top + ',resizable=yes'); } catch (e) { }
  if (!w) showBubble('The browser blocked the widget window. Allow pop-ups for this page, then try again.', '', 8000);
  else showBubble('Widget window opened. You can drag it anywhere.', '', 3000);
}
function widgetOnTop() {
  if (root.documentPictureInPicture) floatOnScreen(true); else openWidgetWindow();
}
function fitWidgetWindow() {
  /* when Lexi is the widget popup, make its page area exactly the widget size */
  if (!isWidgetPage()) return;
  try { root.resizeBy(WIDGET_W - root.innerWidth, WIDGET_H - root.innerHeight); } catch (e) { }
}

var curSize = 'normal';
function applySize(s) {
  if (!el || !/^(mini|small|normal|large)$/.test(s)) return;
  curSize = s; el.classList.remove('sz-mini', 'sz-small', 'sz-normal', 'sz-large'); el.classList.add('sz-' + s);
  requestAnimationFrame(placeRing); setTimeout(placeRing, 200);
}
function enter(opts) {
  if (on) return;
  build(); on = true;
  if (root.lexiDesktop && root.lexiDesktop.size) { applySize(root.lexiDesktop.size); if (root.lexiDesktop.onSize) root.lexiDesktop.onSize(applySize); }
  installCloud();
  doc.documentElement.classList.add('robot-mode');
  if (DESK) { doc.documentElement.classList.add('robot-clear'); if (!DROID && !(root.lexiDesktop && root.lexiDesktop.size === 'mini')) { box.classList.add('show'); el.classList.add('keep'); } }
  if (isWidgetPage()) { widgetStyle(true); try { doc.title = 'Lexi'; } catch (e) { } setTimeout(fitWidgetWindow, 50); }
  if (!el.parentNode) doc.body.appendChild(el);
  position(); setMicUI(); syncState();
  requestAnimationFrame(placeRing); setTimeout(placeRing, 300);
  if (P.mic && !(opts && opts.noMic)) setTimeout(function () { setMic(true, true); }, 600);
  if (!(opts && opts.quiet)) showBubble('Hi! Tap me to talk, or turn the mic ON below and just speak.', '', 6000);
  if (location.hash !== '#robot' && !(opts && opts.keepUrl)) try { history.replaceState(null, '', location.pathname + location.search + '#robot'); } catch (e) { }
  root.dispatchEvent(new CustomEvent('lexi-robot', { detail: { on: true } }));
}
function exit() {
  if (!on) return;
  on = false;
  if (pip) try { pip.close(); } catch (e) { }
  doc.documentElement.classList.remove('robot-mode', 'robot-clear', 'widget-mode');
  if (el && el.parentNode) el.remove();
  if (location.hash === '#robot') try { history.replaceState(null, '', location.pathname + location.search.replace(/([?&])mode=robot&?/, '$1').replace(/[?&]$/, '')); } catch (e) { }
  root.dispatchEvent(new CustomEvent('lexi-robot', { detail: { on: false } }));
}

/* ---------- voice / typed commands ---------- */
var CMD = [
  [/^(?:open|start|show|launch|go to|switch to)?\s*(?:the\s+)?(?:lexi\s+)?(?:mini\s+window|floating\s+widget|widget(?:\s+window)?|small\s+window)(?:\s+on)?$/i, 'widget'],
  [/^(?:turn\s+|switch\s+)?(?:the\s+)?(?:mic|microphone|mike)\s+(?:on|off)$|^(?:turn|switch)\s+(?:on|off)\s+(?:the\s+)?(?:mic|microphone|mike)$|^(?:start|stop)\s+listening$|^(?:माइक|mic)\s+(?:on|off|चालू|बंद)(?:\s+(?:करो|कर दो))?$/i, 'mic'],
  [/^(?:open|start|show|go to|switch to|turn on)?\s*(?:the\s+)?(?:floating\s+robot|robot\s+mode)(?:\s+on)?$/i, 'robot'],
  [/^(?:exit|close|leave|stop|turn off)\s+(?:the\s+)?(?:floating\s+robot|robot\s+mode)$|^(?:robot\s+mode\s+off)$|^(?:open|show)\s+(?:the\s+)?full\s+(?:lexi|app)$/i, 'full']
];
function command(raw) {
  var t = String(raw || '').trim().replace(/[.!?।]+$/, '').replace(/^(?:hey\s+|ok\s+)?lexi[,\s]+/i, '').replace(/^please\s+|\s+please$/ig, '').trim();
  if (!t || t.length > 60) return false;
  if (/^robot$/i.test(t) && on) return true;   /* index.html#robot start-up link: already handled */
  for (var i = 0; i < CMD.length; i++) {
    var m = CMD[i][0].exec(t); if (!m) continue;
    var k = CMD[i][1], say = '';
    if (k === 'mic') {
      var want = /\b(on|start)\b|चालू/i.test(t) && !/\b(off|stop)\b|बंद/i.test(t);
      setMic(want, true); say = want ? 'Mic is on. I am listening — just talk to me.' : 'Mic is off. Tap me or the mic button when you need me.';
    } else if (k === 'widget') { if (!on) enter({ quiet: true }); widgetOnTop(); say = root.documentPictureInPicture ? 'Opening the widget on top of your windows.' : 'Opening the widget window.'; }
    else if (k === 'robot') { if (on) say = 'I am already the floating robot. Tap me to talk.'; else { enter({ quiet: true }); say = 'Floating robot mode is on. Tap me to talk, or turn the mic on below me.'; } }
    else { if (root.lexiDesktop) { root.lexiDesktop.openFull(); say = 'Opening full Lexi.'; } else { exit(); say = 'Here is the full Lexi app.'; } }
    try { g('add')(g('esc')(String(raw).trim()), 'u'); g('reply')(g('esc')(say), null, say); } catch (e) { }
    return true;
  }
  return false;
}
function hook() {
  var h = root.handle; if (typeof h !== 'function' || h._robot) return;
  var w = function (raw) { if (command(raw)) { var i = g('inp'); if (i) i.value = ''; return; } return h.apply(this, arguments); };
  w._robot = true; root.handle = w;
}

/* ---------- header button (shows in the + menu) and start-up ---------- */
function addButton() {
  var hd = doc.querySelector('header'), gear = $('gear'); if (!hd || doc.getElementById('robob')) return;
  var b = doc.createElement('button'); b.id = 'robob'; b.className = 'ib'; b.title = 'Floating robot'; b.setAttribute('aria-label', 'Floating robot'); b.textContent = '🤖';
  b.onclick = function () { enter(); };
  hd.insertBefore(b, gear || null);
}
function wantRobot() { return location.hash === '#robot' || isWidgetPage() || Q.get('mode') === 'robot' || DESK || DROID || (P.start && !Q.get('mode')); }
function init() {
  addButton(); hook(); watchLog(); watchStatus();
  if (needCloud()) installCloud();
  if (wantRobot()) enter({ quiet: false, keepUrl: DESK || DROID });
  root.addEventListener('hashchange', function () { if (location.hash === '#robot' || location.hash === '#widget') enter(); });
  root.addEventListener('resize', function () { if (on) { position(); placeRing(); } });
  setInterval(function () { if (on) syncState(); }, 1000);
  /* desktop app: clicks pass through the empty, transparent parts of the window */
  if (root.lexiDesktop && root.lexiDesktop.clickThrough) {
    var last = null;
    doc.addEventListener('mousemove', function (e) {
      var d = (pip ? pip.document : doc), inside = !!(e.target && e.target.closest && e.target.closest('#robo .bub,#robo .rbx,#robo .ctl,#robo .type,#robo .menu,#robo .st'));
      if (inside !== last) { last = inside; root.lexiDesktop.clickThrough(!inside); }
    });
  }
}
root.lexiRobot = { enter: enter, exit: exit, isOn: function () { return on; }, setMic: setMic, toggleMic: function () { var h = hf(); setMic(!(h && h.checked)); }, talk: talkOnce, float: floatOnScreen, widget: widgetOnTop, widgetWindow: openWidgetWindow, command: command, prefs: function () { return P; }, _native: onNative, _heard: function () { if (el) el.classList.add('hear'); } };
if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init); else init();
/* other modules wrap handle() after load; keep the robot commands on the outside */
root.addEventListener('load', function () { setTimeout(hook, 0); setTimeout(hook, 1500); });
})(window);
