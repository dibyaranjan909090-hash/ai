/* Lexi smart.js
   Creator identity, coding mode (code blocks you can copy, download and run),
   calculator hookup and the Photo Studio (restyle and customise any picture).
   Loaded last, so it sees every message first. */
(function (root) {
'use strict';

/* ======================= PURE LOGIC ======================= */
var CREATOR = 'ER Dibyaranjan';
var WHO_CREATED = /\b(?:who|whom)\s+(?:has\s+|have\s+|had\s+)?(?:created|made|built|developed|designed|programmed|coded|invented|owns|own|started|founded|trained)\s+(?:you|lexi|jaan|this\s+(?:app|assistant|application|bot))\b|\bwho(?:'s| is)\s+your\s+(?:creator|developer|owner|maker|founder|inventor|programmer|father|boss|author)\b|\bwho(?:'s| is)\s+the\s+(?:creator|developer|owner|maker|founder|inventor)\s+of\s+(?:you|lexi|jaan|this\s+(?:app|assistant|application|bot))\b|\byour\s+(?:creator|developer|owner|maker|founder|inventor|programmer)\b|\bhow\s+(?:were\s+you|was\s+(?:lexi|jaan)|are\s+you)\s+(?:created|made|built|developed)\b|\bhow\s+(?:did|do|does|can)\s+\w+\s+(?:create|make|build|develop)\s+(?:you|lexi|jaan)\b|\bhow\s+(?:create|created|made|built)\s+(?:you|lexi|jaan)\b|\b(?:tumhe|tujhe|aapko|apko|tumko)\s+kisne\s+(?:banaya|banaaya|create|design)|\b(?:tumhara|aapka|tera)\s+(?:creator|owner|developer|malik|banane\s?wala)\b|\bkisne\s+banaya\b/i;
var WHO_ARE_YOU = /^(?:who\s+are\s+you|what(?:'s|\s+is)\s+your\s+name|your\s+name|introduce\s+yourself|tell\s+me\s+about\s+yourself|what\s+are\s+you)$/i;
var ABOUT_CREATOR = /\bwho(?:'s| is)\s+(?:er\.?\s+)?dibyaranjan\b|\bdibyaranjan\b.*\b(?:who|creator|developer)\b/i;
function identityAnswer(text) {
  var s = String(text).toLowerCase().replace(/[?!.]+$/g, '').replace(/\s+/g, ' ').trim();
  if (ABOUT_CREATOR.test(s)) return CREATOR + ' is my creator. He built Lexi, the voice assistant you are talking to.';
  if (WHO_CREATED.test(s) && s.length < 90) return CREATOR + ' created me. I am Lexi, your voice assistant.';
  if (WHO_ARE_YOU.test(s)) return 'I am Lexi, a voice assistant created by ' + CREATOR + '. I can set alarms, call and message your contacts, translate and read aloud in many languages, write and fix code, solve maths, and restyle your photos.';
  return null;
}
var CMD_START = /^(?:call|dial|whatsapp|whats app|message|msg|text|sms|alarm|remind|set\s|note|play|open|translate|read|say|send|show|delete|cancel|navigate|weather|news|spent|save|email|share|tell|switch|speak|good morning|import|snooze)\b/i;
/* pasted code, fenced blocks, or several lines */
function isCodeInput(s) {
  s = String(s || '');
  if (/```/.test(s)) return true;
  var lines = s.split('\n').filter(function (l) { return l.trim(); });
  if (lines.length >= 3) return true;
  return s.length > 50 && /[{};]\s*$|=>|\bdef\s+\w+\(|\bfunction\b|\bclass\s+\w+|#include|<\/?[a-z][a-z0-9]*[^>]*>|\bSELECT\b[\s\S]*\bFROM\b|console\.log|System\.out|\bprint\(|\bimport\s+[\w.{]+|\breturn\b.*;/i.test(s);
}
var CODE_WORDS = /\b(?:code|coding|program|programming|script|function|method|class|variable|array|loop|bug|bugs|error|errors|exception|stack ?trace|compile|compiler|debug|refactor|algorithm|regex|sql|query|database|api|endpoint|html|css|javascript|typescript|python|java|c\+\+|c#|kotlin|swift|php|ruby|golang|rust|react|angular|vue|node(?:\.?js)?|flutter|django|flask|spring|json|xml|yaml|dockerfile|docker|bash|powershell|shell script|git|arduino|esp32|raspberry pi|plc|matlab|verilog|vhdl|json|unit test|leetcode|data structure|linked list|binary tree|recursion|oop)\b/i;
function isCodingRequest(s) {
  s = String(s || '').trim();
  if (!s || CMD_START.test(s)) return false;
  if (isCodeInput(s)) return true;
  return CODE_WORDS.test(s) && /\b(?:write|create|make|build|generate|fix|solve|debug|convert|explain|optimi[sz]e|improve|add|implement|develop|code|program|rewrite|refactor|translate|complete|find|resolve|why|how|error|bug)\b/i.test(s) && s.split(/\s+/).length >= 4;
}
var EXT = { javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', python: 'py', py: 'py', java: 'java', c: 'c', cpp: 'cpp', 'c++': 'cpp', csharp: 'cs', 'c#': 'cs', go: 'go', rust: 'rs', php: 'php', ruby: 'rb', swift: 'swift', kotlin: 'kt', html: 'html', css: 'css', json: 'json', xml: 'xml', yaml: 'yml', yml: 'yml', sql: 'sql', bash: 'sh', sh: 'sh', shell: 'sh', powershell: 'ps1', markdown: 'md', md: 'md', jsx: 'jsx', tsx: 'tsx', dart: 'dart', r: 'r', matlab: 'm', lua: 'lua', perl: 'pl', scala: 'scala', arduino: 'ino', ino: 'ino', svg: 'svg', vue: 'vue', docker: 'Dockerfile', dockerfile: 'Dockerfile', text: 'txt' };
function extFor(lang) { return EXT[String(lang || '').toLowerCase()] || 'txt'; }
function escH(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
/* markdown with fenced code blocks, headings, tables, lists, bold, italics, links */
function mdx(t) {
  var blocks = [];
  t = String(t == null ? '' : t).replace(/```([\w+#.-]*)[^\n]*\n([\s\S]*?)```/g, function (_, l, c) { blocks.push({ l: l, c: c.replace(/\n$/, '') }); return '\n\u0000' + (blocks.length - 1) + '\u0000\n'; })
    .replace(/```([\w+#.-]*)[^\n]*\n([\s\S]*)$/, function (_, l, c) { blocks.push({ l: l, c: c }); return '\n\u0000' + (blocks.length - 1) + '\u0000\n'; });
  function inline(x) {
    var h = escH(x);
    h = h.replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/(^|[\s(])\*(?!\s)([^*]+?)\*(?=[\s).,!?:;]|$)/g, '$1<i>$2</i>');
    h = h.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a class="go" href="$2" target="_blank" rel="noopener">$1</a>');
    return h;
  }
  var out = '', lines = t.split('\n'), i, list = '', tbl = null;
  function close() { if (list) { out += '</' + list + '>'; list = ''; } }
  function flushTbl() { if (!tbl) return; var rows = tbl; tbl = null; out += '<div class="jt-tbl"><table>' + rows.map(function (r, k) { return '<tr>' + r.map(function (c) { return (k === 0 ? '<th>' : '<td>') + inline(c.trim()) + (k === 0 ? '</th>' : '</td>'); }).join('') + '</tr>'; }).join('') + '</table></div>'; }
  for (i = 0; i < lines.length; i++) {
    var l = lines[i], m;
    if ((m = l.match(/^\u0000(\d+)\u0000$/))) { close(); flushTbl(); var b = blocks[+m[1]]; out += '<pre class="jt-code" data-lang="' + escH(b.l || '') + '"><code>' + escH(b.c) + '</code></pre>'; continue; }
    if (/^\s*\|.*\|\s*$/.test(l)) { close(); if (/^\s*\|[\s:|-]+\|\s*$/.test(l)) continue; (tbl = tbl || []).push(l.trim().replace(/^\||\|$/g, '').split('|')); continue; }
    flushTbl();
    if ((m = l.match(/^(#{1,4})\s+(.*)$/))) { close(); out += '<p><b>' + inline(m[2]) + '</b></p>'; continue; }
    if ((m = l.match(/^\s*([-*•]|\d+[.)])\s+(.*)$/))) { var tag = /\d/.test(m[1]) ? 'ol' : 'ul'; if (list !== tag) { close(); out += '<' + tag + '>'; list = tag; } out += '<li>' + inline(m[2]) + '</li>'; continue; }
    if (/^\s*(?:---+|\*\*\*+)\s*$/.test(l)) { close(); out += '<hr>'; continue; }
    close(); if (l.trim()) out += '<p>' + inline(l) + '</p>';
  }
  close(); flushTbl();
  return out;
}
/* what the voice should say for a long markdown answer */
function speakable(t) {
  var s = String(t), had = /```/.test(s);
  s = s.replace(/```[\s\S]*?(?:```|$)/g, ' ').replace(/^\s*\|.*\|\s*$/gm, ' ').replace(/[#*_`>|]/g, ' ').replace(/\s+/g, ' ').trim();
  if (had) s = (s ? s + ' ' : '') + 'The code is shown on the screen.';
  return s;
}
root.JTSMART = { identityAnswer: identityAnswer, isCodeInput: isCodeInput, isCodingRequest: isCodingRequest, mdx: mdx, speakable: speakable, extFor: extFor, CREATOR: CREATOR };
if (typeof document === 'undefined' || typeof window === 'undefined' || typeof add !== 'function') return;

/* ======================= PAGE INTEGRATION ======================= */
var Z = root.JTSMART, CA = root.JTCALC;
function mk(tag, props, kids) {
  var e = document.createElement(tag), k;
  for (k in (props || {})) { if (k === 'text') e.textContent = props[k]; else if (k === 'html') e.innerHTML = props[k]; else e.setAttribute(k, props[k]); }
  (kids || []).forEach(function (c) { e.appendChild(c); });
  return e;
}
function btn(label, fn, cls) { var b = mk('button', { 'class': cls || 'c', type: 'button', text: label }); b.style.margin = '4px 6px 0 0'; b.onclick = fn; return b; }
function say(t) { try { speak(t); } catch (e) { } }
function esc2(s) { return typeof esc === 'function' ? esc(s) : escH(s); }

var style = mk('style');
style.textContent = '.row.u .m{white-space:pre-wrap}' +
  'pre.jt-code{background:#101226;color:#e8e8f4;border-radius:0 0 12px 12px;padding:12px 14px;margin:0 0 10px;overflow-x:auto;font:13px/1.55 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre;tab-size:2}' +
  'pre.jt-code code{background:none;padding:0;color:inherit;font:inherit}' +
  '.jt-bar{display:flex;align-items:center;gap:6px;background:#1c1f3a;color:#aab;border-radius:12px 12px 0 0;padding:5px 8px;margin-top:8px;font:12px ui-monospace,Menlo,Consolas,monospace}' +
  '.jt-bar span{flex:1}.jt-bar button{background:#2a2e55;color:#fff;border:0;border-radius:8px;padding:4px 9px;cursor:pointer;font:12px system-ui,sans-serif}' +
  '.jt-tbl{overflow-x:auto}.jt-tbl table{border-collapse:collapse;margin:6px 0}.jt-tbl th,.jt-tbl td{border:1px solid var(--bd);padding:4px 10px;text-align:left}.jt-tbl th{background:var(--card)}' +
  '.jt-chip{display:inline-block;margin:3px 4px 0 0;padding:6px 12px;border-radius:18px;border:1px solid var(--bd);background:var(--card);color:var(--fg);cursor:pointer;font-size:13px}' +
  '.jt-chip.on{background:linear-gradient(135deg,var(--a),var(--b));color:#fff;border-color:transparent}' +
  '.jt-rng{display:grid;grid-template-columns:90px 1fr 34px;align-items:center;gap:6px;font-size:13px}.jt-rng input{width:100%}';
document.head.appendChild(style);

/* ---------- better markdown + code blocks ---------- */
window.md = Z.mdx;
function decorateCode() {
  [].forEach.call(document.querySelectorAll('pre.jt-code:not([data-tools])'), function (pre) {
    pre.setAttribute('data-tools', '1');
    var lang = (pre.getAttribute('data-lang') || 'code').toLowerCase(), bar = mk('div', { 'class': 'jt-bar' });
    bar.appendChild(mk('span', { text: lang }));
    function code() { return pre.textContent; }
    var cp = btn('Copy', function () { try { navigator.clipboard.writeText(code()); cp.textContent = 'Copied'; setTimeout(function () { cp.textContent = 'Copy'; }, 1200); } catch (e) { } }); cp.style.margin = '0';
    var dl = btn('Download', function () { downloadText(code(), 'lexi-code.' + Z.extFor(lang)); }); dl.style.margin = '0';
    bar.appendChild(cp); bar.appendChild(dl);
    if (/^(html|js|javascript|svg|css)$/.test(lang) || (lang === 'code' && /^\s*<(?:!doctype|html|svg)/i.test(code()))) { var rn = btn('▶ Run', function () { runCode(lang, code()); }); rn.style.margin = '0'; bar.appendChild(rn); }
    pre.parentNode.insertBefore(bar, pre);
  });
}
function downloadText(text, name) { var a = mk('a', { href: URL.createObjectURL(new Blob([text], { type: 'text/plain' })), download: name }); document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
var runDlg = mk('dialog'); runDlg.style.cssText = 'width:min(96vw,720px);border:1px solid var(--bd);border-radius:14px;background:var(--card);color:var(--fg);padding:12px'; document.body.appendChild(runDlg);
function runCode(lang, code) {
  var doc;
  if (/^(js|javascript)$/.test(lang)) doc = '<!doctype html><meta charset="utf-8"><body style="font:14px ui-monospace,monospace;margin:8px"><pre id="o" style="white-space:pre-wrap"></pre><script>var o=document.getElementById("o");function w(a){o.textContent+=Array.prototype.map.call(a,function(x){try{return typeof x==="object"?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(" ")+"\\n"}console.log=console.info=console.warn=console.error=function(){w(arguments)};window.onerror=function(m,s,l){o.textContent+="Error: "+m+" (line "+l+")\\n"};try{' + code.replace(/<\/script/gi, '<\\/script') + '\n}catch(e){o.textContent+="Error: "+e.message+"\\n"}<\/script>';
  else if (lang === 'css') doc = '<!doctype html><meta charset="utf-8"><style>' + code + '</style><h1>Heading</h1><p>Paragraph with <a href="#">a link</a> and <button>a button</button>.</p><ul><li>One</li><li>Two</li></ul>';
  else doc = code;
  runDlg.innerHTML = '';
  runDlg.appendChild(mk('b', { text: '▶ Output (sandboxed)' }));
  var fr = mk('iframe', { sandbox: 'allow-scripts allow-forms allow-modals', title: 'Code output' }); fr.style.cssText = 'width:100%;height:55vh;border:1px solid var(--bd);border-radius:10px;background:#fff;margin-top:8px'; fr.srcdoc = doc;
  runDlg.appendChild(fr);
  var c = btn('Close', function () { runDlg.close(); runDlg.innerHTML = ''; }); c.style.background = 'var(--a)'; c.style.color = '#fff'; runDlg.appendChild(mk('div', {}, [c]));
  if (!runDlg.open) runDlg.showModal();
}
var tmr = null;
new MutationObserver(function () { clearTimeout(tmr); tmr = setTimeout(decorateCode, 250); }).observe(log, { childList: true, subtree: true });

/* ---------- speaking: never read code aloud ---------- */
var speak0 = window.speak;
window.speak = function (t) {
  var s = String(t);
  if (/```|^\s*\|.*\|\s*$/m.test(s)) { var sp = Z.speakable(s); return speak0(sp || 'Done.'); }
  return speak0(t);
};

/* ---------- calculator card ---------- */
function calcCard(raw, r) {
  add(esc2(raw), 'u');
  var m = add('', 'a');
  m.appendChild(mk('div', { text: r.answer, style: 'font-size:22px;font-weight:700;word-break:break-word' }));
  (r.lines || []).forEach(function (l) { m.appendChild(mk('div', { text: l, style: 'opacity:.8;font-size:13.5px;margin-top:3px;word-break:break-all' })); });
  m.appendChild(btn('📋 Copy', function () { try { navigator.clipboard.writeText(r.copy || r.answer); } catch (e) { } }));
  m.appendChild(btn('🔊 Read', function () { say(r.answer); }));
  try { mood('happy', 1500); } catch (e) { }
  log.scrollTop = log.scrollHeight;
  var spoken = r.answer.length > 120 ? 'The answer is a very large number. See the screen.' : r.answer.replace(/\^(\d+)/g, ' to the power $1').replace(/[*]/g, ' times ');
  say(spoken);
}

/* ======================= PHOTO STUDIO ======================= */
function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : v; }
function boxBlur(d, w, h, r) { /* separable box blur on RGBA Uint8ClampedArray, returns new array */
  r = Math.max(0, Math.round(r)); if (!r) return new Uint8ClampedArray(d);
  var tmp = new Float32Array(d.length), out = new Uint8ClampedArray(d.length), x, y, c, k, sum, n = 2 * r + 1, idx;
  for (y = 0; y < h; y++) for (c = 0; c < 4; c++) {
    sum = 0; for (k = -r; k <= r; k++) sum += d[(y * w + Math.min(w - 1, Math.max(0, k))) * 4 + c];
    for (x = 0; x < w; x++) { tmp[(y * w + x) * 4 + c] = sum / n; sum += d[(y * w + Math.min(w - 1, x + r + 1)) * 4 + c] - d[(y * w + Math.max(0, x - r)) * 4 + c]; }
  }
  for (x = 0; x < w; x++) for (c = 0; c < 4; c++) {
    sum = 0; for (k = -r; k <= r; k++) sum += tmp[(Math.min(h - 1, Math.max(0, k)) * w + x) * 4 + c];
    for (y = 0; y < h; y++) { out[(y * w + x) * 4 + c] = sum / n; sum += tmp[(Math.min(h - 1, y + r + 1) * w + x) * 4 + c] - tmp[(Math.max(0, y - r) * w + x) * 4 + c]; }
  }
  return out;
}
function gray(d, w, h) { var g = new Float32Array(w * h), i; for (i = 0; i < w * h; i++) g[i] = d[i * 4] * 0.299 + d[i * 4 + 1] * 0.587 + d[i * 4 + 2] * 0.114; return g; }
function sobel(g, w, h) { var m = new Float32Array(w * h), a = new Float32Array(w * h), x, y; for (y = 1; y < h - 1; y++) for (x = 1; x < w - 1; x++) { var i = y * w + x, gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1], gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]; m[i] = Math.sqrt(gx * gx + gy * gy); a[i] = Math.atan2(gy, gx); } return { m: m, a: a }; }
function satur(d, f) { for (var i = 0; i < d.length; i += 4) { var l = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114; d[i] = clamp(l + (d[i] - l) * f); d[i + 1] = clamp(l + (d[i + 1] - l) * f); d[i + 2] = clamp(l + (d[i + 2] - l) * f); } }
function contrast(d, f, mid) { mid = mid === undefined ? 128 : mid; for (var i = 0; i < d.length; i += 4) { d[i] = clamp((d[i] - mid) * f + mid); d[i + 1] = clamp((d[i + 1] - mid) * f + mid); d[i + 2] = clamp((d[i + 2] - mid) * f + mid); } }
function unsharp(d, w, h, amount, r) { var b = boxBlur(d, w, h, r), i; for (i = 0; i < d.length; i += 4) { d[i] = clamp(d[i] + (d[i] - b[i]) * amount); d[i + 1] = clamp(d[i + 1] + (d[i + 1] - b[i + 1]) * amount); d[i + 2] = clamp(d[i + 2] + (d[i + 2] - b[i + 2]) * amount); } }
function vignette(d, w, h, amt) { var cx = w / 2, cy = h / 2, md = Math.sqrt(cx * cx + cy * cy), x, y; for (y = 0; y < h; y++) for (x = 0; x < w; x++) { var dist = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / md, f = 1 - amt * Math.pow(Math.max(0, dist - 0.35) / 0.65, 1.6), i = (y * w + x) * 4; d[i] *= f; d[i + 1] *= f; d[i + 2] *= f; } }
function autoLevels(d) { var hist = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)], n = d.length / 4, i, c; for (i = 0; i < d.length; i += 4) { hist[0][d[i]]++; hist[1][d[i + 1]]++; hist[2][d[i + 2]]++; } var lo = [], hi = [];
  for (c = 0; c < 3; c++) { var s = 0, k; for (k = 0; k < 256; k++) { s += hist[c][k]; if (s >= n * 0.01) { lo[c] = k; break; } } s = 0; for (k = 255; k >= 0; k--) { s += hist[c][k]; if (s >= n * 0.01) { hi[c] = k; break; } } if (hi[c] - lo[c] < 20) { lo[c] = 0; hi[c] = 255; } }
  for (i = 0; i < d.length; i += 4) for (c = 0; c < 3; c++) d[i + c] = clamp((d[i + c] - lo[c]) * 255 / (hi[c] - lo[c])); }
var PRESETS = {
  original: { name: 'Original', fn: function () { } },
  enhance: { name: '✨ Auto enhance', fn: function (d, w, h) { autoLevels(d); satur(d, 1.15); unsharp(d, w, h, 0.6, 1); } },
  vivid: { name: 'Vivid', fn: function (d) { satur(d, 1.5); contrast(d, 1.12); } },
  hdr: { name: 'HDR', fn: function (d, w, h) { var b = boxBlur(d, w, h, Math.max(8, w / 40)), i; for (i = 0; i < d.length; i += 4) { d[i] = clamp(d[i] + (d[i] - b[i]) * 1.1); d[i + 1] = clamp(d[i + 1] + (d[i + 1] - b[i + 1]) * 1.1); d[i + 2] = clamp(d[i + 2] + (d[i + 2] - b[i + 2]) * 1.1); } satur(d, 1.25); } },
  bw: { name: 'Black & white', fn: function (d) { contrast(d, 1.12); for (var i = 0; i < d.length; i += 4) { var l = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114; d[i] = d[i + 1] = d[i + 2] = l; } } },
  sepia: { name: 'Sepia', fn: function (d) { for (var i = 0; i < d.length; i += 4) { var r = d[i], g = d[i + 1], b = d[i + 2]; d[i] = clamp(r * 0.393 + g * 0.769 + b * 0.189); d[i + 1] = clamp(r * 0.349 + g * 0.686 + b * 0.168); d[i + 2] = clamp(r * 0.272 + g * 0.534 + b * 0.131); } } },
  vintage: { name: 'Vintage', fn: function (d, w, h) { for (var i = 0; i < d.length; i += 4) { var r = d[i], g = d[i + 1], b = d[i + 2], n = (Math.random() - 0.5) * 22; d[i] = clamp(r * 0.55 + g * 0.5 + b * 0.15 + 18 + n); d[i + 1] = clamp(r * 0.3 + g * 0.62 + b * 0.12 + 12 + n); d[i + 2] = clamp(r * 0.2 + g * 0.4 + b * 0.35 + 6 + n); } contrast(d, 0.9); vignette(d, w, h, 0.55); } },
  matte: { name: 'Matte fade', fn: function (d) { for (var i = 0; i < d.length; i += 4) { d[i] = 28 + d[i] * 0.86; d[i + 1] = 26 + d[i + 1] * 0.86; d[i + 2] = 34 + d[i + 2] * 0.84; } satur(d, 0.9); } },
  warm: { name: 'Warm', fn: function (d) { for (var i = 0; i < d.length; i += 4) { d[i] = clamp(d[i] * 1.08 + 8); d[i + 2] = clamp(d[i + 2] * 0.9); } satur(d, 1.1); } },
  cool: { name: 'Cool', fn: function (d) { for (var i = 0; i < d.length; i += 4) { d[i] = clamp(d[i] * 0.9); d[i + 2] = clamp(d[i + 2] * 1.1 + 8); } satur(d, 1.05); } },
  cartoon: { name: '🎭 Cartoon', fn: function (d, w, h) { var sm = boxBlur(d, w, h, Math.max(1, Math.round(w / 300))); sm = boxBlur(sm, w, h, Math.max(1, Math.round(w / 300))); var g = gray(sm, w, h), e = sobel(g, w, h), lv = 5, st = 255 / (lv - 1), i, th = 55; satur(sm, 1.45);
    for (i = 0; i < w * h; i++) { var o = i * 4; if (e.m[i] > th) { d[o] = d[o + 1] = d[o + 2] = 20; } else { d[o] = clamp(Math.round(sm[o] / st) * st); d[o + 1] = clamp(Math.round(sm[o + 1] / st) * st); d[o + 2] = clamp(Math.round(sm[o + 2] / st) * st); } } } },
  sketch: { name: '✏️ Pencil sketch', fn: function (d, w, h) { var g = new Uint8ClampedArray(d.length), i; for (i = 0; i < d.length; i += 4) { var l = d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114; g[i] = g[i + 1] = g[i + 2] = l; g[i + 3] = 255; } var inv = new Uint8ClampedArray(g.length); for (i = 0; i < g.length; i += 4) { inv[i] = inv[i + 1] = inv[i + 2] = 255 - g[i]; inv[i + 3] = 255; } var bl = boxBlur(inv, w, h, Math.max(3, Math.round(w / 90)));
    for (i = 0; i < d.length; i += 4) { var v = bl[i] >= 255 ? 255 : Math.min(255, g[i] * 255 / (255 - bl[i])); d[i] = d[i + 1] = d[i + 2] = clamp(v); } } },
  colorsketch: { name: 'Colour sketch', fn: function (d, w, h) { var o = new Uint8ClampedArray(d); PRESETS.sketch.fn(d, w, h); for (var i = 0; i < d.length; i += 4) { var k = d[i] / 255; d[i] = clamp(o[i] * k * 1.1 + 10); d[i + 1] = clamp(o[i + 1] * k * 1.1 + 10); d[i + 2] = clamp(o[i + 2] * k * 1.1 + 10); } satur(d, 1.3); } },
  oil: { name: '🖌 Oil painting', fn: function (d, w, h) { var r = Math.max(2, Math.round(w / 260)), lv = 20, src = new Uint8ClampedArray(d), x, y, dx, dy, cnt = new Int32Array(lv), R = new Int32Array(lv), G = new Int32Array(lv), B = new Int32Array(lv);
    for (y = 0; y < h; y++) for (x = 0; x < w; x++) { cnt.fill(0); R.fill(0); G.fill(0); B.fill(0); for (dy = -r; dy <= r; dy++) { var yy = Math.min(h - 1, Math.max(0, y + dy)); for (dx = -r; dx <= r; dx++) { var xx = Math.min(w - 1, Math.max(0, x + dx)), p = (yy * w + xx) * 4, q = Math.min(lv - 1, ((src[p] + src[p + 1] + src[p + 2]) / 3 * lv / 256) | 0); cnt[q]++; R[q] += src[p]; G[q] += src[p + 1]; B[q] += src[p + 2]; } }
      var best = 0, bi = 0, k; for (k = 0; k < lv; k++) if (cnt[k] > best) { best = cnt[k]; bi = k; } var o = (y * w + x) * 4; d[o] = R[bi] / best; d[o + 1] = G[bi] / best; d[o + 2] = B[bi] / best; } satur(d, 1.2); } },
  poster: { name: 'Poster', fn: function (d) { var st = 255 / 3; for (var i = 0; i < d.length; i += 4) { d[i] = Math.round(d[i] / st) * st; d[i + 1] = Math.round(d[i + 1] / st) * st; d[i + 2] = Math.round(d[i + 2] / st) * st; } satur(d, 1.4); } },
  pixel: { name: '👾 Pixel art', fn: function (d, w, h) { var s = Math.max(4, Math.round(w / 80)), x, y, i, j; for (y = 0; y < h; y += s) for (x = 0; x < w; x += s) { var r = 0, g = 0, b = 0, n = 0; for (j = y; j < Math.min(h, y + s); j++) for (i = x; i < Math.min(w, x + s); i++) { var p = (j * w + i) * 4; r += d[p]; g += d[p + 1]; b += d[p + 2]; n++; } r /= n; g /= n; b /= n; for (j = y; j < Math.min(h, y + s); j++) for (i = x; i < Math.min(w, x + s); i++) { var q = (j * w + i) * 4; d[q] = r; d[q + 1] = g; d[q + 2] = b; } } satur(d, 1.2); } },
  neon: { name: '🌃 Neon edges', fn: function (d, w, h) { var g = gray(boxBlur(d, w, h, 1), w, h), e = sobel(g, w, h), i; for (i = 0; i < w * h; i++) { var o = i * 4, s = Math.min(1, e.m[i] / 160), hue = (e.a[i] + Math.PI) / (2 * Math.PI); var r = 0.5 + 0.5 * Math.cos(6.283 * hue), gg = 0.5 + 0.5 * Math.cos(6.283 * (hue + 0.33)), b = 0.5 + 0.5 * Math.cos(6.283 * (hue + 0.66)); d[o] = clamp(d[o] * 0.18 + 255 * s * r); d[o + 1] = clamp(d[o + 1] * 0.18 + 255 * s * gg); d[o + 2] = clamp(d[o + 2] * 0.22 + 255 * s * b); } } },
  duotone: { name: 'Duotone', fn: function (d) { for (var i = 0; i < d.length; i += 4) { var t = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) / 255; d[i] = 43 + (125 - 43) * t; d[i + 1] = 16 + (226 - 16) * t; d[i + 2] = 85 + (209 - 85) * t; } } },
  emboss: { name: 'Emboss', fn: function (d, w, h) { var g = gray(d, w, h), x, y; for (y = 1; y < h - 1; y++) for (x = 1; x < w - 1; x++) { var i = y * w + x, v = clamp(128 + (g[i - w - 1] * -2 - g[i - w] - g[i - 1] + g[i + 1] + g[i + w] + g[i + w + 1] * 2)); d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = v; } } },
  glow: { name: 'Dreamy glow', fn: function (d, w, h) { var b = boxBlur(d, w, h, Math.max(6, w / 50)), i; for (i = 0; i < d.length; i += 4) { d[i] = 255 - (255 - d[i]) * (255 - b[i]) / 255; d[i + 1] = 255 - (255 - d[i + 1]) * (255 - b[i + 1]) / 255; d[i + 2] = 255 - (255 - d[i + 2]) * (255 - b[i + 2]) / 255; } satur(d, 1.1); } },
  portrait: { name: 'Portrait blur', fn: function (d, w, h) { var b = boxBlur(boxBlur(d, w, h, Math.max(4, w / 60)), w, h, Math.max(4, w / 60)), cx = w / 2, cy = h * 0.45, x, y; for (y = 0; y < h; y++) for (x = 0; x < w; x++) { var dd = Math.sqrt(Math.pow((x - cx) / (w * 0.42), 2) + Math.pow((y - cy) / (h * 0.5), 2)), t = Math.min(1, Math.max(0, (dd - 0.7) / 0.5)), i = (y * w + x) * 4; d[i] = d[i] * (1 - t) + b[i] * t; d[i + 1] = d[i + 1] * (1 - t) + b[i + 1] * t; d[i + 2] = d[i + 2] * (1 - t) + b[i + 2] * t; } satur(d, 1.1); } }
};
var AI_STYLES = [
  ['Studio Ghibli', 'Redraw this photo in the style of a hand-painted Studio Ghibli anime film, soft watercolour backgrounds, warm light'],
  ['Anime', 'Turn this photo into a high quality anime illustration with clean line art and vibrant colours'],
  ['3D cartoon', 'Turn this photo into a 3D animated movie character style render, soft lighting, expressive'],
  ['Oil painting', 'Repaint this photo as a classic oil painting with visible brush strokes'],
  ['Watercolour', 'Repaint this photo as a delicate watercolour painting'],
  ['Cyberpunk', 'Restyle this photo as a cyberpunk night scene with neon pink and teal lighting'],
  ['Cinematic', 'Give this photo a cinematic movie look: dramatic lighting, teal and orange colour grade, shallow depth of field'],
  ['Pro portrait', 'Retouch this into a professional studio portrait: natural skin, balanced light, clean background'],
  ['Remove background', 'Remove the background and place the subject on a clean plain white background'],
  ['HD / sharper', 'Enhance this photo: sharper details, better light and colour, reduce noise']
];
var KEEP = ' Keep the same people, faces, pose and composition.';

var studio = mk('dialog'); studio.style.cssText = 'width:min(96vw,760px);border:1px solid var(--bd);border-radius:14px;background:var(--card);color:var(--fg);max-height:94vh;overflow:auto;padding:14px';
document.body.appendChild(studio);
var S0 = null; /* studio state, rebuilt on every open */
function loadImage(src, cb) { var im = new Image(); im.onload = function () { cb(im); }; im.onerror = function () { cb(null); }; im.src = src; }
function renderTo(st, maxSide) {
  var im = st.img; if (!im) return null;
  var sw = im.naturalWidth || im.width, sh = im.naturalHeight || im.height;
  /* crop */
  var cw = sw, ch = sh, cx = 0, cy = 0, ar = { orig: 0, sq: 1, '43': 4 / 3, '169': 16 / 9, '34': 3 / 4, '916': 9 / 16 }[st.crop] || 0;
  if (ar) { if (sw / sh > ar) { cw = Math.round(sh * ar); cx = Math.round((sw - cw) / 2); } else { ch = Math.round(sw / ar); cy = Math.round((sh - ch) / 2); } }
  var rot = st.rot % 360, swap = rot === 90 || rot === 270, ow = swap ? ch : cw, oh = swap ? cw : ch, sc = Math.min(1, maxSide / Math.max(ow, oh)), w = Math.max(1, Math.round(ow * sc)), h = Math.max(1, Math.round(oh * sc));
  var cv = document.createElement('canvas'); cv.width = w; cv.height = h; var c = cv.getContext('2d', { willReadFrequently: true });
  c.save(); c.translate(w / 2, h / 2); c.rotate(rot * Math.PI / 180); c.scale(st.fh ? -1 : 1, st.fv ? -1 : 1);
  var dw = (swap ? h : w), dh = (swap ? w : h); c.drawImage(im, cx, cy, cw, ch, -dw / 2, -dh / 2, dw, dh); c.restore();
  var id = c.getImageData(0, 0, w, h), d = id.data;
  var P = PRESETS[st.preset] || PRESETS.original; P.fn(d, w, h);
  var a = st.adj;
  if (a.bright) { for (var i = 0; i < d.length; i += 4) { d[i] = clamp(d[i] + a.bright * 2.2); d[i + 1] = clamp(d[i + 1] + a.bright * 2.2); d[i + 2] = clamp(d[i + 2] + a.bright * 2.2); } }
  if (a.contrast) contrast(d, 1 + a.contrast / 100);
  if (a.sat) satur(d, 1 + a.sat / 100);
  if (a.warm) { for (var j = 0; j < d.length; j += 4) { d[j] = clamp(d[j] + a.warm * 0.6); d[j + 2] = clamp(d[j + 2] - a.warm * 0.6); } }
  if (a.sharp) unsharp(d, w, h, a.sharp / 40, Math.max(1, Math.round(w / 700)));
  if (a.blur) { var b = boxBlur(d, w, h, Math.round(a.blur / 100 * w / 40)); d.set(b); }
  if (a.vig) vignette(d, w, h, a.vig / 100);
  c.putImageData(id, 0, 0);
  if (st.frame) { c.strokeStyle = '#fff'; c.lineWidth = Math.max(6, w / 40); c.strokeRect(c.lineWidth / 2, c.lineWidth / 2, w - c.lineWidth, h - c.lineWidth); }
  if (st.text && st.text.value) { var fs = Math.round(w * st.text.size / 100); c.font = '800 ' + fs + 'px system-ui,"Segoe UI",Arial,sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; var ty = st.text.pos === 'top' ? fs * 1.1 : st.text.pos === 'center' ? h / 2 : h - fs * 1.1; c.lineJoin = 'round'; c.lineWidth = Math.max(3, fs / 7); c.strokeStyle = st.text.color === '#ffffff' ? 'rgba(0,0,0,.65)' : 'rgba(255,255,255,.75)'; c.strokeText(st.text.value, w / 2, ty, w * 0.94); c.fillStyle = st.text.color; c.fillText(st.text.value, w / 2, ty, w * 0.94); }
  return cv;
}
root.JT_PRESETS = PRESETS;
function openStudio(file, presetKey) {
  root.JT_openStudio = openStudio;
  S0 = { img: null, preset: presetKey || 'original', rot: 0, fh: false, fv: false, crop: 'orig', frame: false, adj: { bright: 0, contrast: 0, sat: 0, warm: 0, sharp: 0, blur: 0, vig: 0 }, text: { value: '', pos: 'bottom', color: '#ffffff', size: 8 }, busy: false };
  var st = S0, redrawT = null;
  studio.innerHTML = '';
  studio.appendChild(mk('h3', { text: '🎨 Photo Studio', style: 'margin:0 0 6px' }));
  studio.appendChild(mk('small', { text: 'Pick a photo, choose a style, fine-tune, then download. Free styles run on your device. The photo never leaves your phone unless you use ✨ AI restyle.' }));
  var top = mk('div', { style: 'margin:8px 0' });
  var fin = mk('input', { type: 'file', accept: 'image/*', style: 'display:none' }), cam = mk('input', { type: 'file', accept: 'image/*', capture: 'environment', style: 'display:none' });
  top.appendChild(btn('🖼 Choose photo', function () { fin.click(); })); top.appendChild(btn('📷 Camera', function () { cam.click(); })); top.appendChild(fin); top.appendChild(cam);
  studio.appendChild(top);
  var cv = mk('canvas', { 'aria-label': 'Photo preview' }); cv.style.cssText = 'width:100%;max-height:52vh;object-fit:contain;border-radius:12px;background:repeating-conic-gradient(#8883 0 25%,#0000 0 50%) 0 0/16px 16px;display:none';
  var hint = mk('div', { text: 'Choose or drop a photo to begin.', style: 'padding:36px 10px;text-align:center;opacity:.7;border:2px dashed var(--bd);border-radius:12px' });
  studio.appendChild(hint); studio.appendChild(cv);
  function redraw() { if (!st.img) return; clearTimeout(redrawT); redrawT = setTimeout(function () { var out = renderTo(st, 900); cv.width = out.width; cv.height = out.height; cv.getContext('2d').drawImage(out, 0, 0); cv.style.display = 'block'; hint.style.display = 'none'; }, 40); }
  function setFile(f) { if (!f || !/^image\//.test(f.type)) return; var r = new FileReader(); r.onload = function () { loadImage(r.result, function (im) { if (!im) { hint.textContent = 'I could not open that image.'; return; } st.img = im; redraw(); }); }; r.readAsDataURL(f); }
  fin.onchange = function () { setFile(fin.files[0]); fin.value = ''; }; cam.onchange = function () { setFile(cam.files[0]); cam.value = ''; };
  studio.ondragover = function (e) { e.preventDefault(); }; studio.ondrop = function (e) { e.preventDefault(); if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); };
  /* styles */
  studio.appendChild(mk('b', { text: 'Styles', style: 'display:block;margin-top:10px' }));
  var chips = mk('div'); studio.appendChild(chips);
  Object.keys(PRESETS).forEach(function (k) { var c = mk('span', { 'class': 'jt-chip' + (k === st.preset ? ' on' : ''), role: 'button', tabindex: '0', text: PRESETS[k].name }); c.onclick = function () { st.preset = k; [].forEach.call(chips.children, function (x) { x.classList.remove('on'); }); c.classList.add('on'); redraw(); }; chips.appendChild(c); });
  /* adjustments */
  studio.appendChild(mk('b', { text: 'Fine-tune', style: 'display:block;margin-top:12px' }));
  [['bright', 'Brightness', -50, 50], ['contrast', 'Contrast', -50, 80], ['sat', 'Colour', -100, 100], ['warm', 'Warmth', -50, 50], ['sharp', 'Sharpness', 0, 100], ['blur', 'Soften', 0, 100], ['vig', 'Vignette', 0, 100]].forEach(function (s) {
    var row = mk('div', { 'class': 'jt-rng' }), lab = mk('span', { text: s[1] }), rg = mk('input', { type: 'range', min: s[2], max: s[3], value: 0, 'aria-label': s[1] }), val = mk('span', { text: '0' });
    rg.oninput = function () { st.adj[s[0]] = +rg.value; val.textContent = rg.value; redraw(); }; row.appendChild(lab); row.appendChild(rg); row.appendChild(val); studio.appendChild(row);
  });
  /* transform */
  studio.appendChild(mk('b', { text: 'Rotate, flip & crop', style: 'display:block;margin-top:12px' }));
  var tr = mk('div');
  tr.appendChild(btn('⟲', function () { st.rot = (st.rot + 270) % 360; redraw(); }, 'ib')); tr.appendChild(btn('⟳', function () { st.rot = (st.rot + 90) % 360; redraw(); }, 'ib'));
  tr.appendChild(btn('⇋ Flip', function () { st.fh = !st.fh; redraw(); })); tr.appendChild(btn('⇅ Flip', function () { st.fv = !st.fv; redraw(); }));
  var cs = mk('select', { 'aria-label': 'Crop' }); cs.style.cssText = 'padding:7px;border-radius:12px;margin-top:4px';
  [['orig', 'Crop: original'], ['sq', 'Square 1:1'], ['43', '4:3'], ['34', '3:4 portrait'], ['169', '16:9 wide'], ['916', '9:16 story']].forEach(function (o) { cs.appendChild(mk('option', { value: o[0], text: o[1] })); });
  cs.onchange = function () { st.crop = cs.value; redraw(); }; tr.appendChild(cs);
  var fl = mk('label', { style: 'margin-left:8px;font-size:13px' }), fc = mk('input', { type: 'checkbox' }); fc.onchange = function () { st.frame = fc.checked; redraw(); }; fl.appendChild(fc); fl.appendChild(document.createTextNode(' White frame')); tr.appendChild(fl);
  studio.appendChild(tr);
  /* text */
  studio.appendChild(mk('b', { text: 'Add text', style: 'display:block;margin-top:12px' }));
  var tx = mk('div'), ti = mk('input', { 'class': 'k', placeholder: 'Caption, name or quote', maxlength: '80' }); ti.style.cssText = 'width:100%;box-sizing:border-box'; ti.oninput = function () { st.text.value = ti.value; redraw(); }; tx.appendChild(ti);
  var tp = mk('select', { 'aria-label': 'Text position' }); [['bottom', 'Bottom'], ['center', 'Centre'], ['top', 'Top']].forEach(function (o) { tp.appendChild(mk('option', { value: o[0], text: o[1] })); }); tp.onchange = function () { st.text.pos = tp.value; redraw(); };
  var tc = mk('input', { type: 'color', value: '#ffffff', 'aria-label': 'Text colour' }); tc.oninput = function () { st.text.color = tc.value; redraw(); };
  var ts = mk('input', { type: 'range', min: '3', max: '16', value: '8', 'aria-label': 'Text size' }); ts.oninput = function () { st.text.size = +ts.value; redraw(); };
  [tp, tc, ts].forEach(function (e) { e.style.cssText = 'margin:6px 8px 0 0;vertical-align:middle'; tx.appendChild(e); }); studio.appendChild(tx);
  /* AI */
  studio.appendChild(mk('b', { text: '✨ AI restyle (needs an OpenAI or Gemini key in ⚙️)', style: 'display:block;margin-top:14px' }));
  var ac = mk('div'), pr = mk('textarea', { 'class': 'k', rows: '2', placeholder: 'Describe the change, e.g. "make me look like a Pixar character"' }); pr.style.cssText = 'width:100%;box-sizing:border-box;font:inherit';
  AI_STYLES.forEach(function (s) { var c = mk('span', { 'class': 'jt-chip', role: 'button', tabindex: '0', text: s[0] }); c.onclick = function () { pr.value = s[1] + '.'; }; ac.appendChild(c); });
  ac.appendChild(pr);
  var aiMsg = mk('div', { style: 'font-size:13px;margin-top:4px' });
  ac.appendChild(btn('✨ Generate with AI', function () { aiRestyle(st, pr.value, aiMsg, redraw); })); ac.appendChild(aiMsg); studio.appendChild(ac);
  /* output */
  var out = mk('div', { style: 'margin-top:14px;border-top:1px solid var(--bd);padding-top:8px' });
  function blobOf(type, q, side, cb) { var o = renderTo(st, side); if (!o) return cb(null); o.toBlob(cb, type, q); }
  function save(type, ext) { if (!st.img) return; blobOf(type, 0.92, 4096, function (b) { var a = mk('a', { href: URL.createObjectURL(b), download: 'lexi-photo.' + ext }); document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 800); }); }
  out.appendChild(btn('⬇ Download PNG', function () { save('image/png', 'png'); })); out.appendChild(btn('⬇ Download JPG', function () { save('image/jpeg', 'jpg'); }));
  out.appendChild(btn('📤 Share', function () { if (!st.img) return; blobOf('image/jpeg', 0.92, 2048, function (b) { var f = new File([b], 'lexi-photo.jpg', { type: 'image/jpeg' }); if (navigator.canShare && navigator.canShare({ files: [f] })) navigator.share({ files: [f], title: 'My photo' }).catch(function () { }); else save('image/jpeg', 'jpg'); }); }));
  out.appendChild(btn('📋 Copy image', function () { if (!st.img) return; blobOf('image/png', 1, 2048, function (b) { try { navigator.clipboard.write([new ClipboardItem({ 'image/png': b })]); } catch (e) { alert('Copy is not supported here. Use Download.'); } }); }));
  out.appendChild(btn('↺ Reset', function () { var im = st.img; openStudio(null); if (im) { S0.img = im; S0.redraw(); } }));
  var cl = btn('Close', function () { studio.close(); }); cl.style.background = 'var(--a)'; cl.style.color = '#fff'; out.appendChild(cl);
  studio.appendChild(out);
  if (file) setFile(file);
  if (!studio.open) studio.showModal();
  st.redraw = redraw; root.__studio = st;
}
function aiRestyle(st, prompt, msg, redraw) {
  prompt = String(prompt || '').trim();
  if (!st.img) { msg.textContent = 'Choose a photo first.'; return; }
  if (!prompt) { msg.textContent = 'Pick a style chip or describe the change.'; return; }
  var C = window.CFG || {}; if (!C.ok && !C.gk) { msg.textContent = 'AI restyle needs an OpenAI or Gemini key (⚙️ Settings). The free styles above work without any key.'; return; }
  var base = renderTo(Object.assign({}, st, { preset: 'original', adj: { bright: 0, contrast: 0, sat: 0, warm: 0, sharp: 0, blur: 0, vig: 0 }, text: { value: '' }, frame: false }), 1024);
  msg.textContent = '✨ Creating… this can take up to a minute.';
  function done(src) { loadImage(src, function (im) { if (!im) { msg.textContent = 'The AI returned something I could not open.'; return; } st.img = im; st.rot = 0; st.fh = st.fv = false; st.crop = 'orig'; st.preset = 'original'; msg.textContent = '✅ Done. You can still add styles, text and download.'; redraw(); }); }
  base.toBlob(function (blob) {
    var tryOpenAI = function () {
      var fd = new FormData(); fd.append('model', 'gpt-image-1'); fd.append('image', blob, 'photo.png'); fd.append('prompt', prompt + KEEP);
      return fetch('https://api.openai.com/v1/images/edits', { method: 'POST', headers: { Authorization: 'Bearer ' + C.ok }, body: fd }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error((j.error && j.error.message) || r.status); return j; }); }).then(function (j) { done('data:image/png;base64,' + j.data[0].b64_json); });
    };
    var tryGemini = function () {
      return new Promise(function (res) { var fr = new FileReader(); fr.onload = function () { res(String(fr.result).split(',')[1]); }; fr.readAsDataURL(blob); }).then(function (b64) {
        return fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=' + encodeURIComponent(C.gk), { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ contents: [{ parts: [{ text: prompt + KEEP }, { inlineData: { mimeType: 'image/png', data: b64 } }] }], generationConfig: { responseModalities: ['TEXT', 'IMAGE'] } }) });
      }).then(function (r) { return r.json(); }).then(function (j) { var parts = (j.candidates && j.candidates[0] && j.candidates[0].content.parts) || [], p = parts.filter(function (x) { return x.inlineData || x.inline_data; })[0]; if (!p) throw new Error((j.error && j.error.message) || 'no image returned'); var id = p.inlineData || p.inline_data; done('data:' + (id.mimeType || id.mime_type || 'image/png') + ';base64,' + id.data); });
    };
    var chain = C.ok ? tryOpenAI().catch(function (e) { if (C.gk) return tryGemini(); throw e; }) : tryGemini();
    chain.catch(function (e) { msg.textContent = 'AI restyle failed: ' + (e && e.message ? e.message : e) + '. Check your key and billing, or use the free styles.'; });
  }, 'image/png');
}
root.JT_openStudio = openStudio;
var STYLE_WORDS = [[/cartoon/, 'cartoon'], [/sketch|pencil|drawing/, 'sketch'], [/black and white|black & white|b&w|bw|grayscale|greyscale|monochrome/, 'bw'], [/sepia/, 'sepia'], [/vintage|retro|old photo/, 'vintage'], [/hdr/, 'hdr'], [/oil paint|painting/, 'oil'], [/pixel/, 'pixel'], [/neon|cyberpunk/, 'neon'], [/enhance|improve|fix|better|hd|sharpen|clean/, 'enhance'], [/vivid|colou?rful|pop/, 'vivid'], [/glow|dreamy/, 'glow'], [/blur background|portrait/, 'portrait'], [/poster/, 'poster'], [/emboss/, 'emboss'], [/duotone/, 'duotone'], [/warm/, 'warm'], [/cool/, 'cool'], [/matte|fade/, 'matte']];
function photoIntent(lc) {
  if (/^(?:open\s+)?(?:the\s+)?(?:photo|picture|image|pic)\s+(?:studio|editor)$/.test(lc)) return { key: null };
  var m = lc.match(/^(?:please\s+)?(?:edit|customi[sz]e|restyle|stylize|stylise|enhance|improve|retouch|filter|convert|turn|make|change|transform|apply)\b.*\b(?:photo|picture|image|pic|selfie)\b/) || lc.match(/^(?:cartoon|sketch|enhance|beautify)\s+(?:my|this|a)\s+(?:photo|picture|image|pic|selfie)/);
  if (!m) return null;
  for (var i = 0; i < STYLE_WORDS.length; i++) if (STYLE_WORDS[i][0].test(lc)) return { key: STYLE_WORDS[i][1] };
  return { key: null };
}
/* paste or drop a picture into the chat opens the Studio */
inp.addEventListener('paste', function (e) { var items = (e.clipboardData && e.clipboardData.files) || []; if (items.length && /^image\//.test(items[0].type)) { e.preventDefault(); openStudio(items[0]); } });
log.addEventListener('dragover', function (e) { e.preventDefault(); });
log.addEventListener('drop', function (e) { var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (f && /^image\//.test(f.type)) { e.preventDefault(); openStudio(f); } });

/* ---------- front door: every message passes here first ---------- */
var prevH = window.handle;
window.handle = function (raw) {
  var s = String(raw == null ? '' : raw), lc = s.toLowerCase().trim().replace(/[?!.]+$/g, '').replace(/\s+/g, ' ');
  if (!lc) return prevH(raw);
  /* who made you */
  var idn = Z.identityAnswer(s);
  if (idn) { add(esc2(s), 'u'); var m = add('<b>' + esc2(idn) + '</b>', 'a'); say(idn); try { mood('happy', 2200); } catch (e) { } return; }
  /* pasted code or a coding request: straight to the AI, no command guessing */
  if (Z.isCodingRequest(s) && !(window.JT_pending && window.JT_pending())) { add(esc2(s), 'u'); if (typeof smart === 'function') return smart(s); }
  /* photo studio */
  var pi = photoIntent(lc);
  if (pi) { add(esc2(s), 'u'); var m2 = add('🎨 Opening the Photo Studio. Choose a picture' + (pi.key ? ' and I will apply <b>' + esc2(PRESETS[pi.key].name) + '</b>.' : '.'), 'a'); say('Opening the photo studio.'); openStudio(null, pi.key); return; }
  /* maths */
  if (CA && !(window.JT_pending && window.JT_pending()) && !/^[+\d][\d\s()-]{6,}$/.test(lc) && !/^\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}$/.test(lc) && !CMD_START.test(lc)) {
    var r = null; try { r = CA.answer(s); } catch (e) { r = null; }
    if (r) return calcCard(s, r);
  }
  return prevH(raw);
};

/* ---------- header button + help ---------- */
(function ui() {
  var header = document.querySelector('header'), anchor = document.getElementById('clr');
  var b = mk('button', { 'class': 'ib', type: 'button', text: '🎨', title: 'Photo Studio', 'aria-label': 'Photo Studio' }); b.onclick = function () { openStudio(null); }; header.insertBefore(b, anchor);
  var det = document.querySelectorAll('#panel details')[1];
  if (det) det.appendChild(mk('div', { html: '<p><b>💻 Coding:</b> paste code (Shift+Enter for a new line) or ask: fix this error · write a python function to … · convert this to java · explain this code. Code blocks have Copy, Download and ▶ Run (HTML / JavaScript).</p><p><b>🧮 Maths:</b> 15% of 2400 · 2^100 · 50 factorial · sin 30 · solve x^2-5x+6=0 · 2x+3y=12, x-y=1 · derivative of x^3+2x · integrate x^2 from 0 to 3 · mean of 2,4,6 · emi for 500000 at 8.5% for 5 years · add 18% gst to 1000 · days between 1 jan 2026 and 15 mar 2026 · 255 in binary</p><p><b>🎨 Photos:</b> tap 🎨, or paste/drop a picture, or say “make my photo cartoon”. 20+ free styles, adjust, crop, add text, download. ✨ AI restyle (Ghibli, anime, remove background…) uses your OpenAI or Gemini key.</p><p><b>🙋 About:</b> who created you</p>' }));
})();
})(typeof window !== 'undefined' ? window : globalThis);
