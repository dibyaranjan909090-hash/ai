/* Lexi tools v17: header icons removed; every function is inside the + menu */
(function () {
  var st = document.createElement('style');
  st.textContent = 'header button.ib:not(#clr):not(#vol):not(#gear){display:none!important}' +
    'header>b{display:flex;flex-direction:column;justify-content:center;font:700 25px/1 "Segoe UI Variable Display","SF Pro Display",system-ui,-apple-system,"Helvetica Neue",Arial,sans-serif;letter-spacing:-.025em;background:linear-gradient(120deg,#4f46e5,#8b5cf6 50%,#0ea5a4);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent}' +
    'header>b::after{content:"AI VOICE ASSISTANT";display:block;margin-top:5px;font:600 9px/1 system-ui,-apple-system,"Segoe UI",Arial,sans-serif;letter-spacing:.2em;color:#6b7090;-webkit-text-fill-color:#6b7090}' +
    '#lxm{position:fixed;z-index:9999;background:#fff;color:#1a1a2e;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.25);padding:6px;min-width:220px;max-height:70vh;overflow:auto;font:15px system-ui}' +
    '#lxm button{display:flex;gap:10px;align-items:center;width:100%;border:0;background:none;padding:10px 12px;border-radius:10px;text-align:left;font:inherit;color:inherit;cursor:pointer}' +
    '#lxm button:hover{background:#eef0ff}';
  document.head.appendChild(st);
  function init() {
    var pb = document.getElementById('plusb'); if (!pb) return;
    var orig = pb.onclick, tools = [].slice.call(document.querySelectorAll('header button.ib')).filter(function (b) { return ['clr', 'vol', 'gear'].indexOf(b.id) < 0; });
    function close() { var m = document.getElementById('lxm'); if (m) m.remove(); }
    pb.title = 'Add files and tools';
    pb.onclick = function (e) {
      e.stopPropagation();
      if (document.getElementById('lxm')) return close();
      var m = document.createElement('div'); m.id = 'lxm';
      function item(icon, label, fn) { var b = document.createElement('button'); b.innerHTML = '<span>' + icon + '</span><span></span>'; b.lastChild.textContent = label; b.onclick = function () { close(); fn(); }; m.appendChild(b); }
      item('🖼️', 'Photo, video, zip or file', function () { orig && orig.call(pb); });
      tools.forEach(function (t) { if (/clip|attach|photo, video/i.test(t.title)) return; item(t.textContent.trim() || '•', t.title || 'Tool', function () { t.click(); }); });
      if (window.lexiTrain) item('🎓', 'Training Center', function () { window.lexiTrain(); });
      if (window.lexiTeach) item('🧠', 'Teach Lexi', window.lexiTeach);
      if (window.lexiSelfTest) item('✅', 'Self-test', window.lexiSelfTest);
      document.body.appendChild(m);
      var r = pb.getBoundingClientRect(); m.style.left = Math.max(8, r.left) + 'px'; m.style.bottom = (innerHeight - r.top + 8) + 'px';
    };
    document.addEventListener('click', function (e) { var m = document.getElementById('lxm'); if (m && !m.contains(e.target)) m.remove(); });
  }
  window.addEventListener('load', function () { setTimeout(init, 400); });
})();
