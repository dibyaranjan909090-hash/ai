/* Lexi vision.js
   Photos: understand them and change them the way you ask.
   - Send a photo (+ button, paste or drop). Lexi always shows instant on-device facts (size, colours,
     brightness, sharpness, transparent background...), then explains the picture with AI:
     your Claude / ChatGPT / Gemini / Groq key if added, otherwise a free vision AI (no key needed).
   - Ask about it afterwards: "what is he wearing", "read the text in this photo", "describe it".
   - Edit it by typing what you want: "remove background", "white background", "make it cartoon",
     "black and white", "add text Happy Birthday", "rotate right", "crop square", "circle profile picture",
     "brighter", "enhance", "add a gold frame", "resize to 1080x1080"... Edits stack, with Undo and Download.
   - Artistic styles (anime, Ghibli, 3D...) use your OpenAI / Gemini key in the Photo Studio, or, without a key,
     a free AI draws a new picture based on yours.
   Loaded last. */
(function (root) {
'use strict';

/* ======================= PURE LOGIC: understand edit requests ======================= */
var NAMED = { white: [255, 255, 255], black: [0, 0, 0], red: [220, 38, 38], green: [22, 163, 74], blue: [37, 99, 235], yellow: [250, 204, 21], orange: [249, 115, 22], purple: [124, 58, 237], pink: [236, 72, 153], grey: [128, 128, 128], gray: [128, 128, 128], gold: [212, 175, 55], silver: [192, 192, 192], brown: [120, 72, 40], navy: [30, 58, 138], teal: [13, 148, 136], cyan: [6, 182, 212], maroon: [127, 29, 29], beige: [245, 230, 200], skyblue: [135, 206, 235], 'sky blue': [135, 206, 235], cream: [255, 248, 220] };
function colorIn(s) { var k, best = null, bi = 1e9; for (k in NAMED) { var i = s.search(new RegExp('\\b' + k + '\\b')); if (i >= 0 && i < bi) { bi = i; best = k; } } var hx = s.match(/#[0-9a-f]{6}\b/i); if (hx) return hx[0]; return best ? 'rgb(' + NAMED[best].join(',') + ')' : null; }
var STYLE_MAP = [[/\bcartoon|toon\b/, 'cartoon'], [/\bsketch|pencil|line drawing\b/, 'sketch'], [/black\s*(?:and|&|n)\s*white|\bb\s?&\s?w\b|\bbw\b|gr[ae]yscale|monochrome/, 'bw'], [/\bsepia\b/, 'sepia'], [/\bvintage|retro|old (?:photo|look)\b/, 'vintage'], [/\bhdr\b/, 'hdr'], [/\boil\b/, 'oil'], [/\bpixel/, 'pixel'], [/\bneon\b/, 'neon'], [/\bposter\b/, 'poster'], [/\bduotone\b/, 'duotone'], [/\bemboss/, 'emboss'], [/\bglow|dreamy\b/, 'glow'], [/blur (?:the )?background|background blur|bokeh|portrait (?:blur|mode)/, 'portrait'], [/\bvivid|colou?rful|pop\b/, 'vivid']];
var AI_ONLY = [[/\bghibli\b/, 'Studio Ghibli anime film style, hand-painted, soft watercolour background, warm light'], [/\banime|manga\b/, 'high quality anime illustration, clean line art, vibrant colours'], [/\b3d|pixar|disney\b/, '3D animated movie character render, soft lighting'], [/\bwater ?colou?r\b/, 'delicate watercolour painting'], [/\bcyberpunk\b/, 'cyberpunk neon night scene, pink and teal light'], [/\bcomic\b/, 'comic book art, bold ink outlines, halftone'], [/\bcinematic|movie look\b/, 'cinematic film still, dramatic light, teal and orange grade'], [/\bavatar\b/, 'stylised avatar portrait'], [/\bpainting|painted|art(?:istic)?\b/, 'fine art painting']];

/* turn a sentence into a list of edit operations */
function parseOps(text) {
  var s = ' ' + String(text || '').toLowerCase().replace(/[“”]/g, '"') + ' ', ops = [], m, c;
  function has(re) { return re.test(s); }
  if ((m = s.match(/\b(?:add|put|write|insert|type)\s+(?:the\s+)?(?:text|caption|title|words?|name)?\s*(?:saying|that says|:)?\s*"([^"]+)"/)) || (m = s.match(/\b(?:add|put|write|insert)\s+(?:the\s+)?(?:text|caption|title|words?)\s*(?:saying|that says|:)?\s*(.+?)(?:\s+(?:on|at|in)\s+(?:the\s+)?(?:top|bottom|middle|centre|center)\b|\s*$)/)) || (m = s.match(/\btext\s*"([^"]+)"/))) {
    var orig = String(text).match(new RegExp(m[1].replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'));
    ops.push({ op: 'text', v: (orig ? orig[0] : m[1]).trim(), pos: /\btop\b/.test(s) ? 'top' : /\b(?:middle|centre|center)\b/.test(s) ? 'mid' : 'bottom', col: colorIn(s.slice(s.indexOf(m[0]) + m[0].length)) });
    s = s.replace(m[0], ' ');
  }
  if (has(/\b(?:remove|delete|erase|cut ?out|transparent)\b.{0,20}\bbackground|\bbackground\b.{0,12}\b(?:remove|transparent)|\bno background|\bcut ?out\b|\bbg remove|remove bg\b/)) ops.push({ op: 'nobg' });
  if ((m = s.match(/\b((?:sky |dark |light |navy )?[a-z]+|#[0-9a-f]{6})\s+(?:colou?r(?:ed)?\s+)?background\b/)) && (c = colorIn(m[1]))) ops.push({ op: 'bg', col: c });
  else if ((m = s.match(/\bbackground\s+(?:colou?r\s+)?(?:to\s+|into\s+|as\s+|=\s*|in\s+)?((?:sky |dark |light )?[a-z]+|#[0-9a-f]{6})\b/)) && (c = colorIn(m[1]))) ops.push({ op: 'bg', col: c });
  if ((m = s.match(/\brotate(?:d)?\s*(?:it\s*|the\s+(?:photo|image|picture)\s*)?(?:by\s+)?(left|right|anti-?clockwise|counter-?clockwise|clockwise|90|180|270|-90)?/))) ops.push({ op: 'rot', v: /left|anti|counter|270|-90/.test(m[1] || '') ? 270 : /180/.test(m[1] || '') ? 180 : 90 });
  else if (has(/upside down/)) ops.push({ op: 'rot', v: 180 });
  if (has(/\b(?:flip|mirror)\b/)) ops.push({ op: 'flip', v: /vertical|upside|top to bottom/.test(s) ? 'v' : 'h' });
  if (has(/\b(?:circle|circular|round)\b.{0,25}\b(?:crop|profile|dp|photo|picture|image|shape|frame)\b|\bprofile (?:pic|picture|photo)\b|\bdp\b/)) ops.push({ op: 'circle' });
  else if ((m = s.match(/\b(\d{1,2})\s*[:x]\s*(\d{1,2})\b(?!\d)/)) && has(/\bcrop|ratio|aspect\b/)) ops.push({ op: 'crop', r: +m[1] / +m[2] });
  else if (has(/\bsquare\b|\binstagram post\b/)) ops.push({ op: 'crop', r: 1 });
  else if (has(/\bpassport\b/)) ops.push({ op: 'crop', r: 35 / 45 });
  else if (has(/\b(?:story|reel|status|wallpaper|mobile wallpaper)\b/)) ops.push({ op: 'crop', r: 9 / 16 });
  else if (has(/\bwide|youtube thumbnail|landscape\b/) && has(/\bcrop|make|thumbnail\b/)) ops.push({ op: 'crop', r: 16 / 9 });
  if ((m = s.match(/\b(\d{2,4})\s*(?:x|×|\*|by)\s*(\d{2,4})\b/)) && +m[1] >= 16) ops.push({ op: 'size', w: +m[1], h: +m[2] });
  else if ((m = s.match(/\b(?:resize|scale|reduce|shrink)\b.{0,15}?\b(\d{1,3})\s*%/))) ops.push({ op: 'scale', v: +m[1] / 100 });
  else if (has(/\b(?:half (?:the )?size|smaller)\b/)) ops.push({ op: 'scale', v: 0.5 });
  if (has(/\b(?:compress|reduce (?:the )?(?:file )?size|smaller file|less mb|low size)\b/)) ops.push({ op: 'jpeg' });
  var amt = (s.match(/\b(\d{1,3})\s*%/) || [])[1]; amt = amt ? +amt : null;
  if (has(/\b(?:enhance|improve|fix (?:the )?(?:photo|image|light|colou?rs?)|auto ?fix|hd|sharper and|make it (?:better|clear|clearer)|quality|clear(?:er)?\b)/)) ops.push({ op: 'preset', v: 'enhance' });
  if (has(/\b(?:brighter|brighten|lighter|more light|increase brightness|lighten)\b/)) ops.push({ op: 'bright', v: amt || 25 });
  if (has(/\b(?:darker|darken|less bright|decrease brightness|reduce brightness|dim)\b/)) ops.push({ op: 'bright', v: -(amt || 25) });
  if (has(/\b(?:more|increase|high)\s+contrast\b/)) ops.push({ op: 'contrast', v: 1 + (amt || 25) / 100 });
  if (has(/\b(?:less|reduce|low)\s+contrast\b/)) ops.push({ op: 'contrast', v: 1 - (amt || 25) / 100 });
  if (has(/\b(?:warm|warmer)\b/)) ops.push({ op: 'warm', v: 22 });
  if (has(/\b(?:cool|cooler|cold)\b/)) ops.push({ op: 'warm', v: -22 });
  if (has(/\b(?:invert|negative)\b/)) ops.push({ op: 'invert' });
  if (has(/\b(?:sharpen|sharper|crisp)\b/) && !ops.some(function (o) { return o.v === 'enhance'; })) ops.push({ op: 'sharp' });
  if (has(/\bblur\b/) && !has(/blur (?:the )?background|background blur/)) ops.push({ op: 'blur', v: amt ? amt / 10 : 4 });
  if (has(/\b(?:desaturate|less colou?r|muted|faded)\b/)) ops.push({ op: 'sat', v: 0.6 });
  for (var i = 0; i < STYLE_MAP.length; i++) if (STYLE_MAP[i][0].test(s)) { ops.push({ op: 'preset', v: STYLE_MAP[i][1] }); break; }
  if (has(/\b(?:frame|border)\b/)) ops.push({ op: 'frame', col: colorIn(s.slice(Math.max(0, s.search(/\b(?:frame|border)\b/) - 14))) || 'rgb(255,255,255)' });
  if (has(/\brounded (?:corners?|edges?)\b/)) ops.push({ op: 'round' });
  if (!ops.length || has(/\b(?:anime|ghibli|3d|pixar|disney|watercolou?r|cyberpunk|comic|cinematic|avatar)\b/)) for (var j = 0; j < AI_ONLY.length; j++) if (AI_ONLY[j][0].test(s) && !ops.some(function (o) { return o.op === 'preset' && o.v !== 'enhance'; })) { ops.push({ op: 'ai', style: AI_ONLY[j][1] }); break; }
  return ops;
}
var EDIT_HINT = /\b(?:make|turn|convert|change|remove|delete|erase|add|put|write|rotate|flip|mirror|crop|resize|scale|reduce|compress|blur|sharpen|brighten|darken|enhance|improve|apply|edit|fix|invert|transform|redraw|restyle|style|filter|effect|cut ?out)\b/;
var ASK_HINT = /\?$|^(?:what|who|where|when|why|how|which|is|are|does|do|can|could|describe|explain|tell|read|identify|count|translate|analy[sz]e|check|name)\b|\b(?:what is|what's|who is|in (?:this|the) (?:photo|image|picture|pic)|from (?:this|the) (?:photo|image|picture))\b/;
var VIS_WORD = /\b(?:photo|image|picture|pic|selfie|background|he|she|they|him|her|his|them|it|this|that|these|wearing|holding|doing|colou?rs?|text|written|logo|brand|person|people|man|woman|boy|girl|face|hair|eyes?|object|animal|plant|caption|describe|identify|analy[sz]e)\b/;
var IMG_WORD = /\b(?:photo|image|picture|pic|pics|selfie|it|this|that|him|her|them|background|bg|dp)\b/;
function intent(text, hasImg) {
  var s = String(text || '').toLowerCase().trim(); if (!s || !hasImg) return null;
  var ops = parseOps(String(text).trim());
  if (ops.length && (EDIT_HINT.test(s) || /^(?:black|sepia|vintage|cartoon|sketch|square|circle|brighter|darker|warmer|cooler|enhance|hd|invert|negative|blur|sharpen|\d+ ?x ?\d+)/.test(s)) && !/\?$/.test(s)) return { kind: 'edit', ops: ops };
  if (ASK_HINT.test(s) && VIS_WORD.test(s)) return { kind: 'ask' };
  return null;
}
var COLNAMES = [['white', 245, 245, 245], ['black', 15, 15, 15], ['grey', 128, 128, 128], ['light grey', 200, 200, 200], ['dark grey', 64, 64, 64], ['red', 200, 30, 30], ['dark red', 120, 20, 20], ['orange', 240, 130, 30], ['yellow', 240, 210, 40], ['beige', 225, 205, 170], ['brown', 120, 75, 40], ['green', 40, 160, 60], ['dark green', 20, 80, 40], ['olive', 120, 120, 40], ['teal', 20, 140, 140], ['cyan', 40, 200, 220], ['sky blue', 120, 190, 235], ['blue', 40, 90, 220], ['navy', 25, 35, 90], ['purple', 120, 50, 170], ['pink', 235, 120, 170], ['skin / peach', 225, 175, 140]];
function colName(r, g, b) { var best = '', bd = 1e9; COLNAMES.forEach(function (c) { var d = (r - c[1]) * (r - c[1]) * 0.3 + (g - c[2]) * (g - c[2]) * 0.59 + (b - c[3]) * (b - c[3]) * 0.11; if (d < bd) { bd = d; best = c[0]; } }); return best; }
var JV = { parseOps: parseOps, intent: intent, colName: colName };
root.JTVISION = JV;
if (typeof module !== 'undefined' && module.exports) module.exports = JV;
if (typeof document === 'undefined' || typeof window.handle !== 'function') return;

/* ======================= PAGE WIRING ======================= */
var style = document.createElement('style');
style.textContent = '.jv-img{max-width:100%;max-height:420px;border-radius:12px;display:block;margin:8px 0;background:repeating-conic-gradient(#8883 0% 25%,transparent 0% 50%) 50%/18px 18px}' +
  '.jv-sw{display:inline-flex;align-items:center;gap:5px;margin:2px 8px 2px 0;font-size:12.5px}.jv-sw i{width:16px;height:16px;border-radius:4px;border:1px solid var(--bd);display:inline-block}' +
  '.jv-facts{font-size:13.5px;margin:4px 0}.jv-facts td{padding:3px 8px 3px 0;vertical-align:top}.jv-row{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}' +
  '.jv-b{border:1px solid var(--bd);background:var(--card);color:var(--fg);border-radius:16px;padding:6px 12px;font-size:13px;cursor:pointer}.jv-b.p{background:linear-gradient(135deg,var(--a),var(--b));color:#fff;border-color:transparent}.jv-hint{font-size:12.5px;color:var(--mut);margin-top:6px}';
document.head.appendChild(style);
function el(t, a, kids) { var e = document.createElement(t); for (var k in a || {}) { if (k === 'text') e.textContent = a[k]; else if (k === 'html') e.innerHTML = a[k]; else e.setAttribute(k, a[k]); } (kids || []).forEach(function (c) { if (c) e.appendChild(c); }); return e; }
function bt(t, fn, p) { var b = el('button', { type: 'button', 'class': 'jv-b' + (p ? ' p' : ''), text: t }); b.onclick = fn; return b; }
function to(ms) { var c = new AbortController(); setTimeout(function () { c.abort(); }, ms); return c.signal; }
function scroll() { log.scrollTop = log.scrollHeight; }
function feel(m, ms) { try { mood(m, ms); } catch (e) { } }
function talk(t) { try { speak(String(t).replace(/[#*`|>]/g, ' ').slice(0, 350)); } catch (e) { } }
function mdh(t) { return (window.md || esc)(t); }
function footer(m, src, raw) { var f = el('div', { 'class': 'src' }); f.appendChild(document.createTextNode('Source: ' + src)); var c = el('button', { 'class': 'cp', text: 'Copy' }); c.onclick = function () { try { navigator.clipboard.writeText(raw); c.textContent = 'Copied'; } catch (e) { } }; f.appendChild(c); m.appendChild(f); }

var CUR = null;      /* {url: dataURL of current picture, hist: [...], name} */
function setCur(url, keepHist) { if (!CUR || !keepHist) CUR = { url: url, hist: [], t: Date.now() }; else { CUR.hist.push(CUR.url); if (CUR.hist.length > 12) CUR.hist.shift(); CUR.url = url; CUR.t = Date.now(); } root.JV_current = CUR; if (root.JW_site) root.JW_site.active = false; }
function loadImg(src) { return new Promise(function (res, rej) { var i = new Image(); i.crossOrigin = 'anonymous'; i.onload = function () { res(i); }; i.onerror = rej; i.src = src; }); }
function canvasOf(img, max) { var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height, s = Math.min(1, (max || 1600) / Math.max(w, h)), c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * s)); c.height = Math.max(1, Math.round(h * s)); c.getContext('2d', { willReadFrequently: true }).drawImage(img, 0, 0, c.width, c.height); return c; }
function blank(w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
function ctx2(c) { return c.getContext('2d', { willReadFrequently: true }); }
function jpegFor(url) { return loadImg(url).then(function (i) { var c = canvasOf(i, 800), o = blank(c.width, c.height), x = ctx2(o); x.fillStyle = '#fff'; x.fillRect(0, 0, o.width, o.height); x.drawImage(c, 0, 0); return o.toDataURL('image/jpeg', 0.85); }); }

/* ---------- on-device facts ---------- */
function facts(img, bytes) {
  var c = canvasOf(img, 256), w = c.width, h = c.height, d = ctx2(c).getImageData(0, 0, w, h).data, n = w * h, i;
  var alpha = 0, lum = 0, lum2 = 0, sat = 0, buckets = {}, gray = new Float32Array(n);
  for (i = 0; i < n; i++) {
    var o = i * 4, r = d[o], g = d[o + 1], b = d[o + 2], a = d[o + 3];
    if (a < 200) alpha++;
    var L = 0.299 * r + 0.587 * g + 0.114 * b; gray[i] = L;
    if (a < 40) continue;
    lum += L; lum2 += L * L; var mx = Math.max(r, g, b), mn = Math.min(r, g, b); sat += mx ? (mx - mn) / mx : 0;
    var k = (r >> 5) + ',' + (g >> 5) + ',' + (b >> 5); var B = buckets[k] || (buckets[k] = [0, 0, 0, 0]); B[0]++; B[1] += r; B[2] += g; B[3] += b;
  }
  var vis = Math.max(1, n - alpha), mean = lum / vis, sd = Math.sqrt(Math.max(0, lum2 / vis - mean * mean)), lap = 0, lc = 0;
  for (var y = 1; y < h - 1; y++) for (var x = 1; x < w - 1; x++) { var p = y * w + x, v = 4 * gray[p] - gray[p - 1] - gray[p + 1] - gray[p - w] - gray[p + w]; lap += v * v; lc++; }
  var sharp = lap / Math.max(1, lc);
  var top = Object.keys(buckets).map(function (k) { var B = buckets[k]; return [B[0], Math.round(B[1] / B[0]), Math.round(B[2] / B[0]), Math.round(B[3] / B[0])]; }).sort(function (a, b) { return b[0] - a[0]; });
  var names = [], pal = [];
  top.forEach(function (t) { var nm = colName(t[1], t[2], t[3]); if (names.indexOf(nm) < 0 && pal.length < 5 && t[0] / vis > 0.03) { names.push(nm); pal.push({ name: nm, rgb: 'rgb(' + t[1] + ',' + t[2] + ',' + t[3] + ')', pct: Math.round(t[0] / vis * 100) }); } });
  var W = img.naturalWidth || img.width, H = img.naturalHeight || img.height;
  return { w: W, h: H, mp: (W * H / 1e6).toFixed(1), orient: W > H * 1.05 ? 'landscape' : H > W * 1.05 ? 'portrait' : 'square', transparent: Math.round(alpha / n * 100), bright: Math.round(mean / 255 * 100), contrast: Math.round(sd / 128 * 100), sharp: sharp, sat: Math.round(sat / vis * 100), pal: pal, bytes: bytes };
}
function factsHTML(f) {
  var q = f.sharp > 350 ? 'sharp' : f.sharp > 90 ? 'fairly sharp' : 'soft / slightly blurry';
  var lt = f.bright > 70 ? 'bright' : f.bright < 30 ? 'dark' : 'well exposed';
  var tips = [];
  if (f.bright < 30) tips.push('“make it brighter”'); if (f.sharp < 90) tips.push('“enhance”'); if (f.transparent < 3) tips.push('“remove background”'); if (f.w < 600) tips.push('it is small; avoid enlarging');
  return '<table class="jv-facts"><tr><td>📐 Size</td><td>' + f.w + ' × ' + f.h + ' px (' + f.mp + ' MP, ' + f.orient + ')' + (f.bytes ? ', ' + Math.round(f.bytes / 1024) + ' KB' : '') + '</td></tr>' +
    '<tr><td>💡 Light</td><td>' + lt + ' (brightness ' + f.bright + '%, contrast ' + f.contrast + '%)</td></tr><tr><td>🔍 Focus</td><td>' + q + '</td></tr>' +
    '<tr><td>🎨 Colours</td><td>' + (f.sat < 12 ? 'almost black and white · ' : f.sat > 45 ? 'very colourful · ' : '') + f.pal.map(function (p) { return '<span class="jv-sw"><i style="background:' + p.rgb + '"></i>' + esc(p.name) + ' ' + p.pct + '%</span>'; }).join('') + '</td></tr>' +
    (f.transparent >= 3 ? '<tr><td>🫥 Background</td><td>' + f.transparent + '% transparent (cut-out / PNG)</td></tr>' : '') +
    (tips.length ? '<tr><td>💡 Try</td><td>' + tips.join(' · ') + '</td></tr>' : '') + '</table>';
}

/* ---------- vision AI: your keys first, then free ---------- */
function vision(prompt, imgs, ms) {
  ms = ms || 60000;
  return Promise.all(imgs.map(jpegFor)).then(function (jp) {
    var b64 = jp.map(function (s) { return s.split(',')[1]; }), T = [], SYSV = 'You are Lexi, a friendly, careful assistant that can see images. Look closely and answer in simple words with short headings and bullets. Read any visible text exactly. If something is unclear, say so. ' + (function () { try { var l = (CFG.lang || 'en').slice(0, 2); return l !== 'en' ? 'Reply in the language of the user (UI language code ' + l + ').' : ''; } catch (e) { return ''; } })();
    var oai = function (url, key, model, src, extra) { return function () { var hd = Object.assign({ 'content-type': 'application/json' }, key ? { authorization: 'Bearer ' + key } : {}, extra || {}); return fetch(url, { method: 'POST', signal: to(ms), headers: hd, body: new Blob([JSON.stringify({ model: model, max_tokens: 1200, messages: [{ role: 'system', content: SYSV }, { role: 'user', content: [{ type: 'text', text: prompt }].concat(jp.map(function (u) { return { type: 'image_url', image_url: { url: u } }; })) }] })], { type: 'application/json' }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return { t: j.choices[0].message.content, src: src }; }); }; };
    var order = CFG.prov && CFG.prov !== 'auto' ? [CFG.prov, 'gemini', 'claude', 'chatgpt', 'groq', 'openrouter'] : ['gemini', 'claude', 'chatgpt', 'groq', 'openrouter'];
    order.filter(function (x, i) { return order.indexOf(x) === i; }).forEach(function (p) {
      if (p === 'claude' && CFG.ak) T.push(function () { return fetch('https://api.anthropic.com/v1/messages', { method: 'POST', signal: to(ms), headers: { 'content-type': 'application/json', 'x-api-key': CFG.ak, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }, body: new Blob([JSON.stringify({ model: 'claude-sonnet-5-5', max_tokens: 1200, system: SYSV, messages: [{ role: 'user', content: b64.map(function (d) { return { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: d } }; }).concat([{ type: 'text', text: prompt }]) }] })], { type: 'application/json' }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return { t: j.content.map(function (x) { return x.text || ''; }).join(''), src: 'Claude' }; }); });
      if (p === 'chatgpt' && CFG.ok) T.push(oai('https://api.openai.com/v1/chat/completions', CFG.ok, 'gpt-4o-mini', 'ChatGPT'));
      if (p === 'gemini' && CFG.gk) T.push(function () { return fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(CFG.gk), { method: 'POST', signal: to(ms), headers: { 'content-type': 'application/json' }, body: new Blob([JSON.stringify({ systemInstruction: { parts: [{ text: SYSV }] }, contents: [{ parts: [{ text: prompt }].concat(b64.map(function (d) { return { inlineData: { mimeType: 'image/jpeg', data: d } }; })) }] })], { type: 'application/json' }) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return { t: j.candidates[0].content.parts.map(function (x) { return x.text || ''; }).join(''), src: 'Gemini' }; }); });
      if (p === 'groq' && CFG.grk) T.push(oai('https://api.groq.com/openai/v1/chat/completions', CFG.grk, 'meta-llama/llama-4-scout-17b-16e-instruct', 'Groq vision'));
      if (p === 'openrouter' && CFG.ork) T.push(oai('https://openrouter.ai/api/v1/chat/completions', CFG.ork, 'openrouter/auto', 'OpenRouter', { 'X-Title': 'Lexi' }));
    });
    /* free vision: new Pollinations API (your free key if added), then the old open endpoint, then anonymous */
    if (CFG.pk) ['gemini', 'openai'].forEach(function (md) { T.push(oai('https://gen.pollinations.ai/v1/chat/completions', CFG.pk, md, 'Pollinations (' + md + ')')); });
    T.push(oai('https://text.pollinations.ai/openai', '', 'openai', 'Free vision AI (no key)'));
    ['gemini', 'openai'].forEach(function (md) { T.push(oai('https://gen.pollinations.ai/v1/chat/completions', '', md, 'Free vision AI (no key)')); });
    return T.reduce(function (p, f) { return p.catch(function () { return f().then(function (r) { if (!r.t || !String(r.t).trim() || /^\s*\{\s*"error/.test(r.t)) throw 0; return r; }); }); }, Promise.reject());
  });
}

/* ---------- image operations (all on this device) ---------- */
function P() { return root.JT_PRESETS || {}; }
function pix(c, fn) { var x = ctx2(c), id = x.getImageData(0, 0, c.width, c.height); fn(id.data, c.width, c.height); x.putImageData(id, 0, 0); return c; }
function cl(v) { return v < 0 ? 0 : v > 255 ? 255 : v; }
function removeBg(c) {
  var w = c.width, h = c.height, x = ctx2(c), id = x.getImageData(0, 0, w, h), d = id.data, i;
  var border = [], k;
  for (k = 0; k < w; k++) { border.push(k, (h - 1) * w + k); } for (k = 0; k < h; k++) { border.push(k * w, k * w + w - 1); }
  var opaque = border.filter(function (p) { return d[p * 4 + 3] > 40; });
  if (opaque.length < border.length * 0.2) return { c: c, note: 'The background is already transparent.' };
  var bk = {}; opaque.forEach(function (p) { var o = p * 4, key = (d[o] >> 4) + ',' + (d[o + 1] >> 4) + ',' + (d[o + 2] >> 4), B = bk[key] || (bk[key] = [0, 0, 0, 0]); B[0]++; B[1] += d[o]; B[2] += d[o + 1]; B[3] += d[o + 2]; });
  var refs = Object.keys(bk).map(function (key) { var B = bk[key]; return [B[0], B[1] / B[0], B[2] / B[0], B[3] / B[0]]; }).sort(function (a, b) { return b[0] - a[0]; }).slice(0, 4).filter(function (r) { return r[0] / opaque.length > 0.04; });
  var cover = refs.reduce(function (s, r) { return s + r[0]; }, 0) / opaque.length;
  var tol = cover > 0.75 ? 34 : 26;
  function near(o) { for (var j = 0; j < refs.length; j++) { var r = refs[j], dr = d[o] - r[1], dg = d[o + 1] - r[2], db = d[o + 2] - r[3]; if (dr * dr + dg * dg + db * db < tol * tol * 3) return true; } return false; }
  var seen = new Uint8Array(w * h), st = [], cnt = 0;
  border.forEach(function (p) { if (!seen[p] && (d[p * 4 + 3] < 40 || near(p * 4))) { seen[p] = 1; st.push(p); } });
  while (st.length) { var p = st.pop(), px = p % w, py = (p - px) / w; d[p * 4 + 3] = 0; cnt++; var nb = [px > 0 ? p - 1 : -1, px < w - 1 ? p + 1 : -1, py > 0 ? p - w : -1, py < h - 1 ? p + w : -1]; for (var q = 0; q < 4; q++) { var t = nb[q]; if (t >= 0 && !seen[t]) { seen[t] = 1; if (d[t * 4 + 3] < 40 || near(t * 4)) st.push(t); } } }
  /* soften the cut edge */
  for (i = 0; i < w * h; i++) { if (d[i * 4 + 3] === 0) continue; var ix = i % w, iy = (i - ix) / w, z = 0; if (ix > 0 && d[(i - 1) * 4 + 3] === 0) z++; if (ix < w - 1 && d[(i + 1) * 4 + 3] === 0) z++; if (iy > 0 && d[(i - w) * 4 + 3] === 0) z++; if (iy < h - 1 && d[(i + w) * 4 + 3] === 0) z++; if (z) d[i * 4 + 3] = Math.round(d[i * 4 + 3] * (1 - z * 0.22)); }
  x.putImageData(id, 0, 0);
  var pct = Math.round(cnt / (w * h) * 100);
  return { c: c, note: pct < 3 ? 'I could not find a plain background to remove (the background is busy). For a perfect cut-out of busy photos, open the Photo Studio → ✨ AI “Remove background” (needs an OpenAI or Gemini key).' : 'Removed ' + pct + '% of the picture as background' + (cover < 0.6 ? ' (busy background: check the edges; the AI cut-out in Photo Studio is cleaner)' : '') + '.' };
}
function apply(c, op, notes) {
  var w = c.width, h = c.height, o, x;
  switch (op.op) {
    case 'nobg': var r = removeBg(c); notes.push(r.note); return r.c;
    case 'bg': if (!/transparent/.test(notes.join(' '))) { var f0 = facts(c, 0); if (f0.transparent < 3) { var r2 = removeBg(c); if (/could not/.test(r2.note)) { notes.push(r2.note); return c; } } }
      o = blank(w, h); x = ctx2(o); x.fillStyle = op.col; x.fillRect(0, 0, w, h); x.drawImage(c, 0, 0); notes.push('New background colour.'); return o;
    case 'rot': var sw = op.v !== 180; o = blank(sw ? h : w, sw ? w : h); x = ctx2(o); x.translate(o.width / 2, o.height / 2); x.rotate(op.v * Math.PI / 180); x.drawImage(c, -w / 2, -h / 2); notes.push('Rotated ' + (op.v === 270 ? 'left' : op.v === 180 ? '180°' : 'right') + '.'); return o;
    case 'flip': o = blank(w, h); x = ctx2(o); if (op.v === 'v') { x.translate(0, h); x.scale(1, -1); } else { x.translate(w, 0); x.scale(-1, 1); } x.drawImage(c, 0, 0); notes.push('Flipped ' + (op.v === 'v' ? 'upside down' : 'left to right') + '.'); return o;
    case 'crop': var cw = w, ch = h; if (w / h > op.r) cw = Math.round(h * op.r); else ch = Math.round(w / op.r); o = blank(cw, ch); ctx2(o).drawImage(c, (w - cw) / 2, (h - ch) * (op.r < 1 ? 0.3 : 0.5), cw, ch, 0, 0, cw, ch); notes.push('Cropped to ' + (op.r === 1 ? 'square' : 'ratio ' + (+op.r.toFixed(2))) + '.'); return o;
    case 'circle': var s = Math.min(w, h); o = blank(s, s); x = ctx2(o); x.beginPath(); x.arc(s / 2, s / 2, s / 2, 0, Math.PI * 2); x.clip(); x.drawImage(c, (w - s) / 2, (h - s) * 0.3, s, s, 0, 0, s, s); notes.push('Round profile picture (transparent corners, download as PNG).'); return o;
    case 'size': o = blank(op.w, op.h); x = ctx2(o); var sc = Math.max(op.w / w, op.h / h); x.drawImage(c, (op.w - w * sc) / 2, (op.h - h * sc) / 2, w * sc, h * sc); notes.push('Resized to ' + op.w + ' × ' + op.h + ' (filled and centred).'); return o;
    case 'scale': o = blank(Math.max(1, Math.round(w * op.v)), Math.max(1, Math.round(h * op.v))); ctx2(o).drawImage(c, 0, 0, o.width, o.height); notes.push('Resized to ' + Math.round(op.v * 100) + '% (' + o.width + ' × ' + o.height + ').'); return o;
    case 'jpeg': notes.push('Download as JPG for a much smaller file.'); return c;
    case 'preset': var pr = P()[op.v]; if (!pr) { notes.push('That style is not available.'); return c; } pix(c, function (d) { pr.fn(d, w, h); }); notes.push((pr.name || op.v).replace(/^\W+\s*/, '') + ' applied.'); return c;
    case 'bright': pix(c, function (d) { for (var i = 0; i < d.length; i += 4) { d[i] = cl(d[i] + op.v * 1.6); d[i + 1] = cl(d[i + 1] + op.v * 1.6); d[i + 2] = cl(d[i + 2] + op.v * 1.6); } }); notes.push(op.v > 0 ? 'Brighter.' : 'Darker.'); return c;
    case 'contrast': pix(c, function (d) { for (var i = 0; i < d.length; i += 4) for (var j = 0; j < 3; j++) d[i + j] = cl((d[i + j] - 128) * op.v + 128); }); notes.push(op.v > 1 ? 'More contrast.' : 'Less contrast.'); return c;
    case 'warm': pix(c, function (d) { for (var i = 0; i < d.length; i += 4) { d[i] = cl(d[i] + op.v); d[i + 2] = cl(d[i + 2] - op.v); } }); notes.push(op.v > 0 ? 'Warmer colours.' : 'Cooler colours.'); return c;
    case 'sat': pix(c, function (d) { for (var i = 0; i < d.length; i += 4) { var g = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]; for (var j = 0; j < 3; j++) d[i + j] = cl(g + (d[i + j] - g) * op.v); } }); notes.push('Softer colours.'); return c;
    case 'invert': pix(c, function (d) { for (var i = 0; i < d.length; i += 4) { d[i] = 255 - d[i]; d[i + 1] = 255 - d[i + 1]; d[i + 2] = 255 - d[i + 2]; } }); notes.push('Inverted (negative).'); return c;
    case 'sharp': pix(c, function (d) { var src = new Uint8ClampedArray(d), i, y, x2, j; for (y = 1; y < h - 1; y++) for (x2 = 1; x2 < w - 1; x2++) { i = (y * w + x2) * 4; for (j = 0; j < 3; j++) d[i + j] = cl(src[i + j] * 5 - src[i + j - 4] - src[i + j + 4] - src[i + j - w * 4] - src[i + j + w * 4]); } }); notes.push('Sharpened.'); return c;
    case 'blur': o = blank(w, h); x = ctx2(o); if ('filter' in x) { x.filter = 'blur(' + Math.max(1, op.v * w / 800) + 'px)'; x.drawImage(c, 0, 0); notes.push('Blurred.'); return o; } notes.push('Blur is not supported in this browser.'); return c;
    case 'text': x = ctx2(c); var fs = Math.max(14, Math.round(Math.min(w, h) / 10)); x.font = '800 ' + fs + 'px system-ui,"Segoe UI",Arial,sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
      var words = op.v.split(/\s+/), lines = [], ln = ''; words.forEach(function (wd) { var t = ln ? ln + ' ' + wd : wd; if (x.measureText(t).width > w * 0.9 && ln) { lines.push(ln); ln = wd; } else ln = t; }); lines.push(ln);
      var y0 = op.pos === 'top' ? fs * 0.9 : op.pos === 'mid' ? h / 2 - (lines.length - 1) * fs * 0.55 : h - fs * 0.9 - (lines.length - 1) * fs * 1.1;
      lines.forEach(function (l, i) { var yy = y0 + i * fs * 1.1; x.lineWidth = Math.max(3, fs / 7); x.strokeStyle = 'rgba(0,0,0,.85)'; x.lineJoin = 'round'; x.strokeText(l, w / 2, yy); x.fillStyle = op.col || '#fff'; x.fillText(l, w / 2, yy); });
      notes.push('Added text “' + op.v + '”.'); return c;
    case 'frame': var bw = Math.max(8, Math.round(Math.min(w, h) / 22)); o = blank(w + bw * 2, h + bw * 2); x = ctx2(o); x.fillStyle = op.col; x.fillRect(0, 0, o.width, o.height); x.drawImage(c, bw, bw); notes.push('Added a frame.'); return o;
    case 'round': o = blank(w, h); x = ctx2(o); var rr = Math.min(w, h) / 12; x.beginPath(); x.moveTo(rr, 0); x.arcTo(w, 0, w, h, rr); x.arcTo(w, h, 0, h, rr); x.arcTo(0, h, 0, 0, rr); x.arcTo(0, 0, w, 0, rr); x.closePath(); x.clip(); x.drawImage(c, 0, 0); notes.push('Rounded corners.'); return o;
  }
  return c;
}

/* ---------- result card ---------- */
function download(url, name) { var a = el('a', { href: url, download: name }); document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); }, 400); }
function toJpg(url) { return loadImg(url).then(function (i) { var c = canvasOf(i, 4000), o = blank(c.width, c.height), x = ctx2(o); x.fillStyle = '#fff'; x.fillRect(0, 0, o.width, o.height); x.drawImage(c, 0, 0); return o.toDataURL('image/jpeg', 0.88); }); }
function chips(m) {
  var row = el('div', { 'class': 'jv-row' });
  ['remove background', 'white background', 'enhance', 'black and white', 'cartoon', 'sketch', 'circle profile picture', 'square crop', 'rotate right', 'add text "Hello"', 'blur background', 'anime style'].forEach(function (t) { row.appendChild(bt(t, function () { window.handle(t); })); });
  m.appendChild(row);
}
function tools(m, url) {
  var row = el('div', { 'class': 'jv-row' });
  row.appendChild(bt('⬇ PNG', function () { download(url, 'lexi-photo.png'); }, true));
  row.appendChild(bt('⬇ JPG (small)', function () { toJpg(url).then(function (j) { download(j, 'lexi-photo.jpg'); }); }));
  if (navigator.share) row.appendChild(bt('📤 Share', function () { fetch(url).then(function (r) { return r.blob(); }).then(function (b) { var f = new File([b], 'lexi-photo.png', { type: 'image/png' }); navigator.share({ files: [f], title: 'Photo' }).catch(function () { }); }); }));
  if (CUR && CUR.hist.length) row.appendChild(bt('↩ Undo', function () { var prev = CUR.hist.pop(); if (!prev) return; CUR.url = prev; var mm = add('', 'a'); show(mm, prev, '↩ Back to the previous version.'); }));
  row.appendChild(bt('🎨 Photo Studio', function () { if (!root.JT_openStudio) return; fetch(url).then(function (r) { return r.blob(); }).then(function (b) { root.JT_openStudio(new File([b], 'photo.png', { type: 'image/png' })); }); }));
  m.appendChild(row);
}
function show(m, url, note, src) {
  m.innerHTML = '';
  if (note) m.appendChild(el('div', { html: mdh(note) }));
  m.appendChild(el('img', { 'class': 'jv-img', src: url, alt: 'Edited photo' }));
  tools(m, url); chips(m);
  m.appendChild(el('div', { 'class': 'jv-hint', text: 'Type any change in your own words, e.g. “make the background blue”, “add text Happy Birthday at the top”, “crop 16:9”, “brighter 30%”, “resize to 1080x1080”. ' + (src ? '' : 'Edits are done on your device: nothing is uploaded.') }));
  scroll();
}

/* ---------- actions ---------- */
function edit(ops, quiet) {
  if (!CUR) return reply('Send a photo first with the ➕ button (or paste / drop one here), then tell me what to change.');
  var m = add('<span class="dots"><i></i><i></i><i></i></span>', 'a'); feel('search');
  var aiOp = ops.filter(function (o) { return o.op === 'ai'; })[0], local = ops.filter(function (o) { return o.op !== 'ai'; });
  if (aiOp && !local.length) return restyle(m, aiOp.style);
  loadImg(CUR.url).then(function (img) {
    var c = canvasOf(img, 1600), notes = [];
    var mx = Math.max(c.width, c.height); if (mx < 720) { var up = blank(Math.round(c.width * 720 / mx), Math.round(c.height * 720 / mx)), ux = ctx2(up); ux.imageSmoothingQuality = 'high'; ux.drawImage(c, 0, 0, up.width, up.height); c = up; } /* tiny pictures: upscale so effects and text look clean */
    local.forEach(function (o) { c = apply(c, o, notes); });
    var url = c.toDataURL('image/png'); setCur(url, true);
    show(m, url, '✅ ' + notes.join(' '));
    feel('happy', 1800); if (!quiet) talk(notes[0] || 'Done.');
    if (aiOp) restyle(add('', 'a'), aiOp.style);
  }).catch(function () { m.innerHTML = 'I could not edit that picture. Try another image (JPG or PNG).'; feel('sad', 2000); });
}
function restyle(m, styleTxt) {
  m.innerHTML = '<span class="dots"><i></i><i></i><i></i></span>'; st.textContent = '🎨 Creating your picture…';
  var keyNote = (CFG.ok || CFG.gk) ? 'For an exact repaint of your own photo, open 🎨 Photo Studio → ✨ AI restyle (uses your OpenAI / Gemini key).' : 'This free AI draws a new picture from a description of your photo. For an exact repaint of your own photo, add an OpenAI or Gemini key in 🔌 and use 🎨 Photo Studio → ✨ AI restyle.';
  vision('Describe this picture in one detailed sentence for an artist to redraw it: the main subject, face/hair, clothing and colours, pose, and background. No intro, max 70 words.', [CUR.url], 45000).then(function (r) {
    var desc = r.t.replace(/\s+/g, ' ').trim().slice(0, 500);
    return loadImg(CUR.url).then(function (img) {
      var w = img.naturalWidth, h = img.naturalHeight, s = 1024 / Math.max(w, h), W = Math.round(w * s / 64) * 64 || 1024, H = Math.round(h * s / 64) * 64 || 1024;
      var url = 'https://image.pollinations.ai/prompt/' + encodeURIComponent(styleTxt + ', ' + desc) + '?width=' + W + '&height=' + H + '&nologo=true&seed=' + Math.floor(Math.random() * 1e6);
      return loadImg(url).catch(function () { return new Promise(function (res, rej) { var i2 = new Image(); i2.onload = function () { res(null); }; i2.onerror = rej; i2.src = url; }); }).then(function (im2) {
        var out = url; if (im2) { try { out = canvasOf(im2, 1600).toDataURL('image/png'); } catch (e) { out = url; } }
        st.textContent = ''; setCur(out, true); show(m, out, '✨ ' + styleTxt.split(',')[0] + ' version. ' + keyNote, 'ai'); feel('happy', 1800); talk('Here is your new picture.');
      });
    });
  }).catch(function () {
    st.textContent = ''; feel('sad', 2000);
    m.innerHTML = mdh('I could not create that style right now (the free AI is busy or offline). Try again in a minute, or use the on-device styles: **cartoon, sketch, oil, neon, pixel, vintage, HDR, glow**. With an OpenAI or Gemini key, 🎨 Photo Studio → ✨ AI restyle repaints your exact photo.');
    chips(m);
  });
}
function ask(question, m) {
  if (!CUR) return reply('Send a photo first with the ➕ button, then ask me about it.');
  m = m || add('<span class="dots"><i></i><i></i><i></i></span>', 'a'); feel('search'); st.textContent = '🔍 Looking at your photo…';
  vision(question + '\n\n(Answer about the attached picture.)', CUR.frames || [CUR.url]).then(function (r) {
    st.textContent = ''; m.innerHTML = mdh(r.t); footer(m, r.src, r.t); scroll(); talk(r.t); feel('happy', 1600);
    try { remember('[photo] ' + question, r.t); } catch (e) { }
  }).catch(function () {
    st.textContent = '🧠 Checking the photo on your device…';
    local(CUR.url).then(function (t) { st.textContent = ''; m.innerHTML = mdh(t); footer(m, 'On-device AI (works without keys)', t); scroll(); talk(t); feel('happy', 1400); })
      .catch(function () {
        st.textContent = ''; feel('sad', 2000);
        m.innerHTML = mdh('The online picture AIs did not answer just now, and the on-device detector could not load (it needs internet once). The photo facts above still work, and every edit still works: try **remove background**, **enhance**, **cartoon** or **add text "Hello"**. For reliable picture answers add a free **Gemini** or **Pollinations** key in 🔌.');
      });
  });
}
/* on-device object detection (TensorFlow.js COCO-SSD, 80 everyday objects); loads once, then works offline */
var cocoP = null;
function script(src) { return new Promise(function (res, rej) { if (document.querySelector('script[src="' + src + '"]')) return res(); var s2 = document.createElement('script'); s2.src = src; s2.onload = res; s2.onerror = rej; document.head.appendChild(s2); }); }
function coco() {
  if (!('regeneratorRuntime' in root)) root.regeneratorRuntime = null; /* lets the library load without needing 'unsafe-eval' */
  if (!cocoP) cocoP = script('lib/tf.min.js').then(function () { return script('lib/coco-ssd.min.js'); }).then(function () { return root.cocoSsd.load({ base: 'lite_mobilenet_v2' }); });
  cocoP.catch(function () { cocoP = null; });
  return cocoP;
}
function local(url) {
  return Promise.all([coco(), loadImg(url)]).then(function (r) {
    var img = r[1], c = canvasOf(img, 640);
    return r[0].detect(c, 20, 0.35).then(function (dets) {
      var f = facts(img, 0), cnt = {};
      dets.forEach(function (d) { cnt[d.class] = (cnt[d.class] || 0) + 1; });
      var names = Object.keys(cnt).map(function (k) { var best = Math.max.apply(null, dets.filter(function (d) { return d.class === k; }).map(function (d) { return d.score; })); return '- **' + (cnt[k] > 1 ? cnt[k] + ' × ' : '') + k + '** (' + Math.round(best * 100) + '% sure)'; });
      var main = f.pal.slice(0, 3).map(function (p) { return p.name; }).join(', ');
      return '### What I can see (on-device check)\n' + (names.length ? names.join('\n') : '- No everyday objects recognised: it may be a drawing, logo, document or close-up.') +
        '\n\n### Picture details\n- ' + f.w + ' × ' + f.h + ' px, ' + f.orient + '\n- Main colours: ' + main + '\n- Looks ' + (f.bright > 70 ? 'bright' : f.bright < 30 ? 'dark' : 'well lit') + ' and ' + (f.sharp > 90 ? 'sharp' : 'a bit soft') + (f.transparent >= 3 ? '\n- Has a transparent background' : '') +
        '\n\n_This quick check knows about 80 kinds of objects (people, vehicles, animals, furniture, phones…). For full descriptions and reading text, add a free Gemini or Pollinations key in 🔌._';
    });
  });
}
root.JV_local = local;
/* called by plus.js when a photo or video frames are sent */
function run(imgs, q, label, el0, srcURL) {
  var first = srcURL || imgs[0], isVideo = imgs.length > 1;
  setCur(first); if (isVideo) CUR.frames = imgs;
  var it = q ? intent(q, true) : null;
  if (it && it.kind === 'edit' && !isVideo) { el0.remove(); return edit(it.ops); }
  loadImg(first).then(function (img) {
    var bytes = Math.round((first.length - first.indexOf(',') - 1) * 0.75), f = facts(img, bytes);
    el0.innerHTML = '<b>📷 Photo facts</b> <span class="jv-hint">(on your device, instant)</span>' + factsHTML(f);
    chips(el0);
  }).catch(function () { el0.innerHTML = '<b>📷 Got your ' + (isVideo ? 'video' : 'picture') + '.</b>'; }).then(function () {
    var prompt = q ? q : 'Analyze ' + label + ' for me. Explain in very simple, easy words with short headings and bullets: what it shows (people, objects, place, style), the important details, any text you can read (exactly), and helpful tips or next steps.';
    ask(prompt, add('<span class="dots"><i></i><i></i><i></i></span>', 'a'));
  });
}
root.JV = { run: run, edit: edit, ask: ask, vision: vision, show: show, facts: facts, loadImg: loadImg, canvasOf: canvasOf, set: function (u) { setCur(u, !!CUR); }, cur: function () { return CUR; } };

/* paste or drop a picture in the chat: analyze it (the 🎨 button still opens the Studio) */
function fromFile(f) {
  if (!f || !/^image\//.test(f.type)) return false;
  var r = new FileReader(); r.onload = function () {
    var src = r.result;
    add('<img src="' + src + '" style="max-width:150px;border-radius:10px">', 'u');
    loadImg(src).then(function (i) { var c = canvasOf(i, 1024); var el0 = add('🔍 Looking carefully…', 'a'); run([c.toDataURL('image/jpeg', 0.85)], (inp.value || '').trim(), 'this photo', el0, c.toDataURL('image/png')); inp.value = ''; });
  }; r.readAsDataURL(f); return true;
}
document.addEventListener('paste', function (e) { if (e.target !== inp) return; var fs = (e.clipboardData && e.clipboardData.files) || []; if (fs.length && /^image\//.test(fs[0].type)) { e.preventDefault(); e.stopImmediatePropagation(); fromFile(fs[0]); } }, true);
log.addEventListener('drop', function (e) { var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (f && /^image\//.test(f.type)) { e.preventDefault(); e.stopImmediatePropagation(); fromFile(f); } }, true);

/* ---------- front door: follow-up messages about the last photo ---------- */
var prevH = root.handle;
root.handle = function (raw) {
  var s = String(raw == null ? '' : raw).trim();
  if (!s || !CUR || (window.JT_pending && window.JT_pending())) return prevH(raw);
  var mentionsImg = /\b(?:photo|image|picture|pic|selfie|background|dp)\b/i.test(s);
  if (root.JW_site && root.JW_site.active && !mentionsImg) return prevH(raw); /* talking about the website */
  if (Date.now() - CUR.t > 30 * 60000 && !mentionsImg) return prevH(raw);       /* old photo, unrelated chat */
  var it = intent(s, true);
  if (!it) return prevH(raw);
  add(esc(s), 'u');
  if (it.kind === 'edit') return edit(it.ops);
  return ask(s);
};
var det = document.querySelectorAll('#panel details')[1];
if (det) det.appendChild(el('div', { html: '<p><b>📷 Photos:</b> send a photo with ➕ (or paste / drop it). Lexi explains it (free, no key needed) and then edits it the way you say: remove background · white background · enhance · cartoon · sketch · black and white · add text "Happy Birthday" at the top · circle profile picture · crop 16:9 · rotate right · brighter 30% · resize to 1080x1080 · anime style. Ask questions too: what is he wearing? read the text.</p>' }));
})(typeof window !== 'undefined' ? window : globalThis);
