# Lexi voice assistant: install on any device

## Download options (smaller files)
- **lexi-app-v28-small.zip**: the whole app without the offline dictionary. Everything works; word meanings are looked up online.
- **lexi-dictionary-addon.zip**: the offline dictionary (147,478 English words, the `dict` folder). Unzip it and put the `dict` folder inside the Lexi folder, next to `index.html`, then upload the folder again. Training Center → Words shows whether it is installed.
- **lexi-app-v28-full.zip**: both in one file.

## New in v31: only the floating robot (desktop app)
`desktop/START-LEXI-ROBOT.bat` (Windows) starts a transparent, always-on-top window that shows only the robot, its Mic/keyboard/menu buttons and the type box, with nothing else around it. See `desktop/README.md`. A normal browser window cannot be transparent, so the ?mode=widget window from v30 keeps its dark background.
- Fixed: when started with `npm start`, "Start with the computer" now remembers the app folder (it used to open an empty Electron window at login).

## New in v30: the cropped Widget window
Just the part you marked: **robot, "Tap me to talk", Mic OFF / ⌨ / ⋯ buttons and the "Type to Lexi…" box with Send**, with the type box always open. Everything works as in robot mode (tap to talk, mic on/off, typed questions, answers in a speech bubble, calculator, memory, all languages).
- **Open it:** ⋯ → **Widget on top of all windows** (Chrome/Edge, stays above every program), ⋯ → **Widget in its own window** (a 400 x 470 pop-up, works in any browser), `index.html?mode=widget`, the app icon shortcut **Widget (cropped)**, or say / type "open widget".
- **Inside the widget:** ⋯ → Open full Lexi in a tab, Close this widget, Always start in robot mode.
- **Tip:** open Lexi from `http://localhost` or your https site, not by double-clicking index.html (file://). On file:// Chrome asks for the microphone every time and the offline cache cannot install.
- Cache is now lexi-v33.

## New in v28: the floating robot (use Lexi without opening the app)
Only Lexi's robot stays on the screen. **Tap the robot** to talk once. The **🎙️ Mic ON / Mic OFF** button under the robot
turns hands-free listening on or off. Answers appear in a speech bubble and are spoken. ⌨️ types, ⋯ (or long-press) opens the menu.
Drag the robot anywhere. Say "mic on", "mic off", "robot mode", "open full Lexi".
- **In the browser / installed web app:** + menu → **Floating robot**, the app icon's long-press shortcut **Floating robot**,
  or open `index.html?mode=robot`. ⋯ → **Float on screen** keeps the robot above all windows (Chrome/Edge on a computer).
  ⋯ → **Always start in robot mode** makes Lexi open as the robot.
- **Windows / Mac / Linux app:** `desktop/` (ready Windows build: `Lexi-Robot-Windows-x64.zip`). Small robot floats over every
  program and website all the time, can't be closed by accident (only tray → Quit), survives the full app closing, 4 sizes, tray icon, Ctrl+Shift+L show/hide, Ctrl+Shift+M mic, start with the computer. See `desktop/README.md`.
- **Android:** `android/` — Android Studio project for a robot that floats over all apps (chat-head style) with Mic ON/OFF
  under it, using the phone's own speech recognition and voice. Build steps in `android/README.md`.
- **Cloud mic:** where a browser has no speech recognition (desktop app, Firefox), Lexi records the question and the company
  AI server (`/v1/transcribe`, update the Worker) or a Gemini key turns it into text.

## New in v27: a living, human-like robot
- **36 animations** (28 new): laugh, giggle, tickle, surprised, confused, wink, shy blush, cry, yawn, stretch, cool sunglasses, star-eyed excited, celebrate with confetti, clap, scared, nervous sweat, sorry, namaste, bow, dizzy spiral eyes, kiss, sing, hum, sleepy, proud, salute, thinking with hand on chin, shiver, hot, nod yes, shake no, shrug, facepalm, point, hug, peekaboo, plus the earlier wave, dance, love, angry, sad, search, listen, think and sleep. New faces, arm poses, and particles (confetti, hearts, music notes, stars, tears, sweat, snow, petals) with little speech bubbles.
- **Human-like behaviour:** eyes follow your finger or mouse; the mouth moves with every spoken word; idle habits (winks, hums, peeks, stretches, yawns); gets sleepy before falling asleep.
- **Reacts to you:** “haha” → laughs, “wow” → surprised, “namaste” → bows with folded hands, “thank you” → bows, “congrats / yay” → confetti, “huh?” → confused, “I am sad” → cries with you, “so cold” → shivers, “bye” → waves and bows; a joke answer makes it laugh; answers starting “Yes” nod, “No” shake, “I’m not sure” shrug. Serious distress messages only ever get a calm, gentle response.
- **Touch:** tap = wave, double-tap = giggle, 4 quick taps = tickle, long press = hug, shake it = dizzy.
- **Commands:** “show animations”, “laugh”, “salute”, “do a facepalm”, “blush”, “animations calm”, “animations off”.
- **Training Center → Animations:** play every animation on a big robot; Full / Calm / Off; switches for eye-follow, lip-sync and reactions. Phones set to “reduce motion” stay still.
- **AI server:** if Google retires every model name it knows, the server now asks Google which Gemini models the key can use and switches automatically.
- Cache is now lexi-v29.

## New in v26: understands sentences and paragraphs in any language
- Ask in chat: “explain: …”, “meaning of this sentence: …”, “what does "…" mean”, “summarize: …”, “simplify: …”, “correct grammar: …”, “word by word: …”, “is line ka matlab batao: …”, “… ka matlab kya hai”, “इस वाक्य का मतलब: …”. Paste long or multi-line paragraphs too (up to 8,000 characters).
- **At once, offline:** language, number of sentences and words, reading time, reading level (English), and meanings of the hard words from the built-in dictionary.
- **Then with AI:** the meaning in plain English and in your language, English translation, summary and key points (paragraphs), a very simple version, idioms and proverbs explained, word-by-word meaning (short sentences), grammar corrections with reasons, tone, and cultural notes.
- **Remembered:** every text goes into **My sentences** (Training Center → Sentences: understand box, search, practice cards) and into your conversation history. Text you paste for explanation is never saved as facts about you.
- Normal questions (“explain how an actuator works”, “summarize the history of India”) still go to the AI as usual; one or two words go to the dictionary.
- `training-examples.jsonl` now has 150 examples, including sentence, proverb, idiom and grammar explanations in English, Hindi, Hinglish, Tamil, Spanish, French and Japanese.
- Cache is now lexi-v28.

## New in v25: strong answers for everyone (company AI server)
- **Why answers were weak:** the free keyless AI Lexi used (Pollinations) now requires a key, so without a key answers were weak or failed.
- **The fix:** `server/lexi-ai-worker.js`, a free Cloudflare Worker that holds the company's free Google Gemini key as a secret. Every Lexi user gets Gemini answers (strong in Hindi, Odia, Malayalam, Kannada and 40+ languages) without entering a key. Setup takes about 10 minutes: see `server/README.md` or **+ → Training Center → AI server**.
- **Automatic:** once the address is set (in the app, or for everyone in `lexi-config.json`), every keyless AI request goes to the server: chat (streaming), the language router, translations, memory, photo questions, website and zip helpers. Your own keys still come first. If the server is down, Lexi falls back as before.
- **Better answers:** with the server, Lexi sends its full instructions (they were cut to 1,500 characters for the old free service), and answers in other languages get extra guidance for correct grammar and accuracy.
- **Safe:** the key never appears in the app; only your site can use the server; each visitor is rate-limited.
- The Training Center Overview now shows **AI quality** first. Cache is now lexi-v27.

## New in v24: accuracy fixes
- **Language detection is more accurate** (79 of 79 test messages, up from 56 of 70): a mostly-English message with a few Hindi words stays English; short phrases like “Gracias”, “Merci beaucoup”, “Obrigado” are recognised; repeated words no longer mislead it; Nepali, Ukrainian, French, Portuguese, Indonesian and Turkish are recognised better. New: Tamil, Telugu, Kannada, Bengali, Marathi, Malayalam and Gujarati typed in English letters (like Hinglish) are recognised and answered the same way.
- **Answers come in the right language:** every clear English message now tells the AI to answer in English, even if the microphone is set to another language.
- **The app no longer switches language too easily:** it needs three clear messages in a row, and asks before installing a new language.
- **Chat answers:** company quick replies only answer clear contact questions (“change your website colour” now goes to the AI); answers no longer show “[Company profile]” labels; saying “that is wrong” makes the next try a fresh answer instead of a saved one; earlier chats are added only when they really match (two or more shared key words).
- **Dictionary:** abbreviations and codes (PWM, SMPS, IP65, 24V, HTTP 404) and phrases like “this error” go to the AI instead of “Did you mean…”; when online, meanings switch to the fuller online dictionary (common meaning first, real examples, pronunciation), keeping WordNet’s similar and opposite words; offline it still uses WordNet.
- **Installed languages:** each translated interface text is checked so a mismatched translation never lands on the wrong button.
- Cache is now lexi-v25.

## New in v23: automatic language + Lexi remembers every conversation
- **Automatic language detection** for everything you type or say: 26 scripts (Hindi, Marathi, Nepali, Bengali, Assamese, Tamil, Telugu, Kannada, Malayalam, Gujarati, Punjabi, Odia, Urdu, Arabic, Persian, Pashto, Russian, Ukrainian, Kazakh, Chinese, Japanese, Korean and more), Hinglish, and 20 Latin-script languages (Spanish, French, German, Portuguese, Italian, Indonesian, Turkish, Swahili, Filipino...).
- **Automatic actions** (Training Center → Languages → Automatic language; each can be turned off):
  - Lexi replies in the language of your message (Hinglish gets Hinglish in Roman letters).
  - The microphone switches to your language, so the next voice message is understood.
  - After two messages in a row in another language, the whole app switches to it (installing the language pack if needed), with an Undo button. Three clear English messages switch it back.
- **Message analysis:** under each message you see its language, type (question, command, greeting, thanks, complaint, statement) and mood, plus “Show in English” for other languages.
- **Remembers every conversation** (Training Center → History, up to 5,000 exchanges on this device): language, type and mood statistics, search, export (.json/.txt), delete. When you ask something related to an earlier chat, Lexi uses it in the answer. Ask “what did I ask about warranty”, “what did we talk about yesterday”, “search history price”, “kal maine kya poocha”. Passwords, OTPs and PINs are hidden. Your usual language is also saved to Memory.
- Cache is now lexi-v24.

## New in v22: install any language
- **173 languages can be installed** (+ → 🎓 Training Center → Languages, or say “install Tamil”, “switch app to Hindi”, “app ko Marathi mein karo”). This includes Indian languages such as Hindi, Bengali, Tamil, Telugu, Kannada, Malayalam, Marathi, Gujarati, Punjabi, Odia, Assamese, Urdu, Konkani, Tulu, Bhojpuri, Maithili, Santali and Dogri, and world languages from Afrikaans to Zulu.
- **Installing a language** translates the whole app once with AI (about 600 texts: buttons, menus, tips, every Training Center tab) and keeps it on the phone, so it works offline afterwards. New text that appears later is translated in the background. Lexi then replies in that language.
- **Speaking and listening** switch to that language where the phone supports it (82 languages). For languages without a voice yet, the Languages tab shows the exact steps for Android, iPhone, Windows or Mac to add the voice and offline speech, with 🔊 Test voice and 🎤 Test listening buttons. A website cannot install phone voices by itself.
- Say “switch the app to English” (or Training Center → Languages → English) to go back. Picking a language in the voice box at the top also switches the app if that language is installed.
- Cache is now lexi-v23.

## New in v21: words and meanings
- **147,478 English words and phrases offline** (Princeton WordNet 3.1, in the `dict/` folder): meanings, examples, similar and opposite words. Lexi understands word forms (ran → run, children → child, happier → happy) and fixes spelling (“serendipty” → serendipity).
- **Every language online:** words in thousands of languages come from Wiktionary (for example “सपना का मतलब”), and English pronunciation and audio from the Free Dictionary API.
- **Ask in chat, in English, Hinglish or Hindi:** “meaning of resilient”, “what does ubiquitous mean”, “serendipity ka matlab”, “सपना का मतलब क्या है”, “synonyms of happy”, “opposite of strong”, “pronounce quinoa”, “spell necessary”, “word of the day”. A Hinglish or Hindi request also gets a short AI explanation in that language. Each card has 🔊, Explain simply, Hindi meaning and Use in sentences.
- **My words:** every word you look up is saved, with flashcard practice that brings words back after 1, 3, 7, 16 and 35 days (Training Center → Words).
- **Fully offline:** Training Center → Words → Download full dictionary (about 7 MB, once). Otherwise each part loads the first time it is needed and is kept.
- **Typo-tolerant understanding:** “warrenty”, “adress”, “actuater” still find your company knowledge.
- Cache is now lexi-v22; the dictionary has its own cache that survives updates. WordNet licence: `dict/WORDNET-LICENSE.txt`. Rebuild the dictionary with `training/build_dictionary.py`.

## New in v20: memory, 82 voice languages, faster replies
- **Long-term memory (any language):** Lexi remembers what you tell it: “my name is Ravi”, “mera naam Suresh hai”, “I live in Pune”, “my wife's name is Priya”, “remember that my car is a white Nexon”, “yaad rakhna …”. With an AI available it also learns facts from messages in any language (for example French or Tamil) in the background. Ask “what is my name”, “what do you remember about me”, “forget my car”, “forget everything”, “undo forget”. Passwords, OTPs, PINs, card, bank and ID numbers are never saved. Manage it in Training Center → Memory. Saved on this device only.
- **Every AI answer knows you:** your name and the memories that match the question are sent with it, to every AI.
- **Languages:** voice input and read-aloud list grows from 36 to 82 languages; replies in Spanish, French, German, Indonesian and similar languages are read aloud in the right voice. Typing works in 100+ languages through the AI. Company questions in Hindi, Tamil, Telugu, Kannada, Bengali, Spanish, French, Russian, Arabic, Chinese, Japanese and more now find your English documents. Training Center → Languages shows which voices your phone has.
- **Faster:** non-English questions and long messages skip the extra “is this a command?” AI call (saves 1 to 6 seconds); the command check now gives up after 6 s instead of 12 s; connections to the AI servers open as the app loads; a question that matches a saved correction, and memory questions, are answered instantly without the AI.
- **Tests:** 20 new questions in 18 languages (Training Center → Tests → Languages). `training-examples.jsonl` now has 134 examples, including 29 in 20 languages and memory behaviour.
- Cache is now lexi-v21.

## New in v19: Training Center (train Lexi properly)
Tap **+ → 🎓 Training Center** (or type "open training center"). Full steps: `training/README.md`.
- **Company profile:** Purlin's address, website, products and protection features are built in (`company-profile.json`). Fill phone, e-mail, hours, specs and warranty in the app; empty fields make Lexi say "the team will confirm" instead of guessing.
- **Knowledge base:** add PDFs, Word, PowerPoint, text or web pages. Before every AI answer Lexi searches them and sends only the best 3 to 5 passages, to every AI (Claude, ChatGPT, Gemini, Groq, OpenRouter, free AI, your own model). `docs.json` ships a general actuator selection guide; add your own and download docs.json to share with all users. PDF reading is bundled (`lib/pdf.min.js`), so it works offline.
- **Corrections by meaning:** every correction is used whenever a similar question comes up, not only the last 8. Up to 25 rules.
- **Instant actuator calculator:** travel time, speed from lead and rpm, power, force from torque, duty cycle, load with safety margin, and company contact answers, offline.
- **Tests:** 50 questions (maths, actuator, company facts, honesty, safety, code, Hindi/Hinglish, logic) plus your own, with score history.
- **Review answers and dataset:** mark good answers or fix wrong ones; export JSONL (all, or train + test split). `training-examples.jsonl` now has 105 examples.
- **My model:** connect a model you fine-tuned (Ollama, LM Studio or any OpenAI-style server); Lexi asks it first. `training/train_lexi_colab.py` trains one in free Google Colab.
- **Fixes:** the old self-test always scored 0 (it called a function it could not reach); the 🧠 button no longer covers the + button; the 1.4 MB TensorFlow files are no longer downloaded at install; cache is now lexi-v20.

## New in v18: professional name
The "Lexi" title now uses a refined system font, tighter spacing, a gradient and a small "AI VOICE ASSISTANT" tagline.

## New in v17: clean header
The extra header icons (mini window, attach, sparkles, tasks, alarms, translate, photo studio, connections) are hidden. Tap the + button next to the message box to open them, plus Teach Lexi and Self-test. All functions and voice commands still work.

## New in v16: second knowledge pack
`knowledge2.js` adds debugging, web/API codes, SEO, writing, business formulas, science, safety, translation and engineering references. `training-examples.jsonl` now has 50 examples.

## New in v15: built-in knowledge
`knowledge.js` adds a compact reference (maths formulas, logic method, website and code checklists, app conversion steps, actuator formulas) to the detailed prompt. `training-examples.jsonl` now has 30 examples.

## New in v14: teach Lexi
Tap the pink 🧠 button (bottom left) to add your own rules ("always reply in Hinglish") and corrections (a question Lexi got wrong plus the right answer). They are saved on this device only and added to every AI request. Delete any with ✕. `training-examples.jsonl` is a small example set for optional real fine-tuning.

## New in v13: smarter, checked answers
- **Stronger built-in rules** for every AI reply: follow instructions exactly, check work before answering, re-check and explain plainly when you say "that is wrong", say "not sure" instead of inventing facts, complete working websites and apps (one .html file, every button wired), verified maths and logic, and privacy rules (never asks for passwords, OTPs or keys).
- **Self-test:** open `index.html#selftest` (or run `lexiSelfTest()` in the console) to score the connected AI on 12 maths, logic, coding and identity questions. Re-run it after changing AI provider or key.
- Manifest description updated, old JAAN referrer removed.

## 1. Put it online (free, needs HTTPS to install)
Upload this whole folder to any static host: Netlify Drop (app.netlify.com/drop), GitHub Pages, Vercel or Cloudflare Pages.
Test on your own computer: `python3 -m http.server 8000`, then open http://localhost:8000 (installing works on localhost).

## 2. Install
- iPhone/iPad: Safari, Share, Add to Home Screen
- Android: Chrome, Install app
- Windows, Mac, Linux, Chromebook: Chrome or Edge, install icon in the address bar
- Or tap the Install button inside the app, which shows the right steps for your device.

## 3. Use on other devices
Open the app, tap the gear icon, then "Share app link" and open that link on the other device.

## New in v12: much faster replies

**Instant replies (about 0.25 seconds, no internet needed).** Everyday conversation is answered on the spot, with several different replies per topic so it never sounds repeated. It works in English, Hindi and Hinglish:
- "I love you" gives "I love you too! 💖" (also "love you", "आई लव यू", "mujhe tumse pyaar hai", "you are so cute", "I miss you", "give me a hug")
- how are you / what's up / kaise ho, thank you / shukriya / धन्यवाद, bye / alvida, good morning / afternoon / evening / night (night puts the robot to sleep), sorry
- compliments ("good job", "you are the best"), rude words (a calm, apologetic reply), "are you a robot / human", age, where you live, "do you sleep", "do you have feelings", "will you be my friend", "will you marry me", favourite colour / food / movie, "tell me about yourself"
- your feelings: sad, happy, bored, tired, hungry, angry, lonely, stressed, not well
- fun: sing, dance, talk to me, lol, I'm back, are you there
- Serious messages (for example about self-harm) are never answered with a quick reply. They always go to the full AI.

**Faster AI answers for everything else**
- Answers **stream in word by word** (you see the first words in about a second instead of waiting for the whole answer).
- Backup routes start **in parallel** after 3 seconds instead of one after another, so a slow or stuck server can no longer freeze a reply. Every network call now has a time limit.
- Short questions use a **short prompt, a fast model and a small token budget**. Long jobs (code, apps, essays) still get the full detailed prompt and the strongest model.
- Less history is sent each time.
- **Saved answers:** asking the same general question again is answered instantly (kept for 6 hours; never used for news, weather, prices, time, or anything personal or follow-up).
- The Hindi / Hinglish command router and the live web lookup now give up after a few seconds instead of up to 15.

## New in v11: the assistant is now called Lexi

The name changed everywhere you can see or hear it: header title, page title, home-screen name, greetings, voice, notifications, alarm files, downloads and what the AI says when you ask "who are you". Voice commands work with the new name ("Hey Lexi, set an alarm") and still accept the old name. Your saved data (contacts, alarms, keys, chat settings) is untouched.

## New in v10: new robot + animations

The logo and the big welcome robot are now your new robot (pink heart antenna, headphones, waving paw). It is built from separate layers (body, waving arm, antenna, floating heart) with a drawn face on the visor, so each part moves on its own:

| Moment | What the robot does |
|---|---|
| App opens, you say hi / hello / hey / hii, you tap the robot | 👋 **Hand wave** (the arm really swings) with a "Hii!" bubble and happy face |
| Idle | Floats, blinks, looks left and right, antenna sways, heart floats. Every ~11 s it waves, smiles or sends a heart |
| You are silent for 45 s | 😴 **Sleeps**: eyes close, "z Z z" float up, antenna and arm droop, it breathes slowly. Any tap, key or voice wakes it with a stretch and a wave. Say "good night" to send it to sleep |
| Search, Google, YouTube, news, weather, reading a photo, website or zip | 🔍 **Searching**: a magnifying glass sweeps across the visor, eyes follow it, body leans side to side |
| Thinking | Eyes look around, thought dots, tilts its head |
| Listening (mic) | Wide eyes, sound waves, glowing headphones |
| Speaking | Mouth moves, nods |
| "I love you", "you are cute" | 😍 **Heart eyes** and a pink glow |
| "Dance", "party", "play music" | 🎵 **Dances**, both antenna and arm wiggle |
| Error / sorry / cannot | Sad face with a tear |
| Rude words | Angry red face |

Animations respect "reduce motion" in your phone settings. The app icons (home screen) were updated to the new robot too.

## New in v9: zip analysis, Edit + Copy on pictures and zips, YouTube fix, stronger coding answers

### 🗜️ Send a zip file (new)
Tap ➕ (or 📎, or drag a .zip into the chat). Lexi reads it **on your device** (nothing is uploaded) and shows:
- what it is (website, PWA, Node, Python, Java, Go, Rust, PHP, Docker…), file and folder counts, size, lines of code per language
- a bar chart of what is inside, the largest files and a full file tree
- **automatic checks**: broken file links (HTML, manifest, service worker), invalid JSON, secrets such as API keys or private keys (the value is never shown), .env files, node_modules / .git / junk files, duplicate files, unsafe paths, risky code (eval, document.write, many innerHTML), TODO notes
- buttons: 🤖 Explain this project · 🐞 Find bugs · 🔒 Security review · ✨ Suggest improvements · 📋 Copy report · ⬇ Report (.md)
- ask anything afterwards: "what does tasks.js do", "is there any bug in index.html", "show sw.js" (opens the file with Copy / Download), "list files", "forget the zip".
- Zip support: stored and deflate zips, zip64, self-extracting zips. Password-protected files are listed but not read. The AI buttons send only short excerpts of the important files to your AI (or the free AI if you have no key).

### ✏️📋 Edit and Copy under every message
Pictures, videos and zips now have the same **Edit** and **Copy** as text messages.
- Picture: Copy puts the picture on your clipboard (or saves it if your browser blocks that). Edit lets you change the question, replace the picture (🖼 Change picture) and send again.
- Zip: Copy copies the full report. Edit lets you change the question or choose another zip (🗜 Change file).

### ▶️ YouTube "Video player configuration error 153" fixed
- The player now sends the correct referrer and origin that YouTube requires.
- Every video has a ↗ YouTube button and a "Video not playing? Watch it on YouTube" link, and more search servers were added.
- Error 153 always happens when the app is opened straight from a file (C:/...). In that case Lexi now opens the video on YouTube instead of showing a broken player. To play videos inside Lexi, host the folder (Netlify Drop, GitHub Pages) or run `python3 -m http.server`.

### 💻 Better coding answers
The built-in instructions now require complete, runnable code (no placeholders), one self-contained HTML file for apps and tools, a mobile-friendly layout, input checks, a mental test run before answering, the code first and short notes after, and a clearly stated assumption when the request is vague.

## New in v8: image creator, accurate technical drawings, photo looks, stronger photo AI

### 🖼️ Image creator (free, no key)
"create an image of a red sports car", "4 logos for Purlin Automation", "draw a cat astronaut in anime style", "wallpaper of mountains 9:16", "create 4 images of an electric linear actuator exploded view".
- 30 styles (photo realistic, cinematic, 3D, anime, Ghibli, cartoon, oil, watercolour, sketch, pixel, cyberpunk, logo, app icon, sticker, poster, product photo, **engineering render, exploded view, cutaway, blueprint**, isometric…), 5 sizes, 1/2/4/6 pictures at once.
- ✨ Improve prompt: the AI rewrites your idea into a detailed, accurate prompt (with correct parts for mechanical subjects).
- 🌈 Same idea in 6 styles. Tap a picture: Download, ✏️ Edit with words, 🔁 4 more like this.
- Models: free Flux / Turbo (Pollinations), or Gemini / OpenAI with your key.

### 📐 Accurate technical drawings (vector, real proportions, dimensions)
- `linear actuator drawing stroke 200 mm retracted 340 hole 10 24V 6000N IP65 model PAI-01-V1`: retracted + extended views, stroke, hole-to-hole lengths, tube/rod/hole sizes, parallel or inline motor, spec table, title block. **Works offline.**
- `flange drawing OD 200 ID 80 PCD 160 8 holes 14 mm thickness 20`: front view + section. **Works offline.**
- Any other part: `technical drawing of a shaft 200 long diameter 30 with keyway`. The AI draws a dimensioned SVG (check the dimensions before manufacturing).
- Download SVG (opens in CAD / Inkscape), PNG, or Print / PDF; 🖼️ Realistic render makes AI pictures of the same part.

### 🎨 Your photo, many looks
- "show all styles": every on-device style side by side; tap one to apply.
- "4 ai styles": anime, Ghibli, 3D and oil versions.
- Free-form changes: "make his hoodie red", "AI edit: add sunglasses". With a Gemini or OpenAI key your exact photo is edited; without a key the free AI redraws it with the change.

### 📷 Photo understanding is stronger
- Uses the new Pollinations service (and an optional free **Pollinations key** in 🔌), with smaller uploads.
- If every online AI is down, an **on-device detector** (TensorFlow.js COCO-SSD, 80 everyday objects) names what is in the photo. It downloads its model once (about 5 MB), then works offline.

## New in v7: photos are understood and edited (no key needed)

### 📷 Understand any photo
Send a photo with ➕ (or paste / drop it in the chat).
- **Photo facts**, instant and on your device: size, light, focus, main colours, transparent background, plus tips.
- **AI explanation**: what it shows, details and any text in it. Uses your Gemini / Claude / ChatGPT / Groq key if added, otherwise a **free vision AI (no key)**.
- Then just ask: "what is he wearing", "read the text in this photo", "what colour is the hoodie", "describe it".

### 🎨 Change the photo the way you want
Type it in your own words; edits stack, with **Undo**, **⬇ PNG**, **⬇ JPG** and **Share**:
- remove background · white / blue / any colour background
- add text "Happy Birthday" at the top (in yellow)
- cartoon · sketch · black and white · sepia · vintage · HDR · oil · neon · pixel · glow · blur background · enhance
- rotate left/right · flip · square crop · crop 16:9 · story size · passport size · circle profile picture · rounded corners · gold frame
- brighter 30% · darker · more contrast · warmer · cooler · sharpen · blur · invert
- resize to 1080x1080 · 50% size · compress (download JPG)
- **anime / Ghibli / 3D / watercolour / cyberpunk / comic** styles: without a key a free AI draws a new picture from your photo's description. With an OpenAI or Gemini key, 🎨 Photo Studio → ✨ AI restyle repaints your exact photo.

Most edits run on your device, so nothing is uploaded. Removing a plain or checkered background works offline; very busy backgrounds get a cleaner cut-out with the AI in Photo Studio.

## New in v6: edit messages, Connections centre, live web search

### ✏️ Edit your messages
- Every message you send has **✏️ Edit** and **📋 Copy** under it. Edit, then press **Enter** (or Save & send): Lexi answers the new version and replaces the old answer, like editing in Claude.
- Shift+Enter = new line, Esc = cancel. Press ↑ in an empty input box to edit your last message.

### 🔌 Connections (all APIs in one place)
Tap 🔌 in the header, or say "connections" or "test all apis". Every service shows its status, and you can paste a key there and tap **Save & test**:
- **Google Gemini** (free key, aistudio.google.com/apikey). Recommended: answers also search Google live and show sources.
- **Groq** (free key, console.groq.com/keys). Very fast Llama answers.
- **Claude**, **ChatGPT**, **OpenRouter** (one key for many models).
- **Google Custom Search** (API key + search engine ID), optional.
- **YouTube** key (optional), plus the free services: free AI, DuckDuckGo/Wikipedia search, website reader, Wikipedia, news, weather, currency, translation.
- Choose which AI answers ("Auto" uses the first connected AI, then the free AI).
- Keys stay in this browser only. No key is built in: each person adds their own.

### 🔎 Live web search
Questions about current things (latest, today, price, score, news, who won, "…?") get fresh results from the web first (Google if connected, otherwise DuckDuckGo + Wikipedia). The AI uses those results and the links are shown under the answer. Switch it off in 🔌.

### Fixes
- "what is / who is …" questions now fall back to the free AI instead of saying "I could not get an answer".
- The settings Save button no longer erases newer keys.

Tip: opening index.html straight from Downloads (C:/…) works, but a few services block local files. Upload the folder to Netlify Drop for everything to work and to install it on your phone.

## New in v5: websites, website builder, fixes

### Read any website (no more "I cannot browse")
- Type or say any link or domain: `purlinautomation.in`, `https://example.com`, "check SEO of mysite.in", "what does flipkart.com sell".
- Lexi opens the page live, shows a **health score out of 100** with 16 checks (HTTPS, title, meta description, H1/H2, mobile viewport, image alt text, word count, Open Graph, canonical, language, favicon, structured data, noindex, contact details, page size), then answers your question with AI.
- Buttons: Summarise · SEO & design tips · Redesign this site. Follow-up questions like "what products does this website sell" use the same page.
- The health check works even without an AI key. Pages are fetched through free public readers (allorigins, corsproxy, codetabs, r.jina.ai).

### Website builder
- "make a website for Sweet Crumbs Bakery with phone 9876543210 services cakes, bread, cookies"
- You get a live preview plus Download .html, Full screen, Copy code, View code and Customise.
- Change it by chatting: "change colour to green", "add a pricing section", "make it dark mode", "website: change name to Purlin Bakery", "add WhatsApp button 9876543210", "address Bhubaneswar, Odisha".
- With an AI key (or the free AI) the design and text are written for you. Offline, a clean built-in template is used, and colour, dark mode, name, tagline, about, phone, e-mail, address and services can still be changed.

### Fixes
- Free-AI answers now get your exact words (capitals, links, code punctuation were being stripped).
- System prompt: follows instructions exactly, answers first, never claims it cannot browse when page content is given.
- "18% gst on 5000" and "gst 12% on 1000" now work (with CGST/SGST split).
- "wake me up at 6:30" and "alarm every day at 7" now default to morning.
- "delete alarm N" confirms the correct label for repeating alarms.
- Free-AI replies that came back as raw JSON are now shown as text.
- Service worker cache bumped to v6 so phones pick up the new files.

## What Lexi can do
- **Alarms:** "alarm tomorrow 8 am", "wake me up at 6:30", "alarm every day at 7", "alarm on monday 9 am", "show alarms", "delete alarm 2", "cancel all alarms". When an alarm rings you get a full-screen Stop / Snooze screen. Every alarm also has a button to add it to your phone calendar, which rings even when Lexi is closed.
- **Calls:** "call mom", "call raj kumar", "call 98765 43210". Lexi searches your saved contacts (spelling mistakes and names like mummy/mom/amma are understood), asks which one if several match, and opens the dialer.
- **WhatsApp / SMS:** "whatsapp mom hii", "message priya saying I am late", "send hello to raj", "tell dad I reached", "text john see you soon", "share my location with mom". WhatsApp opens with the message ready; you tap Send.
- **Reminders, events, timers:** "remind me to pay rent tomorrow 9 am", "add event dentist friday 5 pm", "set timer 1 hour 30 minutes".
- **Daily tools:** expenses ("spent 250 on lunch", "how much did I spend this month"), shopping list, stopwatch, "good morning" daily summary, "keep screen on".

### Any language, translation and reading aloud (new)
- **Speak or type in any language:** Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi, Bengali, Hinglish and more, e.g. "कल सुबह 8 बजे अलार्म लगाओ", "ಅಮ್ಮನಿಗೆ ಕರೆ ಮಾಡು", "mummy ko call karo". Lexi turns it into a command with AI (your key if set, otherwise a free online service), then runs it. Questions are answered in the same language.
- **Pick the voice language** from the dropdown (36 languages), or say "speak in Hindi" / "switch to English". Confirmations are shown and spoken in that language too (turn this off in 🌐).
- **Translate:** "translate good morning to kannada", "how do you say thank you in french", "translate this to hindi" (translates the last answer). Each result has 🔊 Listen, Copy, WhatsApp and "other language".
- **Read aloud:** "read that again", "read aloud <text>", or the 🔊 Read button under every answer. The 🌐 button opens a full Translate & Read screen (type, paste, speak or load a .txt file).
- **Offline:** without internet, basic Hindi / Hinglish alarm, call, WhatsApp, timer and weather commands still work. Other languages and translation need internet.
- **Voices:** reading aloud uses voices installed on your phone. If a language has no voice, Lexi tells you how to install it (Settings, Text-to-speech) or you can use the OpenAI neural voice in ⚙️.
- **Privacy:** with no AI key, the text of a non-English command or translation is sent to a free online service (Pollinations, or MyMemory as backup). Add your own key in ⚙️ to keep it with your provider instead.

### Coding, maths, photos and identity (new)
- **Who made Lexi:** ask "who created you" (or "how create you", in any language) and Lexi answers that ER Dibyaranjan created it.
- **Coding in any language:** paste code (Shift+Enter makes a new line) or ask "fix this error", "write a python function to ...", "add a delete button to this", "convert this to java". Lexi replies with complete code in a code block that has Copy, Download (right file extension) and ▶ Run for HTML / JavaScript (runs in a safe sandbox). Code is never read aloud. Needs an AI key for best results; the free fallback works but is weaker on long code.
- **Maths, solved on your device:** exact big numbers (2^100, 50 factorial), percentages, trig, logs, equations (x^2-5x+6=0), systems (2x+3y=12, x-y=1), derivatives and integrals, statistics, EMI, GST, discounts, interest, dates (days between, age), number bases, primes, GCD/LCM, BMI. Word problems go to the AI, which shows its working.
- **Photo Studio (🎨):** choose, take, paste or drop a picture. 20 free styles (cartoon, pencil sketch, oil painting, HDR, vintage, pixel art, neon...), brightness/colour/sharpness sliders, rotate, flip, crop, text, frame, then download PNG/JPG or share. ✨ AI restyle (Ghibli, anime, 3D cartoon, remove background...) uses your OpenAI or Gemini key; without a key the free styles still work.

### Getting your contacts into Lexi (one time)
Websites cannot read a phone's whole contact list silently. Use the 📇 button:
- **Android Chrome:** "Import from phone", then tap Select all.
- **iPhone / any device:** export contacts as a .vcf (or .csv) file and choose "Import .vcf / .csv". On iPhone: iCloud.com, Contacts, Select all, Export vCard.
Contacts stay on your device only. Set your default country code in the contact book (91 = India).

### Honest limits of a web app
- Calls and WhatsApp open the dialer / WhatsApp with everything filled in; the final Call / Send tap is yours. Phones do not let websites press those buttons.
- Alarms ring while Lexi is open (use "keep screen on"). For alarms that must ring with the app closed, use the calendar button on the alarm card.

## 4. Optional: real store packages
Paste your hosted URL into pwabuilder.com to get Windows (MSIX), Android (APK/AAB) and iOS project packages.

Offline: the app now has a real service worker, so it opens without internet after the first visit.

AI answers need your own API key (gear icon, AI settings). Keys stay in the browser.

## Floating chat bubble on any website
Host this folder, then add to your site: `<script src="https://YOUR-HOST/bubble.js" data-src="https://YOUR-HOST/index.html"></script>`

## Mini window
Tap the mini-window button in the header (Chrome/Edge desktop keeps it on top of other apps).
