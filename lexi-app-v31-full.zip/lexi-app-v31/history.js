/* Lexi history.js v23: remembers every conversation (on this device).
   - Saves each question and answer with its date, language, type and mood (IndexedDB, up to 5,000 exchanges).
   - Before each AI answer, the two most relevant earlier exchanges are added, so Lexi can build on past chats.
   - Ask: "what did I ask about warranty", "what did we talk about yesterday", "search history price", "show my history".
   - Messages with passwords, OTPs, PINs or card/bank numbers are saved with that part hidden.
   Training Center > History: search, statistics by language, export, delete. */
(function (root) {
'use strict';
var doc = root.document, MAX = 5000;
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
var C = Object.assign({ on: true, use: true }, L('lexi_history_cfg', {}));
var H = [], ready = false, DB = null;

function open() {
  if (DB) return DB;
  DB = new Promise(function (res) {
    try { var r = indexedDB.open('lexi-history', 1); r.onupgradeneeded = function () { r.result.createObjectStore('h', { keyPath: 'id' }); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { res(null); }; }
    catch (e) { res(null); }
  });
  return DB;
}
function put(x) { return open().then(function (db) { if (!db) return; try { db.transaction('h', 'readwrite').objectStore('h').put(x); } catch (e) { } }); }
function del(ids) { return open().then(function (db) { if (!db) return; try { var st = db.transaction('h', 'readwrite').objectStore('h'); ids.forEach(function (i) { st.delete(i); }); } catch (e) { } }); }
function clearAll() { H = []; return open().then(function (db) { if (!db) return; try { db.transaction('h', 'readwrite').objectStore('h').clear(); } catch (e) { } }); }
function load() {
  return open().then(function (db) {
    if (!db) { ready = true; return; }
    return new Promise(function (res) {
      try { var q = db.transaction('h').objectStore('h').getAll(); q.onsuccess = function () { H = (q.result || []).sort(function (a, b) { return a.t - b.t; }); H.forEach(index); ready = true; res(); }; q.onerror = function () { ready = true; res(); }; }
      catch (e) { ready = true; res(); }
    });
  });
}

/* ---------- search ---------- */
function toks(s) { try { return root.lexiTrainAPI.toks(s); } catch (e) { return String(s).toLowerCase().match(/[\p{L}\p{N}]+/gu) || []; } }
var DF = {};
function index(x) { if (x.k) return; var t = toks(x.q + ' ' + String(x.a).slice(0, 600)), set = {}; t.forEach(function (w) { set[w] = (set[w] || 0) + 1; }); x.k = set; x.n = t.length || 1; Object.keys(set).forEach(function (w) { DF[w] = (DF[w] || 0) + 1; }); }
function score(x, terms) { var s = 0, hit = 0; terms.forEach(function (w) { var f = x.k[w]; if (!f) return; hit++; s += Math.log(1 + (H.length - DF[w] + 0.5) / (DF[w] + 0.5)) * (f * 2.2) / (f + 1.2 * (0.25 + 0.75 * x.n / 40)); }); return hit ? { s: s * (0.5 + hit / terms.length), cover: hit / terms.length, hit: hit } : null; }
function search(q, n, opts) {
  opts = opts || {};
  var terms = toks(q).filter(function (w, i, a) { return a.indexOf(w) === i; }); if (!terms.length) return [];
  var skip = opts.skipRecent || 0, pool = skip ? H.slice(0, Math.max(0, H.length - skip)) : H, out = [];
  pool.forEach(function (x) { var r = score(x, terms); if (r && r.cover >= (opts.minCover || 0.34) && r.hit >= (opts.minHits || 1)) out.push({ x: x, s: r.s }); });
  out.sort(function (a, b) { return b.s - a.s; });
  return out.slice(0, n || 5).map(function (o) { return o.x; });
}
function day(t) { var d = new Date(t); return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: new Date().getFullYear() === d.getFullYear() ? undefined : 'numeric' }); }
function sameDay(a, b) { a = new Date(a); b = new Date(b); return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
function byDay(offset) { var ref = Date.now() - offset * 864e5; return H.filter(function (x) { return sameDay(x.t, ref); }); }

/* relevant earlier exchanges for an AI request (used by train.js) */
function relevant(q) {
  if (!C.use || H.length < 4) return [];
  return search(String(q).slice(0, 500), 2, { skipRecent: 8, minCover: 0.5, minHits: 2 }).filter(function (x) { return x.a && x.a.length > 20; });
}

/* ---------- saving ---------- */
function hide(s) { var M = root.lexiMemory; return M && M.isSecret(s) ? String(s).replace(/\b\d{4,19}\b/g, '••••').replace(/\b(otp|password|passcode|pin|cvv|upi pin)\b\s*(?:is|:)?\s*\S+/gi, '$1 ••••') : s; }
function add(q, a) {
  if (!C.on) return;
  q = String(q || '').trim(); a = String(a || '').trim(); if (!q || !a) return;
  if (root.__lexiRouted) return;
  var last = H[H.length - 1]; if (last && last.q === q && last.a === a) return;
  var an = root.lexiLingo ? root.lexiLingo.last() : null;
  if (an && an.t && Date.now() - an.t > 120000) an = null;
  var x = { id: Date.now() + '-' + Math.random().toString(36).slice(2, 6), t: Date.now(), q: hide(q).slice(0, 2000), a: hide(a).slice(0, 3000),
    lang: an && an.lang ? an.lang.name : '', type: an ? an.type : '', mood: an ? an.mood : '' };
  put({ id: x.id, t: x.t, q: x.q, a: x.a, lang: x.lang, type: x.type, mood: x.mood }); index(x); H.push(x);
  if (H.length > MAX) { var gone = H.splice(0, H.length - MAX); del(gone.map(function (g) { return g.id; })); }
}
/* every answer in Lexi passes through remember(question, answer) */
function hook() {
  if (typeof root.remember !== 'function' || root.remember.__hist) return;
  var prev = root.remember;
  var w = function (u, a) { var r = prev.apply(this, arguments); try { add(u, a); } catch (e) { } return r; };
  w.__hist = true; root.remember = w;
}

/* ---------- chat commands ---------- */
var TIME = { today: 0, aaj: 0, 'आज': 0, yesterday: 1, kal: 1, 'कल': 1 };
var CMDS = [
  [/^(?:show|open) (?:my )?(?:chat |conversation )?history$|^(?:meri )?history (?:dikhao|kholo)$/i, function () { return { open: true }; }],
  [/^what did (?:i|we) (?:ask|talk|say|discuss|chat)(?: (?:about|regarding|on))? (today|yesterday)\s*\??$|^(aaj|kal) (?:maine|humne) kya (?:poocha|pucha|baat ki|baat kari)\s*\??$|^(आज|कल) (?:मैंने|हमने) क्या (?:पूछा|बात की)\s*\??$/i, function (m) { return { when: TIME[(m[1] || m[2] || m[3]).toLowerCase()] }; }],
  [/^what did (?:i|we) (?:ask|talk|say|discuss|chat)(?: (?:about|regarding|on))? (.{2,60}?)\s*\??$/i, function (m) { return { q: m[1] }; }],
  [/^(?:search|find) (?:in )?(?:my )?(?:chat |conversation )?history (?:for )?(.{2,60})$/i, function (m) { return { q: m[1] }; }],
  [/^(?:maine|humne) (.{2,60}?) (?:ke|ki) (?:baare|bare) (?:mein|me) kya (?:poocha|pucha|baat ki)\s*\??$/i, function (m) { return { q: m[1] }; }]
];
function command(raw) {
  var t = String(raw || '').trim(); if (t.length > 90) return null;
  for (var i = 0; i < CMDS.length; i++) { var m = CMDS[i][0].exec(t); if (m) return CMDS[i][1](m); }
  return null;
}
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function short(s, n) { s = String(s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
function answerText(c) {
  if (!ready) return 'Still loading your history; ask again in a moment.';
  if (c.when != null) {
    var list = byDay(c.when).filter(function (x) { return !command(x.q); });
    var label = c.when === 0 ? 'today' : 'yesterday';
    if (!list.length) return 'We did not talk ' + label + '.';
    return '**What we talked about ' + label + '** (' + list.length + '):\n' + list.slice(-12).map(function (x) { return '- ' + new Date(x.t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' · ' + short(x.q, 90); }).join('\n');
  }
  var hits = search(c.q, 6, { minCover: 0.5 }).filter(function (x) { return !command(x.q); });
  if (!hits.length) return 'I could not find “' + c.q + '” in our earlier chats.';
  return '**Earlier chats about “' + c.q + '”:**\n' + hits.map(function (x) { return '- **' + day(x.t) + '** · ' + short(x.q, 80) + '\n  ↳ ' + short(x.a, 140); }).join('\n');
}

root.lexiHistory = { all: function () { return H; }, search: search, relevant: relevant, add: add, clear: clearAll, command: command, answerText: answerText, byDay: byDay, day: day, ready: function () { return ready; },
  cfg: function (k, v) { if (arguments.length > 1) { C[k] = v; S('lexi_history_cfg', C); } return C[k]; },
  importAll: function (items) {
    var have = {}; H.forEach(function (x) { have[x.id] = 1; });
    (items || []).forEach(function (x) { if (!x || !x.id || have[x.id] || !x.q) return; var y = { id: x.id, t: x.t, q: x.q, a: x.a, lang: x.lang, type: x.type, mood: x.mood }; put(y); index(y); H.push(y); });
    H.sort(function (a, b) { return a.t - b.t; }); return Promise.resolve();
  },
  remove: function (id) { H = H.filter(function (x) { return x.id !== id; }); del([id]); } };
load();
if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', hook); else hook();
setTimeout(hook, 1500);
})(window);
