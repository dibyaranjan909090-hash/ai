/* Lexi aiserver.js v25: strong AI for everyone, without keys in the app.
   The free keyless service Lexi used (Pollinations) now needs a key, so keyless answers were weak or failed.
   When a company AI server is set (server/lexi-ai-worker.js on Cloudflare, holding the company's Gemini key),
   every keyless AI request in Lexi (chat, streaming answers, the language router, translations, memory,
   photo questions, website and zip helpers) is sent there instead. Your own keys in Settings still come first.
   Set the address in Training Center > AI server, or for every user in lexi-config.json ("aiServer").
   Loaded first, so the knowledge, memory and language instructions are already in each request. */
(function (root) {
'use strict';
var of = root.fetch.bind(root);
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
var shipped = '', local = L('lexi_aiserver', { url: '', on: true });
var stats = { routed: 0, ok: 0, failed: 0, last: '', lastErr: '' };
function base() { var u = String(local.url || shipped || '').trim().replace(/\/+$/, ''); return /^https?:\/\//.test(u) ? u : ''; }
function on() { return !!base() && local.on !== false; }
of('lexi-config.json', { cache: 'no-cache' }).then(function (r) { return r.ok ? r.json() : {}; }).then(function (c) { shipped = (c && c.aiServer) || ''; }).catch(function () { });

/* which requests are "free AI" requests */
function freeKind(url, o) {
  var u; try { u = new URL(url, location.href); } catch (e) { return ''; }
  var h = u.hostname;
  if (h === 'text.pollinations.ai') { if (/^\/(openai|v1\/chat\/completions)\/?$/.test(u.pathname)) return 'post'; if (/^\/models/.test(u.pathname)) return ''; return (o && o.method && o.method !== 'GET') ? '' : 'get'; }
  if (h === 'gen.pollinations.ai' && /^\/v1\/chat\/completions/.test(u.pathname)) {
    var hd = o && o.headers || {}, auth = hd.authorization || hd.Authorization || (typeof hd.get === 'function' ? hd.get('authorization') : '');
    return auth && !/Bearer\s*$/.test(auth) ? '' : 'post'; /* someone's own Pollinations key: leave it */
  }
  return '';
}
function reroute(url, o) {
  var kind = freeKind(url, o), b = base(), target, init;
  if (kind === 'post') {
    target = b + '/v1/chat/completions';
    init = { method: 'POST', headers: { 'content-type': 'application/json' }, body: o.body, signal: o.signal };
  } else {
    var u = new URL(url), prompt = decodeURIComponent(u.pathname.slice(1)), sys = u.searchParams.get('system') || '';
    var msgs = (sys ? [{ role: 'system', content: sys }] : []).concat([{ role: 'user', content: prompt }]);
    target = b + '/v1/chat/completions?format=text';
    init = { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ messages: msgs }), signal: o && o.signal };
  }
  stats.routed++; stats.last = new Date().toLocaleTimeString();
  return of(target, init).then(function (r) {
    if (r.ok) { stats.ok++; return r; }
    stats.failed++; stats.lastErr = 'HTTP ' + r.status;
    if (r.status === 429) return r;          /* busy: let Lexi show its normal "try again" */
    return of(url, o);                       /* server problem: try the old route as a last resort */
  }, function (e) { stats.failed++; stats.lastErr = String(e && e.message || e); if (e && e.name === 'AbortError') throw e; return of(url, o); });
}
root.fetch = function (u, o) {
  try {
    if (on()) { var url = typeof u === 'string' ? u : (u && u.url) || String(u); if (freeKind(url, o)) return reroute(url, o || {}); }
  } catch (e) { }
  return of(u, o);
};

/* check the server: answer, model and speed */
function test(question) {
  var b = base(); if (!b) return Promise.reject(new Error('No AI server address set.'));
  var t0 = Date.now();
  return of(b + '/v1/chat/completions', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ messages: [{ role: 'user', content: question || 'Reply with the word OK only.' }], max_tokens: 300 }) })
    .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || ('HTTP ' + r.status)); return { text: j.choices[0].message.content, model: j.model, ms: Date.now() - t0 }; }); });
}
function health() { var b = base(); if (!b) return Promise.reject(new Error('No AI server address set.')); return of(b + '/health').then(function (r) { return r.json(); }); }

root.lexiAIServerOn = on;
root.lexiAIServer = { on: on, url: base, shipped: function () { return shipped; }, local: function () { return local; },
  set: function (url, enabled) { local = { url: String(url || '').trim(), on: enabled !== false }; S('lexi_aiserver', local); },
  test: test, health: health, stats: function () { return stats; }, _freeKind: freeKind };
})(window);
