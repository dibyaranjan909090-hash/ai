/* Lexi connect.js
   1) Edit any message you sent: ✏️ Edit under your bubble, change the text, Save (or press Enter)
      and Lexi answers the new version, like editing a message in Claude.
   2) Connections centre (🔌): every AI and data service in one place with its status, a key box,
      a "Get free key" link and Save & test. Claude, ChatGPT, Gemini (+ Google Search), Groq,
      OpenRouter, Google Custom Search, YouTube, and the free services.
   3) Live web search: questions about current things get fresh results from the web
      (Google if connected, otherwise DuckDuckGo + Wikipedia) added to the AI's answer, with sources.
   Loaded last. */
(function (root) {
'use strict';
if (typeof document === 'undefined') return;

var style = document.createElement('style');
style.textContent =
  '.row.u{flex-wrap:wrap}.jx-ut{width:100%;display:flex;justify-content:flex-end;gap:4px;margin-top:3px;opacity:.55;transition:opacity .15s}.row.u:hover .jx-ut,.jx-ut:focus-within{opacity:1}' +
  '.jx-ub{border:0;background:transparent;color:var(--mut);font-size:12.5px;padding:3px 8px;border-radius:10px;cursor:pointer}.jx-ub:hover{background:var(--card);color:var(--fg)}' +
  '.jx-ed{width:min(100%,640px);margin-left:auto;background:var(--card);border:2px solid var(--a);border-radius:16px;padding:8px}' +
  '.jx-ed textarea{width:100%;min-height:70px;border:0;outline:0;background:transparent;color:var(--fg);font:inherit;font-size:15.5px;resize:vertical}' +
  '.jx-eb{display:flex;justify-content:flex-end;gap:6px;align-items:center}.jx-eb small{color:var(--mut);margin-right:auto}' +
  '.jx-btn{border:1px solid var(--bd);background:var(--card);color:var(--fg);border-radius:14px;padding:6px 14px;font-size:13px;cursor:pointer}.jx-btn.p{background:linear-gradient(135deg,var(--a),#9b59f0);color:#fff;border-color:transparent}' +
  '.jx-svc{border-top:1px solid var(--bd);padding:9px 0}.jx-svc:first-of-type{border-top:0}.jx-h{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.jx-h b{font-size:14.5px}.jx-st{font-size:13px}' +
  '.jx-note{font-size:12.5px;color:var(--mut);margin:2px 0 4px}.jx-k{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:4px}' +
  '.jx-k input{flex:1;min-width:180px;padding:7px 10px;border-radius:10px;border:1px solid var(--bd);background:var(--bg);color:var(--fg);font-size:13px}' +
  '.jx-k a{font-size:12.5px;color:var(--b);font-weight:600;text-decoration:none}.jx-sum{padding:8px 10px;border-radius:12px;background:var(--bg);margin:6px 0;font-size:13.5px}' +
  '.jx-tg{display:flex;gap:8px;align-items:center;font-size:13.5px;margin:4px 0}.jx-web{margin-top:6px;font-size:12.5px;color:var(--mut)}.jx-web a{color:var(--b);text-decoration:none}';
document.head.appendChild(style);

function el(t, a, kids) { var e = document.createElement(t); for (var k in a || {}) { if (k === 'text') e.textContent = a[k]; else if (k === 'html') e.innerHTML = a[k]; else e.setAttribute(k, a[k]); } (kids || []).forEach(function (c) { if (c) e.appendChild(c); }); return e; }
function bt(t, fn, cls) { var b = el('button', { type: 'button', 'class': cls || 'jx-btn', text: t }); b.onclick = fn; return b; }
function saveCfg() { try { localStorage.setItem('vacfg', JSON.stringify(CFG)); } catch (e) { } }
function to(ms) { var c = new AbortController(); setTimeout(function () { c.abort(); }, ms); return c.signal; }
function jget(u, ms) { return fetch(u, { signal: to(ms || 9000) }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }); }

/* ======================= 1) EDIT YOUR MESSAGES ======================= */
function userText(m) {
  if (m.dataset.raw) return m.dataset.raw;
  var c = m.cloneNode(true); [].forEach.call(c.querySelectorAll('div'), function (d) { d.remove(); });
  return c.innerText.trim();
}
function decorateUser() {
  [].forEach.call(log.querySelectorAll('.row.u'), function (row) {
    if (row.querySelector('.jx-ut')) return;
    var m = row.querySelector('.m'); if (!m) return;
    if (m.querySelector('img') || m.querySelector('[data-zid]')) { var mt = el('div', { 'class': 'jx-ut' }); try { if (root.JM && root.JM.decorate) root.JM.decorate(row, m, mt); } catch (e) { } row.appendChild(mt); return; } /* picture / video / zip bubble: Edit + Copy come from media.js */
    var tools = el('div', { 'class': 'jx-ut' });
    tools.appendChild(bt('✏️ Edit', function () { startEdit(row); }, 'jx-ub'));
    var cp = bt('📋 Copy', function () { try { navigator.clipboard.writeText(userText(m)); cp.textContent = '✅ Copied'; setTimeout(function () { cp.textContent = '📋 Copy'; }, 1200); } catch (e) { } }, 'jx-ub');
    tools.appendChild(cp);
    row.appendChild(tools);
  });
}
function startEdit(row) {
  if (row.querySelector('.jx-ed')) return;
  var m = row.querySelector('.m'), tools = row.querySelector('.jx-ut'), old = userText(m);
  var ta = el('textarea', { 'aria-label': 'Edit your message' }); ta.value = old;
  var box = el('div', { 'class': 'jx-ed' }, [ta]);
  function cancel() { box.remove(); m.style.display = ''; if (tools) tools.style.display = ''; }
  function save() {
    var v = ta.value.trim(); if (!v) return cancel();
    var n = row; while (n) { var nx = n.nextElementSibling; n.remove(); n = nx; } /* answers below the edited message are replaced */
    try { speechSynthesis.cancel(); } catch (e) { }
    window.handle(v);
  }
  var bar = el('div', { 'class': 'jx-eb' }, [el('small', { text: 'Enter = save & send · Shift+Enter = new line · Esc = cancel' }), bt('Cancel', cancel), bt('Save & send ➤', save, 'jx-btn p')]);
  box.appendChild(bar);
  ta.onkeydown = function (e) {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); save(); }
    else if (e.key === 'Escape') { e.preventDefault(); cancel(); }
  };
  m.style.display = 'none'; if (tools) tools.style.display = 'none';
  row.insertBefore(box, tools || null);
  ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
  ta.style.height = 'auto'; ta.style.height = Math.min(260, Math.max(70, ta.scrollHeight)) + 'px';
}
root.JX_decorate = decorateUser;
var ut = null;
new MutationObserver(function () { clearTimeout(ut); ut = setTimeout(decorateUser, 120); }).observe(log, { childList: true });
decorateUser();
/* Up-arrow in an empty input edits your last message */
inp.addEventListener('keydown', function (e) {
  if (e.key === 'ArrowUp' && !inp.value) { var u = log.querySelectorAll('.row.u'); if (u.length) { e.preventDefault(); startEdit(u[u.length - 1]); } }
});

/* ======================= 2) CONNECTIONS CENTRE ======================= */
var AIQ = 'Reply with OK';
function aiTest(p) { return function () { return ai(p, AIQ).then(function (t) { if (!t) throw 0; }); }; }
var SVC = [
  { g: 'AI brains (answers, coding, translation)' },
  { id: 'free', name: 'Free AI (no key)', note: 'Always on as a backup. Good for simple questions; slower and weaker on long code.', test: function () { return fetch('https://text.pollinations.ai/openai', { method: 'POST', signal: to(20000), headers: { 'content-type': 'application/json' }, body: new Blob([JSON.stringify({ model: 'openai', messages: [{ role: 'user', content: AIQ }] })], { type: 'application/json' }) }).then(function (r) { if (!r.ok) throw 0; }); } },
  { id: 'gemini', name: 'Google Gemini', keys: [['gk', 'Gemini API key (starts with AIza…)']], get: 'https://aistudio.google.com/apikey', note: '⭐ Recommended: free key, and answers use live Google Search with sources.', test: aiTest('gemini') },
  { id: 'groq', name: 'Groq (Llama)', keys: [['grk', 'Groq API key (starts with gsk_…)']], get: 'https://console.groq.com/keys', note: 'Free key, very fast answers.', test: aiTest('groq') },
  { id: 'claude', name: 'Claude (Anthropic)', keys: [['ak', 'Claude API key (starts with sk-ant-…)']], get: 'https://console.anthropic.com/settings/keys', note: 'Best for coding and long answers. Paid (pay as you go).', test: aiTest('claude') },
  { id: 'chatgpt', name: 'ChatGPT (OpenAI)', keys: [['ok', 'OpenAI API key (starts with sk-…)']], get: 'https://platform.openai.com/api-keys', note: 'Also powers the natural “Nova” voice and AI photo styles. Paid.', test: aiTest('chatgpt') },
  { id: 'openrouter', name: 'OpenRouter', keys: [['ork', 'OpenRouter key (starts with sk-or-…)']], get: 'https://openrouter.ai/keys', note: 'One key for many models, including free ones.', test: aiTest('openrouter') },
  { id: 'pollinations', name: 'Pollinations (free images + AI)', keys: [['pk', 'Pollinations key (sk_… or pk_…)']], get: 'https://enter.pollinations.ai', note: 'Free account. Makes free picture creation, photo understanding and free AI answers faster and more reliable.', test: function () { return fetch('https://gen.pollinations.ai/v1/chat/completions', { method: 'POST', signal: to(20000), headers: { 'content-type': 'application/json', authorization: 'Bearer ' + CFG.pk }, body: JSON.stringify({ model: 'openai', messages: [{ role: 'user', content: AIQ }] }) }).then(function (r) { if (!r.ok) throw 0; }); } },
  { g: 'Search the internet' },
  { id: 'gsearch', name: 'Google Search (Custom Search API)', keys: [['gsk', 'Google Cloud API key'], ['gcx', 'Search engine ID (cx)']], get: 'https://programmablesearchengine.google.com/controlpanel/create', note: 'Optional. Create a search engine set to “Search the entire web”, copy its ID, and enable “Custom Search API” for your key in Google Cloud. (Gemini above already searches Google without this.)', test: function () { return jget('https://www.googleapis.com/customsearch/v1?num=1&q=india&key=' + encodeURIComponent(CFG.gsk) + '&cx=' + encodeURIComponent(CFG.gcx)).then(function (r) { if (!r.items) throw 0; }); } },
  { id: 'ddg', name: 'DuckDuckGo + Wikipedia search', note: 'Free, used for live web results when Google is not connected.', test: function () { return jget('https://api.duckduckgo.com/?q=india&format=json&no_html=1'); } },
  { id: 'reader', name: 'Website reader', note: 'Free. Opens any link you send and checks it.', test: function () { return fetch('https://api.allorigins.win/raw?url=' + encodeURIComponent('https://example.com'), { signal: to(12000) }).then(function (r) { if (!r.ok) throw 0; }); } },
  { g: 'Other services' },
  { id: 'youtube', name: 'YouTube', keys: [['yk', 'YouTube Data API v3 key (optional)']], get: 'https://console.cloud.google.com/apis/library/youtube.googleapis.com', note: 'Works without a key; a key makes video search more reliable.', test: function () { return ytSearch('music'); }, optional: true },
  { id: 'wiki', name: 'Wikipedia', note: 'Free.', test: function () { return wiki('India'); } },
  { id: 'news', name: 'Wikipedia news', note: 'Free.', test: function () { var d = new Date(), z = function (n) { return ('0' + n).slice(-2); }; return jget('https://en.wikipedia.org/api/rest_v1/feed/featured/' + d.getFullYear() + '/' + z(d.getMonth() + 1) + '/' + z(d.getDate())); } },
  { id: 'weather', name: 'Weather (Open-Meteo)', note: 'Free.', test: function () { return jget('https://geocoding-api.open-meteo.com/v1/search?count=1&name=Delhi'); } },
  { id: 'currency', name: 'Currency rates', note: 'Free.', test: function () { return jget('https://open.er-api.com/v6/latest/USD'); } },
  { id: 'translate', name: 'Translation (MyMemory)', note: 'Free backup translator.', test: function () { return jget('https://api.mymemory.translated.net/get?q=hello&langpair=en|hi'); } }
];
var INPUT_ID = { ak: 'ak', ok: 'ok', gk: 'gk', yk: 'yk' }; /* keep the old settings panel in sync */
function hasKeys(s) { return !s.keys || s.keys.every(function (k) { return CFG[k[0]]; }); }
function openConnections() {
  var m = add('<b>🔌 Connections: all APIs</b><div class="jx-sum"></div>', 'a'), sum = m.querySelector('.jx-sum'), res = {};
  function summary() {
    var ok = 0, tot = 0, ais = 0;
    SVC.forEach(function (s) { if (!s.id) return; if (res[s.id] === 'ok') { ok++; if (s.keys && ['gk', 'grk', 'ak', 'ok', 'ork'].indexOf(s.keys[0][0]) >= 0) ais++; } if (res[s.id]) tot++; });
    sum.innerHTML = '✅ ' + ok + ' working' + (ais ? ' · 🧠 ' + ais + ' AI key' + (ais > 1 ? 's' : '') + ' connected' : ' · <b>Tip:</b> add a free Gemini or Groq key below for strong answers with live Google search.');
  }
  var gtoggle = el('label', { 'class': 'jx-tg' }, [el('input', { type: 'checkbox' }), document.createTextNode('🔎 Add live web results to answers (current news, prices, scores, “latest …”)')]);
  gtoggle.firstChild.checked = CFG.web !== false; gtoggle.firstChild.onchange = function () { CFG.web = this.checked; saveCfg(); };
  var gs = el('label', { 'class': 'jx-tg' }, [el('input', { type: 'checkbox' }), document.createTextNode('🌍 Let Gemini search Google while answering')]);
  gs.firstChild.checked = CFG.gsearch !== false; gs.firstChild.onchange = function () { CFG.gsearch = this.checked; saveCfg(); };
  m.appendChild(gtoggle); m.appendChild(gs);
  var pv = el('label', { 'class': 'jx-tg' }, [document.createTextNode('🧠 Answer with: ')]), sel = el('select', { 'class': 'jx-btn' });
  [['auto', 'Auto (first connected AI, then free AI)'], ['gemini', 'Gemini'], ['groq', 'Groq'], ['claude', 'Claude'], ['chatgpt', 'ChatGPT'], ['openrouter', 'OpenRouter']].forEach(function (o) { sel.appendChild(el('option', { value: o[0], text: o[1] })); });
  sel.value = CFG.prov || 'auto'; sel.onchange = function () { CFG.prov = sel.value; var pe = document.getElementById('pv'); if (pe) pe.value = sel.value; saveCfg(); };
  pv.appendChild(sel); m.appendChild(pv);
  SVC.forEach(function (s) {
    if (s.g) { m.appendChild(el('p', { html: '<b>' + esc(s.g) + '</b>', style: 'margin:12px 0 2px;color:var(--a)' })); return; }
    var stEl = el('span', { 'class': 'jx-st' }), box = el('div', { 'class': 'jx-svc' }, [el('div', { 'class': 'jx-h' }, [el('b', { text: s.name }), stEl]), el('div', { 'class': 'jx-note', text: s.note || '' })]);
    function run() {
      if (s.keys && !hasKeys(s)) { res[s.id] = s.optional ? 'ok' : 'nokey'; stEl.textContent = s.optional ? '✅ working without key' : '➕ add key to connect'; if (s.optional) s.test().then(null, function () { stEl.textContent = '⚠️ needs a key here'; }); summary(); return; }
      stEl.textContent = '⏳ testing…';
      var p; try { p = Promise.resolve(s.test()); } catch (e) { p = Promise.reject(e); }
      Promise.race([p, new Promise(function (_, rj) { setTimeout(rj, 25000); })]).then(function () { res[s.id] = 'ok'; stEl.textContent = '✅ connected & working'; summary(); }, function () { res[s.id] = 'bad'; stEl.textContent = s.keys ? '❌ key not working (check it, or its limits)' : '❌ not reachable right now'; summary(); });
    }
    if (s.keys) {
      var ins = s.keys.map(function (k) { var i = el('input', { type: 'password', placeholder: k[1], autocomplete: 'off', 'aria-label': k[1] }); i.value = CFG[k[0]] || ''; i.dataset.k = k[0]; i.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); save(); } }; return i; });
      var row = el('div', { 'class': 'jx-k' }); ins.forEach(function (i) { row.appendChild(i); });
      var eye = bt('👁', function () { ins.forEach(function (i) { i.type = i.type === 'password' ? 'text' : 'password'; }); }); eye.title = 'Show / hide key';
      row.appendChild(eye);
      function save() { ins.forEach(function (i) { var v = i.value.trim(); CFG[i.dataset.k] = v; var pe = INPUT_ID[i.dataset.k] && document.getElementById(INPUT_ID[i.dataset.k]); if (pe) pe.value = v; }); saveCfg(); run(); }
      row.appendChild(bt('💾 Save & test', save, 'jx-btn p'));
      if (s.keys.some(function (k) { return CFG[k[0]]; })) row.appendChild(bt('Remove', function () { ins.forEach(function (i) { i.value = ''; }); save(); }));
      row.appendChild(el('a', { href: s.get, target: '_blank', rel: 'noopener', text: 'Get free key ↗' }));
      if (/claude|chatgpt/.test(s.id)) row.lastChild.textContent = 'Get key ↗';
      box.appendChild(row);
    }
    m.appendChild(box); run();
  });
  m.appendChild(el('div', { 'class': 'jx-note', html: '🔒 Keys are saved only in this browser on this device and sent only to that provider. Use low-limit keys. Opened as a local file (C:/…)? Some services block that: upload the folder to Netlify Drop for everything to work.' }));
  summary(); log.scrollTop = log.scrollHeight;
  try { speak('Here are all your connections. Paste a key and tap save and test.'); } catch (e) { }
}
root.diag = openConnections;
var td = document.getElementById('td'); if (td) { td.onclick = openConnections; td.textContent = '🔌 Connections & test'; }
(function () {
  var header = document.querySelector('header'), gear = document.getElementById('gear');
  var b = el('button', { 'class': 'ib', type: 'button', title: 'Connections: AI keys & APIs', 'aria-label': 'Connections', text: '🔌' }); b.onclick = function () { add('Connections', 'u'); openConnections(); };
  header.insertBefore(b, gear);
  /* extra key boxes in the old settings panel */
  var ok = document.getElementById('gk');
  if (ok) [['grk', 'Groq API key (free)'], ['ork', 'OpenRouter API key'], ['gsk', 'Google Custom Search API key'], ['gcx', 'Google search engine ID (cx)']].forEach(function (k) {
    var i = el('input', { id: 'x' + k[0], 'class': 'k', type: 'password', placeholder: k[1] }); i.value = CFG[k[0]] || '';
    i.onchange = function () { CFG[k[0]] = i.value.trim(); saveCfg(); };
    ok.parentNode.insertBefore(i, document.getElementById('yk'));
  });
})();

/* ======================= 3) LIVE WEB RESULTS ======================= */
function needsWeb(c) {
  if (CFG.web === false) return false;
  c = String(c || '').trim();
  if (!c || c.length > 300 || /```|\n/.test(c)) return false;
  if (root.JTSMART && root.JTSMART.isCodingRequest(c)) return false;
  if (/^(?:write|create|make|draw|compose|translate|summari[sz]e|rewrite|generate)\b/i.test(c)) return false;
  return /\b(?:latest|today|tonight|current|currently|now|news|price|prices|cost|rate|rates|score|scores|result|results|winner|won|update|updates|release|released|launch|launched|new|upcoming|recent|recently|this (?:week|month|year)|202[4-9]|vs\.?|versus|stock|share price|weather|election|match|ipl|budget|ceo|president|prime minister|minister|chief minister)\b/i.test(c) ||
    /^(?:who|what|when|where|which|how much|how many|is|are|does|did|has|have)\b.*\?$/i.test(c) ||
    /^(?:who is|who was|who won|when is|when was|where is|how much|how many)\b/i.test(c);
}
function stripTags(h) { return new DOMParser().parseFromString(String(h || ''), 'text/html').body.textContent.replace(/\s+/g, ' ').trim(); }
function webResults(q) {
  var p;
  if (CFG.gsk && CFG.gcx) p = jget('https://www.googleapis.com/customsearch/v1?num=5&q=' + encodeURIComponent(q) + '&key=' + encodeURIComponent(CFG.gsk) + '&cx=' + encodeURIComponent(CFG.gcx), 4000).then(function (r) {
    var a = (r.items || []).map(function (x) { return { t: x.title, s: x.snippet || '', u: x.link, src: 'Google' }; }); if (!a.length) throw 0; return a;
  });
  else p = Promise.reject();
  return p.catch(function () {
    return Promise.all([
      jget('https://api.duckduckgo.com/?q=' + encodeURIComponent(q) + '&format=json&no_html=1&skip_disambig=1', 3500).catch(function () { return null; }),
      jget('https://en.wikipedia.org/w/api.php?action=query&list=search&srlimit=4&format=json&origin=*&srsearch=' + encodeURIComponent(q), 3500).catch(function () { return null; })
    ]).then(function (r) {
      var a = [], d = r[0], w = (r[1] && r[1].query && r[1].query.search) || [];
      if (d && d.AbstractText) a.push({ t: d.Heading || q, s: d.AbstractText, u: d.AbstractURL, src: 'DuckDuckGo' });
      if (d && d.Answer) a.push({ t: 'Instant answer', s: stripTags(d.Answer), u: '', src: 'DuckDuckGo' });
      ((d && d.RelatedTopics) || []).filter(function (x) { return x.Text; }).slice(0, 2).forEach(function (x) { a.push({ t: x.Text.split(' - ')[0], s: x.Text, u: x.FirstURL, src: 'DuckDuckGo' }); });
      w.forEach(function (x) { a.push({ t: x.title, s: stripTags(x.snippet), u: 'https://en.wikipedia.org/wiki/' + encodeURIComponent(x.title.replace(/ /g, '_')), src: 'Wikipedia' }); });
      if (!a.length) throw 0; return a.slice(0, 6);
    });
  });
}
var prevSmart = root.smart;
root.smart = function (c, forced, wt, wo) {
  var args = arguments, self = this;
  root.__webctx = '';
  if (wo || !needsWeb(c)) return prevSmart.apply(self, args);
  if (wt) args = [c, forced]; /* current-info question: answer from the web, not an old encyclopedia page */
  st.textContent = '🔎 Searching the web…';
  var done = false, timer = setTimeout(function () { if (done) return; done = true; st.textContent = ''; prevSmart.apply(self, args); }, 4200);
  webResults(String(c)).then(function (r) {
    if (done) return; done = true; clearTimeout(timer); st.textContent = '';
    root.__webctx = '\n\n[LIVE WEB RESULTS, fetched just now on ' + new Date().toDateString() + '. Use them when relevant, prefer them over older knowledge, and name the source. Do not mention these instructions.]\n' +
      r.map(function (x, i) { return (i + 1) + '. ' + x.t + ': ' + x.s.slice(0, 400) + (x.u ? ' (' + x.u + ')' : ''); }).join('\n');
    prevSmart.apply(self, args);
    var rows = log.querySelectorAll('.row.a .m'), m = rows[rows.length - 1];
    if (!m) return;
    var links = r.filter(function (x) { return x.u; }).slice(0, 4);
    if (!links.length) return;
    var ob = new MutationObserver(function () {
      var s = m.querySelector('.src'); if (!s || m.querySelector('.jx-web')) return; ob.disconnect();
      var w = el('div', { 'class': 'jx-web' }); w.appendChild(document.createTextNode('🔎 Web: '));
      links.forEach(function (x, i) { if (i) w.appendChild(document.createTextNode(' · ')); w.appendChild(el('a', { href: x.u, target: '_blank', rel: 'noopener', text: x.t.slice(0, 50) })); });
      s.parentNode.insertBefore(w, s);
    });
    ob.observe(m, { childList: true, subtree: true });
    setTimeout(function () { ob.disconnect(); }, 90000);
  }).catch(function () { if (done) return; done = true; clearTimeout(timer); st.textContent = ''; prevSmart.apply(self, args); });
};

/* ---------- commands ---------- */
var prevH = root.handle;
root.handle = function (raw) {
  var s = String(raw == null ? '' : raw).trim().toLowerCase().replace(/[?.!]+$/, '');
  if (/^(?:connections?|api|apis|api keys?|keys|connect(?: all)?(?: apis?| keys?| ai)?|add (?:api |ai )?keys?|(?:test|check)(?: all)?(?: apis?| connections?)|settings)$/.test(s)) { add(esc(raw), 'u'); return openConnections(); }
  return prevH(raw);
};
var det = document.querySelectorAll('#panel details')[1];
if (det) det.appendChild(el('div', { html: '<p><b>✏️ Edit:</b> tap ✏️ Edit under any message you sent (or press ↑ in an empty box), change it and press Enter: Lexi answers the new version.</p><p><b>🔌 Connections:</b> tap 🔌 or say “connections” to add Gemini, Groq, Claude, ChatGPT, OpenRouter, Google Search and YouTube keys and test everything.</p>' }));
})(typeof window !== 'undefined' ? window : globalThis);
