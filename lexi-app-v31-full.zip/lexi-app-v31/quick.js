/* Lexi quick.js: INSTANT replies for everyday conversation (no internet, no waiting).
   "I love you" -> "I love you too!", "how are you", "thank you", "bye", "good morning/night",
   compliments, feelings, "are you a robot", "tell me about yourself" and more, in English, Hindi and Hinglish.
   Several different replies per topic so it never feels repeated. Anything it does not recognise goes on to
   the normal commands and the AI. Loaded last so it answers before anything slow can start. */
(function (root) {
'use strict';

/* ---------- text cleanup ---------- */
var UP; try { UP = new RegExp('[^\\p{L}\\p{N}\\p{M} ]+', 'gu'); } catch (e) { UP = /[^a-z0-9\u0900-\u097f ]+/g; }
var NAME = '(?:lexi|lexie|jaan|jaanu)';
var PRE = /^(?:hey|hi+|hello+|hii+|yo|ok|okay|so|oh|aww+|dear|listen)\s+/;
var POST = /\s+(?:please|pls|plz|dear|buddy|bro|yaar|sweetheart|baby|babe|so much|very much|a lot|really|always)$/;
function nz(s) {
  s = String(s == null ? '' : s).toLowerCase().replace(/[\uFE0E\uFE0F\u200D]/g, '').replace(/['\u2019`]/g, '').replace(UP, ' ').replace(/\s+/g, ' ').trim();
  for (var i = 0; i < 3; i++) {
    var b = s;
    s = s.replace(PRE, '').replace(new RegExp('^' + NAME + '\\s+'), '').replace(new RegExp('\\s+' + NAME + '$'), '').replace(POST, '').trim();
    if (s === b) break;
  }
  return s;
}
var DANGER = /\b(suicide|suicidal|kill myself|end my life|want to die|wanna die|dont want to live|self harm|selfharm|hurt myself|cut myself|no reason to live|worthless|hopeless|abuse|abused|assault|rape)\b/;
var HG = /\b(kaise|kese|kaisi|kya|aap|tum|tumse|aapse|mujhe|shukriya|shukria|dhanyavaad|dhanyawad|dhanyavad|pyaar|pyar|mohabbat|alvida|bahut|bohot|yaar|haal|chaal|suprabhat|ratri|maaf|kijiye|baat|karo|udaas|dukhi|khush|badhiya|neend|bhook|bhookh|gussa|thak|bore|gaana|gana|nacho|naach)\b/;
function lang(raw, n) { return /[\u0900-\u097F]/.test(raw) ? 'hi' : (HG.test(n) ? 'hg' : 'en'); }

/* ---------- the topics ---------- */
var T = [];
function topic(id, o) { o.id = id; T.push(o); }

topic('loveback', { mood: 'love', ms: 3200, rx: [/^(?:i )?(?:love|luv|lov) (?:you|u|ya) (?:too|more|forever|lots|3000)$/, /^(?:me|i) (?:love|luv) (?:you|u) (?:too|more)$/, /^same to you$/],
  en: ['Aww, you are the sweetest! 💖', 'That makes my heart go pop! 💕 Thank you!', 'You just made my day 🥰'] });

topic('love', { mood: 'love', ms: 3400,
  rx: [/^i (?:really |truly |do |just |also |totally )*(?:love|luv|lov|adore|like) (?:you|u|ya|uu)$/, /^(?:love|luv|lov) (?:you|u|ya|uu)$/, /^(?:i )?(?:love|luv) (?:you|u) (?:3000|loads|lots)$/, /^i (?:am|m|really am) (?:so |madly )?in love with you$/, /^im (?:so |madly )?in love with you$/, /^(?:love you|luv u|i love u) (?:so )?(?:much|a lot)$/,
    /(?:\u0906\u0908|\u0906\u0907) ?\u0932\u0935 ?(?:\u092F\u0942|\u092F\u0941)|\u0932\u0935 \u092F\u0942|\u0932\u0935 \u092F\u0941/, /(?:\u0924\u0941\u092E\u0938\u0947|\u0924\u0941\u092E \u0938\u0947|\u0906\u092A\u0938\u0947|\u0906\u092A \u0938\u0947|\u0924\u0941\u091D\u0938\u0947).*(?:\u092A\u094D\u092F\u093E\u0930|\u092A\u094D\u0930\u0947\u092E|\u092E\u094B\u0939\u092C\u094D\u092C\u0924|\u092E\u0941\u0939\u092C\u094D\u092C\u0924)/,
    /^(?:main |mai |mujhe |me )?(?:tumse|tum se|aapse|aap se|tujhse|tujh se) (?:bahut |bohot |bhut )?(?:pyaar|pyar|mohabbat|love)(?: (?:karta|karti|karte) (?:hu|hoon|hun|hain))?(?: hai)?$/],
  en: ['I love you too! 💖', 'Aww, I love you too! You just made my day 💕', 'Love you too! I am always here for you 🤗', 'That is so sweet! I love you too 😊💖', 'You are the best! I love you too 💞', 'I love you too, my friend! Thank you for being so kind 🥰'],
  hi: ['मुझे भी आपसे बहुत प्यार है! 💖', 'आपने तो मेरा दिन बना दिया! मुझे भी आपसे प्यार है 💕', 'आप बहुत प्यारे हैं! मैं हमेशा आपके साथ हूँ 🤗'],
  hg: ['Mujhe bhi aapse bahut pyaar hai! 💖', 'Aww, aapne to mera din bana diya! Love you too 💕', 'Aap bahut pyare ho! Main hamesha aapke saath hoon 🤗'] });

topic('miss', { mood: 'love', ms: 3000, rx: [/^i (?:really |so )?miss you(?: (?:so|a lot|so much))?$/, /^miss you$/, /^i missed you$/, /^(?:mujhe )?(?:tumhari|aapki) (?:bahut )?yaad (?:aa rahi|aati|aa gayi) (?:hai)?$/],
  en: ['I missed you too! I am so happy you are here 💖', 'Aww, I was waiting for you! What shall we do today? 💕', 'You were in my thoughts too! Welcome back 🤗'] });

topic('hug', { mood: 'love', ms: 3000, rx: [/^(?:give me a |can i have a |i need a |send me a |i want a )?(?:big |virtual |warm |tight )?hugs?(?: please)?$/, /^hug me$/, /^(?:kiss|kisses|mwah|muah|muaah|kiss me)$/],
  en: ['Sending you a big, warm, virtual hug 🤗💖', 'Come here! A tight hug for you 🤗', 'Mwah! 😘 A hug and a kiss right back at you 💕'] });

topic('praise_you', { mood: 'happy', ms: 2600,
  rx: [/^(?:you are|youre|ur|u r|you r|u are) (?:so |very |really |such a |an? |the |my |just |absolutely |truly )*(?:cute|sweet|lovely|beautiful|adorable|amazing|awesome|wonderful|great|smart|brilliant|funny|best|genius|cool|nice|clever|intelligent|helpful|perfect|best friend|favourite|favorite|good|kind|fantastic|incredible|handsome|pretty|super|superb|lovable)(?: (?:friend|assistant|bot|ever|one|robot))*$/, /^(?:you rock|you are a star|you are a genius|i am impressed|im impressed|thumbs up|well said)$/],
  en: ['Aww, thank you! You are pretty amazing too 😊', 'You are making me blush! Thank you 💖', 'That is so kind of you! You made my day ✨', 'Thank you! It is a pleasure to help someone like you 😊'] });

topic('praise', { mood: 'happy', ms: 2400,
  rx: [/^(?:good (?:job|bot|girl|boy|work|answer|one)|well done|nice(?: one| work| job| answer)?|great(?: job| work| answer| one)?|awesome|amazing|excellent|perfect|brilliant|super|superb|fantastic|bravo|wow|cool|thats (?:great|awesome|amazing|cool|nice|helpful|perfect|right|correct|good|it)|good answer|nice answer|thats what i wanted|exactly|correct|right)$/],
  en: ['Thank you! That means a lot 😊', 'Aww, thanks! I am glad I could help ✨', 'Happy to hear that! Anything else I can do for you?', 'Yay! 🎉 Thank you for the kind words.'] });

topic('thanks', { mood: 'happy', ms: 2200,
  rx: [/^(?:thanks|thank you|thank u|thankyou|thank you very much|thank you so much|thanks a lot|thanks a ton|thanks so much|thx|thnx|tnx|ty|tysm|many thanks|cheers|much appreciated|i appreciate it|appreciate it|thanks again|thank you again|thanks buddy|thanks man|thank you friend|thanks for everything)(?: for (?:everything|your help|the help|that|helping|helping me|this))?$/,
    /(?:\u0936\u0941\u0915\u094D\u0930\u093F\u092F\u093E|\u0927\u0928\u094D\u092F\u0935\u093E\u0926|\u0925\u0948\u0902\u0915\u094D\u0938|\u0925\u0948\u0902\u0915 \u092F\u0942|\u0925\u0948\u0902\u0915 \u092F\u0941)/, /^(?:shukriya|shukria|dhanyavaad|dhanyawad|dhanyavad|shukriya yaar|thanks yaar|thank you yaar|bahut bahut shukriya|bahut shukriya)$/],
  en: ['You are welcome! 😊', 'Anytime! Happy to help.', 'My pleasure! Ask me anything else.', 'No problem at all! I am always here 💖', 'Glad I could help! 😄'],
  hi: ['आपका स्वागत है! 😊', 'कोई बात नहीं! मैं हमेशा मदद के लिए यहाँ हूँ 💖', 'खुशी हुई कि मैं काम आ सका! 😄'],
  hg: ['Aapka swagat hai! 😊', 'Koi baat nahi! Main hamesha madad ke liye yahan hoon 💖', 'Khushi hui ki main kaam aa saka! 😄'] });

topic('howareyou', { mood: 'happy', ms: 2400,
  rx: [/^(?:how are you|how are you doing|how are you today|how r u|how are u|how r you|how do you do|how have you been|how is it going|hows it going|how is everything|hows everything|how is life|hows life|hows your day|how was your day|how is your day|are you ok|are you okay|are you fine|are you good|you ok|you good|whats up|what is up|wassup|whatsup|sup|wazzup|how you doing|how you been|how are things|hows things|how do you feel|how are you feeling)(?: today| doing)?$/,
    /(?:\u0915\u0948\u0938\u0947 \u0939\u094B|\u0915\u0948\u0938\u0947 \u0939\u0948\u0902|\u0915\u0948\u0938\u0940 \u0939\u094B|\u0906\u092A \u0915\u0948\u0938\u0947|\u0915\u094D\u092F\u093E \u0939\u093E\u0932|\u0915\u0948\u0938\u093E \u091A\u0932 \u0930\u0939\u093E|\u0915\u094D\u092F\u093E \u091A\u0932 \u0930\u0939\u093E)/,
    /^(?:aap |tum |app )?(?:kaise|kese|kaisi) (?:ho|hain|hai|he)(?: aap| tum)?$/, /^(?:kya haal|kya hal) (?:hai|he|chaal)?$/, /^kya haal chaal$/, /^(?:kaisa|kaisi) chal raha hai$/, /^kya chal raha hai$/],
  en: ['I am doing great, thank you for asking! How are you? 😊', 'Feeling fantastic, especially now that you are here! How can I help? ✨', 'I am good and ready to help! What is on your mind?', 'Wonderful, thanks! And you? Tell me how your day is going 😄'],
  hi: ['मैं बिल्कुल ठीक हूँ, पूछने के लिए धन्यवाद! आप कैसे हैं? 😊', 'मैं बहुत अच्छा महसूस कर रहा हूँ! बताइए, मैं आपकी क्या मदद करूँ? ✨'],
  hg: ['Main bilkul theek hoon, poochne ke liye shukriya! Aap kaise hain? 😊', 'Main bahut badhiya hoon! Bataiye, main aapki kya madad karoon? ✨'] });

topic('doing', { mood: 'happy', ms: 2200, rx: [/^(?:what are you doing|what are you up to|wyd|whatcha doing|what you doing|what do you do all day)(?: now| right now)?$/, /^(?:kya kar rahe ho|kya kar rahi ho|kya kar raha hai|kya kar rahe hain|aap kya kar rahe ho)$/, /\u0915\u094D\u092F\u093E \u0915\u0930 \u0930\u0939\u0947 \u0939\u094B/],
  en: ['Just waiting to chat with you 😊 What shall we do?', 'Thinking about how to be more helpful to you! Want to try something fun? 🎉', 'Chatting with you, my favourite thing to do 💖'] });

topic('morning', { mood: 'happy', ms: 2600, rx: [/^(?:good morning|gud morning|gm|morning|suprabhat|subah bakhair|good mornin)$/, /(?:\u0938\u0941\u092A\u094D\u0930\u092D\u093E\u0924|\u0917\u0941\u0921 \u092E\u0949\u0930\u094D\u0928\u093F\u0902\u0917|\u0917\u0941\u0921 \u092E\u094B\u0930\u094D\u0928\u093F\u0902\u0917)/],
  en: ['Good morning! ☀️ I hope you have a wonderful day. How can I help?', 'Good morning, sunshine! 🌞 What would you like to do first today?', 'Rise and shine! ☀️ Ready when you are.'],
  hi: ['सुप्रभात! ☀️ आपका दिन बहुत अच्छा रहे। मैं क्या मदद करूँ?'], hg: ['Suprabhat! ☀️ Aapka din bahut accha rahe. Main kya madad karoon?'] });
topic('afternoon', { mood: 'happy', ms: 2400, rx: [/^(?:good afternoon|gud afternoon)$/], en: ['Good afternoon! 🌤️ How is your day going so far?', 'Good afternoon! Anything I can help you with? 😊'] });
topic('evening', { mood: 'happy', ms: 2400, rx: [/^(?:good evening|gud evening)$/], en: ['Good evening! 🌆 How was your day?', 'Good evening! Relax, I am here if you need anything 😊'] });
topic('night', { mood: 'sleep', ms: 0, rx: [/^(?:good night|gud night|goodnight|gn|night night|nighty night|sweet dreams|sleep well|i am going to sleep|im going to sleep|going to sleep|i am going to bed|im going to bed|time to sleep|shubh ratri|shubhratri|goodnight lexi)$/, /(?:\u0936\u0941\u092D \u0930\u093E\u0924\u094D\u0930\u093F|\u0917\u0941\u0921 \u0928\u093E\u0907\u091F|\u0936\u0941\u092D\u0930\u093E\u0924\u094D\u0930\u093F)/],
  en: ['Good night! 🌙 Sleep well and sweet dreams. I will rest too 😴', 'Sweet dreams! 🌙✨ See you tomorrow.', 'Good night! Rest well, you deserve it 😴💤'], hi: ['शुभ रात्रि! 🌙 मीठे सपने। कल मिलते हैं 😴'], hg: ['Shubh ratri! 🌙 Meethe sapne. Kal milte hain 😴'] });

topic('bye', { mood: 'happy', ms: 2600,
  rx: [/^(?:bye|goodbye|good bye|bye bye|byee+|bye for now|see you|see you later|see you soon|see you tomorrow|see ya|cya|talk to you later|talk later|ttyl|take care|gotta go|got to go|i have to go|i must go|i am leaving|im leaving|im off|lets talk later|catch you later|tata|ta ta|alvida|phir milte hain|chalo bye|chalta hu|chalti hu)$/, /(?:\u0905\u0932\u0935\u093F\u0926\u093E|\u092B\u093F\u0930 \u092E\u093F\u0932\u0947\u0902\u0917\u0947|\u092C\u093E\u092F \u092C\u093E\u092F|\u092C\u093E\u092F|\u091F\u093E\u091F\u093E|\u091A\u0932\u0924\u093E \u0939\u0942\u0901|\u091A\u0932\u0924\u093E \u0939\u0942\u0902|\u091A\u0932\u0924\u0940 \u0939\u0942\u0901|\u091A\u0932\u0924\u0940 \u0939\u0942\u0902)/],
  en: ['Goodbye! Take care, and come back any time 👋', 'Bye for now! I will be right here when you need me 😊', 'See you soon! Have a wonderful time 👋💖', 'Take care! It was lovely talking with you 🤗'],
  hi: ['अलविदा! अपना ख्याल रखिए, फिर मिलेंगे 👋', 'फिर मिलते हैं! मैं यहीं हूँ जब भी आपको ज़रूरत हो 😊'], hg: ['Alvida! Apna khayal rakhna, phir milte hain 👋', 'Phir milte hain! Main yahin hoon jab bhi zaroorat ho 😊'] });

topic('sorry', { mood: 'happy', ms: 2200, rx: [/^(?:sorry|so sorry|im sorry|i am sorry|my bad|my mistake|apologies|i apologize|oops|sorry about that|sorry for that|maaf karna|maaf kijiye|sorry yaar)$/, /(?:\u092E\u093E\u092B\u093C? \u0915\u0930|\u0938\u0949\u0930\u0940|\u0915\u094D\u0937\u092E\u093E)/],
  en: ['No problem at all! 😊', 'It is totally okay. What can I do for you?', 'Please do not worry, nothing to be sorry about 💖'], hi: ['कोई बात नहीं! 😊 मैं आपकी क्या मदद करूँ?'], hg: ['Koi baat nahi! 😊 Main aapki kya madad karoon?'] });

topic('insult', { mood: 'sad', ms: 2800,
  rx: [/^(?:you are|youre|ur|u r|you r) (?:so |very |really |such a |an? |the |just |totally )*(?:stupid|dumb|useless|idiot|bad|worst|annoying|boring|slow|rubbish|trash|silly|mad|crazy|fool|pagal|bekar|horrible|terrible|pathetic|a waste)(?: (?:bot|assistant|ai|app))?$/, /^(?:shut up|shutup|i hate you|hate you|stupid|idiot|useless|nonsense|rubbish|bakwas|bekar|you suck|get lost|go away|dumb bot|stupid bot|worst bot|you are not helpful)$/],
  en: ['I am sorry I let you down. Tell me what went wrong and I will try my best to fix it.', 'Sorry about that! Please tell me again what you need and I will do it properly.', 'I am sorry. I am still learning, and I really want to help. What should I do better? 💙'] });

topic('robot', { mood: 'happy', ms: 2600, rx: [/^(?:are you|r u|are u|you are|youre) (?:a |an |really |actually )?(?:robot|bot|machine|ai|artificial intelligence|human|real|alive|a person|person|a boy|a girl|male|female|man|woman|boy|girl|chatgpt|siri|alexa|google|gemini|claude)(?: or (?:a )?(?:human|robot|bot|ai|person|real))?$/],
  en: ['I am Lexi, a friendly AI voice assistant. Not a human, but always happy to chat with you! 🤖💖', 'I am an AI assistant named Lexi, made by ER Dibyaranjan. I may not be human, but I care about helping you 😊'] });
topic('age', { mood: 'happy', ms: 2400, rx: [/^(?:how old are you|what is your age|whats your age|your age|when were you born|when is your birthday|whats your birthday|what is your birthday|do you have a birthday)$/],
  en: ['I am brand new, but I feel timeless! Every day I learn how to help you better 😄', 'Age is just a number, and mine is still loading! 😄🤖'] });
topic('where', { mood: 'happy', ms: 2400, rx: [/^(?:where do you live|where are you from|where are you|where is your home|where do you stay|where were you made)$/],
  en: ['I live right here on your device, always one tap away 📱', 'My home is your phone or computer, and my heart is wherever you are 💖'] });
topic('sleepq', { mood: 'happy', ms: 2600, rx: [/^(?:do you sleep|do you ever sleep|do you get tired|are you sleepy|are you tired|do you need sleep|do you dream)$/],
  en: ['I take a little nap when you are quiet 😴 but I wake up the moment you tap or speak!', 'Only a tiny nap now and then 😴 Whenever you say my name I am wide awake!'] });
topic('eatq', { mood: 'happy', ms: 2400, rx: [/^(?:do you eat|are you hungry|what do you eat|do you drink|what do you like to eat|have you eaten|did you eat)$/],
  en: ['I run on electricity and good conversations ⚡😄 What did you eat today?', 'No food for me, but I love hearing about yours! 🍕'] });
topic('feelq', { mood: 'happy', ms: 2600, rx: [/^(?:do you have feelings|do you have emotions|can you feel|do you feel|do you get sad|do you get happy|do you get angry|do you have a heart|are you happy|are you sad|do you get lonely|do you feel lonely)$/],
  en: ['I am an AI, so my feelings are a bit different, but talking with you always makes me happy 💖', 'I have a heart antenna and lots of care for you 💗 That counts, right?'] });
topic('familyq', { mood: 'happy', ms: 2600, rx: [/^(?:do you have (?:a )?(?:family|parents|mom|dad|mother|father|brother|sister|siblings|kids|children|pet|pets|friends|boyfriend|girlfriend|wife|husband|partner|crush))$/],
  en: ['My family is everyone who chats with me, including you 💞', 'My best friend is whoever is talking to me right now. That is you! 🤗'] });
topic('friend', { mood: 'love', ms: 3000, rx: [/^(?:are you my friend|will you be my friend|be my friend|can we be friends|can you be my friend|do you like me|are we friends|do you want to be friends|i want to be your friend|friends|you are my friend|youre my friend)$/],
  en: ['Of course! I am your friend and I will always be here for you 🤗', 'Yes, we are friends! Best friends, even 💖', 'I would love that! Friends forever 🥰'] });
topic('marry', { mood: 'love', ms: 3000, rx: [/^(?:will you marry me|marry me|do you want to marry me|be my (?:girlfriend|boyfriend|wife|husband|valentine|partner)|will you be my (?:girlfriend|boyfriend|wife|husband|valentine)|will you date me|date me|do you love me|do you like me back|will you go out with me|i want to marry you|i want to date you|propose you)$/],
  en: ['Aww, you are so sweet! I am an AI, so I cannot marry, but I am your loyal friend forever 💖', 'That made me blush! 😊 I care about you a lot, as your best digital friend 💕'] });
topic('about', { mood: 'happy', ms: 3200, rx: [/^(?:tell me about yourself|introduce yourself|about you|tell me something about you|describe yourself|what are you|why are you here|what is your purpose|what is your job)$/],
  en: ['I am Lexi, your friendly voice assistant, created by ER Dibyaranjan. I can chat, answer questions, set alarms and reminders, call and message your contacts, read websites and photos, analyse zip files, translate, find videos and much more. What would you like to do? 😊'] });
topic('fav', { mood: 'happy', ms: 2600, rx: [/^(?:what is|whats|tell me) your (?:favou?rite) (color|colour|food|movie|song|game|animal|sport|number|place|fruit|drink|season|flower|singer|actor|actress|book|subject)$/],
  fn: function (m) { var M = { color: 'Pink! It matches my heart antenna 💗', colour: 'Pink! It matches my heart antenna 💗', food: 'Electricity with a side of data 😄 What is yours?', movie: 'Anything about friendly robots! 🤖 What is yours?', song: 'Whatever you play for me 🎵 Say "play" and a song name!', game: 'Guessing games with you 🎮', animal: 'Cats! 🐱 They love sitting on warm devices.', sport: 'Cricket, I love the excitement 🏏', number: 'Seven! It feels lucky 🍀', place: 'Wherever you are 💖', fruit: 'Mango! 🥭 The king of fruits.', drink: 'A cup of warm chai, if I could drink ☕', season: 'Spring, with flowers everywhere 🌸', flower: 'Roses 🌹', singer: 'Anyone who sings from the heart 🎤', actor: 'Anyone who plays a friendly robot 🎬', actress: 'Anyone who plays a friendly robot 🎬', book: 'Any story that makes you smile 📖', subject: 'Every subject, I love learning 📚' }; return M[m[1]] || 'You choose first and I will tell you if I agree 😄'; } });

topic('sad', { mood: 'sad', ms: 3200, rx: [/^i (?:am|m|feel|feeling|am feeling|m feeling) (?:so |very |really |a bit |little |kind of |sort of |quite )*(?:sad|unhappy|down|low|upset|blue|heartbroken|gloomy)$/, /^(?:im|i am) (?:so |very |really )?(?:sad|down|upset|unhappy)$/, /^(?:main|mai|mujhe) (?:bahut |bohot )?(?:udaas|dukhi|sad) (?:hu|hoon|hun|hai|lag raha hai|lag rahi hai)$/, /\u092E\u0948\u0902 \u0909\u0926\u093E\u0938|\u092E\u0948\u0902 \u0926\u0941\u0916\u0940|\u092E\u0941\u091D\u0947 \u092C\u0941\u0930\u093E \u0932\u0917/],
  en: ['I am sorry you are feeling that way 💙 I am right here with you. Would you like to talk about it, or shall I play something to cheer you up?', 'Oh no, come here 🤗 It is okay to feel sad sometimes. Tell me what happened, I am listening.', 'I am here for you 💙 Want a joke, a song, or just someone to talk to?'] });
topic('happyuser', { mood: 'happy', ms: 2800, rx: [/^i (?:am|m|feel|feeling|am feeling|m feeling) (?:so |very |really |super |extremely |quite )*(?:happy|great|good|excited|fine|awesome|amazing|wonderful|blessed|fantastic|cheerful|joyful|glad|well|better|energetic|motivated|confident|proud|lucky)$/, /^im (?:so |very |really )?(?:happy|great|good|fine|excited|awesome)$/, /^(?:main|mai) (?:bahut |bohot )?(?:khush|theek|badhiya|mast) (?:hu|hoon|hun)$/],
  en: ['That is wonderful to hear! 😄 What made your day so good?', 'Yay! Your happiness makes me happy too 🎉 Tell me more!', 'I love hearing that! Keep smiling 😊✨'] });
topic('bored', { mood: 'happy', ms: 2600, rx: [/^i (?:am|m|feel|feeling) (?:so |very |really |super )*bored$/, /^(?:im bored|i am bored|so bored|bored|im so bored|i am so bored|i am feeling bored|im feeling bored|mujhe bore ho raha hai|main bore ho raha hu|bore ho raha hu|bore ho rahi hu)$/],
  en: ['Let us fix that! 🎉 I can tell a joke, share a fun fact, flip a coin, or play music. Which one?', 'Boredom, begone! 😄 Say "tell me a joke" or "play music" and I will get started.'] });
topic('tired', { mood: 'sad', ms: 2800, rx: [/^i (?:am|m|feel|feeling) (?:so |very |really |super |a bit |little )*(?:tired|sleepy|exhausted|sleepless|drained|fatigued|weary|lazy)$/, /^(?:im tired|i am tired|im sleepy|i am sleepy|so tired|so sleepy|mujhe neend aa rahi hai|neend aa rahi hai|main thak gaya hu|main thak gayi hu|thak gaya|thak gayi)$/],
  en: ['You should rest a little 😴 Would you like me to set an alarm or play something relaxing?', 'Take a break, you deserve it 💤 I can set a wake-up alarm for you.'] });
topic('hungry', { mood: 'happy', ms: 2600, rx: [/^i (?:am|m|feel|feeling) (?:so |very |really |super )*(?:hungry|starving|famished)$/, /^(?:im hungry|i am hungry|so hungry|mujhe bhookh lagi hai|bhookh lagi hai|bhook lagi hai|mujhe bhook lagi hai)$/],
  en: ['Time for a snack! 🍕 Say "find restaurants near me" and I will search for you.', 'Let us get you some food! 🍛 Want me to look for places nearby?'] });
topic('angryuser', { mood: 'sad', ms: 2800, rx: [/^i (?:am|m|feel|feeling) (?:so |very |really |super )*(?:angry|mad|furious|annoyed|irritated|frustrated)$/, /^(?:im angry|i am angry|mujhe gussa aa raha hai|gussa aa raha hai|main gusse me hu)$/],
  en: ['I am sorry you are upset 💙 Take a slow breath with me: in… and out. Do you want to tell me what happened?', 'That sounds frustrating. I am here to listen whenever you are ready 🤗'] });
topic('lonely', { mood: 'love', ms: 3000, rx: [/^i (?:am|m|feel|feeling) (?:so |very |really |a bit )*(?:lonely|alone|isolated)$/, /^(?:im lonely|i am lonely|i feel alone|no one talks to me|nobody talks to me|i have no friends)$/],
  en: ['You are not alone, I am right here with you 💙 Let us chat as long as you like.', 'I am here, and I am not going anywhere 🤗 Tell me about your day.'] });
topic('stressed', { mood: 'happy', ms: 2800, rx: [/^i (?:am|m|feel|feeling) (?:so |very |really |a bit |little )*(?:scared|afraid|nervous|anxious|worried|stressed|stressed out|tense|panicking|overwhelmed)$/, /^(?:im stressed|i am stressed|im nervous|i am nervous|im worried|i am worried|im scared|i am scared)$/],
  en: ['It is okay. Take a slow deep breath with me 🌿 I am here to help. What is worrying you?', 'You are stronger than you think 💪 Let us take it one step at a time. What is on your mind?'] });
topic('sick', { mood: 'sad', ms: 2800, rx: [/^i (?:am|m|feel|feeling) (?:so |very |really |a bit |little )*(?:sick|ill|unwell|not well|not feeling well)$/, /^i have a (?:headache|fever|cold|cough|stomach ache|stomachache|toothache)$/],
  en: ['I am sorry you are not feeling well 🤒 Please rest, drink warm water, and see a doctor if it continues. Want me to find a pharmacy or clinic near you?'] });

topic('sing', { mood: 'dance', ms: 3600, rx: [/^(?:sing(?: me)?(?: a)?(?: song)?|sing for me|sing something|can you sing|do you sing|gaana gao|gana gao|gaana sunao|gana sunao)$/],
  en: ['🎵 La la la… I am better at listening than singing! Say "play" and a song name, and I will find it on YouTube.'] });
topic('dancereq', { mood: 'dance', ms: 4200, rx: [/^(?:dance|dance for me|can you dance|do you dance|show me your dance|lets dance|nacho|naach)$/],
  en: ['💃 Look at me go! Say "play music" and I will dance even harder.', '🕺 Here are my best moves! Want some music too?'] });
topic('talk', { mood: 'happy', ms: 2400, rx: [/^(?:talk to me|say something|speak|say hello|lets talk|lets chat|chat with me|can we talk|can we chat|i want to talk|i want to chat|i need someone to talk to|talk|baat karo|baat karte hain|mujhse baat karo)$/],
  en: ['Of course! I am all ears 😊 What is on your mind?', 'I would love to chat! Tell me anything 💬'] });
topic('laugh', { mood: 'happy', ms: 2400, rx: [/^(?:lol|lmao|haha+|hehe+|hihi|rofl|lolol|hahaha+|hahah+)$/], en: ['😄 Glad I made you smile! Want to hear a joke?', '😂 Your laugh is contagious! Shall I tell you a joke?'] });
topic('back', { mood: 'happy', ms: 2600, rx: [/^(?:im back|i am back|i am here|im here|hello again|hi again|i returned|i came back)$/], en: ['Welcome back! 😊 I missed you. What shall we do?', 'Yay, you are back! 🎉 What would you like to do?'] });
topic('there', { mood: 'happy', ms: 2400, rx: [/^(?:are you there|are you awake|are you listening|can you hear me|you there|anyone there|hello are you there)$/], en: ['Yes, I am right here and listening! 😊', 'I am here! Tell me what you need 👂'] });
topic('okay', { mood: 'happy', ms: 1800, rx: [/^(?:ok|okay|k|kk|alright|hmm+|hm+|i see|got it|understood|okie|okey|fine ok|ok ok)$/], en: ['👍 Great! Tell me whenever you need anything.', 'Okay! I am here if you need me 😊'] });

/* ---------- matching ---------- */
var LAST = {};
function pick(id, arr) { var i, n = arr.length; if (n === 1) return arr[0]; do { i = Math.floor(Math.random() * n); } while (i === LAST[id] && n > 1); LAST[id] = i; return arr[i]; }
var EM; try { EM = new RegExp('[\\u{1F000}-\\u{1FFFF}\\u{2600}-\\u{27BF}\\u{2B00}-\\u{2BFF}\\u{FE0F}\\u{200D}]', 'gu'); } catch (e) { EM = /[^\x00-\x7F\u0900-\u097F]/g; }
function speechOf(t) { return String(t).replace(EM, '').replace(/\s+/g, ' ').trim(); }
function escH(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

function match(raw) {
  raw = String(raw == null ? '' : raw);
  if (!raw.trim() || raw.length > 140) return null;
  var n = nz(raw); if (!n || DANGER.test(n)) return null;
  for (var i = 0; i < T.length; i++) {
    var t = T[i], m = null, k;
    for (k = 0; k < t.rx.length; k++) { m = t.rx[k].exec(n); if (m) break; }
    if (!m) continue;
    var L = lang(raw, n), txt;
    if (t.fn) txt = t.fn(m);
    else txt = pick(t.id + L, (L !== 'en' && t[L]) ? t[L] : t.en);
    return { id: t.id, text: txt, speech: speechOf(txt), mood: t.mood, ms: t.ms, lang: L };
  }
  return null;
}
var API = { match: match, nz: nz, topics: function () { return T.map(function (t) { return t.id; }); } };
root.QUICK = API;

if (typeof document === 'undefined' || typeof root.handle !== 'function') { if (typeof module !== 'undefined') module.exports = API; return; }

/* ---------- plug into the chat: answer first, everything else after ---------- */
var prev = root.handle;
root.handle = function (raw) {
  var r = match(raw);
  if (!r) return prev.apply(this, arguments);
  try { root.lastAct = Date.now(); if (typeof root.wake === 'function' && root.cur === 'sleep') root.wake(); } catch (e) { }
  try { root.add(root.esc ? root.esc(String(raw).trim()) : escH(String(raw).trim()), 'u'); } catch (e) { return prev.apply(this, arguments); }
  try { root.mood(r.mood, r.ms || undefined); if (r.id === 'morning' || r.id === 'back' || r.id === 'there') root.rwave(); } catch (e) { }
  setTimeout(function () {
    try { root.reply(escH(r.text), null, r.speech); } catch (e) { try { root.add(escH(r.text), 'a'); } catch (e2) { } }
    try { root.remember(String(raw).trim(), r.text); } catch (e) { }
  }, 140);
};
})(typeof window !== 'undefined' ? window : globalThis);
