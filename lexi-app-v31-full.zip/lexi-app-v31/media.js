/* Lexi media.js
   1) ZIP import + analysis (no library): read a .zip with the ➕ button, drag & drop, or the 📎 button.
      Lexi lists everything inside, detects the kind of project, checks for broken links, secrets,
      duplicates, bad JSON, junk files, counts lines of code and can then answer questions about it.
   2) Edit + Copy under every picture / video / zip message you send (same as text messages).
   Loaded after create.js. The core (JMZIP) is plain JavaScript so it also runs in Node for tests. */
(function (root) {
'use strict';

/* =============================== CORE: ZIP READER =============================== */
var LIMIT_FILE = 1500000, LIMIT_TOTAL = 25000000, MAX_ENTRIES = 20000;
var LANG = { js: 'JavaScript', mjs: 'JavaScript', cjs: 'JavaScript', jsx: 'JavaScript (React)', ts: 'TypeScript', tsx: 'TypeScript (React)', py: 'Python', java: 'Java', kt: 'Kotlin', swift: 'Swift', c: 'C', h: 'C/C++ header', cpp: 'C++', hpp: 'C++', cs: 'C#', go: 'Go', rs: 'Rust', php: 'PHP', rb: 'Ruby', sh: 'Shell', bat: 'Batch', ps1: 'PowerShell', sql: 'SQL', html: 'HTML', htm: 'HTML', css: 'CSS', scss: 'SCSS', vue: 'Vue', svelte: 'Svelte', json: 'JSON', webmanifest: 'JSON', yml: 'YAML', yaml: 'YAML', xml: 'XML', md: 'Markdown', dart: 'Dart', lua: 'Lua', r: 'R' };
var TEXT_EXT = /\.(txt|md|markdown|csv|tsv|json|jsonl|webmanifest|html?|css|scss|sass|less|xml|svg|ya?ml|toml|ini|cfg|conf|env|log|m?js|cjs|jsx|tsx?|vue|svelte|py|rb|php|java|kt|swift|c|h|cpp|hpp|cs|go|rs|sh|bash|bat|ps1|sql|r|lua|dart|gradle|properties|lock)$/i;
var TEXT_NAME = /(^|\/)(dockerfile|makefile|procfile|license|readme|\.gitignore|\.env[^\/]*|\.editorconfig|\.npmrc)$/i;
var CATS = [
  ['Code', /\.(m?js|cjs|jsx|tsx?|py|rb|php|java|kt|swift|c|h|cpp|hpp|cs|go|rs|sh|bash|bat|ps1|sql|r|lua|dart|vue|svelte)$/i],
  ['Web pages & styles', /\.(html?|css|scss|sass|less)$/i],
  ['Data & config', /\.(json|jsonl|webmanifest|xml|ya?ml|toml|ini|cfg|conf|env|csv|tsv|lock|properties|gradle)$/i],
  ['Documents', /\.(md|markdown|txt|pdf|docx?|xlsx?|pptx?|rtf|odt)$/i],
  ['Images', /\.(png|jpe?g|gif|webp|svg|ico|bmp|avif|heic|tiff?)$/i],
  ['Audio & video', /\.(mp3|wav|ogg|m4a|aac|flac|mp4|mov|avi|mkv|webm)$/i],
  ['Fonts', /\.(woff2?|ttf|otf|eot)$/i],
  ['Archives & binaries', /\.(zip|rar|7z|tar|gz|tgz|bz2|xz|exe|dll|so|dylib|bin|apk|jar|class|pyc|wasm|dmg|iso)$/i]
];
function catOf(n) { for (var i = 0; i < CATS.length; i++) if (CATS[i][1].test(n)) return CATS[i][0]; return 'Other'; }
function extOf(n) { var m = /\.([A-Za-z0-9]+)$/.exec(n); return m ? m[1].toLowerCase() : ''; }
function baseOf(n) { return n.replace(/\/+$/, '').split('/').pop(); }
function dirOf(n) { var i = n.lastIndexOf('/'); return i < 0 ? '' : n.slice(0, i); }
function isTextName(n) { return TEXT_EXT.test(n) || TEXT_NAME.test(n); }
function u16(d, o) { return d.getUint16(o, true); }
function u32(d, o) { return d.getUint32(o, true); }
function n64(d, o) { return d.getUint32(o, true) + d.getUint32(o + 4, true) * 4294967296; }
function dosDate(d, t) { try { return new Date(1980 + (d >> 9), ((d >> 5) & 15) - 1, d & 31, t >> 11, (t >> 5) & 63, (t & 31) * 2).getTime(); } catch (e) { return 0; } }
function fmtSize(b) { if (b < 1024) return b + ' B'; if (b < 1048576) return (b / 1024).toFixed(1) + ' KB'; if (b < 1073741824) return (b / 1048576).toFixed(1) + ' MB'; return (b / 1073741824).toFixed(2) + ' GB'; }
function joinPath(dir, rel) {
  var parts = (dir ? dir.split('/') : []).concat(rel.split('/')), out = [];
  parts.forEach(function (p) { if (p === '' || p === '.') return; if (p === '..') out.pop(); else out.push(p); });
  return out.join('/');
}

/* read the central directory: names, sizes, methods, offsets */
function parseZip(buf) {
  var dv = new DataView(buf), n = buf.byteLength, e = -1, notes = [], i;
  if (n < 22) throw new Error('This file is too small to be a zip.');
  for (i = n - 22; i >= Math.max(0, n - 22 - 65535); i--) if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('This does not look like a valid .zip file (no end-of-archive marker found).');
  var total = u16(dv, e + 10), cdSize = u32(dv, e + 12), cdOff = u32(dv, e + 16), z64 = false;
  if ((total === 0xFFFF || cdOff === 0xFFFFFFFF || cdSize === 0xFFFFFFFF) && e >= 20 && u32(dv, e - 20) === 0x07064b50) {
    var z = n64(dv, e - 12);
    if (z + 56 <= n && u32(dv, z) === 0x06064b50) { total = n64(dv, z + 32); cdSize = n64(dv, z + 40); cdOff = n64(dv, z + 48); z64 = true; }
  }
  var delta = (!z64 && cdOff + cdSize <= e) ? e - (cdOff + cdSize) : 0; /* zip with data in front (self-extracting) */
  var p = cdOff + delta, entries = [], dec = new TextDecoder('utf-8');
  if (total > MAX_ENTRIES) { notes.push('Archive lists ' + total + ' entries; only the first ' + MAX_ENTRIES + ' are analysed.'); }
  for (var k = 0; k < Math.min(total, MAX_ENTRIES) && p + 46 <= n; k++) {
    if (u32(dv, p) !== 0x02014b50) { notes.push('The directory is damaged after ' + entries.length + ' entries.'); break; }
    var flags = u16(dv, p + 8), method = u16(dv, p + 10), tm = u16(dv, p + 12), dt = u16(dv, p + 14), crc = u32(dv, p + 16),
      cs = u32(dv, p + 20), us = u32(dv, p + 24), nl = u16(dv, p + 28), xl = u16(dv, p + 30), cl = u16(dv, p + 32), off = u32(dv, p + 42);
    var name = dec.decode(new Uint8Array(buf, p + 46, nl)).replace(/\\/g, '/');
    var xp = p + 46 + nl, xe = xp + xl;
    while (xp + 4 <= xe) { /* zip64 extra field */
      var id = u16(dv, xp), sz = u16(dv, xp + 2), q = xp + 4;
      if (id === 1) {
        if (us === 0xFFFFFFFF && q + 8 <= xe) { us = n64(dv, q); q += 8; }
        if (cs === 0xFFFFFFFF && q + 8 <= xe) { cs = n64(dv, q); q += 8; }
        if (off === 0xFFFFFFFF && q + 8 <= xe) { off = n64(dv, q); q += 8; }
      }
      xp += 4 + sz;
    }
    entries.push({ name: name, dir: /\/$/.test(name), method: method, enc: !!(flags & 1), crc: crc, cs: cs, us: us, off: off + delta, time: dosDate(dt, tm) });
    p += 46 + nl + xl + cl;
  }
  return { entries: entries, notes: notes, total: total };
}

/* decompress one entry (stored or deflate) */
function readEntry(buf, en) {
  var dv = new DataView(buf), o = en.off;
  if (en.enc) return Promise.reject(new Error('password protected'));
  if (o + 30 > buf.byteLength || u32(dv, o) !== 0x04034b50) return Promise.reject(new Error('bad local header'));
  var s = o + 30 + u16(dv, o + 26) + u16(dv, o + 28);
  if (s + en.cs > buf.byteLength) return Promise.reject(new Error('truncated'));
  var data = new Uint8Array(buf, s, en.cs);
  if (en.method === 0) return Promise.resolve(data);
  if (en.method === 8 && typeof DecompressionStream !== 'undefined') {
    var rs = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Response(rs).arrayBuffer().then(function (b) { return new Uint8Array(b); });
  }
  return Promise.reject(new Error('unsupported compression method ' + en.method));
}
function looksText(u8) {
  var n = Math.min(u8.length, 4096), bad = 0;
  for (var i = 0; i < n; i++) { var c = u8[i]; if (c === 0) return false; if (c < 9 || (c > 13 && c < 32 && c !== 27)) bad++; }
  return bad <= n * 0.02;
}

var SECRETS = [
  ['Anthropic key', /sk-ant-[A-Za-z0-9_-]{20,}/], ['OpenAI-style key', /\bsk-[A-Za-z0-9]{32,}/], ['Google API key', /AIza[0-9A-Za-z_-]{35}/],
  ['AWS access key', /\bAKIA[0-9A-Z]{16}\b/], ['GitHub token', /\bgh[pousr]_[A-Za-z0-9]{30,}/], ['Private key', /-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/],
  ['Hard-coded secret', /\b(?:password|passwd|secret|api[_-]?key|access[_-]?token)\b\s*[:=]\s*['"][^'"\s]{10,}['"]/i]
];
var PRIORITY = /(^|\/)(readme[^\/]*|package\.json|manifest\.(json|webmanifest)|index\.html?|main\.[a-z]+|app\.[a-z]+|requirements\.txt|pyproject\.toml|pom\.xml|go\.mod|cargo\.toml|composer\.json|dockerfile|sw\.js|service-?worker\.js)$/i;

function analyse(buf, opt) {
  opt = opt || {};
  var z = parseZip(buf), all = z.entries, files = all.filter(function (e) { return !e.dir; }), dirs = {}, set = {}, rep, i;
  all.forEach(function (e) { var parts = e.name.replace(/\/$/, '').split('/'); for (var j = 1; j <= (e.dir ? parts.length : parts.length - 1); j++) dirs[parts.slice(0, j).join('/')] = 1; });
  files.forEach(function (e) { set[e.name] = e; });
  rep = { entries: all, files: files, dirCount: Object.keys(dirs).length, notes: z.notes.slice(), texts: {}, unread: [], cat: {}, ext: {}, lang: {}, kinds: [], facts: [], checks: [], dupes: [], secrets: [], largest: [], size: 0, csize: 0, newest: 0, oldest: 0 };
  files.forEach(function (e) {
    var c = catOf(e.name), x = rep.cat[c] || (rep.cat[c] = { n: 0, size: 0 }); x.n++; x.size += e.us;
    var ex = extOf(e.name) || '(none)'; rep.ext[ex] = (rep.ext[ex] || 0) + 1;
    rep.size += e.us; rep.csize += e.cs;
    if (e.time) { if (!rep.newest || e.time > rep.newest) rep.newest = e.time; if (!rep.oldest || e.time < rep.oldest) rep.oldest = e.time; }
  });
  rep.largest = files.slice().sort(function (a, b) { return b.us - a.us; }).slice(0, 8);
  var seen = {}; files.forEach(function (e) { if (e.us > 0) { var k = e.crc + ':' + e.us; (seen[k] = seen[k] || []).push(e.name); } });
  Object.keys(seen).forEach(function (k) { if (seen[k].length > 1) rep.dupes.push(seen[k]); });

  /* choose and read text files (important ones first, small ones next) */
  var cand = files.filter(function (e) { return !e.enc && e.us > 0 && e.us <= LIMIT_FILE && (isTextName(e.name) || (!catOf(e.name).match(/Images|Audio|Fonts|Archives/) && catOf(e.name) === 'Other')); })
    .sort(function (a, b) { var pa = PRIORITY.test(a.name) ? 0 : 1, pb = PRIORITY.test(b.name) ? 0 : 1; return pa - pb || a.us - b.us; });
  var budget = LIMIT_TOTAL, idx = 0, done = 0;
  function worker() {
    if (idx >= cand.length) return Promise.resolve();
    var en = cand[idx++];
    if (budget - en.us < 0) { rep.unread.push(en.name); return worker(); }
    budget -= en.us;
    return readEntry(buf, en).then(function (u8) {
      if (isTextName(en.name) || looksText(u8)) rep.texts[en.name] = new TextDecoder('utf-8').decode(u8);
    }).catch(function () { rep.unread.push(en.name); }).then(function () { done++; if (opt.onProgress && done % 10 === 0) try { opt.onProgress(done, cand.length); } catch (e) { } return worker(); });
  }
  return Promise.all([worker(), worker(), worker(), worker()]).then(function () { return finish(rep, set); });
}

function finish(rep, set) {
  var T = rep.texts, names = Object.keys(T), files = rep.files, K = rep.kinds, F = rep.facts, C = rep.checks, i;
  function add(lv, t) { C.push({ lv: lv, t: t }); }
  function findBase(re) { return files.map(function (e) { return e.name; }).filter(function (n) { return re.test(baseOf(n)); }).sort(function (a, b) { return a.split('/').length - b.split('/').length; }); }
  function json(n) { try { return JSON.parse(T[n].replace(/^\uFEFF/, '')); } catch (e) { return null; } }

  /* lines of code per language */
  names.forEach(function (n) { var L = LANG[extOf(n)]; if (!L || /\.min\.(js|css)$/i.test(n)) return; var lines = T[n].split('\n').length, o = rep.lang[L] || (rep.lang[L] = { files: 0, lines: 0 }); o.files++; o.lines += lines; });
  rep.loc = 0; Object.keys(rep.lang).forEach(function (k) { if (!/JSON|Markdown|XML|YAML/.test(k)) rep.loc += rep.lang[k].lines; });

  /* project kind + facts */
  var pk = findBase(/^package\.json$/)[0];
  if (pk && T[pk]) { var pj = json(pk); if (pj) { K.push('Node.js / JavaScript project'); F.push('package.json: ' + (pj.name || 'unnamed') + (pj.version ? ' v' + pj.version : '') + ', ' + Object.keys(pj.dependencies || {}).length + ' dependencies, ' + Object.keys(pj.devDependencies || {}).length + ' dev dependencies' + (pj.scripts ? ', scripts: ' + Object.keys(pj.scripts).slice(0, 6).join(', ') : '')); var dps = Object.keys(pj.dependencies || {}).concat(Object.keys(pj.devDependencies || {})); ['react', 'vue', 'next', 'svelte', 'express', 'vite', 'webpack', '@angular/core'].forEach(function (d) { if (dps.indexOf(d) > -1) F.push('Uses ' + d); }); } else add('bad', 'package.json is not valid JSON.'); }
  var mf = findBase(/^manifest\.(webmanifest|json)$/)[0], swf = findBase(/^(sw|service-?worker)\.js$/i)[0], mj = mf && T[mf] ? json(mf) : null;
  if (mj && (mj.start_url || mj.display)) { K.push('Progressive Web App (installable)'); F.push('Manifest: "' + (mj.name || mj.short_name || '?') + '", display ' + (mj.display || 'browser') + ', ' + (mj.icons || []).length + ' icons'); if (!swf) add('warn', 'Manifest found but no service worker (sw.js), so it will not work offline.'); }
  if (swf) { F.push('Service worker: ' + swf); var cv = /(?:var|const|let)\s+\w+\s*=\s*['"]([^'"]+)['"]/.exec(T[swf] || ''); if (cv) F.push('Cache name: ' + cv[1]); }
  if (findBase(/^(requirements\.txt|pyproject\.toml|setup\.py|Pipfile)$/)[0]) K.push('Python project');
  if (findBase(/^pom\.xml$|^build\.gradle(\.kts)?$/)[0]) K.push('Java / Kotlin project');
  if (findBase(/^go\.mod$/)[0]) K.push('Go project'); if (findBase(/^Cargo\.toml$/)[0]) K.push('Rust project');
  if (findBase(/^composer\.json$/)[0]) K.push('PHP project'); if (findBase(/^Gemfile$/)[0]) K.push('Ruby project');
  if (findBase(/^(Dockerfile|docker-compose\.ya?ml)$/i)[0]) K.push('Docker setup');
  if (files.some(function (e) { return /(^|\/)\.github\/workflows\//.test(e.name); })) K.push('GitHub Actions CI');
  var idxs = findBase(/^index\.html?$/i); if (idxs[0] && !K.length) K.push('Static website / web app');
  else if (idxs[0] && K.indexOf('Static website / web app') < 0 && !/Node|Python|Java|PHP|Ruby|Go|Rust/.test(K.join())) K.push('Static website / web app');
  if (!K.length) K.push(rep.loc ? 'Source files (no standard project file found)' : 'Collection of files');
  var rd = findBase(/^readme(\.\w+)?$/i)[0]; if (rd && T[rd]) { var first = T[rd].split('\n').filter(function (l) { return l.trim(); }).slice(0, 2).join(' · ').replace(/[#*`]/g, '').slice(0, 160); F.push('README: ' + first); } else add('warn', 'No README file: add one that explains what the project does and how to run it.');

  /* health checks */
  var bad = rep.entries.filter(function (e) { return /(^|\/)\.\.(\/|$)/.test(e.name) || /^\/|^[A-Za-z]:/.test(e.name); });
  if (bad.length) add('bad', 'Unsafe paths inside the zip (' + bad.length + ', e.g. ' + bad[0].name + '). Do not extract it with tools that trust paths.'); 
  var envs = files.filter(function (e) { return /(^|\/)\.env(\.|$)/.test(e.name) && !/example|sample|template/i.test(e.name); });
  if (envs.length) add('bad', 'Environment file included (' + envs[0].name + '). It usually holds secrets: remove it before sharing.');
  var junk = files.filter(function (e) { return /(^|\/)(\.DS_Store|Thumbs\.db|__MACOSX|__pycache__)(\/|$)|\.pyc$/.test(e.name); });
  if (junk.length) add('warn', junk.length + ' junk files (.DS_Store / __MACOSX / __pycache__ …) can be deleted.');
  var nm = files.filter(function (e) { return /(^|\/)node_modules\//.test(e.name); }).length; if (nm) add('warn', nm + ' files from node_modules are packed in. Ship package.json instead and run npm install.');
  if (files.some(function (e) { return /(^|\/)\.git\//.test(e.name); })) add('warn', 'The .git folder (full history) is included.');
  var enc = files.filter(function (e) { return e.enc; }); if (enc.length) add('warn', enc.length + ' files are password protected and could not be read.');
  if (rep.dupes.length) add('warn', rep.dupes.length + ' groups of identical files (e.g. ' + rep.dupes[0].slice(0, 2).join(' = ') + ').');
  var big = files.filter(function (e) { return e.us > 5e6; }); if (big.length) add('warn', big.length + ' very large files (>5 MB): ' + big[0].name + ' is ' + fmtSize(big[0].us) + '.');
  var jbad = [], k; names.forEach(function (n) { if (/\.(json|webmanifest)$/i.test(n) && !/(^|\/)(tsconfig|jsconfig|\.eslintrc)[^\/]*$/i.test(n) && !json(n)) jbad.push(n); });
  if (jbad.length) add('bad', 'Invalid JSON: ' + jbad.slice(0, 4).join(', ') + '.');

  /* broken references: html src/href, manifest icons, service-worker cache list */
  function exists(p) { return !!set[p] || !!set[p.replace(/\/$/, '')]; }
  var broken = [];
  function ref(from, r) {
    if (!r || /^(?:[a-z][a-z0-9+.-]*:|\/\/|#)/i.test(r)) return; r = r.split('#')[0].split('?')[0]; if (!r || /\/$/.test(r) || /\{\{|<%|\$\{/.test(r)) return;
    var p = r.charAt(0) === '/' ? joinPath('', r) : joinPath(dirOf(from), r);
    if (!exists(p) && !(r.charAt(0) === '/' && files.some(function (e) { return e.name.slice(-p.length - 1) === '/' + p; }))) broken.push(from + ' → ' + r);
  }
  names.forEach(function (n) {
    if (/\.html?$/i.test(n)) { var re = /(?:src|href)\s*=\s*["']([^"']+)["']/gi, m; while ((m = re.exec(T[n]))) ref(n, m[1]); }
    else if (/(^|\/)(sw|service-?worker)\.js$/i.test(n)) { var re2 = /['"]([^'"\s]+\.(?:js|html?|css|png|jpe?g|svg|webp|ico|json|webmanifest|woff2?))['"]/gi, m2; while ((m2 = re2.exec(T[n]))) if (!/^(https?:|\/\/)/.test(m2[1])) ref(n, m2[1]); }
  });
  if (mj && mj.icons) mj.icons.forEach(function (ic) { if (ic && ic.src) ref(mf, ic.src); });
  rep.broken = broken.filter(function (v, i2, a) { return a.indexOf(v) === i2; });
  if (rep.broken.length) add('bad', rep.broken.length + ' broken file reference' + (rep.broken.length > 1 ? 's' : '') + ': ' + rep.broken.slice(0, 3).join('; ') + (rep.broken.length > 3 ? ' …' : ''));
  else if (names.some(function (n) { return /\.html?$/i.test(n); })) add('ok', 'All files linked from the HTML, manifest and service worker exist.');

  /* secrets: report file + kind only, never the value */
  names.forEach(function (n) { if (/\.min\.js$|\.lock$|package-lock\.json$/i.test(n)) return; SECRETS.forEach(function (s) { var m = s[1].exec(T[n]); if (m) rep.secrets.push({ file: n, kind: s[0], hint: m[0].slice(0, 4) + '…' }); }); });
  if (rep.secrets.length) add('bad', 'Possible secrets in ' + rep.secrets.length + ' place(s): ' + rep.secrets.slice(0, 3).map(function (s) { return s.kind + ' in ' + s.file; }).join('; ') + '. Revoke and remove them.');
  else if (names.length) add('ok', 'No API keys, tokens or private keys found in the readable files.');

  /* code smells */
  var cnt = { eval: 0, doc: 0, inner: 0, todo: 0 };
  names.forEach(function (n) { if (/\.min\.js$/i.test(n) || /^(Markdown|JSON)$/.test(LANG[extOf(n)] || '')) return; if (!/\.(m?js|cjs|jsx|tsx?|html?|vue|php|py)$/i.test(n)) return; var t = T[n]; cnt.eval += (t.match(/\beval\s*\(|new Function\s*\(/g) || []).length; cnt.doc += (t.match(/document\.write\s*\(/g) || []).length; cnt.inner += (t.match(/\.innerHTML\s*=/g) || []).length; cnt.todo += (t.match(/\b(?:TODO|FIXME|HACK|XXX)\b/g) || []).length; });
  if (cnt.eval || cnt.doc) add('warn', 'Risky calls: eval/new Function ×' + cnt.eval + ', document.write ×' + cnt.doc + '.');
  if (cnt.inner > 20) add('warn', 'innerHTML assignments ×' + cnt.inner + ': make sure any user or web text is escaped first.');
  if (cnt.todo) add('warn', cnt.todo + ' TODO / FIXME notes left in the code.');
  if (rep.unread.length) rep.notes.push(rep.unread.length + ' large or unreadable files were skipped when reading text.');
  rep.cnt = cnt;
  rep.md = reportMd(rep);
  return rep;
}

function reportMd(r) {
  var L = [], cats = Object.keys(r.cat).sort(function (a, b) { return r.cat[b].size - r.cat[a].size; });
  L.push('# Zip analysis', '', '- Files: ' + r.files.length + ', folders: ' + r.dirCount, '- Size: ' + fmtSize(r.size) + ' (compressed ' + fmtSize(r.csize) + ')', '- Type: ' + r.kinds.join(', '), '- Lines of code: ' + r.loc.toLocaleString('en-US'), '');
  if (r.facts.length) { L.push('## Details'); r.facts.forEach(function (f) { L.push('- ' + f); }); L.push(''); }
  L.push('## Contents by type'); cats.forEach(function (c) { L.push('- ' + c + ': ' + r.cat[c].n + ' files, ' + fmtSize(r.cat[c].size)); }); L.push('');
  if (Object.keys(r.lang).length) { L.push('## Languages'); Object.keys(r.lang).sort(function (a, b) { return r.lang[b].lines - r.lang[a].lines; }).forEach(function (k) { L.push('- ' + k + ': ' + r.lang[k].files + ' files, ' + r.lang[k].lines.toLocaleString('en-US') + ' lines'); }); L.push(''); }
  L.push('## Checks'); r.checks.forEach(function (c) { L.push('- ' + (c.lv === 'ok' ? '[OK] ' : c.lv === 'warn' ? '[WARN] ' : '[PROBLEM] ') + c.t); }); L.push('');
  L.push('## Largest files'); r.largest.forEach(function (e) { L.push('- ' + e.name + ' (' + fmtSize(e.us) + ')'); }); L.push('');
  L.push('## All files'); r.files.slice(0, 600).forEach(function (e) { L.push('- ' + e.name + ' (' + fmtSize(e.us) + ')'); }); if (r.files.length > 600) L.push('- … and ' + (r.files.length - 600) + ' more');
  return L.join('\n');
}

/* text handed to the AI: summary + file list + the most important files */
function contextFor(r, extra, max) {
  max = max || 16000; var out = [], used = 0, T = r.texts;
  function put(s) { out.push(s); used += s.length; }
  put('ZIP ARCHIVE (read on the user\'s device just now). Kind: ' + r.kinds.join(', ') + '. ' + r.files.length + ' files, ' + fmtSize(r.size) + ', about ' + r.loc + ' lines of code.\nAutomatic checks:\n' + r.checks.map(function (c) { return '- [' + c.lv + '] ' + c.t; }).join('\n') + '\nFile list:\n' + r.files.slice(0, 150).map(function (e) { return e.name + ' (' + fmtSize(e.us) + ')'; }).join('\n'));
  var want = (extra || []).filter(function (n) { return T[n] !== undefined; }), rest = Object.keys(T).filter(function (n) { return want.indexOf(n) < 0 && !/\.min\.|\.lock$|package-lock/i.test(n); }).sort(function (a, b) { var pa = PRIORITY.test(a) ? 0 : 1, pb = PRIORITY.test(b) ? 0 : 1; return pa - pb || T[a].length - T[b].length; });
  want.forEach(function (n) { if (used < max) put('\n\n===== FILE ' + n + ' =====\n' + T[n].slice(0, 7000)); });
  rest.forEach(function (n) { if (used < max - 400) put('\n\n===== FILE ' + n + ' =====\n' + T[n].slice(0, PRIORITY.test(n) ? 2500 : 1100)); });
  return out.join('').slice(0, max + 8000);
}

root.JMZIP = { parse: parseZip, read: readEntry, analyse: analyse, context: contextFor, fmt: fmtSize, cat: catOf, ext: extOf, base: baseOf, joinPath: joinPath };
if (typeof document === 'undefined' || typeof root.handle !== 'function') { if (typeof module !== 'undefined') module.exports = root.JMZIP; return; }

/* =============================== UI =============================== */
var log = document.getElementById('log'), inp = document.getElementById('t');
var ZIPS = {}, ZN = 0, ZIPCUR = null, bypass = false;
function esc0(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
function h(tag, attrs, kids) { var e = document.createElement(tag); for (var k in attrs || {}) { if (k === 'text') e.textContent = attrs[k]; else e.setAttribute(k, attrs[k]); } (kids || []).forEach(function (c) { if (c) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); }); return e; }
function say(t) { try { root.speak(t); } catch (e) { } }
function feel(m, ms) { try { root.mood(m, ms); } catch (e) { } }
function scrollDown() { try { log.scrollTop = log.scrollHeight; } catch (e) { } }
function md(t) { return (root.md || esc0)(t); }
function flash(b, t, back) { var o = back || b.textContent; b.textContent = t; setTimeout(function () { b.textContent = o; }, 1500); }
function download(name, blobOrText, type) { var b = blobOrText instanceof Blob ? blobOrText : new Blob([blobOrText], { type: type || 'text/plain' }), u = URL.createObjectURL(b), a = h('a', { href: u, download: name }); document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 4000); }

var style = document.createElement('style');
style.textContent =
  '.jm-file{display:flex;gap:10px;align-items:center;min-width:210px;max-width:320px}.jm-file span{font-size:28px}.jm-file b{display:block;word-break:break-all;font-size:14.5px}.jm-file small{opacity:.85;font-size:12px}' +
  '.jm-card{font-size:14px;line-height:1.45}.jm-h{font-size:16px;margin-bottom:6px;word-break:break-all}.jm-h small{color:var(--mut);font-weight:400}' +
  '.jm-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.jm-chips i{font-style:normal;font-size:12.5px;background:var(--bg);border:1px solid var(--bd);border-radius:12px;padding:3px 9px}' +
  '.jm-sec{margin:10px 0 4px;font-weight:700;font-size:13.5px}.jm-bar{display:flex;align-items:center;gap:8px;font-size:12.5px;margin:3px 0}.jm-bar em{font-style:normal;width:128px;flex:none}.jm-bar u{display:block;height:9px;border-radius:5px;background:linear-gradient(90deg,var(--a),#22d3c5);text-decoration:none;min-width:3px}.jm-bar s{text-decoration:none;color:var(--mut)}' +
  '.jm-li{margin:3px 0;font-size:13.5px}.jm-li.bad{color:#d33}.jm-li.warn{color:#b7791f}.jm-li.ok{color:#198754}' +
  '.jm-card details{margin:8px 0;border:1px solid var(--bd);border-radius:10px;padding:6px 10px;background:var(--bg)}.jm-card summary{cursor:pointer;font-weight:600;font-size:13.5px}.jm-tree{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px;max-height:300px;overflow:auto;padding-left:4px}.jm-tree details{border:0;margin:1px 0;padding:0 0 0 12px;background:none}.jm-tree .f{padding-left:14px;white-space:nowrap}.jm-tree .f small{color:var(--mut)}' +
  '.jm-act{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}.jm-act button{border:1px solid var(--bd);background:var(--card);color:var(--fg);border-radius:14px;padding:6px 12px;font-size:13px;cursor:pointer}.jm-act button:hover{border-color:var(--a)}' +
  '.jm-pre{white-space:pre-wrap;word-break:break-word;max-height:340px;overflow:auto;background:var(--bg);border:1px solid var(--bd);border-radius:10px;padding:8px;font:12px ui-monospace,Menlo,Consolas,monospace}' +
  '.jm-pv{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px}.jm-pv img{max-height:90px;border-radius:8px}';
document.head.appendChild(style);

/* ---------- AI call: your key first, then the free service ---------- */
function askAI(prompt) {
  var C = root.CFG || {}, keys = { claude: 'ak', chatgpt: 'ok', gemini: 'gk', groq: 'grk', openrouter: 'ork' };
  var order = Object.keys(keys).filter(function (p) { return C[keys[p]]; });
  if (C.prov && C.prov !== 'auto' && order.indexOf(C.prov) > -1) order = [C.prov].concat(order.filter(function (p) { return p !== C.prov; }));
  var tries = order.map(function (p) { return function () { return root.ai(p, prompt); }; });
  tries.push(function () {
    return fetch('https://text.pollinations.ai/openai', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ model: 'openai', messages: [{ role: 'system', content: String(root.SYS || 'You are a helpful assistant.') }, { role: 'user', content: prompt }] }) })
      .then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.choices[0].message.content; });
  });
  return tries.reduce(function (a, f) { return a.catch(f); }, Promise.reject()).then(function (t) { if (!t || !String(t).trim()) throw 0; return String(t); });
}
var ZIP_RULES = 'Answer using ONLY what is in the ZIP context above. Quote file names exactly. If something is not in the provided files, say so instead of guessing. Be accurate and specific: point to the file and the exact line or function when you can, and give complete corrected code in a fenced code block when you suggest a fix.';
function askZip(question, label) {
  if (!ZIPCUR) return;
  var rep = ZIPCUR.rep, names = Object.keys(rep.texts).filter(function (n) { var b = baseOf(n); return b.length >= 4 && question.toLowerCase().indexOf(b.toLowerCase()) > -1; });
  var prompt = contextFor(rep, names, root.CFG && (root.CFG.ak || root.CFG.ok || root.CFG.gk) ? 30000 : 14000) + '\n\n' + ZIP_RULES + '\n\nUSER REQUEST: ' + question;
  var el = add('<span class="dots"><i></i><i></i><i></i></span>', 'a'); scrollDown();
  askAI(prompt).then(function (t) { el.innerHTML = md(t); scrollDown(); say(String(t).replace(/```[\s\S]*?```/g, ' ').replace(/[#*`|>-]/g, ' ').slice(0, 300)); feel('happy', 1500); })
    .catch(function () { el.innerHTML = md('I could not reach an AI right now. The automatic analysis above still works offline. Add a free Gemini or Groq key in 🔌 for in-depth answers, or try again in a minute.'); });
}

/* ---------- render the analysis card ---------- */
function bars(rep) {
  var cats = Object.keys(rep.cat).sort(function (a, b) { return rep.cat[b].size - rep.cat[a].size || rep.cat[b].n - rep.cat[a].n; }), max = Math.max.apply(null, cats.map(function (c) { return rep.cat[c].size || 1; }).concat([1])), d = h('div');
  cats.forEach(function (c) { var o = rep.cat[c]; d.appendChild(h('div', { 'class': 'jm-bar' }, [h('em', { text: c }), h('u', { style: 'width:' + Math.max(3, Math.round(o.size / max * 52)) + '%' }), h('s', { text: o.n + ' · ' + JMZIP.fmt(o.size) })])); });
  return d;
}
function tree(rep) {
  var rootN = { d: {}, f: [] }, shown = 0, LIM = 700;
  rep.files.forEach(function (e) { var p = e.name.split('/'), n = rootN; for (var i = 0; i < p.length - 1; i++) n = n.d[p[i]] || (n.d[p[i]] = { d: {}, f: [] }); n.f.push(e); });
  function count(n) { var c = n.f.length; Object.keys(n.d).forEach(function (k) { c += count(n.d[k]); }); return c; }
  function build(n, open) {
    var box = h('div');
    Object.keys(n.d).sort().forEach(function (k) { if (shown > LIM) return; shown++; var dt = h('details'); if (open) dt.open = true; dt.appendChild(h('summary', { text: '📁 ' + k + '/ (' + count(n.d[k]) + ')' })); dt.appendChild(build(n.d[k], false)); box.appendChild(dt); });
    n.f.sort(function (a, b) { return a.name < b.name ? -1 : 1; }).forEach(function (e) { if (shown > LIM) return; shown++; var f = h('div', { 'class': 'f' }); f.appendChild(document.createTextNode('📄 ' + baseOf(e.name) + ' ')); f.appendChild(h('small', { text: JMZIP.fmt(e.us) })); box.appendChild(f); });
    return box;
  }
  var t = h('div', { 'class': 'jm-tree' }); t.appendChild(build(rootN, true)); if (shown > LIM) t.appendChild(h('div', { 'class': 'f', text: '… more files not shown' })); return t;
}
function render(el, rep, file) {
  var when = rep.newest ? new Date(rep.newest).toLocaleDateString() : '';
  el.innerHTML = ''; var c = h('div', { 'class': 'jm-card' });
  c.appendChild(h('div', { 'class': 'jm-h' }, ['🗜️ ', h('b', { text: file.name }), ' ', h('small', { text: '· ' + JMZIP.fmt(file.size) })]));
  var chips = h('div', { 'class': 'jm-chips' }); [rep.files.length + ' files', rep.dirCount + ' folders', JMZIP.fmt(rep.size) + ' unpacked', rep.csize && rep.size ? 'compressed to ' + Math.round(rep.csize / rep.size * 100) + '%' : '', rep.loc ? rep.loc.toLocaleString('en-US') + ' lines of code' : '', when ? 'newest file ' + when : ''].forEach(function (t) { if (t) chips.appendChild(h('i', { text: t })); }); c.appendChild(chips);
  c.appendChild(h('div', { 'class': 'jm-sec', text: '📦 What it is' })); rep.kinds.forEach(function (k) { c.appendChild(h('div', { 'class': 'jm-li', text: '• ' + k })); }); rep.facts.forEach(function (f) { c.appendChild(h('div', { 'class': 'jm-li', text: '• ' + f })); });
  c.appendChild(h('div', { 'class': 'jm-sec', text: '📊 What is inside' })); c.appendChild(bars(rep));
  var lg = Object.keys(rep.lang).filter(function (k) { return !/JSON|Markdown|XML|YAML/.test(k); }).sort(function (a, b) { return rep.lang[b].lines - rep.lang[a].lines; }).slice(0, 6);
  if (lg.length) c.appendChild(h('div', { 'class': 'jm-li', text: '🔤 ' + lg.map(function (k) { return k + ' ' + rep.lang[k].lines.toLocaleString('en-US') + ' lines'; }).join(' · ') }));
  c.appendChild(h('div', { 'class': 'jm-sec', text: '🔎 Automatic checks' }));
  var order = { bad: 0, warn: 1, ok: 2 }, ic = { bad: '❌ ', warn: '⚠️ ', ok: '✅ ' };
  rep.checks.slice().sort(function (a, b) { return order[a.lv] - order[b.lv]; }).forEach(function (k) { c.appendChild(h('div', { 'class': 'jm-li ' + k.lv, text: ic[k.lv] + k.t })); });
  if (!rep.checks.length) c.appendChild(h('div', { 'class': 'jm-li', text: 'Nothing to check in these files.' }));
  rep.notes.forEach(function (n) { c.appendChild(h('div', { 'class': 'jm-li', text: 'ℹ️ ' + n })); });
  var big = h('details'); big.appendChild(h('summary', { text: '📏 Largest files' })); rep.largest.forEach(function (e) { big.appendChild(h('div', { 'class': 'jm-li', text: e.name + ' — ' + JMZIP.fmt(e.us) })); }); c.appendChild(big);
  var tr = h('details'); tr.appendChild(h('summary', { text: '🌳 All files (' + rep.files.length + ')' })); tr.appendChild(tree(rep)); c.appendChild(tr);
  var act = h('div', { 'class': 'jm-act' });
  function ab(t, fn) { var b = h('button', { type: 'button', text: t }); b.onclick = fn; act.appendChild(b); return b; }
  function ask(label, q) { return function () { add(esc0(label), 'u'); askZip(q, label); }; }
  ab('🤖 Explain this project', ask('Explain this project', 'Explain what this project is, how it is organised, what each important file does, and how to run it. Use short headings and simple words.'));
  ab('🐞 Find bugs', ask('Find bugs in this project', 'Review the code for real bugs, broken logic, missing files and error handling problems. For each issue give the file, what is wrong, and the corrected code.'));
  ab('🔒 Security review', ask('Security review of this project', 'Do a security review: exposed secrets, XSS, injection, unsafe storage, risky permissions or dependencies. For each finding give file, risk level and the fix.'));
  ab('✨ Suggest improvements', ask('Suggest improvements for this project', 'Suggest the most valuable improvements (performance, structure, user experience, missing features) in priority order, with concrete code for the top three.'));
  ab('📋 Copy report', function () { var b = this; try { navigator.clipboard.writeText(rep.md); flash(b, '✅ Copied'); } catch (e) { } });
  ab('⬇ Report (.md)', function () { download(file.name.replace(/\.zip$/i, '') + '-analysis.md', rep.md, 'text/markdown'); });
  c.appendChild(act);
  c.appendChild(h('div', { 'class': 'src', text: 'Analysed on your device. Nothing was uploaded. Ask me anything about it, or say "show index.html" to open a file.' }));
  el.appendChild(c); scrollDown();
}

/* ---------- ZIP flow ---------- */
function zipSummaryLine(rep) { return 'Your zip has ' + rep.files.length + ' files. It looks like ' + rep.kinds[0] + '. ' + (rep.checks.filter(function (c) { return c.lv === 'bad'; }).length ? 'I found problems to look at.' : 'No serious problems found.'); }
function runZip(file, q) {
  if (file.size > 400e6) { add('🗜️ That zip is ' + JMZIP.fmt(file.size) + '. Please use one under 400 MB.', 'a'); return; }
  var id = 'z' + (++ZN);
  add('<div class="jm-file" data-zid="' + id + '"><span>🗜️</span><div><b>' + esc0(file.name) + '</b><small>' + JMZIP.fmt(file.size) + ' · zip archive</small></div></div>' + (q ? '<br>' + esc0(q) : ''), 'u');
  ZIPS[id] = { file: file, q: q || '' };
  var el = add('<span class="dots"><i></i><i></i><i></i></span> <small>Reading the zip…</small>', 'a'); scrollDown(); feel('search');
  file.arrayBuffer().then(function (buf) { return JMZIP.analyse(buf, { onProgress: function (d, t) { el.querySelector('small') && (el.querySelector('small').textContent = 'Reading files… ' + d + ' / ' + t); } }); })
    .then(function (rep) {
      if (ZIPCUR && ZIPS[ZIPCUR.id] && ZIPS[ZIPCUR.id].rep) ZIPS[ZIPCUR.id].rep.texts = {};
      ZIPS[id].rep = rep; ZIPCUR = { id: id, rep: rep, file: file };
      render(el, rep, file); say(zipSummaryLine(rep)); feel('happy', 1500);
      if (q) askZip(q);
    })
    .catch(function (err) { el.innerHTML = md('I could not read **' + esc0(file.name) + '**: ' + esc0(err && err.message || 'unknown error') + '. Check that it is a normal .zip (not .rar or .7z) and try again.'); feel('sad', 1800); });
}
function isZip(f) { return f && (/\.zip$/i.test(f.name) || /zip/.test(f.type || '') && !/rar|7z/.test(f.type)); }
root.JM = { zip: function (f) { var q = (inp.value || '').trim(); inp.value = ''; runZip(f, q); }, isZip: isZip };

/* drop a zip anywhere in the chat */
log.addEventListener('dragover', function (e) { if (e.dataTransfer && [].some.call(e.dataTransfer.items || [], function (i) { return /zip/.test(i.type); })) e.preventDefault(); }, true);
log.addEventListener('drop', function (e) { var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (isZip(f)) { e.preventDefault(); e.stopImmediatePropagation(); root.JM.zip(f); } }, true);

/* ---------- follow-up questions about the zip ---------- */
function findEntry(rep, q) {
  q = q.trim().replace(/^["'`]|["'`]$/g, '').toLowerCase(); var names = rep.files.map(function (e) { return e.name; });
  return names.filter(function (n) { return n.toLowerCase() === q; })[0] || names.filter(function (n) { return baseOf(n).toLowerCase() === q; })[0] || names.filter(function (n) { return n.toLowerCase().slice(-q.length) === q && q.length > 2; })[0];
}
function showFile(name) {
  var rep = ZIPCUR.rep, t = rep.texts[name]; var m = add('', 'a');
  if (t === undefined) { m.innerHTML = md('**' + esc0(name) + '** is not a text file I can show (' + JMZIP.fmt((rep.files.filter(function (e) { return e.name === name; })[0] || { us: 0 }).us) + '). Binary files such as images are not displayed.'); return; }
  var lines = t.split('\n'), shown = lines.slice(0, 220).join('\n');
  m.appendChild(h('b', { text: '📄 ' + name + ' ' })); m.appendChild(h('small', { text: lines.length + ' lines' + (lines.length > 220 ? ' (first 220 shown)' : '') }));
  m.appendChild(h('pre', { 'class': 'jm-pre', text: shown }));
  var a = h('div', { 'class': 'jm-act' }); var b1 = h('button', { type: 'button', text: '📋 Copy' }); b1.onclick = function () { try { navigator.clipboard.writeText(t); flash(b1, '✅ Copied'); } catch (e) { } };
  var b2 = h('button', { type: 'button', text: '⬇ Download' }); b2.onclick = function () { download(baseOf(name), t); };
  var b3 = h('button', { type: 'button', text: '🤖 Explain this file' }); b3.onclick = function () { add(esc0('Explain ' + baseOf(name)), 'u'); askZip('Explain what ' + name + ' does, section by section, and point out any bugs.'); };
  a.appendChild(b1); a.appendChild(b2); a.appendChild(b3); m.appendChild(a); scrollDown();
}
var prevH = root.handle;
root.handle = function (raw) {
  var s = String(raw == null ? '' : raw).trim();
  if (bypass || !s || !ZIPCUR) return prevH.apply(this, arguments);
  var rep = ZIPCUR.rep, m;
  if (/^(?:forget|close|clear|remove)\s+(?:the\s+|this\s+|my\s+)?(?:zip|archive)\b/i.test(s)) { add(esc0(s), 'u'); ZIPCUR = null; add('Done. I forgot the zip. Send another any time with ➕.', 'a'); return; }
  if ((m = s.match(/^(?:show|open|view|read|cat|print|display)\s+(?:me\s+)?(?:the\s+)?(?:file\s+)?(\S.*)$/i))) { var fn = findEntry(rep, m[1]); if (fn) { add(esc0(s), 'u'); return showFile(fn); } }
  if (/^(?:list|show)\s+(?:all\s+)?(?:the\s+|my\s+)?(?:files|contents?|tree)(?:\s+(?:in|of)\s+(?:the\s+)?(?:zip|archive))?$/i.test(s)) { add(esc0(s), 'u'); var mm = add('', 'a'); render(mm, rep, ZIPCUR.file); return; }
  var named = rep.files.some(function (e) { var b = baseOf(e.name); return b.length >= 5 && s.toLowerCase().indexOf(b.toLowerCase()) > -1; });
  if (named || /\b(?:zip|archive|project|codebase|repo(?:sitory)?|source code|this app|the app|my app|folder)\b/i.test(s) && /\b(?:what|how|why|explain|find|fix|bugs?|errors?|security|improve|review|summar|check|list|does|is|are|which|where|add|change|update|convert|write)\b/i.test(s)) {
    add(esc0(s), 'u'); return askZip(s);
  }
  return prevH.apply(this, arguments);
};

/* ======================= EDIT + COPY under pictures / videos / zips ======================= */
function rowsAfter(row) { var n = row, out = []; while (n) { out.push(n); n = n.nextElementSibling; } return out; }
function imgToPngBlob(src) {
  return new Promise(function (res, rej) { var i = new Image(); i.onload = function () { var c = document.createElement('canvas'); c.width = i.naturalWidth; c.height = i.naturalHeight; c.getContext('2d').drawImage(i, 0, 0); c.toBlob(function (b) { b ? res(b) : rej(new Error('png')); }, 'image/png'); }; i.onerror = rej; i.src = src; });
}
function captionOf(m) { var c = m.cloneNode(true); [].forEach.call(c.querySelectorAll('img,.jm-file,div'), function (n) { n.remove(); }); return c.textContent.trim(); }
function toJpeg(file) {
  return new Promise(function (res, rej) {
    var r = new FileReader(); r.onerror = rej; r.onload = function () {
      var src = r.result, i = new Image(); i.onerror = rej; i.onload = function () {
        var s = Math.min(1, 1024 / Math.max(i.width, i.height)), c = document.createElement('canvas'); c.width = Math.round(i.width * s); c.height = Math.round(i.height * s); c.getContext('2d').drawImage(i, 0, 0, c.width, c.height);
        res({ jpg: c.toDataURL('image/jpeg', 0.85), png: /^data:image\/(png|webp|gif)/.test(src) && src.length < 6e6 ? src : null });
      }; i.src = src;
    }; r.readAsDataURL(file);
  });
}
function runPhoto(jpgs, q, png) {
  var label = jpgs.length > 1 ? 'these frames taken from a video (describe what happens; I cannot hear the audio)' : 'this photo';
  add(jpgs.map(function (s) { return '<img src="' + s + '" style="max-width:150px;border-radius:10px;margin:2px">'; }).join('') + (q ? '<br>' + esc0(q) : ''), 'u');
  var el0 = add('🔍 Looking carefully…', 'a'); scrollDown(); feel('search');
  if (root.JV && root.JV.run) root.JV.run(jpgs, q, label, el0, jpgs.length === 1 ? (png || jpgs[0]) : null);
  else el0.textContent = 'Photo tools did not load. Reload the app and try again.';
}
function sendAny(file, q) {
  if (isZip(file)) return runZip(file, q);
  if (/^image\//.test(file.type)) return toJpeg(file).then(function (o) { runPhoto([o.jpg], q, o.png); }).catch(function () { add('I could not open that image. Try a JPG or PNG.', 'a'); });
  add('Please choose a picture or a .zip file.', 'a');
}
function startEdit(row, kind) {
  if (row.querySelector('.jx-ed')) return;
  var m = row.querySelector('.m'), tools = row.querySelector('.jx-ut'), srcs = [].map.call(m.querySelectorAll('img'), function (i) { return i.src; }), zid = (m.querySelector('[data-zid]') || {}).getAttribute && m.querySelector('[data-zid]').getAttribute('data-zid');
  var ta = h('textarea', { 'aria-label': 'Edit your message', placeholder: kind === 'zip' ? 'Ask something about the zip (optional), e.g. find bugs, explain index.html' : 'Ask or change something about the picture, e.g. remove background, what is written here?' });
  ta.value = captionOf(m);
  var pv = h('div', { 'class': 'jm-pv' }); if (kind === 'zip') pv.appendChild(h('div', { text: '🗜️ ' + (ZIPS[zid] ? ZIPS[zid].file.name : 'zip file') })); else srcs.forEach(function (s) { pv.appendChild(h('img', { src: s })); });
  var box = h('div', { 'class': 'jx-ed' }, [pv, ta]);
  function cancel() { box.remove(); m.style.display = ''; if (tools) tools.style.display = ''; }
  function drop() { rowsAfter(row).forEach(function (n) { n.remove(); }); try { speechSynthesis.cancel(); } catch (e) { } }
  function save() {
    var q = ta.value.trim(); drop();
    if (kind === 'zip') { if (ZIPS[zid]) runZip(ZIPS[zid].file, q); } else runPhoto(srcs, q, srcs.length === 1 ? srcs[0] : null);
  }
  var pick = h('input', { type: 'file', accept: 'image/*,.zip,application/zip', style: 'display:none' });
  pick.onchange = function () { var f = pick.files[0]; if (!f) return; var q = ta.value.trim(); drop(); sendAny(f, q); };
  var change = bt(kind === 'zip' ? '🗜 Change file' : '🖼 Change picture', function () { pick.click(); });
  var bar = h('div', { 'class': 'jx-eb' }, [h('small', { text: 'Enter = save & send · Shift+Enter = new line · Esc = cancel' }), bt('Cancel', cancel), change, bt('Save & send ➤', save, 'jx-btn p'), pick]);
  box.appendChild(bar);
  ta.onkeydown = function (e) { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); save(); } else if (e.key === 'Escape') { e.preventDefault(); cancel(); } };
  m.style.display = 'none'; if (tools) tools.style.display = 'none';
  row.insertBefore(box, tools || null); ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length);
}
function bt(t, fn, cls) { var b = h('button', { type: 'button', 'class': cls || 'jx-btn', text: t }); b.onclick = fn; return b; }
root.JM.decorate = function (row, m, tools) {
  var isz = !!m.querySelector('[data-zid]'), kind = isz ? 'zip' : 'photo';
  tools.appendChild(bt('✏️ Edit', function () { startEdit(row, kind); }, 'jx-ub'));
  var cp = bt('📋 Copy', function () {
    if (isz) { var z = ZIPS[m.querySelector('[data-zid]').getAttribute('data-zid')]; var txt = z && z.rep ? z.rep.md : (z ? z.file.name : ''); try { navigator.clipboard.writeText(txt); flash(cp, '✅ Copied', '📋 Copy'); } catch (e) { flash(cp, '⚠ Not allowed', '📋 Copy'); } return; }
    var src = m.querySelector('img').src;
    imgToPngBlob(src).then(function (b) {
      if (navigator.clipboard && window.ClipboardItem) return navigator.clipboard.write([new ClipboardItem({ 'image/png': b })]).then(function () { flash(cp, '✅ Picture copied', '📋 Copy'); });
      download('lexi-picture.png', b); flash(cp, '⬇ Saved (copy not supported here)', '📋 Copy');
    }).catch(function () { try { imgToPngBlob(src).then(function (b) { download('lexi-picture.png', b); flash(cp, '⬇ Saved instead', '📋 Copy'); }); } catch (e) { } });
  }, 'jx-ub');
  tools.appendChild(cp);
};
/* decorate pictures/zips that were added before this file loaded */
[].forEach.call(log.querySelectorAll('.jx-ut:empty'), function (n) { n.remove(); });
if (typeof root.JX_decorate === 'function') root.JX_decorate();

/* ======================= YouTube fallback hook ======================= */
/* If the page runs from a local file, YouTube refuses embeds (Error 153): open the video on YouTube instead. */
root.JM_ytOK = function () { return location.protocol !== 'file:' && location.origin !== 'null'; };

})(typeof window !== 'undefined' ? window : globalThis);
