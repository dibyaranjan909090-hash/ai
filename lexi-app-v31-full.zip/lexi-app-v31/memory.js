/* Lexi memory.js v20: long-term memory about the user, in any language.
   - Remembers when you say it: "remember that my car is a white Nexon", "yaad rakhna ki ...", "याद रखना ...".
   - Picks up facts as you chat: "my name is Ravi", "mera naam Ravi hai", "I live in Pune", "my wife's name is Priya".
   - With an AI available, also learns facts from messages in any language (in the background, never slowing a reply).
   - Recall instantly: "what is my name", "what do you remember about me", "forget my car", "forget everything".
   - Never stores passwords, OTPs, PINs, card or account numbers or API keys.
   Saved on this device only. Relevant memories are added to AI requests by train.js. */
(function (root) {
'use strict';
var K = 'lexi_memory', KC = 'lexi_memory_cfg', KT = 'lexi_memory_trash';
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
var M = L(K, { items: [] }); if (!Array.isArray(M.items)) M.items = [];
var C = Object.assign({ auto: true, ai: true }, L(KC, {}));
function save() { S(K, M); try { if (root.lexiTrainRebuild) root.lexiTrainRebuild(); } catch (e) { } }
function cap(s) { s = String(s).trim(); return s.charAt(0).toUpperCase() + s.slice(1); }
function clean(s) { return String(s || '').replace(/\s+/g, ' ').replace(/^[\s,:;-]+|[\s.,!?।;:-]+$/g, '').trim(); }

var SECRET = /\b(otp|one[- ]time|password|passwd|passcode|pass code|pin|mpin|upi pin|cvv|card (?:number|no)|account (?:number|no)|a\/c|ifsc|api[- ]?key|secret|token|aadhaar|aadhar|pan (?:card|number)|ssn)\b|पासवर्ड|ओटीपी|पिन|\b\d{9,19}\b|\b(?:sk|pk|gsk|sk-ant)[-_][A-Za-z0-9]{8,}|AIza[0-9A-Za-z_-]{20,}/i;
function isSecret(s) { return SECRET.test(String(s)); }

var WRE; try { WRE = new RegExp('[\\p{L}\\p{N}\\p{M}]+', 'gu'); } catch (e) { WRE = /[a-z0-9ऀ-෿]+/gi; }
function words(s) { return (String(s).toLowerCase().match(WRE) || []).filter(function (w) { return w.length > 1; }); }
function sim(a, b) { var A = words(a), B = words(b); if (!A.length || !B.length) return 0; var sa = {}, n = 0, u = {}; A.forEach(function (w) { sa[w] = 1; u[w] = 1; }); B.forEach(function (w) { if (sa[w]) { n++; delete sa[w]; } u[w] = 1; }); return n / Object.keys(u).length; }

function add(text, key, src) {
  text = clean(text).slice(0, 300);
  if (!text || text.length < 3) return { ok: false };
  if (isSecret(text)) return { ok: false, secret: true };
  var now = Date.now();
  if (key) M.items = M.items.filter(function (x) { return x.k !== key; });
  else {
    var dup = M.items.filter(function (x) { return !x.k && sim(x.text, text) >= 0.75; })[0];
    if (dup) { dup.text = text; dup.t = now; save(); return { ok: true, item: dup, updated: true }; }
  }
  var it = { id: now.toString(36) + Math.random().toString(36).slice(2, 6), k: key || '', text: text, t: now, src: src || 'chat' };
  M.items.push(it);
  if (M.items.length > 400) M.items = M.items.slice(-400);
  save(); return { ok: true, item: it };
}
function get(key) { var x = M.items.filter(function (i) { return i.k === key; }).pop(); return x ? x.v || x.text : ''; }
function nameOf() { var x = M.items.filter(function (i) { return i.k === 'name'; }).pop(); return x ? x.v : ''; }
function setName(n) { n = clean(n).replace(/\b(hai|h|hoon|hu|है|हूँ|हूं)$/i, '').trim(); if (!n || n.length > 40 || isSecret(n)) return null; n = n.split(' ').map(cap).join(' '); var r = add("User's name is " + n, 'name', 'chat'); if (r.item) { r.item.v = n; save(); } return n; }
function remove(id) { M.items = M.items.filter(function (x) { return x.id !== id; }); save(); }
function forget(q) {
  var ws = words(q).filter(function (w) { return !/^(my|the|about|that|mera|meri|mere|ke|ki|ka|baare|bare|mein|me|wala|wali|sab|all)$/.test(w); });
  if (!ws.length) return 0;
  var before = M.items.length, gone = [];
  M.items = M.items.filter(function (x) { var t = x.text.toLowerCase(); var hit = ws.every(function (w) { return t.indexOf(w) >= 0; }); if (hit) gone.push(x); return !hit; });
  if (gone.length) { S(KT, gone); save(); }
  return before - M.items.length;
}
function forgetAll() { S(KT, M.items); M.items = []; save(); }
function undo() { var t = L(KT, []); if (!t.length) return 0; M.items = M.items.concat(t); S(KT, []); save(); return t.length; }

/* ---------- facts said in chat (English, Hinglish, Hindi) ---------- */
var NAME_STOP = /^(back|later|tomorrow|today|now|at|when|in|on|after|please|soon|asap|again|him|her|them|mom|dad|me)\b/i;
var REL = 'wife|husband|son|daughter|mother|mom|mum|father|dad|brother|sister|friend|best friend|boss|manager|partner|girlfriend|boyfriend|grandmother|grandfather|uncle|aunt|cousin|teacher|accountant|driver|assistant|colleague';
var REL_HG = { biwi: 'wife', patni: 'wife', pati: 'husband', beta: 'son', beti: 'daughter', maa: 'mother', mummy: 'mother', papa: 'father', pitaji: 'father', bhai: 'brother', behen: 'sister', bahan: 'sister', dost: 'friend', boss: 'boss', wife: 'wife', husband: 'husband' };
var OBJ_STOP = /^(you|u|ya|it|this|that|them|him|her|to|so|when|how|the way)\b/i;
var PAT = [
  { re: /\b(?:my name is|my name's|i am called|people call me|you can call me|call me)\s+([A-Za-zÀ-ɏऀ-෿][A-Za-zÀ-ɏऀ-෿ .'-]{0,38})/i, fn: function (m) { if (NAME_STOP.test(m[1])) return null; var n = m[1].split(/\s+(?:and|but|i|from|aur|,)\s+/i)[0]; return { name: n }; } },
  { re: /\b(?:mera|meraa|apna) naam\s+([a-z][a-z .'-]{0,38}?)\s+(?:hai|h|he)\b/i, fn: function (m) { return { name: m[1] }; } },
  { re: /मेरा नाम\s+(.{1,40}?)\s*(?:है|हैं)/, fn: function (m) { return { name: m[1] }; } },
  { re: /\b(?:i live in|i stay in|i'm from|i am from|i am based in|i'm based in)\s+([A-Za-z][A-Za-z .,'-]{1,40})/i, fn: function (m) { var c = clean(m[1]).split(/\s+(?:and|but|since|for)\s+/)[0]; return { k: 'city', text: (/from/i.test(m[0]) ? 'User is from ' : 'User lives in ') + c }; } },
  { re: /\b(?:main|mai|mein|hum)\s+([a-z][a-z ]{1,30}?)\s+(?:mein|me|main)\s+(?:rehta|rehti|rahta|rahti|rehte|rahte)\b/i, fn: function (m) { return { k: 'city', text: 'User lives in ' + cap(m[1]) }; } },
  { re: /मैं\s+(.{1,30}?)\s+में\s+रह(?:ता|ती|ते)/, fn: function (m) { return { k: 'city', text: 'User lives in ' + m[1] }; } },
  { re: /\bmy (?:birthday|bday|date of birth|dob) is\s+(?:on\s+)?(.{3,30})/i, fn: function (m) { return { k: 'birthday', text: "User's birthday is " + clean(m[1]) }; } },
  { re: /\bmera (?:birthday|janamdin|janmdin) (.{3,30}?) (?:ko )?(?:hai|h)\b/i, fn: function (m) { return { k: 'birthday', text: "User's birthday is " + clean(m[1]) }; } },
  { re: /\bi (?:work|am working) (?:at|in|for|as)\s+(.{2,60})/i, fn: function (m) { return { k: 'work', text: 'User works ' + m[0].replace(/^i (?:work|am working) /i, '').trim() }; } },
  { re: new RegExp("\\bmy (" + REL + ")(?:'s name| name)? is\\s+([A-Za-z\\u0900-\\u0DFF][A-Za-z\\u0900-\\u0DFF .'-]{0,30})", 'i'), fn: function (m) { var r = m[1].toLowerCase(); return { k: 'person_' + r.replace(/\s+/g, '_'), text: "User's " + r + ' is ' + clean(m[2]).split(/\s+(?:and|but|who)\s+/)[0].split(' ').map(cap).join(' ') }; } },
  { re: /\b(?:meri|mere|mera)\s+(biwi|patni|pati|beta|beti|maa|mummy|papa|pitaji|bhai|behen|bahan|dost|boss|wife|husband)\s+(?:ka|ki|ke)\s+naam\s+([a-z][a-z .'-]{0,30}?)\s+(?:hai|h)\b/i, fn: function (m) { var r = REL_HG[m[1].toLowerCase()] || m[1]; return { k: 'person_' + r, text: "User's " + r + ' is ' + m[2].split(' ').map(cap).join(' ') }; } },
  { re: /\bmy fav(?:ou?rite)? ([a-z ]{2,20}?) is\s+(.{2,40})/i, fn: function (m) { var w = clean(m[1]).toLowerCase(); return { k: 'fav_' + w.replace(/\s+/g, '_'), text: "User's favourite " + w + ' is ' + clean(m[2]) }; } },
  { re: /\bi (?:really |also )?(?:like|love|enjoy|prefer)\s+(.{2,60})/i, fn: function (m) { if (OBJ_STOP.test(m[1])) return null; return { text: 'User likes ' + clean(m[1]) }; } },
  { re: /\bi (?:don't|do not|dont|hate|dislike|can't stand)\s*(?:like\s+)?(.{2,60})/i, fn: function (m) { if (OBJ_STOP.test(m[1]) || /^(know|understand|have|want|need|think|get)\b/i.test(m[1])) return null; return { text: 'User dislikes ' + clean(m[1]) }; } },
  { re: /\bi(?: am|'m) (?:vegetarian|vegan|jain|eggetarian)\b/i, fn: function (m) { return { k: 'diet', text: 'User is ' + m[0].replace(/^i(?: am|'m) /i, '') }; } },
  { re: /\b(?:reply|talk|speak|answer) (?:to me )?(?:always )?in ([a-z]+)\b(?: always| from now)?/i, fn: function (m) { if (!/always|from now|please always/i.test(m[0])) return null; return { k: 'lang_pref', text: 'User prefers replies in ' + cap(m[1]) }; } }
];
function capture(raw) {
  raw = String(raw || '').trim();
  if (!C.auto || !raw || raw.length > 400 || /\?\s*$/.test(raw) || isSecret(raw)) return [];
  var got = [];
  PAT.forEach(function (p) {
    var m = p.re.exec(raw); if (!m) return;
    var r = null; try { r = p.fn(m); } catch (e) { r = null; }
    if (!r) return;
    if (r.name) { var n = setName(r.name); if (n) got.push('name: ' + n); return; }
    var a = add(r.text, r.k, 'chat'); if (a.ok) got.push(r.text.replace(/^User(?:'s)? /, ''));
  });
  return got;
}

/* ---------- explicit commands, answered instantly ---------- */
var EXPLICIT = [
  /^(?:please\s+|lexi\s+)?(?:remember|yaad rakh(?:na|o|iye|ein)?|note that|keep in mind|don'?t forget)\s*(?:that|ki|ke)?\s+(.{3,300})$/i,
  /^(?:कृपया\s+)?याद\s*रख(?:ना|ो|िए|ें|िये)?\s*(?:कि)?\s+(.{3,300})$/,
  /^(.{3,300}?)\s*,?\s+(?:yaad rakhna|yaad rakho|yaad rakhiye|याद रखना|याद रखो|याद रखिए|remember (?:this|that|it))\s*[.!]?$/i
];
var RECALL_NAME = /^(?:what(?:'s| is) my name|do you know my name|who am i|mera naam kya hai|mera naam batao|मेरा नाम क्या है|मेरा नाम बताओ)\s*\??$/i;
var RECALL_ALL = /^(?:what do you (?:remember|know)(?: about me)?|what have you remembered|show (?:my )?memor(?:y|ies)|my memor(?:y|ies)|tum mere (?:baare|bare) (?:mein|me) kya jaante ho|kya yaad hai|मेरे बारे में क्या याद है|तुम्हें क्या याद है)\s*\??$/i;
var FORGET_ALL = /^(?:forget everything(?: about me)?|clear (?:my |your )?memor(?:y|ies)|delete (?:all )?(?:my )?memor(?:y|ies)|sab bhool jao|sab kuch bhool jao|सब भूल जाओ)\s*[.!]?$/i;
var FORGET = /^(?:please\s+)?(?:forget|bhool jao|bhul jao|भूल जाओ)\s+(?:about\s+|that\s+|ki\s+)?(.{2,120})$|^(.{2,120}?)\s+(?:bhool jao|bhul jao|भूल जाओ|forget (?:it|that))\s*[.!]?$/i;
var UNDO = /^(?:undo forget|restore (?:my )?memor(?:y|ies)|wapas lao)\s*[.!]?$/i;
var ASK_KEY = [
  [/^(?:where do i live|where am i from|main kahan rehta hoon|main kahan rehti hoon|मैं कहाँ रहता हूँ)\s*\??$/i, 'city'],
  [/^(?:when is my birthday|what is my birthday|mera birthday kab hai|मेरा जन्मदिन कब है)\s*\??$/i, 'birthday'],
  [/^(?:where do i work|what is my work|what do i do)\s*\??$/i, 'work']
];
/* "User's car is..." -> "Your car is...", "User lives in..." -> "You live in..." */
function you(t) {
  return String(t).replace(/^User's /, 'Your ').replace(/^User is /, 'You are ').replace(/^User has /, 'You have ')
    .replace(/^User (\w+s)\b(?=\s)/, function (m, v) { return 'You ' + (/(?:ch|sh|x|ss|o)es$/.test(v) ? v.slice(0, -2) : v.slice(0, -1)); })
    .replace(/^User\b/, 'You');
}
function list(n) { return M.items.slice().sort(function (a, b) { return b.t - a.t; }).slice(0, n || 400); }
function command(raw) {
  var t = String(raw || '').trim(); if (!t || t.length > 320 || /\n/.test(t)) return null;
  var m, i;
  if (RECALL_NAME.test(t)) { var n = nameOf(); return n ? 'Your name is **' + n + '**. 😊' : 'You have not told me your name yet. Say “my name is …” and I will remember it.'; }
  if (RECALL_ALL.test(t)) {
    var L2 = list(15);
    if (!L2.length) return 'I have not saved anything about you yet. Tell me things like “my name is …” or “remember that …”.';
    return '**What I remember about you** (' + M.items.length + '):\n' + L2.map(function (x) { return '- ' + you(x.text); }).join('\n') + '\n\nSay “forget …” to remove something, or open + → Training Center → Memory.';
  }
  for (i = 0; i < ASK_KEY.length; i++) if (ASK_KEY[i][0].test(t)) { var v = M.items.filter(function (x) { return x.k === ASK_KEY[i][1]; }).pop(); return v ? you(v.text) + '.' : 'You have not told me that yet.'; }
  if (UNDO.test(t)) { var u = undo(); return u ? 'Restored ' + u + ' memories.' : 'There is nothing to restore.'; }
  if (FORGET_ALL.test(t)) { var c = M.items.length; forgetAll(); return 'Done, I have forgotten all ' + c + ' things about you. Say “undo forget” to bring them back.'; }
  if ((m = FORGET.exec(t))) { var q = m[1] || m[2], k = forget(q); return k ? 'Forgotten (' + k + '). Say “undo forget” if that was a mistake.' : 'I could not find anything about “' + q + '” in my memory.'; }
  for (i = 0; i < EXPLICIT.length; i++) if ((m = EXPLICIT[i].exec(t))) {
    var f = clean(m[1]);
    if (/^to\s/i.test(f) || /^(?:me to|mujhe)\b/i.test(f)) return null; /* "remember to buy milk" is a reminder: let tasks handle it */
    if (isSecret(f)) return 'I will not save passwords, OTPs, PINs, card or account numbers. Keep those in a password manager. 🔒';
    var nm = /^(?:my name is|mera naam)\s+(.+?)(?:\s+(?:hai|h))?$/i.exec(f);
    if (nm) { var nn = setName(nm[1]); return nn ? 'Nice to meet you, **' + nn + '**! I will remember your name.' : null; }
    var was = C.auto; C.auto = true; var got = capture(f); C.auto = was;
    if (got.length) return '🧠 Got it, I will remember: ' + got.join(' · ') + '.';
    var r = add(f.replace(/^my\b/i, "User's").replace(/^i\b/i, 'User'), '', 'told');
    return r.ok ? '🧠 Got it, I will remember: “' + f + '”.' : null;
  }
  return null;
}

/* ---------- learn from any language with AI (background) ---------- */
var FIRST = /\b(i|i'm|im|i've|my|me|mine|myself|mera|meri|mere|mujhe|main|hamara|humara|je|j'|mon|ma|mes|moi|ich|mein|meine|mich|mir|yo|mis|eu|meu|minha|io|mio|mia|saya|aku|ben|benim|ik|mijn|tôi|naan|nanu|nenu|ami|amar)\b|मैं|मेरा|मेरी|मुझे|हमारा|আমি|আমার|நான்|என்|నేను|నా |ನಾನು|ನನ್ನ|मी |माझ|હું|મારું|મારી|ഞാൻ|എന്റെ|ମୁଁ|ମୋର|ਮੈਂ|ਮੇਰਾ|ਮੇਰੀ|میں|میرا|میری|я |мой|моя|меня|мне|我|私|僕|나는|내 |저는|제 |أنا|اسمي|لدي|אני|ฉัน|ผม|ฉัน/i;
var EXTRACT_SYS = '[LEXI-TRAIN][/LEXI-TRAIN] You extract durable personal facts that a user states about themselves, for an assistant\'s long-term memory. ' +
  'Include: name, where they live, work/company/role, family members and their names, preferences, likes and dislikes, important dates, the language they prefer, ongoing projects. ' +
  'Exclude: questions, temporary moods, one-off tasks, anything about other topics, and secrets (passwords, OTPs, PINs, card, bank or ID numbers, API keys). ' +
  'Write each fact as one short English sentence starting with "User" (e.g. "User\'s name is Ravi", "User lives in Pune", "User\'s daughter is Asha"). ' +
  'Reply with ONLY a JSON array of strings, or [] if there is nothing durable.';
var lastAI = 0, queue = null, busy = false;
function aiCall(text) {
  var CFG = root.CFG || {}, H = { 'content-type': 'application/json' }, ctl = new AbortController();
  setTimeout(function () { try { ctl.abort(); } catch (e) { } }, 20000);
  var o = { method: 'POST', signal: ctl.signal, headers: H };
  function oai(u, key, model) { if (key) H.authorization = 'Bearer ' + key; o.body = JSON.stringify({ model: model, temperature: 0, messages: [{ role: 'system', content: EXTRACT_SYS }, { role: 'user', content: text }] }); return root.fetch(u, o).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.choices[0].message.content; }); }
  if (CFG.gk) { o.body = JSON.stringify({ systemInstruction: { parts: [{ text: EXTRACT_SYS }] }, contents: [{ role: 'user', parts: [{ text: text }] }], generationConfig: { temperature: 0 } }); return root.fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(CFG.gk), o).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.candidates[0].content.parts.map(function (p) { return p.text || ''; }).join(''); }); }
  if (CFG.grk) return oai('https://api.groq.com/openai/v1/chat/completions', CFG.grk, 'llama-3.1-8b-instant');
  if (CFG.ok) return oai('https://api.openai.com/v1/chat/completions', CFG.ok, 'gpt-4.1-mini');
  if (CFG.ak) { H['x-api-key'] = CFG.ak; H['anthropic-version'] = '2023-06-01'; H['anthropic-dangerous-direct-browser-access'] = 'true'; o.body = JSON.stringify({ model: 'claude-haiku-5-5', max_tokens: 300, system: EXTRACT_SYS, messages: [{ role: 'user', content: text }] }); return root.fetch('https://api.anthropic.com/v1/messages', o).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { return j.content[0].text; }); }
  return oai('https://text.pollinations.ai/openai', '', 'openai');
}
function parseFacts(out) {
  var s = String(out || ''), a = s.indexOf('['), b = s.lastIndexOf(']');
  if (a < 0 || b <= a) return [];
  try { var j = JSON.parse(s.slice(a, b + 1)); return Array.isArray(j) ? j.filter(function (x) { return typeof x === 'string' && x.length > 6 && x.length < 300; }).slice(0, 6) : []; } catch (e) { return []; }
}
function learnAI(text) {
  if (!C.ai) return;
  if (busy || Date.now() - lastAI < 12000) { queue = text; return; }
  busy = true; lastAI = Date.now();
  aiCall(text).then(parseFacts).then(function (fs) {
    var saved = [];
    fs.forEach(function (f) {
      if (isSecret(f)) return;
      var nm = /^User's name is (.{1,40})$/i.exec(clean(f));
      if (nm) { var n = setName(nm[1]); if (n) saved.push('name: ' + n); return; }
      var r = add(f, '', 'ai'); if (r.ok && !r.updated) saved.push(f.replace(/^User(?:'s)? /, ''));
    });
    if (saved.length) toast(saved);
  }).catch(function () { }).then(function () { busy = false; if (queue) { var q = queue; queue = null; setTimeout(function () { learnAI(q); }, 1500); } });
}
function observe(raw) {
  raw = String(raw || '').trim();
  if (!raw || isSecret(raw)) return;
  var got = capture(raw);
  if (got.length) { toast(got); return; }
  if (raw.length >= 8 && raw.length <= 600 && !/```/.test(raw) && FIRST.test(' ' + raw + ' ') && !/\?\s*$/.test(raw)) learnAI(raw);
}

/* ---------- small "remembered" note ---------- */
function toast(items) {
  try {
    var d = document.createElement('div');
    d.setAttribute('role', 'status');
    d.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:calc(150px + env(safe-area-inset-bottom,0px));z-index:9998;background:#1d1a3a;color:#fff;padding:8px 14px;border-radius:999px;font:13px system-ui;box-shadow:0 4px 16px rgba(0,0,0,.25);max-width:90vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer';
    d.textContent = '🧠 Remembered: ' + items.join(' · ');
    d.onclick = function () { d.remove(); if (root.lexiTrain) root.lexiTrain('memory'); };
    document.body.appendChild(d); setTimeout(function () { d.remove(); }, 3500);
  } catch (e) { }
}

root.lexiMemory = {
  items: function () { return M.items; }, list: list, add: add, remove: remove, forget: forget, forgetAll: forgetAll, undo: undo,
  name: nameOf, setName: setName, get: get, command: command, observe: observe, capture: capture, isSecret: isSecret,
  cfg: function (k, v) { if (arguments.length > 1) { C[k] = v; S(KC, C); } return C[k]; },
  replaceAll: function (items) { M.items = (items || []).filter(function (x) { return x && x.text && !isSecret(x.text); }); save(); },
  _parseFacts: parseFacts, you: you
};
})(window);
