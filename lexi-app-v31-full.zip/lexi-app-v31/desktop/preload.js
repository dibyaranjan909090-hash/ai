/* gives the robot page a few safe controls for its window (nothing else from the computer) */
const { contextBridge, ipcRenderer } = require('electron');
if (/[?&]desktop=1/.test(location.search)) {
  contextBridge.exposeInMainWorld('lexiDesktop', {
    moveBy: (dx, dy) => ipcRenderer.send('lexi:moveBy', Number(dx) || 0, Number(dy) || 0),
    moved: () => ipcRenderer.send('lexi:moved'),
    clickThrough: (on) => ipcRenderer.send('lexi:clickThrough', !!on),
    openFull: () => ipcRenderer.send('lexi:openFull'),
    hide: () => ipcRenderer.send('lexi:hide'),
    quit: () => ipcRenderer.send('lexi:quit'),
    micState: (on) => ipcRenderer.send('lexi:mic', !!on),
    setSize: (s) => ipcRenderer.send('lexi:setSize', String(s)),
    size: (new URLSearchParams(location.search).get('size') || 'small'),
    onSize: (cb) => ipcRenderer.on('lexi:size', (e, s) => { try { cb(String(s)); } catch (x) { } }),
    platform: process.platform
  });
}
