/* copies the Lexi web app (the folder above) into ./app so the desktop robot works offline-first */
const fs = require('fs'), path = require('path');
const from = path.join(__dirname, '..'), to = path.join(__dirname, 'app');
const SKIP = new Set(['desktop', 'android', 'server', 'training', 'node_modules', '.git', 'dist']);
if (!fs.existsSync(path.join(from, 'index.html'))) { console.log('Lexi web app not found next to this folder; using the existing app/ copy or config.json url.'); process.exit(0); }
fs.rmSync(to, { recursive: true, force: true });
(function copy(a, b) {
  fs.mkdirSync(b, { recursive: true });
  for (const n of fs.readdirSync(a)) {
    if (a === from && (SKIP.has(n) || /\.zip$/i.test(n))) continue;
    const s = path.join(a, n), d = path.join(b, n);
    if (fs.statSync(s).isDirectory()) copy(s, d); else fs.copyFileSync(s, d);
  }
})(from, to);
console.log('Copied Lexi into', to);
