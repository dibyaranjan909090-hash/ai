@echo off
rem Lexi Robot: double-click to start the floating robot (only the robot, mic button and type box float on your screen).
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto nonode
if exist "node_modules\electron\dist\electron.exe" goto run
echo First start: installing Electron. This needs internet and takes 1 to 2 minutes...
call npm install
if errorlevel 1 goto fail
:run
call node copy-app.js
start "" "node_modules\electron\dist\electron.exe" .
exit /b 0
:nonode
echo Node.js is not installed. Install the LTS version from https://nodejs.org and run this file again.
pause
exit /b 1
:fail
echo npm install failed. Check your internet connection and run this file again.
pause
exit /b 1
