# Lexi Robot — desktop floating robot (Windows, Mac, Linux)

Only Lexi's small robot sits on your screen, above every window, every website and every program, all the time.
You never open the full app to use Lexi. Opening or closing the full Lexi window does not touch the robot.

## v31: only the robot (transparent, nothing else)
The robot window has **no background and no frame**: only the robot, "Tap me to talk", the **Mic OFF / ⌨ / ⋯** buttons and the **Type to Lexi…** box with Send are drawn, floating above every program. The type box is open by default (⌨ hides it; Mini size hides it). Clicks on the empty area around it go to the program behind.
**Quickest start on Windows:** double-click **`START-LEXI-ROBOT.bat`** (needs Node.js; the first run installs Electron, about 1 to 2 minutes, then it starts in seconds).
A browser tab or pop-up can never be transparent, so use this app when you want the robot alone on the screen.

## It stays on screen (v29)
- **Always on top:** above browsers, Office, games in a window and full-screen apps; it comes back on top every 3 seconds
  if another program pushes it down, and after sleep, unlock or a screen change.
- **Cannot be closed by accident:** Alt+F4, close commands and Ctrl+Q do nothing; minimise brings it straight back.
  If its page ever crashes or freezes, it reloads itself; if its window is lost, a new one appears.
- **Starts with the computer** automatically (first run turns this on; switch it off in the tray menu).
- **Hide robot** only hides it (tray icon or `Ctrl+Shift+L` brings it back). The *only* way to stop Lexi is
  tray icon → **Quit Lexi…** → confirm. Shutting down or restarting the computer is never blocked.
- **Small size by default.** ⋯ → Size, or tray → Robot size: **Mini** (robot only, buttons on hover), **Small**, **Normal**, **Large**.
  The robot stays in its corner when you change size; tray → *Move robot to the corner* if it's ever off screen.

- **Tap the robot** → Lexi listens once, answers in a speech bubble and speaks.
- **🎙️ Mic ON / Mic OFF** (button under the robot) → ON = hands-free, Lexi keeps listening; OFF = Lexi stops listening.
- **⌨️** → type to Lexi. **⋯** (or long-press the robot) → Open full Lexi, Size, Hide robot.
- **Drag the robot** anywhere; it remembers the place.
- **Tray icon** (near the clock): show/hide robot, Mic on/off, Robot size, Move robot to the corner, Open full Lexi, Start Lexi with the computer, Quit.
- **Keys:** `Ctrl+Shift+L` show/hide robot · `Ctrl+Shift+M` mic on/off (`Cmd` on Mac).
- Voice commands: "mic off", "mic on", "open full Lexi".

## Voice needs the AI server
Desktop apps have no built-in speech recognition, so the robot records your question and the company AI server
(`server/lexi-ai-worker.js`, endpoint `/v1/transcribe`) turns it into text. Set it once for everyone:
1. Update the Worker on Cloudflare with the new `lexi-ai-worker.js` (paste, Deploy).
2. In the Worker's `ALLOWED_ORIGINS` add `lexi://app` (keep your website too, separated by a comma).
3. Put the server address in `lexi-config.json` (`"aiServer": "https://lexi-ai.<name>.workers.dev"`) **before** building,
   or open the robot's ⋯ → Open full Lexi → + → Training Center → AI server on each computer.
Without the server, a Gemini key in ⚙️ Settings also works for voice. Typing always works.

## Ready-made Windows app
`Lexi-Robot-Windows-x64.zip` → unzip to a folder that stays (e.g. `Documents\Lexi Robot`) → double-click **Lexi Robot.exe**.
Don't run it from inside the zip, and don't move the folder later (start-with-Windows points to it).
Windows may show "Windows protected your PC" because the app is not code-signed yet: click **More info → Run anyway**.
It starts with Windows by itself from then on (tray icon → **Start Lexi with the computer** to switch off).
The tray icon may be hidden under the **^** arrow near the clock — drag it onto the taskbar to keep it visible.

## Build it yourself (any computer with Node.js 20+)
```
cd desktop
npm install
npm start              # try it
npm run build:win      # Windows  -> dist/Lexi Robot-win32-x64
npm run build:mac      # Mac (build on a Mac) -> dist/Lexi Robot-darwin-universal
npm run build:linux    # Linux -> dist/lexi-robot-linux-x64
```
`npm start` / build copies the Lexi web app from the folder above into `desktop/app` first.
To always load your online Lexi instead of the built-in copy, put its address in `config.json` (`"url"`), then add that
site (it is already in `ALLOWED_ORIGINS`) — the robot then updates whenever the website updates.

## Notes
- Click-through: on Windows and Mac, clicks on the empty transparent area around the robot go to the window behind it.
- Mac: allow the microphone when asked (System Settings → Privacy & Security → Microphone → Lexi Robot).
  Unsigned Mac apps: right-click → Open the first time.
- The app only grants the microphone to Lexi's own pages, and links open in your normal browser.
