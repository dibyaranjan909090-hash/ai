/* Lexi Robot desktop app (v31: the robot window is transparent - only the robot, its Mic/keyboard/menu buttons and the type box are visible; nothing else): only Lexi's robot floats on the screen, above every window and every website.
   - Always on top, on every desktop/space, also over the taskbar and full-screen windows.
   - Independent: closing the full Lexi window, your browser or any other app never closes the robot.
     The robot window cannot be closed by accident (Alt+F4 / Cmd+W are ignored); it only stops with Quit in the tray.
   - Starts with the computer (on by default, can be turned off in the tray menu).
   - Comes back by itself if its page crashes or freezes, and keeps itself on top.
   - Sizes: Mini, Small (default), Normal, Large. Drag it anywhere; it remembers the place and size.
   - Tray icon: show/hide, mic on/off, size, open full Lexi, start with computer, quit.
   - Keys: Ctrl+Shift+L show/hide robot, Ctrl+Shift+M mic on/off (Cmd on Mac). */
const { app, BrowserWindow, Tray, Menu, ipcMain, globalShortcut, screen, session, shell, protocol, net, nativeImage, systemPreferences, dialog, powerMonitor } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), { pathToFileURL } = require('url');

const SIZES = { mini: [210, 250], small: [250, 330], normal: [300, 430], large: [350, 520] };
const SIZE_LABEL = { mini: 'Mini', small: 'Small', normal: 'Normal', large: 'Large' };
const APP_DIR = path.join(__dirname, 'app');
let cfg = {}; try { cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8')); } catch (e) { }
const STATE = () => path.join(app.getPath('userData'), 'state.json');
let state = {}; function loadState() { try { state = JSON.parse(fs.readFileSync(STATE(), 'utf8')); } catch (e) { state = {}; } }
function saveState() { try { fs.writeFileSync(STATE(), JSON.stringify(state)); } catch (e) { } }
function size() { return SIZES[state.size] ? state.size : 'small'; }
function dims() { return SIZES[size()]; }

/* never die on an unexpected error: log it and keep the robot running */
process.on('uncaughtException', (e) => { try { fs.appendFileSync(path.join(app.getPath('userData'), 'errors.log'), new Date().toISOString() + ' ' + (e && e.stack || e) + '\n'); } catch (x) { } });

/* the built-in copy of Lexi is served as lexi://app/ (a fixed address, so the AI server can allow it) */
protocol.registerSchemesAsPrivileged([{ scheme: 'lexi', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);
function base() {
  const u = String(cfg.url || '').trim();
  if (/^https?:\/\//.test(u)) return u.replace(/#.*$/, '');
  return 'lexi://app/index.html';
}
function withQuery(u, q) { return u + (u.includes('?') ? '&' : '?') + q; }

let robot = null, full = null, tray = null, mic = false, hiddenByUser = false;
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
app.on('second-instance', () => showRobot());

/* the robot stays above everything: "screen-saver" is the highest level (above the taskbar and full-screen windows) */
const LEVEL = process.platform === 'linux' ? undefined : 'screen-saver';
function keepOnTop() {
  if (!robot || robot.isDestroyed() || !robot.isVisible()) return;
  robot.setAlwaysOnTop(true, LEVEL);
  try { robot.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true, skipTransformProcessType: true }); } catch (e) { }
  if (process.platform === 'win32') robot.moveTop();
}
function onScreen(x, y, w, h) {
  return screen.getAllDisplays().some(d => { const b = d.workArea; return x + w * 0.5 >= b.x && x + w * 0.5 <= b.x + b.width && y + h * 0.5 >= b.y && y + h * 0.5 <= b.y + b.height; });
}
function corner() { const [w, h] = dims(), wa = screen.getPrimaryDisplay().workArea; return [wa.x + wa.width - w - 12, wa.y + wa.height - h - 8]; }

function createRobot() {
  const [W, H] = dims();
  let [x, y] = corner();
  if (state.pos && onScreen(state.pos[0], state.pos[1], W, H)) [x, y] = state.pos;
  robot = new BrowserWindow({
    width: W, height: H, x, y, frame: false, transparent: true, backgroundColor: '#00000000', resizable: false, maximizable: false, minimizable: false, fullscreenable: false,
    closable: false, alwaysOnTop: true, skipTaskbar: true, hasShadow: false, show: false, title: 'Lexi Robot', focusable: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
  });
  keepOnTop();
  robot.loadURL(withQuery(base(), 'mode=robot&desktop=1&size=' + size()));
  robot.once('ready-to-show', () => { if (!hiddenByUser) { robot.showInactive(); keepOnTop(); } });
  /* Alt+F4, Cmd+W or "close" from the taskbar: ignored. Only Quit (tray) ends Lexi */
  robot.on('close', (e) => { if (!app.isQuitting) e.preventDefault(); });
  robot.on('session-end', () => { app.isQuitting = true; });   /* Windows shutdown / log off */
  robot.on('blur', () => setTimeout(keepOnTop, 50));
  robot.on('always-on-top-changed', (e, top) => { if (!top) setTimeout(keepOnTop, 50); });
  robot.on('minimize', () => { robot.restore(); keepOnTop(); });
  robot.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:|^mailto:|^tel:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  robot.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('lexi://') && !(cfg.url && url.startsWith(new URL(base()).origin))) { e.preventDefault(); shell.openExternal(url); } });
  /* self-healing: a crashed or frozen robot page is reloaded */
  robot.webContents.on('render-process-gone', () => { setTimeout(() => { if (robot && !robot.isDestroyed()) robot.webContents.reload(); }, 1000); });
  robot.on('unresponsive', () => { setTimeout(() => { if (robot && !robot.isDestroyed()) robot.webContents.forcefullyCrashRenderer(); }, 8000); });
  robot.webContents.on('did-fail-load', (e, code, desc, url, mainFrame) => { if (mainFrame) setTimeout(() => { if (robot && !robot.isDestroyed()) robot.loadURL(withQuery(base(), 'mode=robot&desktop=1&size=' + size())); }, 5000); });
  robot.on('closed', () => { robot = null; if (!app.isQuitting) setTimeout(createRobot, 500); });
}
function showRobot() { hiddenByUser = false; if (!robot) createRobot(); else { robot.showInactive(); keepOnTop(); } menu(); }
function hideRobot() { hiddenByUser = true; if (robot) robot.hide(); menu(); if (tray && process.platform === 'win32') try { tray.displayBalloon({ title: 'Lexi is still here', content: 'Click the Lexi icon near the clock, or press Ctrl+Shift+L, to show the robot again.', iconType: 'info' }); } catch (e) { } }
function toggleRobot() { robot && robot.isVisible() ? hideRobot() : showRobot(); }
function setSize(s) {
  if (!SIZES[s]) return;
  const [ow, oh] = dims(); state.size = s; saveState(); const [w, h] = dims();
  if (robot) {
    const [x, y] = robot.getPosition();      /* keep the robot's feet where they were */
    robot.setResizable(true); robot.setBounds({ x: Math.round(x + ow - w), y: Math.round(y + oh - h), width: w, height: h }); robot.setResizable(false);
    state.pos = robot.getPosition(); saveState();
    robot.webContents.send('lexi:size', s);
  }
  menu();
}
function openFull() {
  if (full) { full.show(); full.focus(); return; }
  full = new BrowserWindow({ width: 440, height: 780, title: 'Lexi', icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true } });
  full.loadURL(withQuery(base(), 'mode=full'));
  full.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:|^mailto:|^tel:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  full.on('closed', () => { full = null; setTimeout(keepOnTop, 100); });   /* closing full Lexi never touches the robot */
}
function toggleMic() {
  if (!robot) createRobot();
  if (!robot.isVisible()) showRobot();
  robot.webContents.executeJavaScript('window.lexiRobot && window.lexiRobot.toggleMic()').catch(() => { });
}

/* start with the computer: on by default, the first time Lexi runs */
function linuxAutostart(on) {
  const dir = path.join(os.homedir(), '.config', 'autostart'), file = path.join(dir, 'lexi-robot.desktop');
  try {
    if (on) { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(file, '[Desktop Entry]\nType=Application\nName=Lexi Robot\nExec="' + process.execPath + '"' + (app.isPackaged ? '' : ' "' + app.getAppPath() + '"') + '\nX-GNOME-Autostart-enabled=true\n'); }
    else fs.rmSync(file, { force: true });
  } catch (e) { }
}
/* v31: when run with npm start (not packaged) the login item must also pass the app folder, or Windows would start a bare Electron window */
function loginOpts() { return app.isPackaged ? { path: process.execPath } : { path: process.execPath, args: [app.getAppPath()] }; }
function autostartOn() { return process.platform === 'linux' ? fs.existsSync(path.join(os.homedir(), '.config', 'autostart', 'lexi-robot.desktop')) : app.getLoginItemSettings(loginOpts()).openAtLogin; }
function setAutostart(on) { if (process.platform === 'linux') linuxAutostart(on); else app.setLoginItemSettings(Object.assign({ openAtLogin: !!on }, loginOpts())); state.autostart = !!on; saveState(); menu(); }

function quit() {
  const r = dialog.showMessageBoxSync({ type: 'question', buttons: ['Keep Lexi', 'Quit Lexi'], defaultId: 0, cancelId: 0, title: 'Quit Lexi?', message: 'Quit the Lexi robot?', detail: 'The robot will disappear until you open Lexi Robot again' + (autostartOn() ? ' or restart the computer.' : '.') });
  if (r !== 1) return;
  app.isQuitting = true;
  if (robot) robot.setClosable(true);
  app.quit();
}
function menu() {
  if (!tray) return;
  const s = size();
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: robot && robot.isVisible() ? 'Hide robot  (Ctrl+Shift+L)' : 'Show robot  (Ctrl+Shift+L)', click: toggleRobot },
    { label: mic ? 'Mic OFF  (Ctrl+Shift+M)' : 'Mic ON  (Ctrl+Shift+M)', click: toggleMic },
    { label: 'Robot size', submenu: Object.keys(SIZES).map(k => ({ label: SIZE_LABEL[k], type: 'radio', checked: k === s, click: () => setSize(k) })) },
    { label: 'Move robot to the corner', click: () => { if (!robot) return; const [x, y] = corner(); robot.setPosition(x, y); state.pos = [x, y]; saveState(); showRobot(); } },
    { label: 'Open full Lexi', click: openFull },
    { type: 'separator' },
    { label: 'Start Lexi with the computer', type: 'checkbox', checked: autostartOn(), click: (i) => setAutostart(i.checked) },
    { type: 'separator' },
    { label: 'Quit Lexi…', click: quit }
  ]));
  tray.setToolTip('Lexi Robot — click to show or hide');
}

/* messages from the robot page (preload.js) */
ipcMain.on('lexi:moveBy', (e, dx, dy) => { const w = BrowserWindow.fromWebContents(e.sender); if (!w) return; const [x, y] = w.getPosition(); w.setPosition(Math.round(x + dx), Math.round(y + dy)); });
ipcMain.on('lexi:moved', (e) => { const w = BrowserWindow.fromWebContents(e.sender); if (w === robot) { state.pos = w.getPosition(); saveState(); } });
ipcMain.on('lexi:clickThrough', (e, on) => { const w = BrowserWindow.fromWebContents(e.sender); if (w && process.platform !== 'linux') w.setIgnoreMouseEvents(!!on, { forward: true }); });
ipcMain.on('lexi:openFull', openFull);
ipcMain.on('lexi:hide', hideRobot);
ipcMain.on('lexi:quit', quit);
ipcMain.on('lexi:mic', (e, on) => { mic = !!on; menu(); });
ipcMain.on('lexi:setSize', (e, s) => setSize(String(s)));

app.whenReady().then(async () => {
  if (!gotLock) return;
  loadState();
  if (state.autostart === undefined) setAutostart(true);   /* first run: start with the computer */
  protocol.handle('lexi', (req) => {
    const u = new URL(req.url);
    let p = decodeURIComponent(u.pathname); if (p === '/' || !p) p = '/index.html';
    const file = path.normalize(path.join(APP_DIR, p));
    if (!file.startsWith(APP_DIR)) return new Response('Not found', { status: 404 });
    return net.fetch(pathToFileURL(file).toString());
  });
  /* microphone for the robot (only for Lexi's own pages) */
  const allowed = (wc) => { try { const u = new URL(wc.getURL()); return u.protocol === 'lexi:' || (cfg.url && u.origin === new URL(base()).origin); } catch (e) { return false; } };
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(allowed(wc) && ['media', 'notifications', 'clipboard-sanitized-write', 'geolocation'].includes(perm)));
  session.defaultSession.setPermissionCheckHandler((wc, perm) => !!wc && allowed(wc) && ['media', 'notifications', 'clipboard-sanitized-write', 'geolocation'].includes(perm));
  if (process.platform === 'darwin') { try { await systemPreferences.askForMediaAccess('microphone'); } catch (e) { } if (app.dock) app.dock.hide(); }

  powerMonitor.on('shutdown', () => { app.isQuitting = true; });
  /* no Cmd+Q / Ctrl+Q shortcut that could close the robot by accident (Edit menu kept for copy and paste) */
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    ...(process.platform === 'darwin' ? [{ label: 'Lexi', submenu: [{ label: 'Hide robot', click: hideRobot }, { label: 'Open full Lexi', click: openFull }, { type: 'separator' }, { label: 'Quit Lexi…', click: quit }] }] : []),
    { role: 'editMenu' }
  ]));
  createRobot();
  const img = nativeImage.createFromPath(path.join(__dirname, 'icon.png')).resize({ width: 18, height: 18 });
  tray = new Tray(img);
  tray.on('click', toggleRobot);
  menu();
  const mod = process.platform === 'darwin' ? 'Command' : 'Control';
  globalShortcut.register(mod + '+Shift+L', toggleRobot);
  globalShortcut.register(mod + '+Shift+M', toggleMic);
  /* stay on top and on screen: re-check every few seconds, after screens change and after the computer wakes up */
  setInterval(() => { if (robot && !robot.isDestroyed() && robot.isVisible() && !robot.isAlwaysOnTop()) keepOnTop(); }, 3000);
  const recheck = () => { if (!robot || robot.isDestroyed()) return; const [x, y] = robot.getPosition(), [w, h] = dims(); if (!onScreen(x, y, w, h)) { const c = corner(); robot.setPosition(c[0], c[1]); } keepOnTop(); };
  screen.on('display-removed', recheck); screen.on('display-metrics-changed', recheck);
  powerMonitor.on('resume', () => setTimeout(() => { if (robot && !robot.isDestroyed()) robot.webContents.reload(); recheck(); }, 2000));
  powerMonitor.on('unlock-screen', () => setTimeout(recheck, 1000));
});
app.on('window-all-closed', () => { /* keep running in the tray */ });
/* shutting down, restarting or logging off the computer must never be blocked */
app.on('before-quit', () => { app.isQuitting = true; if (robot && !robot.isDestroyed()) robot.setClosable(true); });
app.on('will-quit', () => globalShortcut.unregisterAll());
