/* Lexi tasks.js
   Smart alarms and reminders, contact book, calling, WhatsApp / SMS / email,
   location sharing, expenses, shopping list, stopwatch and daily summary.
   Loaded after plus.js. The first half is pure logic (testable in Node),
   the second half wires it into the page. */
(function (root) {
'use strict';

/* ======================= PURE LOGIC ======================= */
var DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
var MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
var MON_RE = 'january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sept|sep|oct|nov|dec';
var NUMW = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, fifteen: 15, twenty: 20, thirty: 30, forty: 40, 'forty five': 45, 'half a': 0.5, 'half an': 0.5 };
var ALIAS = [
  ['mom', 'mummy', 'mother', 'amma', 'mama', 'mommy', 'maa'],
  ['dad', 'papa', 'father', 'appa', 'daddy', 'pappa'],
  ['brother', 'bro', 'anna', 'bhai'],
  ['sister', 'sis', 'akka', 'didi'],
  ['wife', 'wifey'], ['husband', 'hubby'],
  ['grandma', 'granny', 'ajji', 'nani', 'dadi'], ['grandpa', 'thatha', 'dada', 'nana', 'ajja']
];

function pad(n) { return ('0' + n).slice(-2); }
function lev(a, b) {
  var d = [], i, j;
  for (i = 0; i <= a.length; i++) d[i] = [i];
  for (j = 1; j <= b.length; j++) d[0][j] = j;
  for (i = 1; i <= a.length; i++) for (j = 1; j <= b.length; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}
function norm(s) { return String(s || '').toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, ' ').replace(/\s+/g, ' ').trim(); }
function digits(s) { return String(s || '').replace(/\D/g, ''); }
function titleCase(s) { return String(s).replace(/\b\p{L}/gu, function (c) { return c.toUpperCase(); }); }
function capFirst(s) { s = String(s || '').trim(); return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

/* ---------- phone numbers ---------- */
function normNum(s, cc) {
  cc = digits(cc || '91');
  var p = String(s || '').replace(/[^\d+]/g, '');
  if (!p) return '';
  if (p.slice(0, 2) === '00') p = '+' + p.slice(2);
  if (p.charAt(0) === '+') return p;
  if (p.length === 10) return '+' + cc + p;
  if (p.length === 11 && p.charAt(0) === '0') return '+' + cc + p.slice(1);
  if (p.length === cc.length + 10 && p.slice(0, cc.length) === cc) return '+' + p;
  return p;
}
function fmtNum(p) {
  var m = String(p).match(/^\+91(\d{5})(\d{5})$/);
  return m ? '+91 ' + m[1] + ' ' + m[2] : p;
}
/* leading number in a string: "98765 43210 hello" -> {num, rest} */
function takeNumber(str) {
  var tk = String(str).trim().split(/\s+/), acc = '', i = 0, want;
  if (!tk[0] || !/^[+\d][\d-]*$/.test(tk[0])) return null;
  for (; i < tk.length; i++) {
    if (!/^[+\d-]+$/.test(tk[i])) break;
    acc += tk[i];
    var dg = digits(acc).length;
    want = acc.charAt(0) === '+' ? 13 : acc.slice(0, 2) === '00' ? 14 : acc.charAt(0) === '0' ? 11 : acc.slice(0, 2) === '91' && dg > 10 ? 12 : 10;
    if (dg >= want) { i++; break; }
  }
  if (digits(acc).length < 7) return null;
  return { num: acc.replace(/-/g, ''), rest: tk.slice(i).join(' ') };
}

/* ---------- contact search ---------- */
function aliasGroup(w) { for (var i = 0; i < ALIAS.length; i++) if (ALIAS[i].indexOf(w) >= 0) return i; return -1; }
function scoreContact(c, qn, qt, qd) {
  var nn = norm(c.n), nt = nn.split(' '), s = 0;
  if (!nn) return 0;
  if (nn === qn) return 100;
  if (nn.indexOf(qn) === 0) s = 85;
  else if (qt.every(function (t) { return nt.some(function (x) { return x.indexOf(t) === 0; }); })) s = 75;
  else if (nn.indexOf(qn) >= 0) s = 55;
  if (s < 70) {
    var g = aliasGroup(qn);
    if (g >= 0 && nt.some(function (x) { return aliasGroup(x) === g; })) s = Math.max(s, 70);
  }
  if (!s) {
    var ok = qt.every(function (t) { return t.length >= 3 && nt.some(function (x) { return lev(t, x) <= (t.length <= 4 ? 1 : 2); }); });
    if (ok) s = 45;
  }
  if (!s && qd.length >= 4 && digits(c.p).indexOf(qd) >= 0) s = 60;
  return s;
}
function findContacts(query, book) {
  var qn = norm(query).replace(/^(?:my|the)\s+/, '');
  if (!qn) return [];
  var qt = qn.split(' '), qd = /^\d[\d\s]*$/.test(qn) ? digits(qn) : '', out = [], seen = {};
  (book || []).forEach(function (c) {
    var sc = scoreContact(c, qn, qt, qd);
    if (sc >= 45) out.push({ c: c, score: sc });
  });
  out.sort(function (a, b) { return b.score - a.score || a.c.n.length - b.c.n.length; });
  return out.filter(function (x) { var k = digits(x.c.p) + '|' + norm(x.c.n); if (seen[k]) return false; seen[k] = 1; return true; });
}
/* best answer: one contact, or several if it is unclear */
function resolve(query, book) {
  var l = findContacts(query, book);
  if (!l.length) return [];
  var top = l[0].score;
  if (top >= 100) return [l[0].c];
  var close = l.filter(function (x) { return x.score >= top - 10; });
  if (top >= 85 && close.length === 1) return [l[0].c];
  var names = {};
  close.forEach(function (x) { names[norm(x.c.n)] = 1; });
  if (close.length > 1 && Object.keys(names).length === 1) return [close[0].c]; /* same person, several numbers: use first */
  return close.slice(0, 5).map(function (x) { return x.c; });
}

/* "mom hello", "john smith saying hi", "98765 43210 on my way" -> {name|num, msg} */
function cleanMsg(m) {
  return capFirst(String(m || '').replace(/^(?:saying|says|say that|say|that says|that|:)\s+/, '').replace(/\s+on whats\s?app$/, '').trim());
}
function splitNameMsg(rest, book) {
  rest = String(rest || '').trim().replace(/^to\s+/, '');
  var n = takeNumber(rest), m, words, k, cand, r;
  if (n) return { num: n.num, msg: cleanMsg(n.rest) };
  m = rest.match(/^(.+?)\s+(?:saying|says|say that|say|that says|with message|with text|message is|that)\s+(.*)$/) || rest.match(/^(.+?)\s*:\s*(.*)$/);
  if (m && m[1].split(' ').length <= 4) return { name: m[1].trim(), msg: cleanMsg(m[2]) };
  words = rest.split(/\s+/);
  for (k = Math.min(words.length, 4); k >= 1; k--) {
    cand = words.slice(0, k).join(' ');
    r = findContacts(cand, book);
    if (r.length && r[0].score >= (k === 1 ? 45 : 70)) return { name: cand, msg: cleanMsg(words.slice(k).join(' ')) };
  }
  return { name: words[0] || '', msg: cleanMsg(words.slice(1).join(' ')) };
}

/* ---------- vCard / CSV import ---------- */
function parseVCF(text) {
  var out = [], cards = String(text).replace(/\r/g, '').replace(/\n[ \t]/g, '').split(/BEGIN:VCARD/i).slice(1);
  cards.forEach(function (card) {
    var fn = '', tels = [];
    card.split('\n').forEach(function (ln) {
      var i = ln.indexOf(':'); if (i < 0) return;
      var key = ln.slice(0, i).toUpperCase(), val = ln.slice(i + 1).trim();
      if (/^FN(;|$)/.test(key)) fn = val;
      else if (/^N(;|$)/.test(key) && !fn) fn = val.split(';').filter(Boolean).reverse().join(' ');
      else if (/^(?:ITEM\d+\.)?TEL/.test(key)) tels.push(val);
    });
    tels.forEach(function (t) { if (digits(t).length >= 6 && fn) out.push({ n: fn.trim(), p: t }); });
  });
  return out;
}
function parseCSV(text) {
  var out = [];
  String(text).replace(/\r/g, '').split('\n').forEach(function (ln) {
    if (!ln.trim()) return;
    var f = [], cur = '', q = false, i, ch;
    for (i = 0; i < ln.length; i++) {
      ch = ln[i];
      if (ch === '"') q = !q; else if (ch === ',' && !q) { f.push(cur); cur = ''; } else cur += ch;
    }
    f.push(cur);
    var pi = -1;
    for (i = 0; i < f.length; i++) if (/^\s*\+?[\d][\d\s()-]{5,}\s*$/.test(f[i])) { pi = i; break; }
    if (pi < 0) return;
    var nm = f.slice(0, pi).map(function (x) { return x.trim(); }).filter(function (x) { return x && /\p{L}/u.test(x); }).slice(0, 3).join(' ');
    if (!nm) nm = f.filter(function (x, j) { return j !== pi && /\p{L}/u.test(x); }).slice(0, 2).join(' ').trim();
    if (nm) out.push({ n: nm, p: f[pi].trim() });
  });
  return out;
}

/* ---------- date and time understanding ---------- */
function wordNum(s) { return NUMW[s] !== undefined ? NUMW[s] : parseFloat(s); }
function parseWhen(input, kind, now) {
  now = now || new Date(); kind = kind || 'remind';
  var r = ' ' + String(input).toLowerCase() + ' ', m, dayOff = null, wd = null, nextFlag = false, dt = null, pod = '', h = null, mi = 0, ap = '', hasTime = false;
  var wakeish = kind === 'alarm' && /\bwake\b|\bevery\s*day\b|\beveryday\b|\bdaily\b|\bweekdays?\b/.test(r);
  r = r.replace(/\ba\.?\s?m\.?(?=\W|$)/g, 'am').replace(/\bp\.?\s?m\.?(?=\W|$)/g, 'pm');
  function cut(x) { r = r.replace(x, ' '); }

  m = r.match(/\b(?:in|after|for)\s+(half an?|an?|\d+(?:\.\d+)?|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty five|forty)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|days?)\b(?:\s+(?:and\s+)?(\d+|half|a quarter)(?:\s*(?:minutes?|mins?))?)?/);
  if (m) {
    var n = wordNum(m[1]), u = m[2].charAt(0);
    if (u === 'd') { dayOff = Math.round(n); cut(m[0]); }
    else {
      var ms = n * (u === 's' ? 1000 : u === 'm' ? 60000 : 3600000);
      if (m[3] && u === 'h') ms += (m[3] === 'half' ? 30 : m[3] === 'a quarter' ? 15 : +m[3]) * 60000;
      cut(m[0]);
      return { t: new Date(now.getTime() + ms), rel: true, hasTime: true, hasDate: false, rest: r.replace(/\s+/g, ' ').trim() };
    }
  }
  if (/\bday after tomorrow\b/.test(r)) { dayOff = 2; cut(/\bday after tomorrow\b/); }
  else if (/\b(?:tomorrow|tmrw|tomorow|tommorow)\b/.test(r)) { dayOff = 1; cut(/\b(?:tomorrow|tmrw|tomorow|tommorow)\b/); }
  else if (/\btonight\b/.test(r)) { dayOff = 0; pod = 'night'; cut(/\btonight\b/); }
  else if (/\btoday\b/.test(r)) { dayOff = 0; cut(/\btoday\b/); }

  m = r.match(new RegExp('\\b(?:(next|this|on)\\s+)?(' + DAYS.join('|') + ')\\b'));
  if (m) { wd = DAYS.indexOf(m[2]); nextFlag = m[1] === 'next'; cut(m[0]); }

  m = r.match(new RegExp('\\b(?:on\\s+)?(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?(' + MON_RE + ')\\b')) || null;
  if (m) { dt = { d: +m[1], mo: monthIdx(m[2]) }; cut(m[0]); }
  else {
    m = r.match(new RegExp('\\b(?:on\\s+)?(' + MON_RE + ')\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b'));
    if (m) { dt = { d: +m[2], mo: monthIdx(m[1]) }; cut(m[0]); }
  }

  m = r.match(/\b(?:in the |at )?(morning|afternoon|evening|night)\b/);
  if (m) { pod = pod || m[1]; cut(m[0]); }

  if ((m = r.match(/\b(?:at\s+)?(\d{1,2})\s*[:.]\s*(\d{2})\s*(am|pm)?(?![\d])/))) { h = +m[1]; mi = +m[2]; ap = m[3] || ''; }
  else if ((m = r.match(/\b(?:at\s+)?(\d{1,2})\s+(\d{2})\s*(am|pm)\b/))) { h = +m[1]; mi = +m[2]; ap = m[3]; }
  else if ((m = r.match(/\b(?:at\s+)?(\d{1,2})\s*(am|pm)\b/))) { h = +m[1]; ap = m[2]; }
  else if ((m = r.match(/\b(?:at|for|by|around)\s+(\d{1,2})(?:\s*o'?\s?clock)?(?!\s*(?:min|hour|sec|day|\d))\b/))) { h = +m[1]; }
  else if ((m = r.match(/\b(\d{1,2})\s*o'?\s?clock\b/))) { h = +m[1]; }
  else if (kind === 'alarm' && (m = r.match(/\b(?:alarm|up)\s+(\d{1,2})\b(?!\s*(?:min|hour|sec|day))/))) { h = +m[1]; m = [m[0].replace(/\d{1,2}.*/, '') + m[1]]; }
  else if ((m = r.match(/\b(noon|midday|midnight)\b/))) { h = m[1] === 'midnight' ? 0 : 12; ap = 'x'; }
  if (h !== null) {
    if (h > 24 || mi > 59 || (ap !== 'x' && ap && h > 12)) { h = null; mi = 0; ap = ''; }
    else { hasTime = true; cut(m[0]); }
  }

  var hasDate = dayOff !== null || wd !== null || !!dt;
  if (!hasTime && !hasDate && !pod) return null;

  var hh;
  if (!hasTime) {
    hh = { morning: 9, afternoon: 14, evening: 18, night: 21 }[pod];
    if (kind === 'alarm' && !pod) return { t: null, needTime: true, hasDate: hasDate, rest: r.replace(/\s+/g, ' ').trim() };
    if (hh === undefined) hh = kind === 'alarm' ? 8 : 9;
    mi = 0;
  } else if (ap === 'x') hh = h;
  else if (ap === 'pm') hh = h < 12 ? h + 12 : h;
  else if (ap === 'am') hh = h === 12 ? 0 : h;
  else if (h > 12 || h === 0) hh = h % 24;
  else if (pod === 'morning') hh = h === 12 ? 0 : h;
  else if (pod === 'afternoon' || pod === 'evening') hh = h < 12 ? h + 12 : h;
  else if (pod === 'night') hh = h === 12 ? 0 : h >= 6 ? h + 12 : h;
  else if (wakeish && h >= 1 && h <= 11) hh = h; /* wake-up and daily alarms default to morning */
  else hh = null; /* ambiguous, decided below */

  var base = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  if (dt) { base = new Date(now.getFullYear(), dt.mo, dt.d); }
  else if (dayOff !== null) base.setDate(base.getDate() + dayOff);
  else if (wd !== null) { var diff = (wd - now.getDay() + 7) % 7; if (nextFlag && diff === 0) diff = 7; base.setDate(base.getDate() + diff); }
  var explicitDay = dt || (dayOff !== null && dayOff > 0) || wd !== null;

  function at(H) { var x = new Date(base.getTime()); x.setHours(H, mi, 0, 0); return x; }
  var t;
  if (hh === null) {
    if (explicitDay) hh = kind === 'alarm' ? (h === 12 ? 12 : h) : (h === 12 ? 12 : h <= 6 ? h + 12 : h);
    else {
      var c1 = at(h % 12), c2 = at((h % 12) + 12);
      t = c1 > now ? c1 : c2 > now ? c2 : at(h % 12);
      if (t <= now) { t = new Date(t.getTime()); t.setDate(t.getDate() + 1); }
      return { t: t, rel: false, hasTime: true, hasDate: hasDate, rest: r.replace(/\s+/g, ' ').trim() };
    }
  }
  t = at(hh);
  if (t <= now) {
    if (dt) t.setFullYear(t.getFullYear() + 1);
    else if (wd !== null) t.setDate(t.getDate() + 7);
    else if (dayOff === null || (dayOff === 0 && hasTime && kind === 'alarm')) t.setDate(t.getDate() + 1);
  }
  return { t: t, rel: false, hasTime: hasTime, hasDate: hasDate, rest: r.replace(/\s+/g, ' ').trim() };
}
function monthIdx(s) { for (var i = 0; i < 12; i++) if (MONTHS[i].indexOf(s.slice(0, 3)) === 0) return i; return 0; }

function repeatSpec(c) {
  if (/\b(?:every\s?day|daily|everyday|each day|every morning|every night|every evening)\b/.test(c)) return { days: [0, 1, 2, 3, 4, 5, 6], label: 'Every day' };
  if (/\bweekdays?\b|\bevery weekday\b|\bmonday to friday\b/.test(c)) return { days: [1, 2, 3, 4, 5], label: 'Weekdays' };
  if (/\bweekends?\b/.test(c)) return { days: [0, 6], label: 'Weekends' };
  var m = c.match(new RegExp('\\bevery\\s+(' + DAYS.join('|') + ')\\b'));
  if (m) return { days: [DAYS.indexOf(m[1])], label: 'Every ' + capFirst(m[1]) };
  return null;
}
function fmtTime(d) { return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); }
function fmtWhen(d, now) {
  now = now || new Date();
  var a = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime(), b = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(), diff = Math.round((b - a) / 864e5);
  var day = diff === 0 ? 'today' : diff === 1 ? 'tomorrow' : d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
  return day + ' at ' + fmtTime(d);
}
function icsDate(d) { return d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + 'T' + pad(d.getHours()) + pad(d.getMinutes()) + '00'; }
function makeICS(label, d, rep) {
  var end = new Date(d.getTime() + 15 * 60000), L = String(label).replace(/[\r\n,;]/g, ' ');
  var days = rep ? rep.days.map(function (x) { return ['SU', 'MO', 'TU', 'WE', 'TH', 'FR', 'SA'][x]; }).join(',') : '';
  return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Lexi//Alarm//EN', 'BEGIN:VEVENT',
    'UID:' + d.getTime() + '-' + Math.floor(Math.random() * 1e6) + '@lexi', 'DTSTAMP:' + icsDate(new Date()),
    'DTSTART:' + icsDate(d), 'DTEND:' + icsDate(end), 'SUMMARY:' + L].concat(rep ? ['RRULE:FREQ=WEEKLY;BYDAY=' + days] : [],
    ['BEGIN:VALARM', 'TRIGGER:PT0S', 'ACTION:DISPLAY', 'DESCRIPTION:' + L, 'END:VALARM', 'END:VEVENT', 'END:VCALENDAR']).join('\r\n');
}
/* label for alarms and reminders: remove command words */
function alarmLabel(rest) {
  var t = ' ' + rest + ' ';
  t = t.replace(/\bevery\s*(?:day|morning|night|evening|weekday|weekend|sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/g, ' ').replace(/\b(?:each day|everyday|monday to friday)\b/g, ' ');
  t = t.replace(/\b(?:set|make|create|add|put|an?|the|my|alarms?|for|at|on|me|up|wake|please|to|called|named|label|with|of|and|every|daily|everyday|weekdays?|weekends?|i|want|need|by|around|in|from|that|it)\b/g, ' ');
  t = t.replace(/\s+/g, ' ').trim();
  return t;
}
function remindText(rest) {
  var t = String(rest).replace(/\s+/g, ' ').trim();
  t = t.replace(/^(?:me\s+)?(?:to|about|that|for)\s+/, '').replace(/\s+(?:at|on|in|for|by|of|to)$/, '').replace(/^(?:at|on|in|by)\s+/, '');
  return t.trim();
}

root.JTCORE = {
  parseWhen: parseWhen, findContacts: findContacts, resolve: resolve, splitNameMsg: splitNameMsg, takeNumber: takeNumber,
  normNum: normNum, fmtNum: fmtNum, parseVCF: parseVCF, parseCSV: parseCSV, repeatSpec: repeatSpec, makeICS: makeICS,
  alarmLabel: alarmLabel, remindText: remindText, fmtWhen: fmtWhen, fmtTime: fmtTime, norm: norm, capFirst: capFirst, titleCase: titleCase, digits: digits
};
if (typeof document === 'undefined' || typeof window === 'undefined' || typeof add !== 'function') return;

/* ======================= PAGE INTEGRATION ======================= */
var K = root.JTCORE;
function ld(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
function sk(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { alert('Storage is full. Remove some contacts or files.'); } }
var BOOK = ld('vabook', []), TS = ld('vatasks', { cc: '91' });
function saveBook() { sk('vabook', BOOK); }
function saveTS() { sk('vatasks', TS); }
S.rep = S.rep || []; S.exp = S.exp || []; S.shop = S.shop || [];
(function mergeLegacy() {
  Object.keys(S.contacts || {}).forEach(function (k) {
    if (!BOOK.some(function (c) { return K.norm(c.n) === K.norm(k); })) BOOK.push({ n: K.titleCase(k), p: K.normNum(S.contacts[k], TS.cc) });
  });
  saveBook();
})();

function addContact(n, p) {
  p = K.normNum(p, TS.cc);
  if (!n || K.digits(p).length < 6) return false;
  var dup = BOOK.some(function (c) { return K.digits(c.p) === K.digits(p) && K.norm(c.n) === K.norm(n); });
  if (!dup) BOOK.push({ n: n.trim(), p: p });
  return !dup;
}
function addMany(list) {
  var n = 0;
  list.forEach(function (x) { if (addContact(x.n, x.p)) n++; });
  saveBook();
  return n;
}
function mk(tag, props, kids) {
  var e = document.createElement(tag), k;
  for (k in (props || {})) { if (k === 'text') e.textContent = props[k]; else if (k === 'html') e.innerHTML = props[k]; else e.setAttribute(k, props[k]); }
  (kids || []).forEach(function (c) { e.appendChild(c); });
  return e;
}
function btn(label, fn, cls) {
  var b = mk('button', { 'class': cls || 'c', type: 'button', text: label });
  b.style.margin = '4px 6px 0 0';
  b.onclick = fn;
  return b;
}
function card(html) { return add(html, 'a'); }
function scroll() { log.scrollTop = log.scrollHeight; }
function happy() { try { mood('happy', 1600); } catch (e) { } }
function sad() { try { mood('sad', 2200); } catch (e) { } }
function say(t) { try { speak(t); } catch (e) { } }
var pickerOK = !!(navigator.contacts && navigator.contacts.select && window.ContactsManager);

/* ---------- contact actions ---------- */
function openURL(u) {
  var w = null;
  try { w = window.open(u, '_blank'); } catch (e) { }
  return !!w;
}
function chooseContact(list, label, cb) {
  var m = card('Which one do you mean?<br>');
  list.forEach(function (c) {
    m.appendChild(btn(c.n + ' · ' + K.fmtNum(c.p), function () { m.querySelectorAll('button').forEach(function (b) { b.disabled = true; }); cb(c); }));
  });
  say('Which one do you mean? ' + list.map(function (c) { return c.n; }).join(', '));
  scroll();
}
function importFromPhone(after) {
  navigator.contacts.select(['name', 'tel'], { multiple: true }).then(function (res) {
    var arr = [];
    res.forEach(function (r) { var nm = (r.name && r.name[0]) || ''; (r.tel || []).forEach(function (t) { arr.push({ n: nm, p: t }); }); });
    var n = addMany(arr);
    reply('✅ Added <b>' + n + '</b> contact' + (n === 1 ? '' : 's') + ' from your phone. Total saved: ' + BOOK.length + '.', null, n + ' contacts added.');
    happy(); if (after) after(arr);
  }).catch(function () { reply('Contact access was cancelled. Nothing was imported.'); });
}
var fileIn = mk('input', { type: 'file', accept: '.vcf,.csv,text/vcard,text/csv,text/x-vcard,text/plain', multiple: 'multiple', style: 'display:none' });
document.body.appendChild(fileIn);
var fileAfter = null;
fileIn.onchange = function () {
  var files = Array.prototype.slice.call(fileIn.files), total = 0, done = 0;
  fileIn.value = '';
  files.forEach(function (f) {
    var r = new FileReader();
    r.onload = function () {
      var t = String(r.result), list = /BEGIN:VCARD/i.test(t) ? K.parseVCF(t) : K.parseCSV(t);
      total += addMany(list);
      if (++done === files.length) {
        reply(total ? '✅ Imported <b>' + total + '</b> contacts from your file. Total saved: ' + BOOK.length + '.' : 'I could not find any contacts in that file. Use a .vcf or .csv export.', null, total ? total + ' contacts imported.' : 'No contacts found in that file.');
        total ? happy() : sad();
        if (fileAfter) { var f2 = fileAfter; fileAfter = null; f2(); }
      }
    };
    r.readAsText(f);
  });
};
function importOptions(title, after) {
  var m = card(title || 'Import your contacts so I can find people by name:');
  m.appendChild(document.createElement('br'));
  if (pickerOK) m.appendChild(btn('📱 Choose from my phone', function () { importFromPhone(after); }));
  m.appendChild(btn('📂 Import .vcf / .csv file', function () { fileAfter = after ? function () { after(); } : null; fileIn.click(); }));
  m.appendChild(btn('📇 Open contact book', openBook));
  if (!pickerOK) {
    var h = mk('small', { html: '<br>Your browser cannot read the phone contact list directly (only Android Chrome can). On iPhone: export contacts as a .vcf file (iCloud.com → Contacts → Select all → Export vCard) and import it here once.' });
    m.appendChild(h);
  }
  scroll();
}
/* resolve a spoken target to a contact and call cb(contact) */
function withContact(target, purpose, cb, extra) {
  target = String(target || '').trim().replace(/^(?:my|the)\s+/, '');
  if (!target) return reply('Who do you mean? Say a name or number.');
  var n = K.takeNumber(target);
  if (n && !n.rest) return cb({ n: '', p: K.normNum(n.num, TS.cc) });
  var list = K.resolve(target, BOOK);
  if (list.length === 1) return cb(list[0]);
  if (list.length > 1) return chooseContact(list, target, cb);
  notFound(target, purpose, cb, extra);
}
function notFound(target, purpose, cb, extra) {
  var m = card('I could not find <b>' + esc(target) + '</b> in your saved contacts' + (BOOK.length ? ' (' + BOOK.length + ' saved).' : '. Your contact book is empty.'));
  say('I could not find ' + target + ' in your contacts.');
  m.appendChild(document.createElement('br'));
  if (pickerOK) m.appendChild(btn('📱 Pick ' + target + ' from my phone', function () {
    navigator.contacts.select(['name', 'tel'], { multiple: false }).then(function (res) {
      if (!res.length || !res[0].tel || !res[0].tel.length) return;
      var nm = (res[0].name && res[0].name[0]) || target, p = res[0].tel[0];
      addContact(nm, p); if (K.norm(nm) !== K.norm(target)) addContact(target, p); saveBook();
      cb({ n: nm, p: K.normNum(p, TS.cc) });
    }).catch(function () { });
  }));
  var inp2 = mk('input', { 'class': 'k', placeholder: 'Or type ' + target + '’s number', inputmode: 'tel' });
  var row = mk('div');
  row.appendChild(inp2);
  row.appendChild(btn('Save & continue', function () {
    var p = K.normNum(inp2.value, TS.cc);
    if (K.digits(p).length < 7) { inp2.focus(); return; }
    addContact(K.titleCase(target), p); saveBook();
    cb({ n: K.titleCase(target), p: p });
  }));
  m.appendChild(row);
  if (purpose === 'wa') m.appendChild(btn('💬 Open WhatsApp and choose contact', function () { openURL('https://wa.me/' + (extra && extra.msg ? '?text=' + encodeURIComponent(extra.msg) : '')); }));
  if (purpose === 'call') m.appendChild(btn('📞 Open phone dialer', function () { location.href = 'tel:'; }));
  m.appendChild(btn('📂 Import contacts file', function () { fileAfter = null; fileIn.click(); }));
  scroll();
}
function who(c) { return c.n ? c.n : K.fmtNum(c.p); }
function doCall(c) {
  var p = K.normNum(c.p, TS.cc), url = 'tel:' + p;
  var m = card('📞 Calling <b>' + esc(who(c)) + '</b>' + (c.n ? ' <small>' + esc(K.fmtNum(p)) + '</small>' : '') + '<br>');
  var cb2 = btn('📞 Call now', function () { location.href = url; }, 'c');
  cb2.style.cssText = 'margin:6px 0 0;padding:12px 24px;font-size:16px;font-weight:650;border:0;border-radius:26px;background:linear-gradient(135deg,var(--a),var(--b));color:#fff;cursor:pointer';
  m.appendChild(cb2);
  say('Calling ' + who(c));
  happy(); scroll();
  setTimeout(function () { location.href = url; }, 350);
}
function smsURL(p, msg) { return 'sms:' + p + (plat() === 'ios' ? '&' : '?') + 'body=' + encodeURIComponent(msg || ''); }
function doMessage(c, msg, channel) {
  var p = K.normNum(c.p, TS.cc), wa = channel !== 'sms';
  function url(t) { return wa ? 'https://wa.me/' + K.digits(p) + '?text=' + encodeURIComponent(t) : smsURL(p, t); }
  var cur = msg;
  var m = card((wa ? '💬 WhatsApp to <b>' : '✉️ SMS to <b>') + esc(who(c)) + '</b>' + (c.n ? ' <small>' + esc(K.fmtNum(p)) + '</small>' : '') + '<div class="mp" style="margin:8px 0;padding:10px 12px;border-radius:14px;background:' + (wa ? 'rgba(34,211,197,.18)' : 'rgba(124,108,240,.18)') + ';display:inline-block;max-width:100%"></div><br>');
  var bub = m.querySelector('.mp');
  bub.textContent = cur;
  var gb = btn(wa ? '💬 Open WhatsApp & send' : '✉️ Open Messages', function () { go(); });
  gb.style.cssText = 'margin:6px 8px 0 0;padding:12px 22px;font-size:16px;font-weight:650;border:0;border-radius:26px;background:linear-gradient(135deg,var(--a),var(--b));color:#fff;cursor:pointer';
  m.appendChild(gb);
  m.appendChild(btn('✏️ Edit', function () {
    var i = mk('input', { 'class': 'k', value: cur });
    var r = mk('div'); r.appendChild(i);
    r.appendChild(btn('Update', function () { cur = i.value.trim() || cur; bub.textContent = cur; r.remove(); }));
    m.appendChild(r); i.focus();
  }));
  m.appendChild(btn(wa ? '✉️ Send as SMS instead' : '💬 Use WhatsApp instead', function () { doMessage(c, cur, wa ? 'sms' : 'wa'); }));
  if (wa) m.appendChild(mk('div', { html: '<small>WhatsApp opens with your message ready. Tap its Send button (websites cannot press Send for you). If nothing opens, tap the big button above.</small>' }));
  function go() { if (wa) { if (!openURL(url(cur))) location.href = url(cur); } else location.href = url(cur); }
  say((wa ? 'Opening WhatsApp for ' : 'Opening messages for ') + who(c) + '. Message: ' + cur);
  happy(); scroll();
  setTimeout(go, 450);
}
function askMessage(c, channel) {
  reply('What should I say to <b>' + esc(who(c)) + '</b>? Type it or tap the mic.', null, 'What should I say to ' + who(c) + '?');
  pend = { act: 'msg', c: c, ch: channel, t: Date.now() };
  try { if (hfEl.checked) setTimeout(function () { if (!speaking && !listening) listen(); }, 1500); } catch (e) { }
}
function sendTo(target, msg, channel) {
  withContact(target, channel === 'sms' ? 'sms' : 'wa', function (c) {
    if (!msg) return askMessage(c, channel);
    doMessage(c, msg, channel);
  }, { msg: msg });
}
function shareLocation(target) {
  withContact(target, 'wa', function (c) {
    if (!navigator.geolocation) return reply('Location is not available in this browser.');
    reply('📍 Getting your location…', null, 'Getting your location.');
    navigator.geolocation.getCurrentPosition(function (o) {
      doMessage(c, '📍 My location: https://maps.google.com/?q=' + o.coords.latitude.toFixed(6) + ',' + o.coords.longitude.toFixed(6), 'wa');
    }, function () { reply('Please allow location access, then try again.'); sad(); }, { timeout: 10000, enableHighAccuracy: true });
  });
}

/* ---------- alarm ringing ---------- */
var ringEl = null, ringIv = null, ringTo = null, ringText = '';
function stopRing() {
  if (ringIv) { clearInterval(ringIv); ringIv = null; }
  if (ringTo) { clearTimeout(ringTo); ringTo = null; }
  if (ringEl) { ringEl.remove(); ringEl = null; }
  try { if (navigator.vibrate) navigator.vibrate(0); } catch (e) { }
}
function snooze(min) {
  var txt = ringText; stopRing();
  S.rem.push({ t: Date.now() + min * 60000, text: txt, k: 'snooze' }); sv();
  reply('😴 Snoozed for ' + min + ' minutes.', null, 'Snoozed for ' + min + ' minutes.');
}
window.ring = function (txt) {
  stopRing(); ringText = txt;
  ringEl = mk('div', { role: 'alertdialog', 'aria-label': 'Alarm' });
  ringEl.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;background:rgba(8,8,20,.94);color:#fff;text-align:center;padding:24px';
  ringEl.appendChild(mk('div', { text: '⏰', style: 'font-size:72px' }));
  ringEl.appendChild(mk('div', { text: txt, style: 'font-size:24px;font-weight:650;max-width:90%' }));
  ringEl.appendChild(mk('div', { text: new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }), style: 'opacity:.7' }));
  var row = mk('div'); row.style.cssText = 'display:flex;gap:12px;flex-wrap:wrap;justify-content:center';
  var b1 = btn('Stop', stopRing), b2 = btn('Snooze 5 min', function () { snooze(5); });
  [b1, b2].forEach(function (b) { b.style.cssText = 'padding:14px 26px;font-size:18px;border-radius:30px;border:0;background:#fff;color:#111;cursor:pointer'; });
  b1.style.background = '#22d3c5';
  row.appendChild(b1); row.appendChild(b2); ringEl.appendChild(row);
  document.body.appendChild(ringEl);
  beep(); ringIv = setInterval(beep, 1800); ringTo = setTimeout(stopRing, 120000);
  add('⏰ ' + esc(txt), 'a'); say(txt);
  try {
    if ('Notification' in window && Notification.permission === 'granted' && navigator.serviceWorker && navigator.serviceWorker.ready)
      navigator.serviceWorker.ready.then(function (r) { r.showNotification('Lexi', { body: txt, icon: 'icon-192.png', vibrate: [300, 150, 300], requireInteraction: true, tag: 'lexi-alarm' }); });
  } catch (e) { }
  try { mood('happy', 3000); } catch (e) { }
};
setInterval(function () {
  var n = new Date(), key = n.toDateString() + n.getHours() + ':' + n.getMinutes(), dirty = false;
  S.rep.forEach(function (r) {
    if (r.days.indexOf(n.getDay()) >= 0 && r.h === n.getHours() && r.m === n.getMinutes() && r.last !== key) { r.last = key; dirty = true; window.ring(r.text); }
  });
  if (dirty) sv();
}, 1000);

/* ---------- alarms and reminders ---------- */
function nextRep(r) {
  var n = new Date(), i, d;
  for (i = 0; i < 8; i++) {
    d = new Date(n.getFullYear(), n.getMonth(), n.getDate() + i, r.h, r.m, 0, 0);
    if (r.days.indexOf(d.getDay()) >= 0 && d > n) return d;
  }
  return d;
}
function allAlarms() {
  var a = S.rem.map(function (r) { return { kind: 'one', r: r, t: new Date(r.t) }; });
  S.rep.forEach(function (r) { a.push({ kind: 'rep', r: r, t: nextRep(r) }); });
  a.sort(function (x, y) { return x.t - y.t; });
  return a;
}
function removeAlarm(x) {
  if (x.kind === 'one') S.rem = S.rem.filter(function (r) { return r !== x.r; });
  else S.rep = S.rep.filter(function (r) { return r !== x.r; });
  sv(); syncWake();
}
function icsLink(label, d, rep) {
  var a = mk('a', { 'class': 'go', download: 'lexi-alarm.ics', href: 'data:text/calendar;charset=utf-8,' + encodeURIComponent(K.makeICS(label, d, rep)), text: '📅 Also add to phone calendar (rings even when this app is closed)' });
  a.style.cssText = 'font-size:13px;font-weight:600;display:inline-block;margin-top:6px';
  return a;
}
function confirmAlarm(kind, text, d, rep) {
  var title = kind === 'alarm' ? '⏰ Alarm set' : kind === 'timer' ? '⏳ Timer set' : '🔔 Reminder set';
  var when = rep ? rep.label + ' at ' + K.fmtTime(d) : K.fmtWhen(d);
  var m = card('<b>' + title + '</b> for ' + esc(when) + (text && !/^(Alarm|Your .* timer)/.test(text) ? '<br>' + esc(text) : '') + '<br>');
  var item = null;
  m.appendChild(btn('🗑 Delete', function () {
    var f = allAlarms().filter(function (x) { return x.r === item; })[0];
    if (f) removeAlarm(f); m.appendChild(mk('div', { text: 'Deleted.' }));
  }));
  m.appendChild(btn('😴 Show all alarms', function () { showAlarms(); }));
  m.appendChild(mk('br'));
  if (kind !== 'timer') m.appendChild(icsLink(text || 'Alarm', d, rep));
  m.appendChild(mk('div', { html: '<small>Keep Lexi open for the alarm to ring (say “keep screen on” to stop the phone sleeping).</small>' }));
  scroll();
  return function (it) { item = it; };
}
function setOne(kind, text, d, ringText2) {
  var it = { t: d.getTime(), text: ringText2, k: kind, label: text };
  S.rem.push(it); sv(); syncWake();
  return it;
}
function doAlarm(c) {
  var rep = K.repeatSpec(c), w = K.parseWhen(c, 'alarm');
  if (!w || w.needTime || (!w.hasTime && !w.rel)) {
    pend = { act: 'alarmTime', c: c, t: Date.now() };
    return reply('⏰ What time should I set the alarm for? For example: “tomorrow 8 am”, “6:30 pm” or “every day at 7”.', null, 'What time should I set the alarm for?');
  }
  var label = K.alarmLabel(w.rest);
  if (rep) {
    var r = { h: w.t.getHours(), m: w.t.getMinutes(), days: rep.days, text: label ? 'Alarm: ' + label : 'Alarm! It is ' + K.fmtTime(w.t), label: label, last: '' };
    S.rep.push(r); sv(); syncWake();
    var set = confirmAlarm('alarm', label, w.t, rep); set(r);
    return say('Repeating alarm set. ' + rep.label + ' at ' + K.fmtTime(w.t));
  }
  var it = setOne('alarm', label, w.t, label ? 'Alarm: ' + label : 'Alarm! It is ' + K.fmtTime(w.t));
  confirmAlarm('alarm', label, w.t)(it);
  say('Alarm set for ' + K.fmtWhen(w.t));
  happy();
}
function doTimer(c) {
  var w = K.parseWhen(c, 'timer') || K.parseWhen('for ' + c.replace(/\b(?:set|start|a|the|timer|for|of)\b/g, ' '), 'timer');
  if (!w || !w.rel) return false;
  var ms = w.t - new Date(), mins = Math.round(ms / 60000), lab = ms < 90000 ? Math.round(ms / 1000) + ' second' + (Math.round(ms / 1000) === 1 ? '' : 's') : mins < 120 ? mins + ' minute' + (mins === 1 ? '' : 's') : (Math.round(ms / 360000) / 10) + ' hours';
  var it = setOne('timer', lab, w.t, 'Your ' + lab + ' timer is finished');
  confirmAlarm('timer', 'Your ' + lab + ' timer', w.t)(it);
  say('Timer set for ' + lab); happy();
  return true;
}
function doRemind(rest, kindLabel) {
  var rep = K.repeatSpec(rest), w = K.parseWhen(rest, 'remind'), text = K.remindText(w ? w.rest : rest);
  if (!text) { pend = { act: 'remindText', when: w, t: Date.now() }; return reply('🔔 What should I remind you about?', null, 'What should I remind you about?'); }
  if (!w) { pend = { act: 'remindWhen', text: text, t: Date.now() }; return reply('🔔 When should I remind you? For example: “in 30 minutes”, “tomorrow 9 am”.', null, 'When should I remind you?'); }
  var msg = (kindLabel || 'Reminder') + ': ' + text;
  if (rep) {
    var r = { h: w.t.getHours(), m: w.t.getMinutes(), days: rep.days, text: msg, label: text, last: '' };
    S.rep.push(r); sv(); syncWake();
    confirmAlarm('remind', text, w.t, rep)(r);
    return say('Repeating reminder set. ' + text);
  }
  var it = setOne('remind', text, w.t, msg);
  confirmAlarm('remind', text, w.t)(it);
  say('Okay. I will remind you ' + K.fmtWhen(w.t) + '. ' + text); happy();
}
function showAlarms(delMode) {
  var a = allAlarms();
  if (!a.length) return reply('You have no alarms, reminders or timers. Try “alarm tomorrow 8 am”.', null, 'You have no alarms or reminders.');
  var m = card('<b>Your alarms &amp; reminders</b>');
  a.forEach(function (x, i) {
    var label = x.r.label || x.r.text.replace(/^(Alarm|Reminder|Event): ?/, ''), icon = x.r.k === 'timer' ? '⏳' : x.r.k === 'remind' || /^Reminder/.test(x.r.text) ? '🔔' : '⏰';
    var row = mk('div'); row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--bd)';
    var txt = mk('div', { html: (i + 1) + '. ' + icon + ' <b>' + esc(x.kind === 'rep' ? x.r.days.length === 7 ? 'Every day ' + K.fmtTime(x.t) : K.repeatLabel(x.r) + ' ' + K.fmtTime(x.t) : K.fmtWhen(x.t)) + '</b>' + (label && label !== 'Alarm' ? '<br><small>' + esc(label) + '</small>' : '') });
    txt.style.flex = '1';
    var del = btn('🗑', function () { removeAlarm(x); row.remove(); }, 'ib'); del.title = 'Delete'; del.style.margin = '0';
    row.appendChild(txt); row.appendChild(del); m.appendChild(row);
  });
  say('You have ' + a.length + (a.length === 1 ? ' alarm. ' : ' alarms and reminders. ') + 'The next one is ' + K.fmtWhen(a[0].t));
  scroll();
}
K.repeatLabel = function (r) {
  if (r.days.length === 5 && r.days.indexOf(0) < 0 && r.days.indexOf(6) < 0) return 'Weekdays';
  if (r.days.length === 2 && r.days.indexOf(0) >= 0 && r.days.indexOf(6) >= 0) return 'Weekends';
  return r.days.map(function (d) { return capDay(d); }).join(', ');
};
function capDay(d) { return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d]; }
function deleteAlarms(c) {
  var kind = /timer/.test(c) ? 'timer' : /reminder/.test(c) ? 'remind' : /alarm/.test(c) ? 'alarm' : '';
  var a = allAlarms().filter(function (x) {
    if (!kind) return true;
    var k = x.r.k || (/^Reminder/.test(x.r.text) ? 'remind' : /timer/i.test(x.r.text) ? 'timer' : 'alarm');
    return k === kind;
  });
  if (/\ball\b|\beverything\b/.test(c) || /^(?:cancel|clear|stop|delete)\s+(?:my\s+)?(?:alarms|reminders|timers)$/.test(c)) {
    if (!a.length) return reply('There is nothing to cancel.');
    a.forEach(removeAlarm);
    return reply('🗑 Cancelled ' + a.length + ' item' + (a.length === 1 ? '' : 's') + '.', null, 'All cancelled.');
  }
  var im = c.match(/\b(?:number\s+)?(\d{1,2})\s*$/);
  if (im && !/am|pm/.test(c)) {
    var x = allAlarms()[+im[1] - 1];
    if (x) { removeAlarm(x); return reply('🗑 Deleted: ' + esc(x.kind === 'rep' ? (x.r.days.length === 7 ? 'Every day ' + K.fmtTime(x.t) : K.repeatLabel(x.r) + ' ' + K.fmtTime(x.t)) : K.fmtWhen(x.t)) + '.', null, 'Deleted.'); }
  }
  var w = K.parseWhen(c.replace(/\b(?:delete|cancel|remove|clear|stop|turn off|disable)\b/, ' '), 'alarm');
  if (w && w.t && w.hasTime) {
    var hit = a.filter(function (x) { return x.t.getHours() === w.t.getHours() && x.t.getMinutes() === w.t.getMinutes(); });
    if (hit.length) { hit.forEach(removeAlarm); return reply('🗑 Deleted ' + hit.length + ' item' + (hit.length === 1 ? '' : 's') + ' at ' + K.fmtTime(w.t) + '.', null, 'Deleted.'); }
    return reply('I could not find an alarm at ' + K.fmtTime(w.t) + '.');
  }
  if (a.length === 1) { removeAlarm(a[0]); return reply('🗑 Deleted your ' + esc(K.fmtWhen(a[0].t)) + ' item.', null, 'Deleted.'); }
  reply('Which one should I delete? Tap 🗑 next to it, or say “delete alarm 2”.');
  showAlarms();
}

/* ---------- keep screen awake ---------- */
var wl = null, wantWake = false;
function keepOn(on) {
  wantWake = on;
  if (!navigator.wakeLock) return false;
  if (on) navigator.wakeLock.request('screen').then(function (l) { wl = l; l.addEventListener('release', function () { wl = null; }); }).catch(function () { });
  else if (wl) { wl.release(); wl = null; }
  return true;
}
function syncWake() { /* only keep awake when the user asked for it */ }
document.addEventListener('visibilitychange', function () { if (wantWake && document.visibilityState === 'visible' && !wl) keepOn(true); });

/* ---------- stopwatch ---------- */
var swT0 = 0, swAcc = 0, swRun = false;
function swNow() { return swAcc + (swRun ? Date.now() - swT0 : 0); }
function swFmt(ms) { var s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60); return (h ? h + ' h ' : '') + (m ? m + ' min ' : '') + (s % 60) + ' sec'; }

/* ---------- expenses and shopping ---------- */
function money(n) { return '₹' + (+n).toLocaleString('en-IN', { maximumFractionDigits: 2 }); }
function expenseSum(from) { return S.exp.filter(function (e) { return e.t >= from; }).reduce(function (a, e) { return a + e.a; }, 0); }
function startOf(kind) {
  var n = new Date();
  if (kind === 'month') return new Date(n.getFullYear(), n.getMonth(), 1).getTime();
  if (kind === 'week') { var d = new Date(n.getFullYear(), n.getMonth(), n.getDate() - ((n.getDay() + 6) % 7)); return d.getTime(); }
  return new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
}
function showList(title, arr, key) {
  if (!arr.length) return reply('Your ' + title + ' is empty.', null, 'Your ' + title + ' is empty.');
  var m = card('<b>' + esc(capFirst(title)) + '</b>');
  arr.slice().forEach(function (it, i) {
    var row = mk('div'); row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid var(--bd)';
    var t = mk('div', { text: key(it) }); t.style.flex = '1';
    var d = btn('✕', function () { var j = arr.indexOf(it); if (j >= 0) arr.splice(j, 1); sv(); row.remove(); }, 'ib'); d.style.margin = '0';
    row.appendChild(t); row.appendChild(d); m.appendChild(row);
  });
  say('You have ' + arr.length + ' items. ' + arr.slice(0, 8).map(key).join(', '));
  scroll();
}

/* ---------- contact book dialog ---------- */
var dlg = mk('dialog');
dlg.style.cssText = 'max-width:560px;width:94%;border:1px solid var(--bd);border-radius:14px;background:var(--card);color:var(--fg);max-height:88vh;overflow:auto';
document.body.appendChild(dlg);
function openBook() {
  var q = '';
  function draw() {
    dlg.innerHTML = '';
    dlg.appendChild(mk('h3', { text: '📇 Contact book (' + BOOK.length + ')', style: 'margin:0 0 8px' }));
    var top = mk('div');
    if (pickerOK) top.appendChild(btn('📱 Import from phone', function () { importFromPhone(draw); }));
    top.appendChild(btn('📂 Import .vcf / .csv', function () { fileAfter = draw; fileIn.click(); }));
    dlg.appendChild(top);
    if (!pickerOK) dlg.appendChild(mk('small', { html: 'Tip: on iPhone export contacts as .vcf (iCloud.com → Contacts → Select all → Export vCard) and import it here. Contacts stay on this device only.' }));
    var s = mk('input', { 'class': 'k', placeholder: 'Search name or number', value: q });
    s.oninput = function () { q = s.value; list(); };
    dlg.appendChild(s);
    var box = mk('div', { id: 'cbl' }); dlg.appendChild(box);
    function list() {
      box.innerHTML = '';
      var rows = q ? K.findContacts(q, BOOK).map(function (x) { return x.c; }) : BOOK.slice().sort(function (a, b) { return a.n.localeCompare(b.n); });
      rows.slice(0, 80).forEach(function (c) {
        var row = mk('div'); row.style.cssText = 'display:flex;align-items:center;gap:4px;padding:6px 0;border-bottom:1px solid var(--bd)';
        var t = mk('div', { html: '<b>' + esc(c.n) + '</b><br><small>' + esc(K.fmtNum(c.p)) + '</small>' }); t.style.flex = '1';
        var b1 = btn('📞', function () { dlg.close(); doCall(c); }, 'ib'), b2 = btn('💬', function () { dlg.close(); askMessage(c, 'wa'); }, 'ib'), b3 = btn('✕', function () { BOOK.splice(BOOK.indexOf(c), 1); saveBook(); draw(); }, 'ib');
        [b1, b2, b3].forEach(function (b) { b.style.margin = '0'; });
        b1.title = 'Call'; b2.title = 'WhatsApp'; b3.title = 'Delete';
        row.appendChild(t); row.appendChild(b1); row.appendChild(b2); row.appendChild(b3); box.appendChild(row);
      });
      if (!rows.length) box.appendChild(mk('small', { text: BOOK.length ? 'No match.' : 'No contacts yet. Import or add one below.' }));
      if (rows.length > 80) box.appendChild(mk('small', { text: 'Showing 80 of ' + rows.length + '. Use search.' }));
    }
    list();
    dlg.appendChild(mk('b', { text: 'Add a contact', style: 'display:block;margin-top:10px' }));
    var nI = mk('input', { 'class': 'k', placeholder: 'Name (e.g. Mom)' }), pI = mk('input', { 'class': 'k', placeholder: 'Phone number', inputmode: 'tel' });
    dlg.appendChild(nI); dlg.appendChild(pI);
    dlg.appendChild(btn('Add contact', function () { if (addContact(K.titleCase(nI.value.trim()), pI.value)) { saveBook(); draw(); } else pI.focus(); }));
    dlg.appendChild(mk('b', { text: 'Default country code', style: 'display:block;margin-top:10px' }));
    var cI = mk('input', { 'class': 'k', value: TS.cc, inputmode: 'numeric', placeholder: '91' });
    cI.onchange = function () { TS.cc = K.digits(cI.value) || '91'; saveTS(); };
    dlg.appendChild(cI);
    dlg.appendChild(mk('small', { text: 'Used for 10-digit numbers so WhatsApp works (91 = India).' }));
    var cl = btn('Close', function () { dlg.close(); }); cl.style.background = 'var(--a)'; cl.style.color = '#fff'; cl.style.marginTop = '12px';
    dlg.appendChild(mk('div', {}, [cl]));
  }
  draw();
  if (!dlg.open) dlg.showModal();
}

/* ---------- command router ---------- */
var pend = null, H0 = '';
window.JT_pending = function () { return !!pend && Date.now() - pend.t < 120000; };
try { H0 = decodeURIComponent(location.hash.slice(1)); } catch (e) { }
function clean(raw) {
  var c = String(raw).toLowerCase().trim().replace(/[?!,]+/g, ' ').replace(/\.+$/, '').replace(/\s+/g, ' ').trim(), p;
  c = c.replace(/^(?:hey|ok|okay|hi)\s+(?:lexi|lexie|jaan|jaanu|assistant|google|siri)\s*/, '');
  do { p = c; c = c.replace(/^(?:please|kindly|can you|could you|would you|will you|i want to|i wanna|i would like to|i need to|just|lexi|jaan)\s+/, ''); } while (c !== p);
  return c.replace(/\s+please$/, '').trim();
}
function handlePending(raw, c) {
  if (!pend) return false;
  if (Date.now() - pend.t > 120000) { pend = null; return false; }
  var p = pend; pend = null;
  if (/^(?:cancel|never ?mind|stop|forget it|no|nothing)$/.test(c)) { add(esc(raw), 'u'); reply('Okay, cancelled.'); return true; }
  add(esc(raw), 'u');
  if (p.act === 'msg') { doMessage(p.c, cleanM(raw), p.ch); return true; }
  if (p.act === 'alarmTime') { doAlarm(p.c + ' ' + c); return true; }
  if (p.act === 'remindWhen') { doRemind(p.text + ' ' + c); return true; }
  if (p.act === 'remindText') { doRemind(c + ' ' + (p.when ? K.fmtTime(p.when.t) : '')); return true; }
  return false;
}
function cleanM(s) { return K.capFirst(String(s).trim()); }

function route(raw) {
  var c = clean(raw), m, w;
  if (!c) return false;

  /* ringing right now */
  if (ringEl && /^(?:stop|dismiss|off|ok|okay|enough|quiet|silence|turn off)(?: the)?(?: alarm)?$/.test(c)) { add(esc(raw), 'u'); stopRing(); reply('Stopped.'); return true; }
  if (ringEl && /^snooze/.test(c)) { add(esc(raw), 'u'); var sm = c.match(/(\d+)/); snooze(sm ? +sm[1] : 5); return true; }

  /* --- contacts --- */
  if (m = c.match(/^(?:save|add|new|create|store)\s+(?:a\s+|new\s+)?(?:contact|number)\s+(?:as\s+|for\s+|of\s+|named\s+)?(.+)$/)) {
    var a = m[1].match(/^(.*?)\s+((?:\+|00)?\d[\d\s-]{5,}\d)$/), b = m[1].match(/^((?:\+|00)?\d[\d\s-]{5,}\d)\s+(?:as\s+|for\s+)?(.+)$/), nm, ph;
    if (a && a[1]) { nm = a[1]; ph = a[2]; } else if (b) { nm = b[2]; ph = b[1]; }
    if (nm) {
      add(esc(raw), 'u');
      if (addContact(K.titleCase(nm.trim()), ph)) saveBook();
      reply('✅ Saved <b>' + esc(K.titleCase(nm.trim())) + '</b> as ' + esc(K.fmtNum(K.normNum(ph, TS.cc))) + '.', null, 'Saved ' + nm);
      return true;
    }
  }
  if (/^(?:show|open|list|view|see|my)?\s*(?:all\s+|my\s+|saved\s+)*contacts?(?:\s+book|\s+list)?$/.test(c)) { add(esc(raw), 'u'); openBook(); return true; }
  if (/^(?:import|sync|load|add|get|upload)\s+(?:my\s+|phone\s+|all\s+)*contacts?(?:\s+from\s+(?:my\s+)?(?:phone|file))?$/.test(c)) { add(esc(raw), 'u'); importOptions(); return true; }
  if ((m = c.match(/^(?:what(?:'s| is)|show|tell me|find|search(?: for)?|look ?up|get)\s+(?:the\s+)?(?:contact\s+)?(?:number\s+(?:of|for)\s+)?(.+?)(?:'s|s)?\s*(?:contact|number|phone number|mobile number)$/)) || (m = c.match(/^(?:find|search(?: for)?|look ?up)\s+contact\s+(.+)$/))) {
    var fl = K.findContacts(m[1].replace(/^(?:my|the)\s+/, ''), BOOK);
    if (fl.length || /contact|number/.test(c)) {
      add(esc(raw), 'u');
      if (!fl.length) return notFound(m[1], 'find', function (cc) { doCall(cc); }), true;
      var mm = card('<b>Contacts found</b>');
      fl.slice(0, 5).forEach(function (x) {
        var row = mk('div'); row.style.cssText = 'padding:6px 0;border-bottom:1px solid var(--bd)';
        row.appendChild(mk('span', { html: '<b>' + esc(x.c.n) + '</b> · ' + esc(K.fmtNum(x.c.p)) + ' ' }));
        row.appendChild(btn('📞', function () { doCall(x.c); }, 'ib')); row.appendChild(btn('💬', function () { askMessage(x.c, 'wa'); }, 'ib'));
        mm.appendChild(row);
      });
      say(fl[0].c.n + ' is ' + K.digits(fl[0].c.p).split('').join(' '));
      return true;
    }
  }

  /* --- call --- */
  if ((m = c.match(/^(?:call|dial|phone|ring|make a call to|give a call to|call up|start a call with)\s+(?:to\s+)?(.+)$/)) && !/^(?:me|us|back)\b/.test(m[1])) {
    add(esc(raw), 'u');
    withContact(m[1].replace(/\s+on speaker(?:phone)?$/, ''), 'call', doCall);
    return true;
  }

  /* --- location sharing --- */
  if (m = c.match(/^(?:share|send)\s+(?:my\s+)?(?:current\s+|live\s+)?location\s+(?:with|to)\s+(.+?)(?:\s+on whats\s?app)?$/)) { add(esc(raw), 'u'); shareLocation(m[1]); return true; }

  /* --- email --- */
  if (m = c.match(/^(?:send\s+(?:an?\s+)?)?(?:e-?mail|mail)\s+(?:to\s+)?(\S+@\S+)\s*(?:saying|that|:)?\s*(.*)$/)) {
    add(esc(raw), 'u');
    var body = K.capFirst(m[2]), mu = 'mailto:' + m[1] + '?body=' + encodeURIComponent(body);
    var em = card('✉️ Email to <b>' + esc(m[1]) + '</b><br>' + esc(body) + '<br>');
    em.appendChild(btn('✉️ Open email app', function () { location.href = mu; })); say('Opening your email app.'); setTimeout(function () { location.href = mu; }, 900);
    return true;
  }

  /* --- WhatsApp / SMS / message --- */
  var chan = 'wa', rest = null;
  if (m = c.match(/^(?:send\s+(?:an?\s+)?)?(?:whats\s?app|wa)\s+(?:message\s+|msg\s+|text\s+)?(?:to\s+)?(.+)$/)) rest = m[1];
  else if (m = c.match(/^(?:send|write|drop|shoot)\s+(?:an?\s+)?(?:(whats\s?app|sms|text)\s+)?(?:message|msg|text)\s+(?:on\s+whats\s?app\s+)?to\s+(.+)$/)) { rest = m[2]; if (m[1] && /sms|text/.test(m[1])) chan = 'sms'; }
  else if (m = c.match(/^(message|msg|text|sms)\s+(.+)$/)) { rest = m[2]; if (/^(?:text|sms)$/.test(m[1])) chan = 'sms'; }
  else if (m = c.match(/^tell\s+(?!me\b|us\b)(.+)$/)) { var sp0 = K.splitNameMsg(m[1], BOOK); if (sp0.msg && (sp0.num || K.resolve(sp0.name, BOOK).length)) rest = m[1]; }
  else if (m = c.match(/^send\s+(.+?)\s+to\s+(.+?)(?:\s+on\s+(whats\s?app|sms))?$/)) {
    var tgt = m[2], tn = K.takeNumber(tgt);
    if ((tn && !tn.rest) || K.resolve(tgt, BOOK).length) { add(esc(raw), 'u'); if (m[3] === 'sms') chan = 'sms'; sendTo(tgt, K.capFirst(m[1]), chan); return true; }
  }
  if (rest) {
    add(esc(raw), 'u');
    var sp = K.splitNameMsg(rest, BOOK);
    sendTo(sp.num || sp.name, sp.msg, chan);
    return true;
  }

  /* --- alarms, reminders, timers --- */
  if (/^(?:alarms?|reminders?|timers?)$/.test(c) || /^(?:show|list|view|see|read|check|open|what(?:'s| are| is))\b.*\b(?:alarms?|reminders?|timers?)\b/.test(c) || /^my (?:alarms?|reminders?|timers?)$/.test(c)) { add(esc(raw), 'u'); showAlarms(); return true; }
  if (/^(?:delete|cancel|remove|clear|stop|turn off|disable)\b.*\b(?:alarms?|reminders?|timers?)\b/.test(c)) { add(esc(raw), 'u'); deleteAlarms(c); return true; }
  if (/\btimer\b/.test(c) && !/\bstop\b/.test(c)) { add(esc(raw), 'u'); if (doTimer(c)) return true; reply('For how long? Say “set timer 10 minutes”.'); return true; }
  if (m = c.match(/^(?:set\s+(?:a\s+)?|add\s+(?:a\s+)?|create\s+(?:a\s+)?)?(?:remind(?:er)?|remind me)\b\s*(?:me\s+)?(.*)$/)) { add(esc(raw), 'u'); doRemind(m[1]); return true; }
  if (m = c.match(/^(?:add|set|create|schedule|book|new)\s+(?:an?\s+)?(?:event|meeting|appointment)\s+(.*)$/)) { add(esc(raw), 'u'); doRemind(m[1], 'Event'); return true; }
  if (/\b(?:alarm|wake me|wake up)\b/.test(c)) { add(esc(raw), 'u'); doAlarm(c); return true; }

  /* --- keep screen on --- */
  if (/^(?:keep|stay|stop)\b.*\b(?:screen|awake|display)\b/.test(c) || /^(?:keep screen on|screen on|stay awake)$/.test(c) || /^(?:keep|stay) awake/.test(c)) {
    add(esc(raw), 'u'); var off = /\b(?:off|stop|normal)\b/.test(c), ok = keepOn(!off);
    reply(ok ? (off ? 'Screen can sleep again.' : '🔆 I will keep the screen on while Lexi is open, so alarms can ring. Say “screen off” to undo.') : 'This browser cannot keep the screen awake.');
    return true;
  }

  /* --- stopwatch --- */
  if (/^(?:start|begin)\s+(?:the\s+|a\s+)?stop ?watch$/.test(c) || c === 'stopwatch') { add(esc(raw), 'u'); swAcc = 0; swT0 = Date.now(); swRun = true; reply('⏱ Stopwatch started.'); return true; }
  if (/^(?:stop|pause|end)\s+(?:the\s+)?stop ?watch$/.test(c)) { add(esc(raw), 'u'); if (!swRun) return reply('The stopwatch is not running.'), true; swAcc = swNow(); swRun = false; reply('⏱ Stopped at <b>' + swFmt(swAcc) + '</b>.', null, 'Stopped at ' + swFmt(swAcc)); return true; }
  if (/^(?:reset|clear)\s+(?:the\s+)?stop ?watch$/.test(c)) { add(esc(raw), 'u'); swAcc = 0; swRun = false; reply('Stopwatch reset.'); return true; }
  if (/^(?:lap|check|show)\s+(?:the\s+)?stop ?watch$/.test(c)) { add(esc(raw), 'u'); reply('⏱ ' + swFmt(swNow()) + (swRun ? ' (running)' : ' (stopped)'), null, swFmt(swNow())); return true; }

  /* --- expenses --- */
  if (m = c.match(/^(?:i\s+)?(?:spent|paid|add (?:an? )?expense(?: of)?|expense|add spending|log expense)\s+(?:rs\.?|₹|rupees?|inr)?\s*(\d+(?:\.\d+)?)\s*(?:rupees?|rs\.?|inr)?\s*(?:on|for|at)?\s*(.*)$/)) {
    add(esc(raw), 'u'); var amt = +m[1], cat = m[2].trim() || 'other';
    S.exp.push({ a: amt, c: cat, t: Date.now() }); sv();
    var tod = expenseSum(startOf('day'));
    reply('💸 Saved <b>' + money(amt) + '</b> for ' + esc(cat) + '.<br><small>Today: ' + money(tod) + ' · This month: ' + money(expenseSum(startOf('month'))) + '</small>', null, 'Saved ' + amt + ' rupees for ' + cat + '. Today you spent ' + Math.round(tod) + ' rupees.');
    return true;
  }
  if (/^(?:show|list|my|view)\s+(?:my\s+)?(?:expenses?|spending)$/.test(c)) { add(esc(raw), 'u'); showList('expenses', S.exp, function (e) { return money(e.a) + ' · ' + e.c + ' · ' + new Date(e.t).toLocaleDateString([], { day: 'numeric', month: 'short' }); }); return true; }
  if (m = c.match(/^(?:total|how much)\b.*\b(?:spent|spend|spending|expenses?)\b.*?(today|this week|this month|week|month)?$/) ) {
    add(esc(raw), 'u'); var per = /month/.test(c) ? 'month' : /week/.test(c) ? 'week' : 'day', nameP = per === 'day' ? 'today' : 'this ' + per, tot = expenseSum(startOf(per));
    reply('💸 You spent <b>' + money(tot) + '</b> ' + nameP + '.', null, 'You spent ' + Math.round(tot) + ' rupees ' + nameP);
    return true;
  }
  if (/^clear\s+(?:all\s+)?(?:my\s+)?expenses?$/.test(c)) { add(esc(raw), 'u'); S.exp = []; sv(); reply('All expenses cleared.'); return true; }

  /* --- shopping list --- */
  if (m = c.match(/^(?:add|put)\s+(.+?)\s+(?:to|in|on)\s+(?:my\s+|the\s+)?(?:shopping|grocery|groceries|market)\s*list$/)) {
    add(esc(raw), 'u');
    var items = m[1].split(/\s*(?:,|\band\b)\s*/).filter(Boolean).map(K.capFirst);
    items.forEach(function (x) { S.shop.push(x); }); sv();
    reply('🛒 Added ' + esc(items.join(', ')) + '. You have ' + S.shop.length + ' item' + (S.shop.length === 1 ? '' : 's') + '.', null, 'Added ' + items.join(', '));
    return true;
  }
  if (/^(?:show|read|open|what(?:'s| is) on|my)\s+(?:my\s+|the\s+)?(?:shopping|grocery|groceries|market)\s*list$/.test(c) || /^(?:shopping|grocery)\s*list$/.test(c)) { add(esc(raw), 'u'); showList('shopping list', S.shop, function (x) { return x; }); return true; }
  if (m = c.match(/^(?:remove|delete|cross off|bought|got)\s+(.+?)\s+(?:from\s+)?(?:my\s+|the\s+)?(?:shopping|grocery)\s*list$/)) {
    add(esc(raw), 'u'); var before = S.shop.length; S.shop = S.shop.filter(function (x) { return K.norm(x) !== K.norm(m[1]); }); sv();
    reply(S.shop.length < before ? '✅ Removed ' + esc(m[1]) + '.' : 'I did not find ' + esc(m[1]) + ' on your list.'); return true;
  }
  if (/^clear\s+(?:my\s+|the\s+)?(?:shopping|grocery)\s*list$/.test(c)) { add(esc(raw), 'u'); S.shop = []; sv(); reply('Shopping list cleared.'); return true; }

  /* --- daily summary --- */
  if (/^(?:good (?:morning|afternoon|evening)|my day|daily (?:summary|brief(?:ing)?)|brief me|what(?:'s| is) my day|what do i have today|summary)$/.test(c)) {
    add(esc(raw), 'u');
    var n = new Date(), hr = n.getHours(), gr = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
    var upcoming = allAlarms().filter(function (x) { return x.t - n < 864e5; });
    var sm2 = card('<b>' + gr + '!</b> It is ' + esc(n.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' })) + ', ' + esc(K.fmtTime(n)) + '.<br>' +
      '⏰ Next 24 hours: ' + (upcoming.length ? upcoming.slice(0, 4).map(function (x) { return esc(K.fmtWhen(x.t) + (x.r.label ? ' – ' + x.r.label : '')); }).join('; ') : 'nothing scheduled') + '<br>' +
      '✅ Tasks: ' + (S.tasks.length ? S.tasks.length + ' open' : 'none') + (S.tasks.length ? ' (' + esc(S.tasks.slice(0, 3).map(function (t) { return t.text || t; }).join(', ')) + ')' : '') + '<br>' +
      '🛒 Shopping list: ' + S.shop.length + ' item' + (S.shop.length === 1 ? '' : 's') + ' · 💸 Today: ' + money(expenseSum(startOf('day'))) + '<br>');
    sm2.appendChild(btn('🌤 Weather', function () { handle('weather'); })); sm2.appendChild(btn('📰 News', function () { handle('news'); }));
    say(gr + '. You have ' + upcoming.length + ' alarms in the next day and ' + S.tasks.length + ' tasks.'); happy(); scroll();
    return true;
  }
  return false;
}

/* ---------- hook into the existing handle() ---------- */
var prev = window.handle;
function guarded(raw) {
  if (window.__JT_skip) return prev(raw);
  var c = clean(raw);
  if (handlePending(raw, c)) return;
  if (route(raw)) return;
  return prev(raw);
}
window.handle = function (raw) {
  if (H0 && raw === H0) {
    H0 = '';
    if (/^(?:call|dial|phone|whatsapp|whats app|message|msg|text|sms|send|email|mail|share|delete|clear|cancel|remove|stop|save|import)\b/i.test(raw)) {
      var m = card('🔒 A link asked me to run: <b>“' + esc(raw) + '”</b><br>Only continue if you trust where this link came from.<br>');
      m.appendChild(btn('Run it', function () { m.remove(); guarded(raw); }));
      m.appendChild(btn('Ignore', function () { m.remove(); }));
      return;
    }
  }
  return guarded(raw);
};

/* ---------- UI: header buttons, chips, help text ---------- */
(function ui() {
  var header = document.querySelector('header'), anchor = document.getElementById('clr');
  function hb(t, fn, label) { var b = mk('button', { 'class': 'ib', type: 'button', text: t, title: label, 'aria-label': label }); b.onclick = fn; header.insertBefore(b, anchor); }
  hb('📇', openBook, 'Contacts'); hb('⏰', function () { handle('show alarms'); }, 'Alarms');
  var det = document.querySelectorAll('#panel details')[1];
  if (det) det.appendChild(mk('div', {
    html: '<p><b>⏰ Alarms:</b> alarm tomorrow 8 am · alarm at 6:30 pm · wake me up at 7 · alarm every day at 6 · alarm on monday 9 am · show alarms · delete alarm 2 · cancel all alarms · snooze</p>' +
      '<p><b>📞 Calls &amp; messages:</b> call mom · call 98765 43210 · whatsapp mom hello · message raj saying I am late · text john see you soon · send hi to mom · tell dad I reached · share my location with mom · email a@b.com saying hi · save contact mom 98765 43210 · show contacts · import contacts</p>' +
      '<p><b>🧰 More:</b> remind me to pay rent tomorrow 9 am · add event dentist friday 5 pm · set timer 1 hour 30 minutes · spent 250 on lunch · how much did I spend this month · add milk and eggs to shopping list · start stopwatch · keep screen on · good morning</p>'
  }));
})();
})(typeof window !== 'undefined' ? window : globalThis);
