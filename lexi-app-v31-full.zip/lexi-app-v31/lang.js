/* Lexi lang.js
   Any-language understanding (AI command router), translation, read-aloud,
   language switching and replies in the user's language.
   Loaded after tasks.js. First half is pure logic (testable in Node). */
(function (root) {
'use strict';

/* ======================= PURE LOGIC ======================= */
var LANGS = [
  ['english', 'en', 'en-IN', 'English'], ['hindi', 'hi', 'hi-IN', 'हिन्दी'], ['kannada', 'kn', 'kn-IN', 'ಕನ್ನಡ'], ['tamil', 'ta', 'ta-IN', 'தமிழ்'],
  ['telugu', 'te', 'te-IN', 'తెలుగు'], ['malayalam', 'ml', 'ml-IN', 'മലയാളം'], ['marathi', 'mr', 'mr-IN', 'मराठी'], ['bengali', 'bn', 'bn-IN', 'বাংলা'],
  ['gujarati', 'gu', 'gu-IN', 'ગુજરાતી'], ['punjabi', 'pa', 'pa-IN', 'ਪੰਜਾਬੀ'], ['urdu', 'ur', 'ur-IN', 'اردو'], ['odia', 'or', 'or-IN', 'ଓଡ଼ିଆ'],
  ['nepali', 'ne', 'ne-NP', 'नेपाली'], ['spanish', 'es', 'es-ES', 'Español'], ['french', 'fr', 'fr-FR', 'Français'], ['german', 'de', 'de-DE', 'Deutsch'],
  ['italian', 'it', 'it-IT', 'Italiano'], ['portuguese', 'pt', 'pt-BR', 'Português'], ['russian', 'ru', 'ru-RU', 'Русский'], ['arabic', 'ar', 'ar-SA', 'العربية'],
  ['japanese', 'ja', 'ja-JP', '日本語'], ['korean', 'ko', 'ko-KR', '한국어'], ['chinese', 'zh', 'zh-CN', '中文'], ['thai', 'th', 'th-TH', 'ไทย'],
  ['vietnamese', 'vi', 'vi-VN', 'Tiếng Việt'], ['indonesian', 'id', 'id-ID', 'Indonesia'], ['turkish', 'tr', 'tr-TR', 'Türkçe'], ['dutch', 'nl', 'nl-NL', 'Nederlands'],
  ['polish', 'pl', 'pl-PL', 'Polski'], ['persian', 'fa', 'fa-IR', 'فارسی'], ['hebrew', 'he', 'he-IL', 'עברית'], ['greek', 'el', 'el-GR', 'Ελληνικά'],
  ['swedish', 'sv', 'sv-SE', 'Svenska'], ['ukrainian', 'uk', 'uk-UA', 'Українська'], ['sinhala', 'si', 'si-LK', 'සිංහල'], ['swahili', 'sw', 'sw-KE', 'Kiswahili'],
  /* v20: more languages that phone and Chrome speech recognition support */
  ['assamese', 'as', 'as-IN', 'অসমীয়া'], ['afrikaans', 'af', 'af-ZA', 'Afrikaans'], ['albanian', 'sq', 'sq-AL', 'Shqip'], ['amharic', 'am', 'am-ET', 'አማርኛ'],
  ['armenian', 'hy', 'hy-AM', 'Հայերեն'], ['azerbaijani', 'az', 'az-AZ', 'Azərbaycan'], ['basque', 'eu', 'eu-ES', 'Euskara'], ['belarusian', 'be', 'be-BY', 'Беларуская'],
  ['bosnian', 'bs', 'bs-BA', 'Bosanski'], ['bulgarian', 'bg', 'bg-BG', 'Български'], ['burmese', 'my', 'my-MM', 'မြန်မာ'], ['catalan', 'ca', 'ca-ES', 'Català'],
  ['croatian', 'hr', 'hr-HR', 'Hrvatski'], ['czech', 'cs', 'cs-CZ', 'Čeština'], ['danish', 'da', 'da-DK', 'Dansk'], ['estonian', 'et', 'et-EE', 'Eesti'],
  ['filipino', 'fil', 'fil-PH', 'Filipino'], ['finnish', 'fi', 'fi-FI', 'Suomi'], ['galician', 'gl', 'gl-ES', 'Galego'], ['georgian', 'ka', 'ka-GE', 'ქართული'],
  ['hausa', 'ha', 'ha-NG', 'Hausa'], ['hungarian', 'hu', 'hu-HU', 'Magyar'], ['icelandic', 'is', 'is-IS', 'Íslenska'], ['igbo', 'ig', 'ig-NG', 'Igbo'],
  ['irish', 'ga', 'ga-IE', 'Gaeilge'], ['javanese', 'jv', 'jv-ID', 'Basa Jawa'], ['kazakh', 'kk', 'kk-KZ', 'Қазақ'], ['khmer', 'km', 'km-KH', 'ខ្មែរ'],
  ['lao', 'lo', 'lo-LA', 'ລາວ'], ['latvian', 'lv', 'lv-LV', 'Latviešu'], ['lithuanian', 'lt', 'lt-LT', 'Lietuvių'], ['macedonian', 'mk', 'mk-MK', 'Македонски'],
  ['malay', 'ms', 'ms-MY', 'Bahasa Melayu'], ['mongolian', 'mn', 'mn-MN', 'Монгол'], ['norwegian', 'nb', 'nb-NO', 'Norsk'], ['pashto', 'ps', 'ps-AF', 'پښتو'],
  ['romanian', 'ro', 'ro-RO', 'Română'], ['serbian', 'sr', 'sr-RS', 'Српски'], ['slovak', 'sk', 'sk-SK', 'Slovenčina'], ['slovenian', 'sl', 'sl-SI', 'Slovenščina'],
  ['somali', 'so', 'so-SO', 'Soomaali'], ['sundanese', 'su', 'su-ID', 'Basa Sunda'], ['uzbek', 'uz', 'uz-UZ', 'Oʻzbek'], ['welsh', 'cy', 'cy-GB', 'Cymraeg'],
  ['yoruba', 'yo', 'yo-NG', 'Yorùbá'], ['zulu', 'zu', 'zu-ZA', 'isiZulu']
].map(function (a) { return { n: a[0], c: a[1], s: a[2], l: a[3], name: a[0].charAt(0).toUpperCase() + a[0].slice(1) }; });
var ALIASES = { kannad: 'kannada', kanada: 'kannada', odiya: 'odia', oriya: 'odia', farsi: 'persian', mandarin: 'chinese', bangla: 'bengali', panjabi: 'punjabi', tamizh: 'tamil', malayali: 'malayalam', gujrati: 'gujarati', hinglish: 'hindi', 'chinese simplified': 'chinese', 'brazilian portuguese': 'portuguese', tagalog: 'filipino', myanmar: 'burmese', 'bahasa': 'indonesian', bokmal: 'norwegian', asamiya: 'assamese', castilian: 'spanish', flemish: 'dutch' };
var SCRIPTS = [['hi', /[\u0900-\u097F]/g], ['bn', /[\u0980-\u09FF]/g], ['pa', /[\u0A00-\u0A7F]/g], ['gu', /[\u0A80-\u0AFF]/g], ['or', /[\u0B00-\u0B7F]/g], ['ta', /[\u0B80-\u0BFF]/g],
  ['te', /[\u0C00-\u0C7F]/g], ['kn', /[\u0C80-\u0CFF]/g], ['ml', /[\u0D00-\u0D7F]/g], ['si', /[\u0D80-\u0DFF]/g], ['th', /[\u0E00-\u0E7F]/g], ['ar', /[\u0600-\u06FF]/g],
  ['he', /[\u0590-\u05FF]/g], ['ru', /[\u0400-\u04FF]/g], ['ko', /[\uAC00-\uD7AF\u1100-\u11FF]/g], ['ja', /[\u3040-\u30FF]/g], ['zh', /[\u4E00-\u9FFF]/g], ['el', /[\u0370-\u03FF]/g],
  ['hy', /[\u0530-\u058F]/g], ['ka', /[\u10A0-\u10FF]/g], ['am', /[\u1200-\u137F]/g], ['km', /[\u1780-\u17FF]/g], ['lo', /[\u0E80-\u0EFF]/g], ['my', /[\u1000-\u109F]/g]];
/* v20: which Latin-script language is this? (for choosing the read-aloud voice) */
var LATIN = {
  es: /\b(el|los|las|que|y|es|por|con|para|una|del|como|pero|muy|está|qué|cómo|gracias|hola)\b|[ñ¿¡]/gi,
  fr: /\b(le|les|des|est|une|du|qui|pas|pour|dans|ce|il|elle|vous|nous|je|avec|sur|bonjour|merci|c'est)\b|[çœ]|[àâèêëîïôûù]/gi,
  de: /\b(der|die|das|und|ist|nicht|ich|du|ein|eine|zu|mit|auf|für|dem|von|sie|wir|danke|bitte)\b|[ßäöü]/gi,
  pt: /\b(os|não|um|uma|com|você|eu|muito|obrigado|obrigada|olá|também|está|são)\b|[ãõ]/gi,
  it: /\b(il|gli|di|che|è|non|per|della|sono|io|tu|grazie|ciao|anche|questo)\b/gi,
  id: /\b(yang|dan|di|ke|dari|ini|itu|dengan|untuk|tidak|ada|saya|anda|kami|akan|terima kasih)\b/gi,
  tr: /\b(ve|bir|bu|için|ile|çok|değil|ben|sen|var|teşekkür|merhaba)\b|[ğşı]/gi,
  nl: /\b(het|een|en|is|van|niet|ik|je|dat|die|op|zijn|met|dank)\b/gi,
  sw: /\b(na|ya|wa|kwa|ni|katika|hii|yangu|wewe|mimi|asante|habari)\b/gi,
  pl: /\b(nie|się|na|że|jest|do|jak|ale|co|dziękuję|cześć)\b|[ąęłżźść]/gi,
  vi: /\b(và|là|của|có|không|tôi|bạn|này|cho|với|được)\b|[ươđạảấầẩẫậắằẳẵặẹẻẽếềểễệịọỏốồổỗộớờởỡợụủứừửữự]/gi,
  en: /\b(the|and|is|are|you|your|to|for|of|in|it|not|with|this|that|have|will|what|how|please|thanks)\b/gi
};
function latinLang(t) {
  t = String(t || '').slice(0, 1200); var best = 'en', bs = 0, en = (t.match(LATIN.en) || []).length;
  Object.keys(LATIN).forEach(function (k) { if (k === 'en') return; var n = (t.match(LATIN[k]) || []).length; if (n > bs) { bs = n; best = k; } });
  return bs >= 2 && bs > en ? best : 'en';
}

function langBy(x) {
  x = String(x || '').toLowerCase().trim();
  if (ALIASES[x]) x = ALIASES[x];
  for (var i = 0; i < LANGS.length; i++) if (LANGS[i].n === x || LANGS[i].c === x || LANGS[i].s.toLowerCase() === x) return LANGS[i];
  return null;
}
function langBySpeech(s) { s = String(s || '').toLowerCase().slice(0, 2); return langBy(s); }
/* script of text: language code of the dominant non-Latin script, 'en' if Latin only, '' if nothing readable */
function scriptOf(text) {
  var best = '', bc = 0, i, m, latin = (String(text).match(/[A-Za-z\u00C0-\u024F]/g) || []).length;
  for (i = 0; i < SCRIPTS.length; i++) { m = String(text).match(SCRIPTS[i][1]); if (m && m.length > bc) { bc = m.length; best = SCRIPTS[i][0]; } }
  if (bc && bc >= Math.min(2, latin + 1)) return best;
  return latin ? 'en' : '';
}
function isEnglishish(t) { return (String(t).match(/\b(?:the|and|is|are|you|your|to|for|set|at|of|in|it|not|with|this|that|have|will|on|please)\b/gi) || []).length >= 1 && scriptOf(t) === 'en'; }
function digitsASCII(s) {
  var z = [0x0966, 0x09E6, 0x0A66, 0x0AE6, 0x0B66, 0x0BE6, 0x0C66, 0x0CE6, 0x0D66, 0x0660, 0x06F0];
  return String(s).replace(/[\u0966-\u096F\u09E6-\u09EF\u0A66-\u0A6F\u0AE6-\u0AEF\u0B66-\u0B6F\u0BE6-\u0BEF\u0C66-\u0C6F\u0CE6-\u0CEF\u0D66-\u0D6F\u0660-\u0669\u06F0-\u06F9]/g, function (c) {
    var cp = c.charCodeAt(0), k; for (k = 0; k < z.length; k++) if (cp >= z[k] && cp < z[k] + 10) return String(cp - z[k]); return c; });
}
var HINGLISH = /\b(?:karo|kardo|kar do|lagao|laga do|bhejo|bhej do|batao|bataiye|dikhao|chalao|kholo|baje|subah|shaam|yaad dilao|dilana|mujhe|mera|meri|nahi|kya hai|kaise|kahan|kitna|kitne|abhi|aaj|kal subah|kal shaam|ko call|ko message)\b/i;
var ENG_VERB = /^(?:please\s+)?(?:call|dial|phone|whatsapp|whats app|message|msg|text|sms|send|tell|remind|alarm|note|add|translate|read|say|speak|set|show|delete|cancel|save|email|mail|share|open|play|search|navigate|wikipedia|spent|start|stop|keep|switch|change|talk|reply|import|snooze|what|who|when|where|how|why|weather|news)\b/i;
/* should this input go through the any-language router? */
function needsRouter(raw) {
  var s = String(raw || '').trim();
  if (!s) return false;
  if (/```|\n.*\n/.test(s)) return false; /* pasted code goes straight to the AI */
  /* v20 speed: questions and long messages are not commands, so they go straight to the AI (saves one AI call, 1-6 s) */
  if (/[?？؟;]\s*$/.test(s) || s.length > 140 || s.split(/\s+/).length > 14) return false;
  if (HINGLISH.test(s)) return true;
  var sc = scriptOf(s);
  if (sc && sc !== 'en') return !ENG_VERB.test(s);
  return false;
}

/* "<text> in|into|to <language>" at the end of a sentence */
function parseLangTail(s) {
  var names = LANGS.map(function (l) { return l.n; }).concat(Object.keys(ALIASES)).sort(function (a, b) { return b.length - a.length; });
  var m = String(s).trim().match(new RegExp('^(.*?)\\s+(?:in|into|to)\\s+(?:the\\s+)?(' + names.join('|') + ')(?:\\s+language)?$', 'i'));
  if (!m || !m[1].trim()) return null;
  return { text: unquote(m[1]), lang: langBy(m[2]) };
}
function unquote(t) { return String(t).trim().replace(/^["“”'‘’]+|["“”'‘’]+$/g, '').trim(); }

/* Offline fallback: Devanagari / Hinglish -> English command (alarm, call, message, whatsapp, timer, weather, news) */
var TOK = {
  'अलार्म': 'alarm', 'अलार्म': 'alarm', 'अलारम': 'alarm', 'alarm': 'alarm', 'कॉल': 'call', 'काल': 'call', 'फोन': 'call', 'फ़ोन': 'call', 'call': 'call', 'dial': 'call',
  'कल': 'tomorrow', 'kal': 'tomorrow', 'आज': 'today', 'aaj': 'today', 'सुबह': 'AM', 'subah': 'AM', 'शाम': 'PM', 'shaam': 'PM', 'रात': 'PM', 'raat': 'PM', 'दोपहर': 'PM',
  'बजे': '', 'baje': '', 'मैसेज': 'message', 'संदेश': 'message', 'message': 'message', 'msg': 'message', 'व्हाट्सएप': 'whatsapp', 'व्हाट्सऐप': 'whatsapp', 'वॉट्सऐप': 'whatsapp', 'व्हाट्सअप': 'whatsapp', 'whatsapp': 'whatsapp',
  'मौसम': 'weather', 'mausam': 'weather', 'weather': 'weather', 'खबर': 'news', 'khabar': 'news', 'समाचार': 'news', 'news': 'news', 'टाइमर': 'timer', 'timer': 'timer',
  'मिनट': 'minutes', 'minute': 'minutes', 'minutes': 'minutes', 'घंटे': 'hours', 'ghante': 'hours', 'घंटा': 'hour', 'मम्मी': 'mom', 'पापा': 'dad', 'मां': 'mom', 'माँ': 'mom', 'mummy': 'mom', 'papa': 'dad',
  'को': '', 'ko': '', 'से': '', 'se': '', 'का': '', 'की': '', 'के': '', 'पर': '', 'par': '', 'लगाओ': '', 'लगा': '', 'lagao': '', 'laga': '', 'do': '', 'दो': '', 'karo': '', 'करो': '', 'kar': '', 'कर': '', 'भेजो': '', 'bhejo': '', 'batao': '', 'बताओ': '', 'please': '', 'plz': '', 'ek': '', 'एक': '', 'mujhe': '', 'मुझे': '', 'सेट': '', 'set': ''
};
var VERBS = ['alarm', 'call', 'whatsapp', 'message', 'timer', 'weather', 'news'];
function offlineNormalize(raw) {
  var toks = digitsASCII(String(raw).toLowerCase()).replace(/[?!,.।]/g, ' ').split(/\s+/).filter(Boolean), out = [], i;
  toks.forEach(function (t) { var v = TOK.hasOwnProperty(t) ? TOK[t] : t; if (v !== '') out.push(v); });
  var vi = -1; for (i = 0; i < out.length; i++) if (VERBS.indexOf(out[i]) >= 0) { vi = i; break; }
  if (vi < 0) return null;
  var verb = out.splice(vi, 1)[0];
  for (i = 0; i < out.length - 1; i++) if ((out[i] === 'AM' || out[i] === 'PM') && /^\d/.test(out[i + 1])) { var tmp = out[i]; out[i] = out[i + 1]; out[i + 1] = tmp; i++; }
  var rest = out.join(' ').replace(/\bAM\b/g, 'am').replace(/\bPM\b/g, 'pm');
  if (verb === 'weather') return 'weather' + (rest ? ' in ' + rest : '');
  if (verb === 'timer') return 'set timer ' + rest;
  if (verb === 'message') return 'whatsapp ' + rest;
  if ((verb === 'alarm') && !rest) return null;
  return verb + (rest ? ' ' + rest : '');
}
var ROUTER_PROMPT = 'You turn a spoken or typed request, written in ANY language (including Hindi, Kannada, Tamil, Telugu, Malayalam, Marathi, Bengali, Hinglish and others), into exactly ONE English command line for a voice assistant. Output ONLY that single line: no quotes, no markdown, no explanation.\n' +
  'Allowed command forms:\n' +
  'call NAME_OR_NUMBER\n' +
  'whatsapp NAME_OR_NUMBER MESSAGE   (also: sms NAME MESSAGE, email ADDRESS MESSAGE, share my location with NAME)\n' +
  'alarm tomorrow 8 am | alarm at 6:30 pm | alarm every day at 7 am | alarm on monday 9 am\n' +
  'remind me to TEXT in 30 minutes | remind me to TEXT tomorrow at 9 am | set timer 10 minutes\n' +
  'show alarms | delete alarm 2 | cancel all alarms | snooze\n' +
  'note TEXT | show notes | add task TEXT | show tasks | add ITEM to shopping list | show shopping list | spent AMOUNT on ITEM | show expenses\n' +
  'weather in CITY | news | what time is it | battery | flashlight on | navigate to PLACE | play SONG | open APP | good morning\n' +
  'calculate EXPRESSION | solve EQUATION (maths in plain English or symbols, digits 0-9) | who created you (when asked who made, created or owns you) | photo studio (edit or restyle a photo)\n' +
  'translate "TEXT" to LANGUAGE | say "TEXT" in LANGUAGE | read aloud "TEXT" | switch to LANGUAGE\n' +
  'ASK    (use exactly the word ASK for any question, chat or request that is not one of the commands above)\n' +
  'Rules: relatives map to English (मम्मी/ಅಮ್ಮ/அம்மா/amma = mom, पापा/ಅಪ್ಪ/appa = dad). Keep other person names, message text, reminder text and translation text in the speaker\'s own words and language (never translate message text). Convert digits to 0-9. Use 24h-free forms like "8 am".\n' +
  'Examples:\nमम्मी को कॉल करो -> call mom\nकल सुबह 8 बजे अलार्म लगाओ -> alarm tomorrow 8 am\nराज को व्हाट्सएप पर हेलो भेजो -> whatsapp raj हेलो\nನಾಳೆ ಬೆಳಿಗ್ಗೆ 6 ಗಂಟೆಗೆ ಅಲಾರಾಂ ಇಡು -> alarm tomorrow 6 am\nmujhe 30 minute baad paani peene ka yaad dilao -> remind me to paani peena in 30 minutes\nबेंगलुरु का मौसम बताओ -> weather in Bengaluru\nइसे तमिल में अनुवाद करो: मैं घर जा रहा हूँ -> translate "मैं घर जा रहा हूँ" to tamil\nफ्रांस की राजधानी क्या है -> ASK';

root.JTLANG = { LANGS: LANGS, langBy: langBy, scriptOf: scriptOf, needsRouter: needsRouter, parseLangTail: parseLangTail, offlineNormalize: offlineNormalize, digitsASCII: digitsASCII, isEnglishish: isEnglishish, ROUTER_PROMPT: ROUTER_PROMPT, unquote: unquote, langBySpeech: langBySpeech, latinLang: latinLang };
if (typeof document === 'undefined' || typeof window === 'undefined' || typeof add !== 'function') return;

/* ======================= PAGE INTEGRATION ======================= */
var J = root.JTLANG, K = root.JTCORE;
function ld(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
function sk(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
var LS = ld('valang', { auto: true });
function mk(tag, props, kids) {
  var e = document.createElement(tag), k;
  for (k in (props || {})) { if (k === 'text') e.textContent = props[k]; else if (k === 'html') e.innerHTML = props[k]; else e.setAttribute(k, props[k]); }
  (kids || []).forEach(function (c) { e.appendChild(c); });
  return e;
}
function btn(label, fn, cls) { var b = mk('button', { 'class': cls || 'c', type: 'button', text: label }); b.style.margin = '4px 6px 0 0'; b.onclick = fn; return b; }
function curLang() { return J.langBySpeech(CFG.lang) || J.langBy('en'); }
var BASE_SYS = String(SYS);
function applySYS() {
  var l = curLang();
  SYS = BASE_SYS + ' Always reply in the same language the user writes in.' + (l.c !== 'en' ? ' If the user does not specify otherwise, reply in ' + l.name + ' using its native script.' : '');
}
/* language dropdown with every language */
(function fillLangSelect() {
  var sel = document.getElementById('lang'), cur = CFG.lang || 'en-IN';
  sel.innerHTML = J.LANGS.map(function (l) { return '<option value="' + l.s + '">' + esc(l.l) + '</option>'; }).join('');
  sel.value = cur; if (!sel.value) sel.value = 'en-IN';
  sel.style.maxWidth = '110px';
  sel.addEventListener('change', function () { applySYS(); });
})();
applySYS();

/* ---------- AI backend (your key first, then the free fallback) ---------- */
function blob(o) { return new Blob([JSON.stringify(o)], { type: 'application/json' }); } /* a Blob body is not touched by the custom-instructions patch in plus.js */
function withTimeout(ms) { var c = new AbortController(); setTimeout(function () { c.abort(); }, ms); return c.signal; }
function oaiTry(p, system, msgs, ms) { var OR = p === 'openrouter', k = OR ? CFG.ork : CFG.grk; if (!k) return null; var hd = { 'content-type': 'application/json', authorization: 'Bearer ' + k }; if (OR) { hd['HTTP-Referer'] = location.origin === 'null' ? 'https://lexi.app' : location.origin; hd['X-Title'] = 'Lexi'; } return function () { return fetch(OR ? 'https://openrouter.ai/api/v1/chat/completions' : 'https://api.groq.com/openai/v1/chat/completions', { method: 'POST', signal: withTimeout(ms), headers: hd, body: new Blob([JSON.stringify({ model: OR ? 'meta-llama/llama-3.3-70b-instruct:free' : 'llama-3.3-70b-versatile', messages: [{ role: 'system', content: system }].concat(msgs) })], { type: 'application/json' }) }).then(function (r) { return r.json(); }).then(function (j) { return j.choices[0].message.content; }); }; }
function llm(system, user, ms) {
  ms = ms || 7000;
  var tries = [];
  if (CFG.ak) tries.push(function () {
    return fetch('https://api.anthropic.com/v1/messages', { method: 'POST', signal: withTimeout(ms), headers: { 'content-type': 'application/json', 'x-api-key': CFG.ak, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: blob({ model: 'claude-haiku-5-5', max_tokens: 1024, system: system, messages: [{ role: 'user', content: user }] }) }).then(function (r) { return r.json(); }).then(function (j) { if (!j.content) throw 0; return j.content.map(function (x) { return x.text || ''; }).join(''); });
  });
  if (CFG.ok) tries.push(function () {
    return fetch('https://api.openai.com/v1/chat/completions', { method: 'POST', signal: withTimeout(ms), headers: { 'content-type': 'application/json', authorization: 'Bearer ' + CFG.ok },
      body: blob({ model: 'gpt-4.1-mini', messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }) }).then(function (r) { return r.json(); }).then(function (j) { return j.choices[0].message.content; });
  });
  if (CFG.gk) tries.push(function () {
    return fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + encodeURIComponent(CFG.gk), { method: 'POST', signal: withTimeout(ms), headers: { 'content-type': 'application/json' },
      body: blob({ systemInstruction: { parts: [{ text: system }] }, contents: [{ role: 'user', parts: [{ text: user }] }] }) }).then(function (r) { return r.json(); }).then(function (j) { return j.candidates[0].content.parts.map(function (p) { return p.text || ''; }).join(''); });
  });
  ['groq', 'openrouter'].forEach(function (p) { var f = oaiTry(p, system, [{ role: 'user', content: user }], ms); if (f) tries.push(f); });
  tries.push(function () {
    return fetch('https://text.pollinations.ai/openai', { method: 'POST', signal: withTimeout(ms), headers: { 'content-type': 'application/json' },
      body: blob({ model: 'openai', messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }) }).then(function (r) { return r.json(); }).then(function (j) { return j.choices[0].message.content; });
  });
  return tries.reduce(function (p, f) { return p.catch(function () { return f().then(function (t) { if (!t || !String(t).trim()) throw 0; return String(t); }); }); }, Promise.reject());
}

/* ---------- translation ---------- */
function decodeEnt(s) { var d = document.createElement('textarea'); d.innerHTML = s; return d.value; }
function myMemory(text, to, from) {
  var parts = [], cur = '';
  String(text).split(/(?<=[.!?।\n])\s+/).forEach(function (s) { if ((cur + ' ' + s).length > 450 && cur) { parts.push(cur); cur = s; } else cur = cur ? cur + ' ' + s : s; });
  if (cur) parts.push(cur);
  return Promise.all(parts.map(function (p) {
    return fetch('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(p.slice(0, 480)) + '&langpair=' + from + '|' + to, { signal: withTimeout(12000) }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j.responseData || !j.responseData.translatedText || (j.responseStatus && +j.responseStatus !== 200)) throw 0; return decodeEnt(j.responseData.translatedText); });
  })).then(function (a) { return a.join(' '); });
}
/* returns {t, pron, from, engine} */
function translateText(text, toL, fromL) {
  text = String(text).trim();
  var sc = J.scriptOf(text), src = fromL || (sc === 'en' ? J.langBy('en') : J.langBy(sc));
  if (src && src.c === toL.c && sc !== 'en') return Promise.resolve({ t: text, pron: '', from: src.name, engine: 'same' });
  var sys = 'You are a precise professional translator. Translate the user\'s text into ' + toL.name + ' (' + toL.c + '). Return ONLY compact JSON: {"translation":"...","pronunciation":"...","source":"..."} where pronunciation is an easy Latin-letter reading of the translation when its script is not Latin (otherwise an empty string), and source is the English name of the detected source language. Keep names, numbers, emojis and line breaks. Never add explanations.';
  return llm(sys, text, 20000).then(function (out) {
    var o = null, a = out.indexOf('{'), b = out.lastIndexOf('}');
    if (a >= 0 && b > a) { try { o = JSON.parse(out.slice(a, b + 1)); } catch (e) { } }
    if (!o || !o.translation) o = { translation: out.replace(/^```\w*|```$/g, '').trim(), pronunciation: '', source: src ? src.name : '' };
    return { t: String(o.translation), pron: String(o.pronunciation || ''), from: o.source || (src ? src.name : ''), engine: CFG.ak || CFG.ok || CFG.gk ? 'AI' : 'free AI' };
  }).catch(function () {
    return myMemory(text, toL.c, src ? src.c : 'en').then(function (t) { return { t: t, pron: '', from: src ? src.name : '', engine: 'MyMemory' }; });
  });
}

/* ---------- reading aloud in any language ---------- */
function speakIn(text, code) {
  var L = J.langBy(code) || curLang(), found = false;
  text = String(text).replace(/<[^>]+>/g, ' ').replace(/[*`#_]/g, '').replace(/\s+/g, ' ').trim();
  if (!text) return false;
  try {
    speechSynthesis.cancel();
    var vs = speechSynthesis.getVoices().filter(function (v) { return v.lang.replace('_', '-').slice(0, 2).toLowerCase() === L.c; });
    found = vs.length > 0;
    var chunks = text.match(/[^.!?।\n]+[.!?।]?/g) || [text], parts = [], cur = '';
    chunks.forEach(function (s) { if ((cur + s).length > 200 && cur) { parts.push(cur); cur = s; } else cur += s; });
    if (cur) parts.push(cur);
    var FEMr = /female|woman|zira|samantha|heera|lekha|veena|kalpana|neerja|swara|google/i;
    parts.forEach(function (p, i) {
      var u = new SpeechSynthesisUtterance(p.trim()); u.lang = L.s;
      var v = vs.filter(function (x) { return FEMr.test(x.name); })[0] || vs[0]; if (v) u.voice = v;
      u.rate = Math.min(CFG.vr || 1, 1.05); u.pitch = CFG.vp || 1.1;
      if (i === 0) u.onstart = function () { speaking = true; try { orb.className = 'talk'; mood('talk'); } catch (e) { } };
      if (i === parts.length - 1) u.onend = u.onerror = function () { speaking = false; try { orb.className = ''; } catch (e) { } };
      speechSynthesis.speak(u);
    });
  } catch (e) { }
  return found;
}
function noVoiceHint(L) {
  return L.name + ' voice is not installed on this device. Install it in your phone settings (Text-to-speech → language data / Google Speech Services), or add an OpenAI key and turn on the neural voice in ⚙️ settings.';
}

/* ---------- translation card in chat ---------- */
function say(t) { try { speak(t); } catch (e) { } }
function translateCard(raw, text, toL, autoSpeak) {
  var m = add('🌐 Translating to <b>' + esc(toL.name) + '</b>…', 'a');
  translateText(text, toL).then(function (r) {
    m.innerHTML = '';
    m.appendChild(mk('div', { text: (r.from ? r.from + ' → ' : '') + toL.name + ' · ' + r.engine, style: 'opacity:.65;font-size:12px' }));
    var tt = mk('div', { text: r.t, style: 'font-size:20px;font-weight:650;margin:6px 0;white-space:pre-wrap' }); m.appendChild(tt);
    if (r.pron) m.appendChild(mk('div', { text: r.pron, style: 'font-style:italic;opacity:.8;margin-bottom:4px' }));
    m.appendChild(btn('🔊 Listen', function () { if (!speakIn(r.t, toL.c)) alert(noVoiceHint(toL)); }));
    m.appendChild(btn('📋 Copy', function () { try { navigator.clipboard.writeText(r.t); } catch (e) { } }));
    m.appendChild(btn('💬 WhatsApp', function () { window.open('https://wa.me/?text=' + encodeURIComponent(r.t), '_blank'); }));
    var sel = mk('select', { 'aria-label': 'Translate to another language' }); sel.style.cssText = 'margin-top:4px;border-radius:12px;padding:6px';
    sel.appendChild(mk('option', { value: '', text: '🌐 Other language…' }));
    J.LANGS.forEach(function (l) { sel.appendChild(mk('option', { value: l.c, text: l.name + ' ' + l.l })); });
    sel.onchange = function () { var l = J.langBy(sel.value); if (l) translateCard('', text, l, true); };
    m.appendChild(sel);
    if (autoSpeak) { if (!speakIn(r.t, toL.c)) m.appendChild(mk('div', { html: '<small>' + esc(noVoiceHint(toL)) + '</small>' })); }
    try { mood('happy', 1500); } catch (e) { }
    log.scrollTop = log.scrollHeight;
  });
  log.scrollTop = log.scrollHeight;
}

/* ---------- speak wrapper: right voice for the text, and replies in the chosen language ---------- */
var origSpeak = window.speak;
window.speak = function (t) {
  var s = String(t), sc = J.scriptOf(s), L = curLang();
  if (!SPK) return origSpeak(t);
  if (sc && sc !== 'en') { /* native-script text: use that language's voice */
    var tl = J.langBy(sc);
    if (tl && tl.c !== L.c) { var oldL = CFG.lang, oldV = CFG.voice; CFG.lang = tl.s; CFG.voice = ''; try { return origSpeak(t); } finally { CFG.lang = oldL; CFG.voice = oldV; } }
    return origSpeak(t);
  }
  if (sc === 'en') { /* v20: Latin-script languages (Spanish, French, German...) get their own voice */
    var ll = J.latinLang(s), tl2 = ll !== 'en' ? J.langBy(ll) : null;
    if (tl2 && tl2.c !== L.c) { var oL = CFG.lang, oV = CFG.voice; CFG.lang = tl2.s; CFG.voice = ''; try { return origSpeak(t); } finally { CFG.lang = oL; CFG.voice = oV; } }
  }
  if (sc === 'en' && L.c !== 'en') {
    if (LS.auto && J.isEnglishish(s) && s.length < 500 && !window.__noTrans) {
      translateText(s, L, J.langBy('en')).then(function (r) {
        var rows = log.querySelectorAll('.row.a .m'), last = rows[rows.length - 1];
        if (last && !last.querySelector('.jt-tr')) last.appendChild(mk('div', { 'class': 'jt-tr', text: r.t, style: 'margin-top:6px;padding-top:6px;border-top:1px dashed var(--bd);font-weight:600' }));
        log.scrollTop = log.scrollHeight;
        speakIn(r.t, L.c);
      }).catch(function () { var o3 = CFG.lang, v3 = CFG.voice; CFG.lang = 'en-IN'; CFG.voice = ''; try { origSpeak(t); } finally { CFG.lang = o3; CFG.voice = v3; } });
      return;
    }
    var o2 = CFG.lang, v2 = CFG.voice; CFG.lang = 'en-IN'; CFG.voice = ''; try { return origSpeak(t); } finally { CFG.lang = o2; CFG.voice = v2; }
  }
  return origSpeak(t);
};

/* ---------- language switching ---------- */
var GREET = { en: 'Okay, I will speak English.', hi: 'ठीक है, अब मैं हिन्दी में बात करूँगा।', kn: 'ಸರಿ, ಈಗ ನಾನು ಕನ್ನಡದಲ್ಲಿ ಮಾತನಾಡುತ್ತೇನೆ.', ta: 'சரி, இப்போது தமிழில் பேசுகிறேன்.', te: 'సరే, ఇప్పుడు తెలుగులో మాట్లాడతాను.', ml: 'ശരി, ഇനി മലയാളത്തിൽ സംസാരിക്കാം.', mr: 'ठीक आहे, आता मी मराठीत बोलेन.', bn: 'ঠিক আছে, এখন আমি বাংলায় কথা বলব।', gu: 'ઠીક છે, હવે હું ગુજરાતીમાં બોલીશ.', pa: 'ਠੀਕ ਹੈ, ਹੁਣ ਮੈਂ ਪੰਜਾਬੀ ਵਿੱਚ ਗੱਲ ਕਰਾਂਗਾ।' };
function setLang(L) {
  var sel = document.getElementById('lang'); sel.value = L.s; CFG.lang = L.s; CFG.voice = '';
  try { fillV(); localStorage.setItem('vacfg', JSON.stringify(CFG)); } catch (e) { }
  applySYS();
  var g = GREET[L.c];
  if (g) { add(esc(g), 'a'); window.__noTrans = true; try { speakIn(g, L.c); } finally { window.__noTrans = false; } }
  else { add('✅ Language set to <b>' + esc(L.name) + '</b>.', 'a'); translateText('Okay, I will speak ' + L.name + ' now.', L).then(function (r) { add(esc(r.t), 'a'); speakIn(r.t, L.c); }); }
}

/* ---------- chat commands in English (translate, read, language) ---------- */
var pendL = null;
function cleanC(raw) { return String(raw).trim().replace(/\s+/g, ' ').replace(/[.]+$/, ''); }
var langNames = J.LANGS.map(function (l) { return l.n; }).concat(Object.keys({ kannad: 1, kanada: 1, odiya: 1, farsi: 1, mandarin: 1, bangla: 1, panjabi: 1 })).sort(function (a, b) { return b.length - a.length; }).join('|');
function lastAnswerText() {
  var rows = log.querySelectorAll('.row.a .m'), i, t;
  for (i = rows.length - 1; i >= 0; i--) { t = rows[i].cloneNode(true); [].forEach.call(t.querySelectorAll('.src,button,select,small'), function (x) { x.remove(); }); t = t.innerText.trim(); if (t.length > 2) return t; }
  return '';
}
function langCommands(raw) {
  var c = cleanC(raw), lc = c.toLowerCase(), m, p;
  if (pendL) {
    var pl = pendL; pendL = null;
    if (/^(?:cancel|never ?mind|stop|no)$/.test(lc)) { add(esc(raw), 'u'); add('Okay, cancelled.', 'a'); return true; }
    if (pl.act === 'text') { add(esc(raw), 'u'); translateCard(raw, J.unquote(c), pl.to, true); return true; }
    if (pl.act === 'lang') { var L2 = J.langBy(lc.replace(/\s+language$/, '').replace(/^(?:in|into|to)\s+/, '')); if (L2) { add(esc(raw), 'u'); translateCard(raw, pl.text, L2, true); return true; } /* not a language: treat it as a new command */ }
  }
  /* switch / talk in a language */
  if ((m = lc.match(new RegExp('^(?:please\\s+)?(?:switch|change|set|turn)\\s+(?:the\\s+)?(?:my\\s+)?(?:language|voice|assistant|app|you)?\\s*(?:over\\s+)?to\\s+(' + langNames + ')(?:\\s+language)?$'))) ||
      (m = lc.match(new RegExp('^(?:please\\s+)?(?:speak|talk|reply|answer|respond|chat|converse)\\s+(?:to me\\s+)?(?:in\\s+)?(' + langNames + ')(?:\\s+language)?$'))) ||
      (m = lc.match(new RegExp('^(?:please\\s+)?(?:speak|talk|reply|answer|respond)\\s+(?:to me\\s+)?(?:in|using)\\s+(' + langNames + ')(?:\\s+(?:from now on|only|please))?$'))) ||
      (m = lc.match(new RegExp('^(' + langNames + ')\\s+(?:mode|please|language)$')))) {
    add(esc(raw), 'u'); setLang(J.langBy(m[1])); return true;
  }
  /* translate */
  if ((m = c.match(/^(?:please\s+)?translate(?:\s+(?:this|it|that))?\s*[:\-]?\s*(.*)$/i)) && /^translate\b/i.test(c.replace(/^please\s+/i, ''))) {
    var rest = m[1].trim(), tail;
    if (!rest) { var la = lastAnswerText(); if (la) { add(esc(raw), 'u'); pendL = { act: 'lang', text: la, t: Date.now() }; add('Translate my last answer into which language?', 'a'); return true; } add(esc(raw), 'u'); pendL = { act: 'text', to: J.langBy('en'), t: Date.now() }; add('What should I translate? Type or say it.', 'a'); return true; }
    tail = J.parseLangTail(rest);
    if (!tail && (p = rest.match(new RegExp('^(?:in|into|to)\\s+(' + langNames + ')$', 'i')))) { add(esc(raw), 'u'); var tl0 = J.langBy(p[1]); var la2 = lastAnswerText(); if (la2) translateCard(raw, la2, tl0, true); else { pendL = { act: 'text', to: tl0, t: Date.now() }; add('What should I translate into ' + tl0.name + '?', 'a'); } return true; }
    add(esc(raw), 'u');
    if (tail) { translateCard(raw, tail.text, tail.lang, true); return true; }
    var sc = J.scriptOf(rest); /* no target language: foreign text goes to English, English text asks for a language */
    if (sc && sc !== 'en') { translateCard(raw, J.unquote(rest), J.langBy('en'), true); return true; }
    pendL = { act: 'lang', text: J.unquote(rest), t: Date.now() }; add('Translate into which language?', 'a'); return true;
  }
  /* how do you say X in Y / say X in Y / what is X in Y */
  if ((m = c.match(/^(?:please\s+)?(?:how (?:do you|to|can i) say|what(?:'s| is) the word for|how do i say|say|tell me|read|speak|pronounce)\s+(.+)$/i)) && (tail = J.parseLangTail(m[1])) && !/^(?:my|the)?\s*(?:notes|tasks)/.test(tail.text)) {
    add(esc(raw), 'u'); translateCard(raw, tail.text, tail.lang, true); return true;
  }
  if ((m = lc.match(/^(?:what(?:'s| is)|what does|meaning of)\s+(.+?)(?:\s+mean)?$/)) && J.scriptOf(c) !== 'en' && J.scriptOf(c) !== '') {
    add(esc(raw), 'u'); translateCard(raw, J.unquote(c.replace(/^(?:what(?:'s| is)|what does|meaning of)\s+/i, '').replace(/\s+mean$/i, '')), J.langBy('en'), false); return true;
  }
  /* read aloud */
  if (/^(?:read|say|repeat|speak)\s+(?:that|it|this|the answer|the last answer|that again|it again|again|aloud|out loud|it aloud|that aloud)$/.test(lc) || /^read (?:aloud|out loud)$/.test(lc) || lc === 'repeat') {
    add(esc(raw), 'u'); var t = lastAnswerText(); if (!t) { add('There is nothing to read yet.', 'a'); return true; }
    var sl = J.scriptOf(t); var L3 = sl && sl !== 'en' ? J.langBy(sl) : curLang();
    if (!speakIn(t, L3.c)) add('<small>' + esc(noVoiceHint(L3)) + '</small>', 'a'); return true;
  }
  if ((m = c.match(/^(?:read|speak|say)\s+(?:aloud|out loud)?\s*[:\-]?\s*(.+)$/i)) && !/^(?:my\s+|the\s+|all\s+)?(?:notes?|tasks?|todos?|news|headlines|reminders?|alarms?|shopping list|expenses?|file)\b/i.test(m[1]) && /^(?:read|speak|say)\s/i.test(c)) {
    var tx = J.unquote(m[1]), tail2 = J.parseLangTail(tx);
    add(esc(raw), 'u');
    if (tail2) { translateCard(raw, tail2.text, tail2.lang, true); return true; }
    var s2 = J.scriptOf(tx), L4 = s2 && s2 !== 'en' ? J.langBy(s2) : curLang();
    if (!speakIn(tx, L4.c)) add('<small>' + esc(noVoiceHint(L4)) + '</small>', 'a'); else add('🔊 Reading in ' + L4.name + '…', 'a');
    return true;
  }
  return false;
}

/* ---------- any-language router ---------- */
var bypass = false;
function cleanCmd(o) {
  var l = String(o).split('\n').map(function (x) { return x.trim(); }).filter(Boolean)[0] || '';
  return l.replace(/^[`"'“]+|[`"'”]+$/g, '').replace(/^(?:command|output)\s*:\s*/i, '').trim();
}
function runInner(cmd, original) {
  var n0 = log.querySelectorAll('.row').length;
  bypass = true; window.__lexiRouted = true; try { window.handle(cmd); } finally { bypass = false; window.__lexiRouted = false; }
  var rows = [].slice.call(log.querySelectorAll('.row'), n0), u = rows.filter(function (r) { return r.classList.contains('u'); })[0];
  if (u) { var mm = u.querySelector('.m') || u; mm.innerHTML = esc(original) + '<div style="opacity:.55;font-size:12px;margin-top:2px">→ ' + esc(cmd) + '</div>'; }
  else { var e = add(esc(original), 'u'); }
}
function routeAny(raw) {
  var text = J.digitsASCII(raw);
  st.textContent = '🌐 Understanding…'; try { mood('think'); } catch (e) { }
  llm(J.ROUTER_PROMPT, text, 6000).then(function (out) {
    var cmd = cleanCmd(out);
    st.textContent = '';
    if (!cmd || /^ask\b/i.test(cmd)) { bypass = true; window.__lexiRouted = true; try { window.handle(raw); } finally { bypass = false; window.__lexiRouted = false; } return; }
    runInner(cmd, raw);
  }).catch(function () {
    st.textContent = '';
    var off = J.offlineNormalize(raw);
    if (off) return runInner(off, raw);
    bypass = true; window.__lexiRouted = true; try { window.handle(raw); } finally { bypass = false; window.__lexiRouted = false; }
  });
}
var prevH = window.handle;
window.handle = function (raw) {
  if (window.__JT_skip) return prevH(raw);
  var s = String(raw == null ? '' : raw);
  if (bypass) { if (langCommands(s)) return; return prevH(raw); }
  if (pendL || !(window.JT_pending && window.JT_pending())) { if (langCommands(s)) return; }
  if (window.JT_pending && window.JT_pending()) return prevH(raw);
  if (J.needsRouter(s)) return routeAny(s);
  return prevH(raw);
};

/* ---------- Read / Translate buttons under AI answers ---------- */
var tmr = null;
function decorate() {
  [].forEach.call(log.querySelectorAll('.row.a .m .src'), function (src) {
    if (src.querySelector('.jt-tools') || src.closest('.m').querySelector('.dots')) return;
    var box = mk('span', { 'class': 'jt-tools' });
    var m = src.closest('.m');
    function body() { var c = m.cloneNode(true); [].forEach.call(c.querySelectorAll('.src,button,select,.jt-tr'), function (x) { x.remove(); }); return c.innerText.trim(); }
    box.appendChild(btn('🔊 Read', function () { var t = body(), s = J.scriptOf(t), L = s && s !== 'en' ? J.langBy(s) : curLang(); if (!speakIn(t, L.c)) alert(noVoiceHint(L)); }, 'ib'));
    var sel = mk('select', { 'aria-label': 'Translate this answer' }); sel.style.cssText = 'border-radius:10px;padding:3px;margin-left:4px;max-width:130px';
    sel.appendChild(mk('option', { value: '', text: '🌐 Translate…' }));
    J.LANGS.forEach(function (l) { sel.appendChild(mk('option', { value: l.c, text: l.name })); });
    sel.onchange = function () { var l = J.langBy(sel.value); sel.value = ''; if (l) translateCard('', body(), l, false); };
    box.appendChild(sel);
    src.appendChild(box);
  });
}
new MutationObserver(function () { clearTimeout(tmr); tmr = setTimeout(decorate, 500); }).observe(log, { childList: true, subtree: true });

/* ---------- Translate & Read dialog ---------- */
var dlg = mk('dialog');
dlg.style.cssText = 'max-width:600px;width:94%;border:1px solid var(--bd);border-radius:14px;background:var(--card);color:var(--fg);max-height:90vh;overflow:auto';
document.body.appendChild(dlg);
function langSelect(withAuto, val) {
  var s = mk('select'); s.style.cssText = 'padding:8px;border-radius:12px;max-width:100%';
  if (withAuto) s.appendChild(mk('option', { value: 'auto', text: '🔎 Detect language' }));
  J.LANGS.forEach(function (l) { s.appendChild(mk('option', { value: l.c, text: l.name + ' – ' + l.l })); });
  s.value = val; return s;
}
function openTranslator(prefill) {
  dlg.innerHTML = '';
  dlg.appendChild(mk('h3', { text: '🌐 Translate & read aloud', style: 'margin:0 0 8px' }));
  var from = langSelect(true, 'auto'), to = langSelect(false, curLang().c === 'en' ? 'hi' : 'en');
  var row = mk('div'); row.style.cssText = 'display:flex;gap:6px;align-items:center;flex-wrap:wrap';
  var swap = btn('⇄', function () { if (from.value !== 'auto') { var a = from.value; from.value = to.value; to.value = a; } }, 'ib');
  row.appendChild(from); row.appendChild(swap); row.appendChild(to); dlg.appendChild(row);
  var ta = mk('textarea', { 'class': 'k', rows: '4', placeholder: 'Type, paste or speak text here…' }); ta.style.cssText = 'width:100%;margin-top:8px;box-sizing:border-box'; ta.value = prefill || '';
  dlg.appendChild(ta);
  var acts = mk('div');
  var out = mk('div', { style: 'margin-top:10px;white-space:pre-wrap' }), last = null;
  function srcL() { return from.value === 'auto' ? (J.scriptOf(ta.value) === 'en' ? J.langBy('en') : J.langBy(J.scriptOf(ta.value)) || J.langBy('en')) : J.langBy(from.value); }
  acts.appendChild(btn('🌐 Translate', function () {
    var t = ta.value.trim(); if (!t) { ta.focus(); return; }
    out.textContent = 'Translating…';
    translateText(t, J.langBy(to.value), from.value === 'auto' ? null : J.langBy(from.value)).then(function (r) {
      last = r; out.innerHTML = ''; out.appendChild(mk('div', { text: (r.from ? r.from + ' → ' : '') + J.langBy(to.value).name + ' · ' + r.engine, style: 'opacity:.65;font-size:12px' }));
      out.appendChild(mk('div', { text: r.t, style: 'font-size:20px;font-weight:650;margin:6px 0' }));
      if (r.pron) out.appendChild(mk('div', { text: r.pron, style: 'font-style:italic;opacity:.8' }));
    });
  }));
  acts.appendChild(btn('🔊 Listen translation', function () { if (last && !speakIn(last.t, to.value)) alert(noVoiceHint(J.langBy(to.value))); }));
  acts.appendChild(btn('🔊 Read original', function () { var L = srcL(); if (ta.value.trim() && !speakIn(ta.value, L.c)) alert(noVoiceHint(L)); }));
  acts.appendChild(btn('⏹ Stop', function () { try { speechSynthesis.cancel(); speaking = false; } catch (e) { } }));
  acts.appendChild(btn('📋 Copy', function () { try { navigator.clipboard.writeText(last ? last.t : ta.value); } catch (e) { } }));
  var SRC = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SRC) acts.appendChild(btn('🎤 Speak', function () {
    var r = new SRC(); r.lang = (srcL() || curLang()).s; r.interimResults = false;
    r.onresult = function (e) { ta.value = (ta.value ? ta.value + ' ' : '') + e.results[0][0].transcript; };
    try { r.start(); } catch (e) { }
  }));
  var fi = mk('input', { type: 'file', accept: '.txt,.md,.csv,text/plain', style: 'display:none' });
  fi.onchange = function () { var f = fi.files[0]; if (!f) return; var fr = new FileReader(); fr.onload = function () { ta.value = String(fr.result).slice(0, 20000); }; fr.readAsText(f); };
  acts.appendChild(btn('📄 Load text file', function () { fi.click(); })); acts.appendChild(fi);
  dlg.appendChild(acts); dlg.appendChild(out);
  dlg.appendChild(mk('hr'));
  dlg.appendChild(mk('b', { text: 'Assistant language' }));
  var al = langSelect(false, curLang().c); al.onchange = function () { setLang(J.langBy(al.value)); };
  var rw = mk('div'); rw.appendChild(al); dlg.appendChild(rw);
  var lab = mk('label', { style: 'display:block;margin-top:8px' }), cb = mk('input', { type: 'checkbox' }); cb.checked = !!LS.auto;
  cb.onchange = function () { LS.auto = cb.checked; sk('valang', LS); };
  lab.appendChild(cb); lab.appendChild(document.createTextNode(' Show and speak the assistant’s confirmations in this language too')); dlg.appendChild(lab);
  dlg.appendChild(mk('small', { html: 'Speak or type commands in any language: Hindi, Kannada, Tamil, Telugu, Hinglish and more. Understanding and translation use your AI key if set, otherwise a free online service (the text you type is sent to it).' }));
  var cl = btn('Close', function () { try { speechSynthesis.cancel(); } catch (e) { } dlg.close(); }); cl.style.background = 'var(--a)'; cl.style.color = '#fff'; cl.style.marginTop = '12px';
  dlg.appendChild(mk('div', {}, [cl]));
  if (!dlg.open) dlg.showModal();
}
(function ui() {
  var header = document.querySelector('header'), anchor = document.getElementById('clr');
  var b = mk('button', { 'class': 'ib', type: 'button', text: '🌐', title: 'Translate & read aloud', 'aria-label': 'Translate and read aloud' });
  b.onclick = function () { openTranslator(); }; header.insertBefore(b, anchor);
  var det = document.querySelectorAll('#panel details')[1];
  if (det) det.appendChild(mk('div', { html: '<p><b>🌐 Any language:</b> just speak or type in Hindi, Kannada, Tamil, Telugu… e.g. “कल सुबह 8 बजे अलार्म लगाओ”, “ಅಮ್ಮನಿಗೆ ಕರೆ ಮಾಡು”. · translate good morning to kannada · how do you say thank you in french · say where is the station in tamil · translate this to hindi · read that again · read aloud … · speak in hindi · switch to english</p>' }));
})();
})(typeof window !== 'undefined' ? window : globalThis);
