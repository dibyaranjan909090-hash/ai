/* Lexi models.js v25: always use an AI model that exists.
   AI companies retire model names (for example, new Gemini keys can no longer use the Gemini 2.5 models).
   With a key saved, Lexi asks each service which models it offers (once a day), picks the best one,
   and quietly replaces any retired model name in Lexi's requests. Works for Gemini, Groq and OpenAI. */
(function (root) {
'use strict';
var K = 'lexi_models';
function L(k, d) { try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } }
function S(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } }
var M = L(K, {});   /* { gemini: {key4, t, ids:[], best, lite}, groq: {...}, openai: {...} } */
var of = root.fetch.bind(root);
function k4(key) { return key ? String(key).slice(-4) : ''; }
function vnum(id) { var m = /(\d+(?:\.\d+)?)/.exec(id); return m ? parseFloat(m[1]) : 0; }

function pickGemini(models) {
  var ok = models.filter(function (m) { return (m.supportedGenerationMethods || []).indexOf('generateContent') >= 0; }).map(function (m) { return String(m.name).replace(/^models\//, ''); })
    .filter(function (id) { return /^gemini-/.test(id) && !/(image|tts|audio|live|embedding|vision|thinking-exp|computer|robotics|native)/.test(id); });
  function rank(id) { return vnum(id) * 10 + (/flash/.test(id) ? 3 : 0) - (/lite/.test(id) ? 2 : 0) - (/(preview|exp)/.test(id) ? 1 : 0) - (/pro/.test(id) ? 5 : 0); }
  ok.sort(function (a, b) { return rank(b) - rank(a); });
  var best = ok[0] || '', lite = ok.filter(function (id) { return /lite/.test(id); })[0] || best;
  return { ids: ok, best: best, lite: lite };
}
function pickGroq(list) {
  var ids = list.map(function (m) { return m.id; }).filter(function (id) { return id && !/(whisper|guard|tts|playai|distil|embed|prompt-guard|compound)/i.test(id); });
  function rank(id) { return (/(120b|maverick|70b|versatile|kimi|qwen3-32b)/i.test(id) ? 50 : 0) + vnum(id) - (/(8b|instant|mini|scout)/i.test(id) ? 5 : 0); }
  ids.sort(function (a, b) { return rank(b) - rank(a); });
  var fast = ids.filter(function (id) { return /(8b|instant|scout|20b)/i.test(id); })[0] || ids[0] || '';
  return { ids: ids, best: ids[0] || '', lite: fast };
}
function pickOpenAI(list) {
  var ids = list.map(function (m) { return m.id; }).filter(function (id) { return /^(gpt-|o\d)/.test(id) && !/(audio|realtime|tts|transcribe|image|search|instruct|vision|embedding|codex)/.test(id); });
  var minis = ids.filter(function (id) { return /mini/.test(id) && !/nano/.test(id); }).sort(function (a, b) { return vnum(b) - vnum(a); });
  return { ids: ids, best: minis[0] || ids[0] || '', lite: minis[0] || '' };
}
function discover(force) {
  var C = root.CFG || {}, jobs = [], now = Date.now();
  function fresh(p, key) { var x = M[p]; return !force && x && x.key4 === k4(key) && now - x.t < 864e5 && x.ids && x.ids.length; }
  if (C.gk && !fresh('gemini', C.gk)) jobs.push(of('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=' + encodeURIComponent(C.gk)).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { M.gemini = Object.assign(pickGemini(j.models || []), { key4: k4(C.gk), t: now }); }).catch(function (e) { M.gemini = { key4: k4(C.gk), t: now, ids: [], err: String(e) }; }));
  if (C.grk && !fresh('groq', C.grk)) jobs.push(of('https://api.groq.com/openai/v1/models', { headers: { authorization: 'Bearer ' + C.grk } }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { M.groq = Object.assign(pickGroq(j.data || []), { key4: k4(C.grk), t: now }); }).catch(function (e) { M.groq = { key4: k4(C.grk), t: now, ids: [], err: String(e) }; }));
  if (C.ok && !fresh('openai', C.ok)) jobs.push(of('https://api.openai.com/v1/models', { headers: { authorization: 'Bearer ' + C.ok } }).then(function (r) { if (!r.ok) throw r.status; return r.json(); }).then(function (j) { M.openai = Object.assign(pickOpenAI(j.data || []), { key4: k4(C.ok), t: now }); }).catch(function (e) { M.openai = { key4: k4(C.ok), t: now, ids: [], err: String(e) }; }));
  return Promise.all(jobs).then(function () { S(K, M); return M; });
}

/* replace a retired model name in any request Lexi makes */
var GEM = /(generativelanguage\.googleapis\.com\/v1beta\/models\/)([^:/?]+)(:(?:stream)?generateContent)/i;
function fix(url, o) {
  var g = M.gemini, m;
  if (g && g.ids && g.ids.length && (m = GEM.exec(url)) && g.ids.indexOf(m[2]) < 0 && /^gemini-/.test(m[2]) && !/(image|tts|audio)/.test(m[2])) {
    var to = /lite/.test(m[2]) ? g.lite : g.best;
    if (to) url = url.replace(GEM, '$1' + to + '$3');
  }
  if (o && typeof o.body === 'string' && /api\.groq\.com|api\.openai\.com/.test(url)) {
    var P = /groq/.test(url) ? M.groq : M.openai;
    if (P && P.ids && P.ids.length) {
      try {
        var b = JSON.parse(o.body);
        if (b.model && P.ids.indexOf(b.model) < 0 && !/(whisper|tts|dall-e|gpt-image|embedding)/.test(b.model)) {
          b.model = /(8b|instant|mini|nano)/.test(b.model) && P.lite ? P.lite : P.best;
          if (b.model) o = Object.assign({}, o, { body: JSON.stringify(b) });
        }
      } catch (e) { }
    }
  }
  return [url, o];
}
root.fetch = function (u, o) {
  try { if (typeof u === 'string' && /generativelanguage|api\.groq\.com|api\.openai\.com/.test(u) && !/\/models(\?|$)/.test(u)) { var r = fix(u, o); u = r[0]; o = r[1]; } } catch (e) { }
  return of(u, o);
};

root.lexiModels = { discover: discover, info: function () { return M; }, fix: fix, _pick: { gemini: pickGemini, groq: pickGroq, openai: pickOpenAI } };
setTimeout(function () { discover(false); }, 1500);
})(window);
